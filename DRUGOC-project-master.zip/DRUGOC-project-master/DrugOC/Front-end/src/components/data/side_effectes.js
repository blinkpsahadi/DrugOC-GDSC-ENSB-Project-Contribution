export default [
{"name" : "5'nucléotidase augmentée"},
{"name" : " Abasie"},
{"name" : " Abcès abdominal"},
{"name" : " Adhérences abdominales"},
{"name" : " Anévrisme de l'aorte abdominale"
},
{"name" : " Bruit aortique abdominal"
},
{"name" : " Rupture aortique abdominale"
},
{"name" : " Ballonnements abdominaux"
},
{"name" : " Colique abdominale"
},
{"name" : " Crampes abdominales"
},
{"name" : " Douleur abdominale"
},
{"name" : " Trouble abdominal"
},
{"name" : " Distension abdominal"
},
{"name" : " Distension abdominale gazeuse"
},
{"name" : " Détresse abdominale"
},
{"name" : " Hernie abdominale"
},
{"name" : " Infection abdominale"
},
{"name" : " Blessure abdominale"
},
{"name" : " Néoplasme abdominal"
},
{"name" : " Douleur abdominale"
},
{"name" : " Douleur abdominale aggravée"
},
{"name" : " Douleur abdominale généralisée"
},
{"name" : " Douleur abdominale localisée"
},
{"name" : " Douleur abdominale inférieure"
},
{"name" : " Douleur abdominale supérieure"
},
{"name" : " Rigidité abdominale"
},
{"name" : " Septicémie abdominale"
},
{"name" : " Spasme abdominal"
},
{"name" : " Hernie étranglée abdominale"
},
{"name" : " Symptôme abdominal"
},
{"name" : " Sensibilité abdominale"
},
{"name" : " Abcès de la paroi abdominale"
},
{"name" : " Comportement anormal"
},
{"name" : " Bruits intestinaux anormaux"
},
{"name" : " Sons thoraciques anormaux SAI"
},
{"name" : " Facteur de coagulation anormal"
},
{"name" : " Rêves anormaux"
},
{"name" : " Éjaculation anormale"
},
{"name" : " Mouvements oculaires anormaux SAI"
},
{"name" : " Fèces anormales"
},
{"name" : " Mouvements involontaires anormaux"
},
{"name" : " Accouchement anormal"
},
{"name" : " Pigmentation anormale"
},
{"name" : " Plaquettes anormales"
},
{"name" : " Sensation anormale dans l'?il"
},
{"name" : " Événement anormal lié au sommeil"
},
{"name" : " Vision anormale"
},
{"name" : " Saignement de sevrage anormal"
},
{"name" : " Anomalies des cheveux"
},
{"name" : " Avortement"
},
{"name" : " Avortement incomplet"
},
{"name" : " Avortement infecté"
},
{"name" : " Avortement manqué"
},
{"name" : " Avortement spontané"
},
{"name" : " Abrasion NOS"
},
{"name" : " Abcès"
},
{"name" : " Abcès d'un membre"
},
{"name" : " Abcès parodontal"
},
{"name" : " Abcès stérile"
},
{"name" : " Abcès cutanés"
},
{"name" : " Absence congénitale"
},
{"name" : " Nombre absolu de neutrophiles diminué"
},
{"name" : " Cholécystite acalculeuse"
},
{"name" : " Kératite à Acanthamoeba"
},
{"name" : " Acanthosis nigricans"
},
{"name" : " Acarodermatite"
},
{"name" : " Chute de cheveux accélérée"
},
{"name" : " Accident"
},
{"name" : " Accident à domicile"
},
{"name" : " Exposition accidentelle à un produit"
},
{"name" : " Ingestion accidentelle"
},
{"name" : " Blessure accidentelle"
},
{"name" : " Surdosage accidentel"
},
{"name" : " Trouble de l'accommodation"
},
{"name" : " Composant accommodatif dans l'ésotropie"
},
{"name" : " Acétonémie"
},
{"name" : " Douleur"
},
{"name" : " Poignets douloureux"
},
{"name" : " Achlorhydrie"
},
{"name" : " Acholie"
},
{"name" : " Indigestion gastrique"
},
{"name" : " Phosphatase acide élevée"
},
{"name" : " Troubles acido-basiques"
},
{"name" : " Acidémie"
},
{"name" : " Acidose"
},
{"name" : " Acidose hyperchlorémique"
},
{"name" : " Acné"
},
{"name" : " Acné conglobata"
},
{"name" : " Acné kystique"
},
{"name" : " Acné fulminans"
},
{"name" : " Acné infantile"
},
{"name" : " Acné pustuleuse"
},
{"name" : " Acné vulgaire"
},
{"name" : " Éruption acnéiforme"
},
{"name" : " Hémophilie acquise"
},
{"name" : " Anémie hémolytique acquise"
},
{"name" : " Syndrome immunodéficitaire acquis"
},
{"name" : " Kératodermie acquise"
},
{"name" : " Diabète lipoatrophique acquis"
},
{"name" : " Mégacôlon acquis"
},
{"name" : " Cécité nocturne acquise"
},
{"name" : " Érythème acral"
},
{"name" : " Acrochordon"
},
{"name" : " Acrocyanose"
},
{"name" : " Acrodynie"
},
{"name" : " Acromégalie"
},
{"name" : " Élastose actinique"
},
{"name" : " Kératose actinique"
},
{"name" : " Actinomycose"
},
{"name" : " Tremblement d'action"
},
{"name" : " Temps d'activation de thromboplastine partielle prolongé"
},
{"name" : " Temps d'activation de thromboplastine partielle raccourci"
},
{"name" : " Syndrome d'activation"
},
{"name" : " Tuberculose active"
},
{"name" : " Syndrome abdominal aigu"
},
{"name" : " Réaction allergique aiguë"
},
{"name" : " Rejet aigu d'une allogreffe"
},
{"name" : " Anaphylaxie aiguë"
},
{"name" : " Glaucome aigu à angle fermé"
},
{"name" : " Appendicite aiguë"
},
{"name" : " Bronchite aiguë"
},
{"name" : " Toxicité cardiaque aiguë"
},
{"name" : " Douleur thoracique aiguë"
},
{"name" : " Syndrome thoracique aiguë"
},
{"name" : " Hépatite cholestatique aiguë"
},
{"name" : " État confusionnel aigu"
},
{"name" : " Conjonctivite aiguë"
},
{"name" : " Syndrome coronarien aigu"
},
{"name" : " Cystite aiguë"
},
{"name" : " Hépatite cytolytique aiguë"
},
{"name" : " Dépression aiguë"
},
{"name" : " Diarrhée aiguë"
},
{"name" : " Encéphalomyélite aiguë disséminée"
},
{"name" : " Ulcère duodénal aigu"
},
{"name" : " Dyspnée aiguë"
},
{"name" : " Dystonie aiguë"
},
{"name" : " Entérocolite aiguë"
},
{"name" : " Exacerbation aiguë de bronchite chronique"
},
{"name" : " Foie gras aigu"
},
{"name" : " Maladie fébrile aiguë"
},
{"name" : " Dermatose neutrophile fébrile aiguë"
},
{"name" : " Gastrite aiguë"
},
{"name" : " Gastro-entérite aiguë"
},
{"name" : " Pustulose exanthémateuse généralisée aiguë"
},
{"name" : " Glaucome aigu"
},
{"name" : " Rejet aigu de greffe"
},
{"name" : " Réaction aiguë du greffon contre l'hote"
},
{"name" : " Anémie hémolytique aiguë"
},
{"name" : " Hémorragie aiguë"
},
{"name" : " Insuffisance hépatique aiguë"
},
{"name" : " Hépatite B aiguë"
},
{"name" : " Hypotension aiguë"
},
{"name" : " Néphrite interstitielle aiguë"
},
{"name" : " Pneumonie interstitielle aiguë"
},
{"name" : " Lésion rénale aiguë"
},
{"name" : " Insuffisance aiguë du ventricule gauche"
},
{"name" : " Leucémie aiguë"
},
{"name" : " Dommages hépatiques aigus"
},
{"name" : " Lésion hépatique aiguë"
},
{"name" : " Leucémie lymphoïde aiguë"
},
{"name" : " Sinusite maxillaire aiguë"
},
{"name" : " Migraine aiguë"
},
{"name" : " Leucémie myéloïde aiguë"
},
{"name" : " Leucémie myélomonocytaire aiguë"
},
{"name" : " Infarctus aigu du myocarde"
},
{"name" : " Ischémie myocardique aiguë"
},
{"name" : " Néphrite aiguë"
},
{"name" : " Surdosage aigu"
},
{"name" : " Douleur aiguë"
},
{"name" : " Pharyngite aiguë"
},
{"name" : " Réaction en phase aiguë"
},
{"name" : " Néphropathie aiguë au phosphate"
},
{"name" : " Pneumonie aiguë"
},
{"name" : " Insuffisance prérénale aiguë"
},
{"name" : " Leucémie promyélocytaire aiguë"
},
{"name" : " Syndrome de différenciation de la leucémie promyélocytaire aiguë"
},
{"name" : " Prostatite aiguë"
},
{"name" : " Psychose aiguë"
},
{"name" : " Oedème pulmonaire aigu"
},
{"name" : " Insuffisance rénale aiguë"
},
{"name" : " Syndrome de détresse respiratoire aiguë"
},
{"name" : " Insuffisance respiratoire aiguë"
},
{"name" : " Insuffisance respiratoire aiguë"
},
{"name" : " Rétention aiguë d'urine"
},
{"name" : " Schizophrénie aiguë"
},
{"name" : " Sinusite aiguë"
},
{"name" : " Trouble de stress aigu"
},
{"name" : " Otite externe aiguë"
},
{"name" : " Amygdalite aiguë"
},
{"name" : " Colite ulcéreuse aiguë"
},
{"name" : " Urticaire aiguë"
},
{"name" : " Uvéite aiguë"
},
{"name" : " Atrophie jaune aiguë du foie"
},
{"name" : " Syndrome d'Adams-Stokes"
},
{"name" : " Maladie d'Addison"
},
{"name" : " Adénite"
},
{"name" : " Adénocarcinome"
},
{"name" : " Adénocarcinome gastrique"
},
{"name" : " Adénocarcinome de la prostate"
},
{"name" : " Adénocarcinome de la jonction gastro-?sophagienne"
},
{"name" : " Adénocarcinome de la prostate métastatique"
},
{"name" : " Adénocarcinome pancréatique"
},
{"name" : " Adénome bénin"
},
{"name" : " Polypose adénomateuse colique"
},
{"name" : " Adénomyose"
},
{"name" : " Infection à adénovirus"
},
{"name" : " ADHF"
},
{"name" : " Adhésion"
},
{"name" : " Trouble de l'adaptation"
},
{"name" : " Infection au site d'administration"
},
{"name" : " Réaction au site d'administration"
},
{"name" : " Kyste de l'annexe utérine"
},
{"name" : " Masse à l'annexe utérine"
},
{"name" : " Douleur de l'annexe utérine"
},
{"name" : " Torsion annexielle"
},
{"name" : " Annexite"
},
{"name" : " Adénome surrénalien"
},
{"name" : " Atrophie surrénale"
},
{"name" : " Carcinome surrénalien"
},
{"name" : " Atrophie du cortex surrénal"
},
{"name" : " Hypofonction corticale surrénale"
},
{"name" : " Trouble surrénalien"
},
{"name" : " Cancer de la glande surrénale"
},
{"name" : " Hémorragie surrénale"
},
{"name" : " Insuffisance surrénale"
},
{"name" : " Tumeur surrénale"
},
{"name" : " Syndrome adrénergique"
},
{"name" : " Carcinome corticosurrénalien"
},
{"name" : " Insuffisance corticosurrénale aiguë"
},
{"name" : " Carence en hormone adrénocorticotrope"
},
{"name" : " Syndrome surrénogénital"
},
{"name" : " Cancer avancé du sein "
},
{"name" : " Cancer avancé"
},
{"name" : " Réaction indésirable"
},
{"name" : " Aérophagie"
},
{"name" : " État affectif élémentaire"
},
{"name" : " Trouble affectif"
},
{"name" : " Trypanosomiase africaine"
},
{"name" : " Agammaglobulinémie"
},
{"name" : " AGEP"
},
{"name" : " Dégénérescence maculaire liée à l'âge"
},
{"name" : " Ageusie"
},
{"name" : " Aggravation d'un trouble existant"
},
{"name" : " Agression"
},
{"name" : " Réaction agressive"
},
{"name" : " Mastocytose systémique agressive"
},
{"name" : " Dépression agitée"
},
{"name" : " Agitation"
},
{"name" : " Agitation postopératoire"
},
{"name" : " Agnosie"
},
{"name" : " Agoraphobie"
},
{"name" : " Agranulocytose"
},
{"name" : " Complexe de la démence du SIDA"
},
{"name" : " AION"
},
{"name" : " Complication des voies respiratoires due à l'anesthésie"
},
{"name" : " Oedème des voies respiratoires"
},
{"name" : " Obstruction des voies respiratoires SAI"
},
{"name" : " Akathisie"
},
{"name" : " Akinesthésie"
},
{"name" : " Akinésie"
},
{"name" : " Crises akinétiques"
},
{"name" : " Alanine aminotransférase anormale"
},
{"name" : " Alanine aminotransférase diminuée"
},
{"name" : " Alanine aminotransférase augmentée"
},
{"name" : " Alanine aminotransférase normale"
},
{"name" : " Albinisme"
},
{"name" : " Maladie d'Albright"
},
{"name" : " Rapport globuline-albumine anormal"
},
{"name" : " Albumine haute"
},
{"name" : " Albumine faible"
},
{"name" : " Augmentation d'albumine de l'urine"
},
{"name" : " Présence d'albumine de l'urine"
},
{"name" : " Albuminurie"
},
{"name" : " Abus d'alcool"
},
{"name" : " Envie d'alcool"
},
{"name" : " Intolérance à l'alcool"
},
{"name" : " Intoxication à l'alcool"
},
{"name" : " Empoisonnement à l'alcool"
},
{"name" : " Problème d'alcool"
},
{"name" : " Syndrome de sevrage alcoolique"
},
{"name" : " Maladie alcoolique du foie"
},
{"name" : " Pancréatite alcoolique"
},
{"name" : " Psychose alcoolique"
},
{"name" : " Alcoolisme"
},
{"name" : " Aldostérone faible"
},
{"name" : " Vigilance diminué"
},
{"name" : " Algodystrophie"
},
{"name" : " Alcaliémie"
},
{"name" : " Augmentation du sérum de phosphatase alcaline"
},
{"name" : " Alcalose"
},
{"name" : " Alcalose hypochlorémique"
},
{"name" : " Alcalose hypokaliémique"
},
{"name" : " Asthme allergique"
},
{"name" : " Bronchite allergique"
},
{"name" : " Bronchospasme allergique"
},
{"name" : " Conditions allergiques"
},
{"name" : " Dermatite allergique de contact"
},
{"name" : " Angiite cutanée allergique"
},
{"name" : " Exanthème allergique"
},
{"name" : " Angiite granulomateuse allergique"
},
{"name" : " Hépatite allergique"
},
{"name" : "dème allergique"
},
{"name" : " Éruption allergique"
},
{"name" : " Sinusite allergique"
},
{"name" : " Réaction allergique cutanée"
},
{"name" : " Urticaire allergique"
},
{"name" : " Allergie aggravée"
},
{"name" : " Allergie aux noix"
},
{"name" : " Allodynie"
},
{"name" : " Alopécie"
},
{"name" : " Alopécie areata"
},
{"name" : " Alopécie réversible"
},
{"name" : " État de conscience altéré"
},
{"name" : " Perception de la profondeur visuelle altérée"
},
{"name" : " Surcharge en aluminium"
},
{"name" : " Ostéite alvéolaire"
},
{"name" : " Protéinose alvéolaire"
},
{"name" : " Alvéolite"
},
{"name" : " Alvéolite allergique"
},
{"name" : " Amaurose"
},
{"name" : " Amaurosis fugax"
},
{"name" : " Amblyopie"
},
{"name" : " Tabac d'amblyopie"
},
{"name" : " Amelie"
},
{"name" : " Aménorrhée secondaire"
},
{"name" : " Aménorrhée"
},
{"name" : " Trouble du métabolisme des acides aminés"
},
{"name" : " Aminoacidurie"
},
{"name" : " Progression de la LMA"
},
{"name" : " Ammoniac augmenté"
},
{"name" : " Amnésie"
},
{"name" : " Amnésie transitoire"
},
{"name" : " Symptômes amnésiques"
},
{"name" : " Infection de la cavité amniotique"
},
{"name" : " Embolie du liquide amniotique"
},
{"name" : " Amibiase"
},
{"name" : " Colite amibienne"
},
{"name" : " Amylase diminuée"
},
{"name" : " Amylase augmentée"
},
{"name" : " Amylose"
},
{"name" : " Sclérose latérale amyotrophique"
},
{"name" : " ANA augmenté"
},
{"name" : " Anémie"
},
{"name" : " Anémie SAI aggravée"
},
{"name" : " Anémie macrocytaire"
},
{"name" : " Anémie mégaloblastique"
},
{"name" : " Anémie néonatale"
},
{"name" : " Anémie de grossesse"
},
{"name" : " Anémie postopératoire"
},
{"name" : " Anémie pernicieuse"
},
{"name" : " Anaemias NEC"
},
{"name" : " Immunité hémolytique aux anémies"
},
{"name" : " Complication anesthésique"
},
{"name" : " Complication anesthésique neurologique"
},
{"name" : " Abcès anal"
},
{"name" : " Atrésie anale"
},
{"name" : " Cancer anal"
},
{"name" : " Candidose anale"
},
{"name" : " Gêne anale"
},
{"name" : " Fissure anale"
},
{"name" : " Fistule anale"
},
{"name" : " Hémorragie anale"
},
{"name" : " Inflammation anale"
},
{"name" : " Irritation anale"
},
{"name" : " Prurit anal"
},
{"name" : " Acrochordons anaux"
},
{"name" : " Spasme anal"
},
{"name" : " Atonie du sphincter anal"
},
{"name" : " Syndrome d'asthme analgésique"
},
{"name" : " Effet analgésique"
},
{"name" : " Thérapie analgésique"
},
{"name" : " Réponses anaphylactiques"
},
{"name" : " Choc anaphylactique"
},
{"name" : " Réaction anaphylactoïde"
},
{"name" : " Syndrome anaphylactoïde de la grossesse"
},
{"name" : " Astrocytome anaplasique"
},
{"name" : " Lymphome anaplasique à grandes cellules"
},
{"name" : " Cancer de la thyroïde anaplasique"
},
{"name" : " Fuite anastomotique"
},
{"name" : " Ulcère anastomotique"
},
{"name" : " Carence en androgènes"
},
{"name" : " Alopécie androgénétique"
},
{"name" : " Anémique"
},
{"name" : " Anencéphalie"
},
{"name" : " Anévrisme"
},
{"name" : " Colère"
},
{"name" : " Angiite nécrosante"
},
{"name" : " Angine decubitus"
},
{"name" : " Angine de poitrine"
},
{"name" : " Angine de poitrine aggravée"
},
{"name" : " Symptôme d'angine"
},
{"name" : " Angine instable"
},
{"name" : " Attaque angulaire"
},
{"name" : " Angiodermatite"
},
{"name" : " Angioedème"
},
{"name" : " Angioedème du larynx"
},
{"name" : " Lymphome angio-immunoblastique à cellules T"
},
{"name" : " Angiomyolipome"
},
{"name" : " Angiopathie"
},
{"name" : " Glaucome à angle fermé"
},
{"name" : " Cheilite angulaire"
},
{"name" : " Anhédonie"
},
{"name" : " Anhidrose"
},
{"name" : " Morsure d'animal"
},
{"name" : " Égratignure animale"
},
{"name" : " Écart anionique augmenté"
},
{"name" : " Anisocytose"
},
{"name" : "?dème de la cheville"
},
{"name" : " Fracture de la cheville"
},
{"name" : " Entorse de la cheville"
},
{"name" : " Spondylarthrite ankylosante"
},
{"name" : " Verrues anogénitales"
},
{"name" : " Anophtalmie"
},
{"name" : " Gêne anorectale"
},
{"name" : " Trouble anorectal"
},
{"name" : " Infection par le papillomavirus humain anorectal"
},
{"name" : " Infection anorectale"
},
{"name" : " Anorexie"
},
{"name" : " Anorexie nerveuse"
},
{"name" : " Anorgasmie"
},
{"name" : " L'anosmie"
},
{"name" : " Anosognosie"
},
{"name" : " Anovulation"
},
{"name" : " Cycle anovulatoire"
},
{"name" : " Anoxie"
},
{"name" : " Hémorragie antepartum"
},
{"name" : " Cellule de la chambre antérieure"
},
{"name" : " Évasement de la chambre antérieure"
},
{"name" : " Inflammation de la chambre antérieure"
},
{"name" : " Pigmentation de la chambre antérieure"
},
{"name" : " Maladie des cellules de la corne antérieure"
},
{"name" : " Neuropathie optique ischémique antérieure"
},
{"name" : " Infarctus du myocarde antérieur"
},
{"name" : " Syndrome de l'artère spinale antérieure"
},
{"name" : " Uvéite antérieure"
},
{"name" : " Amnésie antérograde"
},
{"name" : " Anthrax"
},
{"name" : " Anticorps anti-thyroïdien positif"
},
{"name" : " Colite associée aux antibiotiques"
},
{"name" : " Diarrhée associée aux antibiotiques"
},
{"name" : " Anticorps NOS négatif"
},
{"name" : " Test d'anticorps négatif"
},
{"name" : " Test d'anticorps positif"
},
{"name" : " Syndrome anticholinergique"
},
{"name" : " Antidiurèse"
},
{"name" : " Anomalie de l'hormone antidiurétique"
},
{"name" : " Anticorps cytoplasmique antineutrophile positif"
},
{"name" : " Augmentation des anticorps antinucléaires"
},
{"name" : " Anticorps antinucléaires positifs"
},
{"name" : " Comportement anti-social"
},
{"name" : " Trouble antisocial de la personnalité "
},
{"name" : " Thérapie antitussive"
},
{"name" : " Anurie"
},
{"name" : " Trouble de l'anus"
},
{"name" : " Anxiété"
},
{"name" : " Anxiété NEC"
},
{"name" : " Anxiété aggravée"
},
{"name" : " Crise d'angoisse"
},
{"name" : " Anxiété dépression"
},
{"name" : " Trouble anxieux"
},
{"name" : " Névrose d'anxiété"
},
{"name" : " État d'anxiété"
},
{"name" : " Symptômes d'anxiété SAI"
},
{"name" : " Humeur anxieuse"
},
{"name" : " Anévrisme aortique"
},
{"name" : " Rupture d'un anévrisme aortique"
},
{"name" : " Artériosclérose aortique"
},
{"name" : " Bruit aortique"
},
{"name" : " Trouble aortique"
},
{"name" : " Dissection de l'aorte"
},
{"name" : " Embolie aortique"
},
{"name" : " Rupture aortique"
},
{"name" : " Incompétence valvulaire aortique"
},
{"name" : " Sclérose valvulaire aortique"
},
{"name" : " Sténose valvulaire aortique"
},
{"name" : " Apathie"
},
{"name" : " Score d'Apgar faible"
},
{"name" : " Aphagie"
},
{"name" : " Aphakia"
},
{"name" : "dème maculaire cystoïde aphaque"
},
{"name" : " Aphasie"
},
{"name" : " Aphonie"
},
{"name" : " Stomatite aphteuse"
},
{"name" : " Aplasie"
},
{"name" : " Aplasia cutis congénitale"
},
{"name" : " Aplasie des globules rouges purs"
},
{"name" : " Anémie aplasique"
},
{"name" : " Apnée"
},
{"name" : " Apnée néonatale"
},
{"name" : " Troubles des glandes apocrines et eccrines"
},
{"name" : " Apoptose"
},
{"name" : " Appendicite"
},
{"name" : " Appétit absent"
},
{"name" : " Trouble de l'appétit"
},
{"name" : " Appétit exagéré"
},
{"name" : " Réactions au site d'application et d'instillation"
},
{"name" : " Anesthésie au site d'application"
},
{"name" : " Atrophie du site d'application"
},
{"name" : " Brûlure au site d'application"
},
{"name" : " Cellulite au site d'application"
},
{"name" : " Décharge au site d'application"
},
{"name" : " Décoloration du site d'application"
},
{"name" : " Gêne au site d'application"
},
{"name" : " Sécheresse du site d'application"
},
{"name" : " Eczéma au site d'application"
},
{"name" : " Érosion du site d'application"
},
{"name" : " Érythème au site d'application"
},
{"name" : " Excoriation du site d'application"
},
{"name" : " Exfoliation du site d'application"
},
{"name" : " Folliculite au site d'application"
},
{"name" : " Hématome au site d'application"
},
{"name" : " Hémorragie au site d'application"
},
{"name" : " Hyperesthésie au site d'application"
},
{"name" : " Hypersensibilité au site d'application"
},
{"name" : " Induration du site d'application"
},
{"name" : " Infection du site d'application"
},
{"name" : " Inflammation au site d'application"
},
{"name" : " Irritation au site d'application"
},
{"name" : " Oedème au site d'application"
},
{"name" : " Douleur au site d'application"
},
{"name" : " Papules du site d'application"
},
{"name" : " Paresthésie au site d'application"
},
{"name" : " Modifications de la pigmentation du site d'application"
},
{"name" : " Prurit au site d'application"
},
{"name" : " Pustules au site d'application"
},
{"name" : " Éruption cutanée au site d'application"
},
{"name" : " Réaction au site d'application"
},
{"name" : " Gale du site d'application"
},
{"name" : " Cicatrice du site d'application"
},
{"name" : " Dégradation cutanée au site d'application"
},
{"name" : " Piqûre au site d'application"
},
{"name" : " Gonflement au site d'application"
},
{"name" : " Ulcère au site d'application"
},
{"name" : " Urticaire au site d'application"
},
{"name" : " Vésicules au site d'application"
},
{"name" : " Chaleur du site d'application"
},
{"name" : " Appréhension"
},
{"name" : " Apraxie"
},
{"name" : " Arachnoïdite"
},
{"name" : " Arcus juvenilis"
},
{"name" : " Arcus lipoides"
},
{"name" : " Arcus senilis"
},
{"name" : " Aréflexie"
},
{"name" : " Déficit en argininosuccinate synthétase"
},
{"name" : " Argumentativité"
},
{"name" : " Arythmie"
},
{"name" : " Arythmie supraventriculaire"
},
{"name" : " Anévrisme artériel"
},
{"name" : " Anomalie artérielle"
},
{"name" : " Trouble artériel"
},
{"name" : " Insuffisance artérielle"
},
{"name" : " Occlusion artérielle"
},
{"name" : " Maladie occlusive artérielle"
},
{"name" : " Spasme artériel"
},
{"name" : " Sténose artérielle d'un membre"
},
{"name" : " Thromboembolie artérielle"
},
{"name" : " Thrombose artérielle"
},
{"name" : " Artériosclérose"
},
{"name" : " Artériosclérose de l'artère coronaire"
},
{"name" : " Artériosclérose oblitérante"
},
{"name" : " Rétinopathie artériosclérotique"
},
{"name" : " Artériospasme coronaire"
},
{"name" : " Fistule artérioveineuse"
},
{"name" : " Thrombose de la fistule artérioveineuse"
},
{"name" : " Malformation artérioveineuse"
},
{"name" : " Neuropathie optique ischémique antérieure artéritique"
},
{"name" : " Artérite"
},
{"name" : " Dissection artérielle"
},
{"name" : " Arthralgie"
},
{"name" : " Arthralgie aggravée"
},
{"name" : " Arthralgie de l'articulation temporo-mandibulaire"
},
{"name" : " Douleurs arthritiques"
},
{"name" : " Arthrite"
},
{"name" : " Arthrite aggravée"
},
{"name" : " Arthrite bactérienne"
},
{"name" : " Arthrite infectieuse"
},
{"name" : " Arthropathie"
},
{"name" : " Morsure d'arthropode"
},
{"name" : " Piqûre d'arthropode"
},
{"name" : " Coagulation rénale artificielle pendant la dialyse"
},
{"name" : " Ménopause artificielle"
},
{"name" : " Ascariasis"
},
{"name" : " Ascite"
},
{"name" : " Ascite chyleuse"
},
{"name" : " Nécrose aseptique"
},
{"name" : " Nécrose aseptique osseuse"
},
{"name" : " Péritonite aseptique"
},
{"name" : " Comportement asocial"
},
{"name" : " Diminution de l'aspartate aminotransférase "
},
{"name" : " Augmentation de l'aspartate aminotransférase"
},
{"name" : " Aspartate aminotransférase normale"
},
{"name" : " Aspergillome"
},
{"name" : " Aspergillose"
},
{"name" : " Infection à Aspergillus"
},
{"name" : " Aspermie"
},
{"name" : " Asphyxie"
},
{"name" : " Aspiration"
},
{"name" : " Pneumopathie par aspiration"
},
{"name" : " Asplénie"
},
{"name" : " Agression"
},
{"name" : " Fécondation assistée"
},
{"name" : " Asteatosis"
},
{"name" : " Astérixis"
},
{"name" : " Asthénie"
},
{"name" : " Conditions asthéniques"
},
{"name" : " Asthénopie"
},
{"name" : " Asthme"
},
{"name" : " Asthme aggravé"
},
{"name" : " Asthme sensible à l'aspirine"
},
{"name" : " Asthme chronique"
},
{"name" : " Exercice de l'asthme induit"
},
{"name" : " Apparition tardive de l'asthme"
},
{"name" : " Attaque asthmatique"
},
{"name" : " Astrocytome"
},
{"name" : " Astrocytome, bas grade"
},
{"name" : " Bactériurie asymptomatique"
},
{"name" : " Hyperlactatémie asymptomatique"
},
{"name" : " Ataxie"
},
{"name" : " Démarche ataxique"
},
{"name" : " Atélectasie"
},
{"name" : " Athérome"
},
{"name" : " Athérosclérose"
},
{"name" : " Athérosclérose cérébrale"
},
{"name" : " Athérothrombose"
},
{"name" : " Athétose"
},
{"name" : " Atonie"
},
{"name" : " Crises atoniques"
},
{"name" : " Vessie urinaire atonique"
},
{"name" : " Rhinite atopique"
},
{"name" : " Atopie"
},
{"name" : " Atrésie biliaire"
},
{"name" : " Arythmie auriculaire"
},
{"name" : " Fibrillation auriculaire"
},
{"name" : " Fibrillation auriculaire et flutter"
},
{"name" : " Flutter auriculaire"
},
{"name" : " Hypertrophie auriculaire"
},
{"name" : " Pression auriculaire"
},
{"name" : " Rythme auriculaire"
},
{"name" : " Défaut septal auriculaire"
},
{"name" : " Tachycardie auriculaire"
},
{"name" : " Bloc auriculo-ventriculaire"
},
{"name" : " Bloc auriculo-ventriculaire complet"
},
{"name" : " Bloc auriculo-ventriculaire premier degré"
},
{"name" : " Bloc auriculo-ventriculaire deuxième degré"
},
{"name" : " Dissociation auriculo-ventriculaire"
},
{"name" : " Glossite atrophique"
},
{"name" : " Vulvovaginite atrophique"
},
{"name" : " Atrophie"
},
{"name" : " Atrophie de la vulve"
},
{"name" : " Difficulté de concentration de l'attention"
},
{"name" : " Trouble déficitaire de l'attention"
},
{"name" : " Déficit d'attention / trouble d'hyperactivité"
},
{"name" : " Fracture atypique du fémur"
},
{"name" : " Fracture atypique"
},
{"name" : " Infection mycobactérienne atypique"
},
{"name" : " Pneumonie atypique"
},
{"name" : " Fracture de stress atypique"
},
{"name" : " Hallucinations auditives et visuelles"
},
{"name" : " Trouble auditif SAI"
},
{"name" : " Aura"
},
{"name" : " Gonflement auriculaire"
},
{"name" : " Autisme"
},
{"name" : " Troubles du spectre autistique"
},
{"name" : " Maladie auto-immune"
},
{"name" : " Anémie hémolytique auto-immune"
},
{"name" : " Hépatite auto-immune"
},
{"name" : " Thrombocytopénie auto-immune"
},
{"name" : " Thyroïdite auto-immune"
},
{"name" : " Vessie automatique"
},
{"name" : " Automatisme"
},
{"name" : " Dysfonctionnement autonome"
},
{"name" : " Syndrome d'échec autonome"
},
{"name" : " Déséquilibre du système nerveux autonome"
},
{"name" : " Neuropathie autonome"
},
{"name" : " Autonomie de la glande thyroïde"
},
{"name" : " Tachycardie réentrante nodale AV"
},
{"name" : " Tachycardie réentrante AV"
},
{"name" : " Tête fémorale de nécrose avasculaire"
},
{"name" : " Avitaminose"
},
{"name" : " Neuropathie axonale"
},
{"name" : " Azoospermie"
},
{"name" : " Azotémie"
},
{"name" : " Azotémie d'origine rénale"
},
{"name" : " Azotémie prérénale"
},
{"name" : " Leucémie lymphoïde chronique à cellules B"
},
{"name" : " Lymphome à cellules B"
},
{"name" : " Leucémie aiguë de type B"
},
{"name" : " Babésiose"
},
{"name" : " Dysenterie bacillaire"
},
{"name" : " Infections bacillaires"
},
{"name" : " Mal de dos"
},
{"name" : " Détresse au dos"
},
{"name" : " Blessure au dos"
},
{"name" : " Mal au dos"
},
{"name" : " Maux de dos aggravés"
},
{"name" : " Maux de dos"
},
{"name" : " Rétinopathie diabétique"
},
{"name" : " Bactériémie"
},
{"name" : " Urine des bactéries identifiées"
},
{"name" : " Colonisation bactérienne"
},
{"name" : " Porteur de maladies bactériennes"
},
{"name" : " Infection bactérienne"
},
{"name" : " Infection bactérienne due à Helicobacter pylori (H. pylori)"
},
{"name" : " Infections bactériennes NEC"
},
{"name" : " Prostatite bactérienne"
},
{"name" : " Rhinite bactérienne"
},
{"name" : " Septicémie bactérienne"
},
{"name" : " Test bactérien positif"
},
{"name" : " Toxémie bactérienne"
},
{"name" : " Bactériurie"
},
{"name" : " Bactériurie NOS présente"
},
{"name" : " Mauvais rêves"
},
{"name" : " Mauvais goût"
},
{"name" : " Difficulté d'équilibre"
},
{"name" : " Trouble de l'équilibre"
},
{"name" : " Balanite"
},
{"name" : " Balanitis candida"
},
{"name" : " Balanoposthite"
},
{"name" : " Ballisme"
},
{"name" : " Augmentation du nombre de neutrophiles dans la bande"
},
{"name" : " Impaction au baryum"
},
{"name" : " Oesophage de Barrett"
},
{"name" : " Kyste de Bartholin"
},
{"name" : " Bartonellose"
},
{"name" : " Carcinome basocellulaire"
},
{"name" : " Syndrome de naevus basocellulaire"
},
{"name" : " Maladie de Basedow"
},
{"name" : " Syndrome de l'artère basilaire"
},
{"name" : " Migraine basilaire"
},
{"name" : " Basophilie"
},
{"name" : " Batterie"
},
{"name" : " Infection au BCG"
},
{"name" : " Syndrome de Beckwith-Wiedemann"
},
{"name" : " Alité"
},
{"name" : " Trouble du comportement"
},
{"name" : " Paralysie de Bell"
},
{"name" : " Tumeur bénigne du sein"
},
{"name" : " Hypertension essentielle bénigne"
},
{"name" : " Tumeur gastro-intestinale bénigne"
},
{"name" : " Tumeur hépatique bénigne"
},
{"name" : " Taupe hydatidiforme bénigne"
},
{"name" : " Hypertension intracrânienne bénigne"
},
{"name" : " Tumeur bénigne"
},
{"name" : " Tumeur bénigne de la peau"
},
{"name" : " Hyperplasie bénigne de la prostate"
},
{"name" : " Hypertrophie bénigne de la prostate"
},
{"name" : " Tumeur vaginale bénigne"
},
{"name" : " Béribéri"
},
{"name" : " Anévrisme des baies"
},
{"name" : " Bérylliose"
},
{"name" : " Augmentation de la microglobuline bêta 2"
},
{"name" : " Augmentation de microglobuline de l'urine bêta 2"
},
{"name" : " Bezoar"
},
{"name" : " Sérum au bicarbonate diminué"
},
{"name" : " Niveau de bicarbonate"
},
{"name" : " Bicytopénie"
},
{"name" : " Hydronéphrose bilatérale"
},
{"name" : " Cancer des voies biliaires"
},
{"name" : " Troubles des voies biliaires"
},
{"name" : " Néoplasmes des voies biliaires malins"
},
{"name" : " Sténose des voies biliaires"
},
{"name" : " Cirrhose biliaire"
},
{"name" : " Cirrhose biliaire primitive"
},
{"name" : " Coliques biliaires"
},
{"name" : " Fibrose biliaire"
},
{"name" : " Fistule biliaire"
},
{"name" : " Boues biliaires"
},
{"name" : " Trouble des voies biliaires"
},
{"name" : " Vomissements bilieux"
},
{"name" : " Bilirubine anormale"
},
{"name" : " Augmentation de la bilirubine conjuguée"
},
{"name" : " Bilirubine normale"
},
{"name" : " Bilirubine totale diminuée"
},
{"name" : " Bilirubine totale augmentée"
},
{"name" : " Bilirubine totale faible"
},
{"name" : " Bilirubine non conjuguée augmentée"
},
{"name" : " Augmentation de la valeur de la bilirubine"
},
{"name" : " Frénésie alimentaire"
},
{"name" : " Trouble bipolaire I"
},
{"name" : " Trouble bipolaire II"
},
{"name" : " Dépression bipolaire"
},
{"name" : " Trouble bipolaire"
},
{"name" : " Poids à la naissance faible"
},
{"name" : " Morsure"
},
{"name" : " Rêves bizarres"
},
{"name" : " Infection par le virus BK"
},
{"name" : " Langue poilue noire"
},
{"name" : " Tâche noire"
},
{"name" : " Noirci (pas d'amnésie)"
},
{"name" : " Fièvre de Blackwater"
},
{"name" : " Symptômes de la vessie et de l'urètre"
},
{"name" : " Cancer de la vessie"
},
{"name" : " Cancer de la vessie stade IV"
},
{"name" : " Carcinome de la vessie"
},
{"name" : " Constriction de la vessie"
},
{"name" : " Dilatation de la vessie"
},
{"name" : " Gêne vésicale"
},
{"name" : " Trouble de la vessie"
},
{"name" : " Distension de la vessie"
},
{"name" : " Diverticule vésical"
},
{"name" : " Dysfonction vésicale"
},
{"name" : " Fibrose vésicale"
},
{"name" : " Infection de la vessie"
},
{"name" : " Irritation de la vessie"
},
{"name" : " Contracture de la vessie"
},
{"name" : " Obstruction du col vésical"
},
{"name" : " Rétrécissement du col vésical"
},
{"name" : " Nécrose de la vessie"
},
{"name" : " Tumeur vésicale"
},
{"name" : " Douleurs vésicales"
},
{"name" : " Spasme de la vessie"
},
{"name" : " Sténose vésicale"
},
{"name" : " Carcinome à cellules transitionnelles de la vessie"
},
{"name" : " Carcinome à cellules transitionnelles de la vessie métastatique"
},
{"name" : " Blanchiment"
},
{"name" : " Blanchiment de la peau"
},
{"name" : " Crise des cellules blastiques"
},
{"name" : " Blastomycose"
},
{"name" : " Percée hémorragique"
},
{"name" : " Tendance hémorragique"
},
{"name" : " Temps de saignement prolongé"
},
{"name" : " Pigmentation blépharale"
},
{"name" : " Blépharite"
},
{"name" : " Blépharite allergique"
},
{"name" : " Blépharoconjonctivite"
},
{"name" : " Blépharospasme"
},
{"name" : " Ovule flétri"
},
{"name" : " Cécité"
},
{"name" : " Cécité corticale"
},
{"name" : " Jour de cécité"
},
{"name" : " Cécité transitoire"
},
{"name" : " Cécité unilatérale"
},
{"name" : " Cécité, les deux yeux"
},
{"name" : " Cloque"
},
{"name" : " Sensation de ballonnement"
},
{"name" : " Bloquage du c?ur"
},
{"name" : " Augmentation de la phosphatase acide sanguine"
},
{"name" : " Albumine sanguine diminuée"
},
{"name" : " Augmentation de l'albumine sanguine"
},
{"name" : " Aldostérone sanguine diminuée"
},
{"name" : " Augmentation de la phosphatase alcaline sanguine"
},
{"name" : " Amylase sanguine augmentée"
},
{"name" : " Troubles du sang et du système lymphatique"
},
{"name" : " Hormone antidiurétique sanguine anormale"
},
{"name" : " Bicarbonate du sang"
},
{"name" : " Bicarbonate du sang diminué"
},
{"name" : " Augmentation du bicarbonate de sang"
},
{"name" : " Bilirubine sanguine anormale"
},
{"name" : " Bilirubine sanguine diminuée"
},
{"name" : " Augmentation de la bilirubine sanguine"
},
{"name" : " Bilirubine sanguine normale"
},
{"name" : " Bilirubine sanguine non conjuguée augmentée"
},
{"name" : " Calcium sanguin anormal"
},
{"name" : " Calcium sanguin diminué"
},
{"name" : " Chlorure de sang diminué"
},
{"name" : " Augmentation du chlorure de sang"
},
{"name" : " Cholestérol sanguin anormal"
},
{"name" : " Cholestérol sanguin diminué"
},
{"name" : " Augmentation du cholestérol sanguin"
},
{"name" : " Cholestérol sanguin normal"
},
{"name" : " Cuivre sanguin diminué"
},
{"name" : " Cortisol sanguin a diminué"
},
{"name" : " Augmentation du cortisol sanguin"
},
{"name" : " Numération sanguine anormale"
},
{"name" : " Augmentation de la créatine sanguine"
},
{"name" : " Augmentation de la créatine phosphokinase sanguine MB"
},
{"name" : " Augmentation de la créatine phosphokinase sanguine MM"
},
{"name" : " Créatine phosphokinase sanguine anormale"
},
{"name" : " Augmentation de la créatine phosphokinase sanguine"
},
{"name" : " Créatine phosphokinase sanguine normale"
},
{"name" : " Créatinine sanguine anormale"
},
{"name" : " Créatinine sanguine diminuée"
},
{"name" : " Augmentation de la créatinine sanguine"
},
{"name" : " Créatinine sanguine normale"
},
{"name" : " Hémoculture négative"
},
{"name" : " Hémoculture positive"
},
{"name" : " Maladie du sang"
},
{"name" : " Électrolytes sanguins anormaux"
},
{"name" : " Electrolytes sanguins diminués"
},
{"name" : " Fibrinogène sanguin diminué"
},
{"name" : " Augmentation du fibrinogène sanguin"
},
{"name" : " Augmentation de l'hormone de stimulation des follicules sanguins"
},
{"name" : " Gaz sanguins anormaux"
},
{"name" : " Gastrine sanguine augmentée"
},
{"name" : " Glycémie anormale"
},
{"name" : " La glycémie a diminué"
},
{"name" : " Fluctuation de la glycémie"
},
{"name" : " Augmentation de la glycémie"
},
{"name" : " Glycémie normale"
},
{"name" : " Gonadotrophine sanguine diminuée"
},
{"name" : " Augmentation de la gonadotrophine sanguine"
},
{"name" : " Augmentation de l'hormone de croissance sanguine"
},
{"name" : " Immunoglobuline sanguine G diminuée"
},
{"name" : " Sang dans les selles"
},
{"name" : " Insuline sanguine a diminuée"
},
{"name" : " Insuline sanguine augmentée"
},
{"name" : " Fer anormal"
},
{"name" : " Fer sanguin diminué"
},
{"name" : " Fer sanguin augmenté"
},
{"name" : " Augmentation de la lactate déshydrogénase sanguine"
},
{"name" : " Augmentation de l'hormone lutéinisante sanguine"
},
{"name" : " Magnésium sanguin diminué"
},
{"name" : " Augmentation du magnésium sanguin"
},
{"name" : " Présence de méthémoglobine dans le sang"
},
{"name" : " Augmentation des monocytes sanguins"
},
{"name" : " Nombre de neutrophiles sanguins diminué"
},
{"name" : "?strogène sanguin diminué"
},
{"name" : " Augmentation des ?strogènes sanguins"
},
{"name" : " Osmolarité sanguine diminuée"
},
{"name" : " Augmentation de l'osmolarité sanguine"
},
{"name" : " PH sanguin diminué"
},
{"name" : " PH sanguin augmenté"
},
{"name" : " PH sanguin normal"
},
{"name" : " Augmentation de l'amylase pancréatique sanguine"
},
{"name" : " Augmentation de l'hormone parathyroïdienne sanguine"
},
{"name" : " Phosphate sanguin augmenté"
},
{"name" : " Phosphore sanguin diminué"
},
{"name" : " Augmentation du phosphore sanguin"
},
{"name" : " Potassium sanguin anormal"
},
{"name" : " Potassium sanguin diminué"
},
{"name" : " Potassium sanguin augmenté"
},
{"name" : " Tension artérielle anormale"
},
{"name" : " Pression artérielle diastolique diminuée"
},
{"name" : " Tension artérielle diastolique augmentée"
},
{"name" : " Fluctuation de la pression artérielle"
},
{"name" : " Pression artérielle insuffisamment contrôlée"
},
{"name" : " Augmentation de la pression artérielle"
},
{"name" : " Pression artérielle normale"
},
{"name" : " Pression artérielle systolique diminuée"
},
{"name" : " Augmentation de la pression artérielle systolique"
},
{"name" : " Prolactine sanguine diminuée"
},
{"name" : " Augmentation de la prolactine sanguine"
},
{"name" : " Sodium sanguin anormal"
},
{"name" : " Augmentation du sodium sanguin"
},
{"name" : " Test sanguin anormal"
},
{"name" : " Testostérone sanguine diminuée"
},
{"name" : " Augmentation de la testostérone sans sang"
},
{"name" : " Augmentation de la testostérone sanguine"
},
{"name" : " Thromboplastine sanguine diminuée"
},
{"name" : " Hormone de stimulation de la thyroïde sanguine diminuée"
},
{"name" : " Augmentation de l'hormone stimulant la thyroïde sanguine"
},
{"name" : " Triglycérides sanguins diminués"
},
{"name" : " Augmentation des triglycérides sanguins"
},
{"name" : " Triglycérides sanguins normaux"
},
{"name" : " Urée sanguine anormale"
},
{"name" : " Urée sanguine diminuée"
},
{"name" : " Augmentation de l'urée sanguine"
},
{"name" : " Urée sanguine normale"
},
{"name" : " Acide urique sanguin anormal"
},
{"name" : " Acide urique sanguin diminué"
},
{"name" : " Augmentation de l'acide urique sanguin"
},
{"name" : " Urine de sang"
},
{"name" : " Présence d'urine dans le sang"
},
{"name" : " Zinc sanguin diminué"
},
{"name" : " Oeil injecté de sang"
},
{"name" : " Écoulement sanglant"
},
{"name" : " Éruption cutanée tachetée"
},
{"name" : " Syndrome de l'orteil bleu"
},
{"name" : " Vive émotion"
},
{"name" : " Trouble de la graisse corporelle"
},
{"name" : " Perte de poils corporels"
},
{"name" : " Taille du corps diminuée"
},
{"name" : " Indice de masse corporelle diminué"
},
{"name" : " Odeur corporelle"
},
{"name" : " Altération de la température corporelle"
},
{"name" : " Température corporelle diminuée"
},
{"name" : " Fluctuation de la température corporelle"
},
{"name" : " Augmentation de la température corporelle"
},
{"name" : " Tinea du corps"
},
{"name" : " Infections osseuses et articulaires"
},
{"name" : " Cancer osseux métastatique"
},
{"name" : " Déformation osseuse"
},
{"name" : " Densité osseuse diminuée"
},
{"name" : " Développement osseux anormal"
},
{"name" : " Trouble osseux"
},
{"name" : " Augmentation de la formation osseuse"
},
{"name" : " Lésion osseuse"
},
{"name" : " Moelle osseuse aplasique"
},
{"name" : " Dépression de la moelle osseuse"
},
{"name" : " Trouble de la moelle osseuse"
},
{"name" : " Granulome de moelle osseuse"
},
{"name" : " Toxicité pour la moelle osseuse"
},
{"name" : " Masse osseuse diminuée"
},
{"name" : " Trouble du métabolisme osseux"
},
{"name" : " Tumeur osseuse"
},
{"name" : " Douleur osseuse"
},
{"name" : " Douleur osseuse aggravée"
},
{"name" : " Sarcome osseux"
},
{"name" : " Éperon osseux"
},
{"name" : " Tendresse osseuse"
},
{"name" : " Borborygmi"
},
{"name" : " Lèpre limite"
},
{"name" : " Trouble de la personnalité limite"
},
{"name" : " Infection à Borrelia"
},
{"name" : " Botulisme"
},
{"name" : " Tuberculose bovine"
},
{"name" : " Les bruits intestinaux ont diminué"
},
{"name" : " Spasme intestinal"
},
{"name" : " Maladie de Bowen"
},
{"name" : " Papulose bowénoïde"
},
{"name" : " Lésion du plexus brachial"
},
{"name" : " Bradyarythmie"
},
{"name" : " Bradycardie"
},
{"name" : " Bradycardie f?tale"
},
{"name" : " Syndrome de bradycardie-tachycardie"
},
{"name" : " Bradykinésie"
},
{"name" : " Bradyphrenie"
},
{"name" : " Réponse bradypsychique"
},
{"name" : " Abcès cérébral"
},
{"name" : " Cancer du cerveau métastatique"
},
{"name" : " Trouble cérébral SAI"
},
{"name" : " Hernie cérébrale"
},
{"name" : " Hypoxie cérébrale"
},
{"name" : " Infarctus cérébral"
},
{"name" : " Lésion cérébrale"
},
{"name" : " Lésion cérébrale"
},
{"name" : " Masse cérébrale"
},
{"name" : " Tumeur cérébrale"
},
{"name" : " Tumeur cérébrale bénigne"
},
{"name" : " Tumeur maligne du cerveau"
},
{"name" : " Oedème cérébral"
},
{"name" : " Gliome de la tige du cerveau"
},
{"name" : " Hémorragie cérébrale"
},
{"name" : " Syndrome du tronc cérébral"
},
{"name" : " Douleur cancéreuse révolutionnaire"
},
{"name" : " Douleur révolutionnaire"
},
{"name" : " Abcès mammaire"
},
{"name" : " Atrophie mammaire"
},
{"name" : " Calcifications mammaires"
},
{"name" : " Cancer du sein"
},
{"name" : " Cancer du sein féminin"
},
{"name" : " Cancer invasif du cancer du sein SAI"
},
{"name" : " Cancer du sein masculin"
},
{"name" : " Cancer du sein récurrent"
},
{"name" : " Cancer du sein stade IV"
},
{"name" : " Kyste mammaire"
},
{"name" : " Écoulement mammaire"
},
{"name" : " Gêne mammaire"
},
{"name" : " Trouble mammaire"
},
{"name" : " Trouble mammaire féminin"
},
{"name" : " Engorgement mammaire"
},
{"name" : " Augmentation mammaire"
},
{"name" : " Elargissement du sein féminin"
},
{"name" : " Allaitement maternel"
},
{"name" : " Fibrome mammaire"
},
{"name" : " Fibrose mammaire"
},
{"name" : " Induration mammaire"
},
{"name" : " Malformation mammaire"
},
{"name" : " Masse mammaire"
},
{"name" : " Microcalcification mammaire"
},
{"name" : " Tumeur mammaire"
},
{"name" : " Néoplasme mammaire NOS mâle"
},
{"name" : " Néoplasme mammaire bénin femelle"
},
{"name" : " Oedème mammaire"
},
{"name" : " Douleur mammaire"
},
{"name" : " Douleur mammaire femelle"
},
{"name" : " Douleur mammaire masculine"
},
{"name" : " Gonflement des seins"
},
{"name" : " Sensibilité des seins"
},
{"name" : " Tension mammaire"
},
{"name" : " Retention du souffle"
},
{"name" : " Souffle retenant l'attaque"
},
{"name" : " Odeur d'haleine"
},
{"name" : " Cétones olfactives"
},
{"name" : " Respiration semble anormale"
},
{"name" : " Présentation du siège"
},
{"name" : " Carcinome bronchique"
},
{"name" : " Trouble bronchique"
},
{"name" : " Hémorragie bronchique"
},
{"name" : " Hyperréactivité bronchique"
},
{"name" : " Infection bronchique"
},
{"name" : " Bouchon de mucus bronchique"
},
{"name" : " Obstruction bronchique"
},
{"name" : " Rétention de sécrétion bronchique"
},
{"name" : " Ulcération bronchique"
},
{"name" : " Bronchiectasis"
},
{"name" : " Bronchiolite"
},
{"name" : " Bronchiolite oblitérante avec pneumonie organisatrice"
},
{"name" : " Carcinome bronchioloalvéolaire"
},
{"name" : " Bronchite"
},
{"name" : " Bronchite asthmatique"
},
{"name" : " Bronchite bactérienne"
},
{"name" : " Bronchite chronique"
},
{"name" : " Bronchite virale"
},
{"name" : " Bronchoconstriction"
},
{"name" : " Bronchopneumonie"
},
{"name" : " Bronchopneumopathie"
},
{"name" : " Aspergillose bronchopulmonaire"
},
{"name" : " Aspergillose bronchopulmonaire allergique"
},
{"name" : " Maladie bronchopulmonaire"
},
{"name" : " Dysplasie bronchopulmonaire"
},
{"name" : " Bronchospasme"
},
{"name" : " Bronchospasme aggravé"
},
{"name" : " Bronchospasme paradoxal"
},
{"name" : " Bronchosténose"
},
{"name" : " Tumeur brune"
},
{"name" : " Urine brune"
},
{"name" : " Brucellose"
},
{"name" : " Syndrome de Brugada"
},
{"name" : " Agammaglobulinémie de Bruton"
},
{"name" : " Bruxisme"
},
{"name" : " Inflammation buccale"
},
{"name" : " Ulcération de la muqueuse buccale"
},
{"name" : " Rudesse muqueuse buccale"
},
{"name" : " Syndrome buccoglosse"
},
{"name" : " Bucking"
},
{"name" : " Syndrome de Budd-Chiari"
},
{"name" : " Bosse du bison"
},
{"name" : " Boulimie"
},
{"name" : " Boulimie nerveuse"
},
{"name" : " Conditions bulleuses"
},
{"name" : " Éruption bulleuse"
},
{"name" : " Impétigo bulleux"
},
{"name" : " Kératopathie bulleuse"
},
{"name" : " Lichen plan bulleux"
},
{"name" : " Bloc de branche "
},
{"name" : " Bloc de branche gauche"
},
{"name" : " Bloc de branche droit"
},
{"name" : " Lymphome de Burkitt"
},
{"name" : " Brûlure"
},
{"name" : " Anal brûlant"
},
{"name" : " Sensation de brûlure au vagin"
},
{"name" : " Pied brûlant"
},
{"name" : " Brûlure dans la gorge"
},
{"name" : " Bouche brûlante"
},
{"name" : " Syndrome de la bouche brûlante"
},
{"name" : " Brûlure rectale"
},
{"name" : " Sensation de brulure"
},
{"name" : " Sensation de brûlure dans les yeux"
},
{"name" : " Langue brûlante"
},
{"name" : " Brûlure au deuxième degré"
},
{"name" : " Brûlure au troisième degré"
},
{"name" : " Bursite"
},
{"name" : " Douleur aux fesses"
},
{"name" : " Augmentation de la protéine C réactive"
},
{"name" : " Déficit en C1 estérase acquis"
},
{"name" : " Ca ++ augmenté"
},
{"name" : " Cachexie"
},
{"name" : " Caecitis"
},
{"name" : " Taches de café au lait"
},
{"name" : " Éperon calcanéen"
},
{"name" : " Calcification métastatique"
},
{"name" : " Calcinose"
},
{"name" : " Calciphylaxie"
},
{"name" : " Calcium anormal SAI"
},
{"name" : " Carence en calcium"
},
{"name" : " Intoxication au calcium"
},
{"name" : " Faible en calcium"
},
{"name" : " Trouble du métabolisme du calcium"
},
{"name" : " Vessie de calcul"
},
{"name" : " Calcul rénal"
},
{"name" : " Calcul urétéral"
},
{"name" : " Calcul urinaire"
},
{"name" : " Syndrome de Call-Fleming"
},
{"name" : " Gastro-entérite à Campylobacter"
},
{"name" : " Douleur cancéreuse"
},
{"name" : " Infection à Candida albicans"
},
{"name" : " Candida cervicite"
},
{"name" : " Infection à Candida"
},
{"name" : " Septicémie à Candida"
},
{"name" : " Candidémie"
},
{"name" : " Candidurie"
},
{"name" : " Réaction au site de la canule"
},
{"name" : " Fragilité capillaire"
},
{"name" : " Augmentation de la fragilité capillaire"
},
{"name" : " Syndrome de fuite capillaire"
},
{"name" : " Perméabilité capillaire"
},
{"name" : " Capsulite"
},
{"name" : " Déficit en carbamoyl phosphate synthétase"
},
{"name" : " Envie de glucides"
},
{"name" : " Tolérance aux glucides diminuée"
},
{"name" : " Dioxyde de carbone diminué"
},
{"name" : " Augmentation du dioxyde de carbone"
},
{"name" : " Empoisonnement au monoxyde de carbone"
},
{"name" : " Escarboucle"
},
{"name" : " Cancérogénicité"
},
{"name" : " Syndrome carcinoïde"
},
{"name" : " Tumeur carcinoïde"
},
{"name" : " Carcinome"
},
{"name" : " Cancer du sein"
},
{"name" : " Côlon cancéreux"
},
{"name" : " Carcinome endométrial métastatique"
},
{"name" : " Carcinome in situ"
},
{"name" : " Carcinome in situ du sein canalaire"
},
{"name" : " Carcinome du poumon"
},
{"name" : " Carcinome de la langue"
},
{"name" : " Carcinome de l'estomavc"
},
{"name" : " Carcinome des testicules"
},
{"name" : " Carcinomatose"
},
{"name" : " Amylose cardiaque"
},
{"name" : " Anévrisme cardiaque"
},
{"name" : " Arrêt cardiaque"
},
{"name" : " Mort cardiaque"
},
{"name" : " Gêne cardiaque"
},
{"name" : " Trouble cardiaque"
},
{"name" : " Augmentation des enzymes cardiaques"
},
{"name" : " Insuffisance cardiaque"
},
{"name" : " Insuffisance cardiaque aiguë"
},
{"name" : " Insuffisance cardiaque chronique"
},
{"name" : " Insuffisance cardiaque congestive"
},
{"name" : " Insuffisance cardiaque à haut débit"
},
{"name" : " Insuffisance cardiaque droite"
},
{"name" : " Fibrillation cardiaque"
},
{"name" : " Flutter cardiaque"
},
{"name" : " Hypertrophie cardiaque"
},
{"name" : " Index cardiaque"
},
{"name" : " Souffle cardiaque"
},
{"name" : " Débit cardiaque diminué"
},
{"name" : " Augmentation du débit cardiaque"
},
{"name" : " Douleur cardiaque"
},
{"name" : " Anomalie septale cardiaque"
},
{"name" : " Syncope cardiaque"
},
{"name" : " Tamponnade cardiaque"
},
{"name" : " Maladie de la valve cardiaque"
},
{"name" : " Complication de remplacement de la valve cardiaque"
},
{"name" : " Arrêt cardio-respiratoire"
},
{"name" : " Détresse cardio-respiratoire"
},
{"name" : " Niveau de médicament cardioactif supérieur à la thérapeutique"
},
{"name" : " Augmentation du niveau de médicaments cardioactifs"
},
{"name" : " Choc cardiogénique"
},
{"name" : " Cardiomégalie"
},
{"name" : " Cardiomyopathie"
},
{"name" : " Cardiomyopathie secondaire SAI"
},
{"name" : " Insuffisance cardio-pulmonaire"
},
{"name" : " Cardiotoxicité"
},
{"name" : " Trouble cardiovasculaire"
},
{"name" : " Insuffisance cardiovasculaire"
},
{"name" : " Cardite"
},
{"name" : " Carence en carnitine"
},
{"name" : " Carotène diminué"
},
{"name" : " Artériosclérose carotidienne"
},
{"name" : " Maladie de l'artère carotide"
},
{"name" : " Occlusion de l'artère carotide"
},
{"name" : " Sténose de l'artère carotide"
},
{"name" : " Thrombose de l'artère carotide"
},
{"name" : " Bruit carotidien"
},
{"name" : " Pouls carotidien"
},
{"name" : " Hypersensibilité au sinus carotidien"
},
{"name" : " Syndrome du sinus carotidien"
},
{"name" : " Syndrome du canal carpien"
},
{"name" : " Spasme carpo-pédale"
},
{"name" : " Maladie des griffes du chat"
},
{"name" : " Catalepsie"
},
{"name" : " Cataplexie"
},
{"name" : " Cataracte"
},
{"name" : " Conditions de cataracte"
},
{"name" : " Cataracte corticale"
},
{"name" : " Cataracte diabétique"
},
{"name" : " Cataracte nucléaire"
},
{"name" : " Cataracte spécifiée"
},
{"name" : " Cataracte sous-capsulaire"
},
{"name" : " Cataracte traumatique"
},
{"name" : " Cataracte unilatérale"
},
{"name" : " Catatonie"
},
{"name" : " Réaction catatonique"
},
{"name" : " Blocage du cathéter"
},
{"name" : " Infection par cathéter"
},
{"name" : " Complication liée au cathéter"
},
{"name" : " Infection liée au cathéter"
},
{"name" : " Septicémie par cathéter"
},
{"name" : " Cellulite au site du cathéter"
},
{"name" : " Érythème au site du cathéter"
},
{"name" : " Hémorragie au site du cathéter"
},
{"name" : " Infection du site du cathéter"
},
{"name" : " Inflammation du site du cathéter"
},
{"name" : " Douleur au site du cathéter"
},
{"name" : " Phlébite du site du cathéter"
},
{"name" : " Réaction liée au site du cathéter"
},
{"name" : " Thrombose du cathéter"
},
{"name" : " Syndrome de la Cauda equina"
},
{"name" : " Causalgie"
},
{"name" : " Lésion caustique"
},
{"name" : " Lymphocytes CD4 diminués"
},
{"name" : " Mort cellulaire"
},
{"name" : " Cellulite"
},
{"name" : " Cellulite gangreneuse"
},
{"name" : " Cellulite staphylococcique"
},
{"name" : " Diabète insipide central"
},
{"name" : " Infection de la ligne centrale"
},
{"name" : " Trouble du système nerveux central"
},
{"name" : " Hémorragie du système nerveux central"
},
{"name" : " Infection du système nerveux central"
},
{"name" : " Lésion du système nerveux central"
},
{"name" : " Leucémie du système nerveux central"
},
{"name" : " Tumeur du système nerveux central"
},
{"name" : " Stimulation du système nerveux central"
},
{"name" : " Obésité centrale"
},
{"name" : " Puberté précoce centrale"
},
{"name" : " Occlusion de la veine rétinienne centrale"
},
{"name" : " Scotome central"
},
{"name" : " Rétinopathie séreuse centrale"
},
{"name" : " Ataxie cérébelleuse"
},
{"name" : " Atrophie cérébelleuse"
},
{"name" : " Infarctus cérébelleux"
},
{"name" : " Oedème cérébelleux"
},
{"name" : " Syndrome cérébelleux"
},
{"name" : " Anévrisme artériel cérébral"
},
{"name" : " Artériosclérose cérébrale"
},
{"name" : " Artérite cérébrale"
},
{"name" : " Embolie artérielle cérébrale"
},
{"name" : " Sténose de l'artère cérébrale"
},
{"name" : " Atrophie cérébrale"
},
{"name" : " Dysfonctionnement cérébral"
},
{"name" : " Hématome cérébral"
},
{"name" : " Hémorragie cérébrale"
},
{"name" : " Hypoperfusion cérébrale"
},
{"name" : " Infarctus cérébral"
},
{"name" : " Ischémie cérébrale"
},
{"name" : " Paralysie cérébrale"
},
{"name" : " Thrombose cérébrale"
},
{"name" : " Toxoplasmose cérébrale"
},
{"name" : " Vasoconstriction cérébrale"
},
{"name" : " Thrombose veineuse cérébrale"
},
{"name" : " Cérébration altérée"
},
{"name" : " Cérébrite"
},
{"name" : " Cérébrosclérose"
},
{"name" : " Fuite de liquide céphalo-rachidien"
},
{"name" : " Rhinorrhée du liquide céphalorachidien"
},
{"name" : " Accident vasculaire cérébral"
},
{"name" : " Trouble cérébrovasculaire"
},
{"name" : " Infarctus cérébrovasculaire"
},
{"name" : " Insuffisance cérébrovasculaire"
},
{"name" : " Impaction du cérumen"
},
{"name" : " La céruminose"
},
{"name" : " Adénite cervicale"
},
{"name" : " Écoulement cervical"
},
{"name" : " Dysplasie cervicale"
},
{"name" : " Incompétence cervicale"
},
{"name" : " Polype cervical"
},
{"name" : " Test de frottis cervical positif"
},
{"name" : " Fracture vertébrale cervicale"
},
{"name" : " Cervicite"
},
{"name" : " Syndrome cervicobrachial"
},
{"name" : " Carcinome du col de l'utérus"
},
{"name" : " Carcinome du col utérin stade 0"
},
{"name" : " Trouble du col de l'utérus"
},
{"name" : " Hémorragie cervicale utérine"
},
{"name" : " Tumeur du col de l'utérus"
},
{"name" : " Chalazion"
},
{"name" : " Goût crayeux"},
{"name" : " Chancre"
},
{"name" : " Changement de la pression artérielle"
},
{"name" : " Changement d'habitude intestinale"
},
{"name" : " Lèvres gercées"
},
{"name" : " Peau gercée"
},
{"name" : " Cheilitis"
},
{"name" : " Cheilosis"
},
{"name" : " Brûlure chimique"
},
{"name" : " Conjonctivite chimique"
},
{"name" : " Cystite chimique"
},
{"name" : " Lésion oculaire chimique"
},
{"name" : " Lésions chimiques"
},
{"name" : " Péritonite chimique"
},
{"name" : " Phlébite chimique"
},
{"name" : " Chemosis"
},
{"name" : " Radiographie thoracique anormale"
},
{"name" : " Radiographie thoracique normale"
},
{"name" : " Gêne thoracique"
},
{"name" : " Lourdeur de poitrine"
},
{"name" : " Masse thoracique NOS"
},
{"name" : " Douleur de poitrine"
},
{"name" : " Douleur thoracique liée à l'effort"
},
{"name" : " Pression thoracique"
},
{"name" : " Sensation de pression thoracique"
},
{"name" : " Oppression thoracique"
},
{"name" : " Douleur à la paroi thoracique"
},
{"name" : " Respiration de Cheyne-Stokes"
},
{"name" : " Schizophrénie infantile"
},
{"name" : " Frissons"
},
{"name" : " Infection à Chlamydia trachomatis"
},
{"name" : " Infection à Chlamydia"
},
{"name" : " Chloasma"
},
{"name" : " Chloropsie"
},
{"name" : " Étouffement"
},
{"name" : " Sensation d'étouffement"
},
{"name" : " Cholangiocarcinome"
},
{"name" : " Cholangite"
},
{"name" : " Cholangite sclérosante"
},
{"name" : " Cholécystite"
},
{"name" : " Cholécystite aiguë"
},
{"name" : " Cholécystite et cholélithiase"
},
{"name" : " Cholécystite chronique"
},
{"name" : " Cholécystite infectieuse"
},
{"name" : " Cholécystolithiase"
},
{"name" : " Cholélithiase"
},
{"name" : " Choléra"
},
{"name" : " Cholestase"
},
{"name" : " Cholestase extrahépatique"
},
{"name" : " Cholestase intrahépatique"
},
{"name" : " Maladie cholestatique du foie"
},
{"name" : " Lésion hépatique cholestatique"
},
{"name" : " Sérum de cholestérol élevé"
},
{"name" : " Crise cholinergique"
},
{"name" : " Syndrome cholinergique"
},
{"name" : " Cholurie"
},
{"name" : " Chondrocalcinose"
},
{"name" : " Chondrodystrophie"
},
{"name" : " Chondrolyse"
},
{"name" : " Chondropathie"
},
{"name" : " Chorée"
},
{"name" : " Choréiforme"
},
{"name" : " Mouvements choréoathétoïdes"
},
{"name" : " Choréoathétose"
},
{"name" : " Choriocarcinome"
},
{"name" : " Choriorétinite"
},
{"name" : " Choriorétinopathie"
},
{"name" : " Détachement choroïdien"
},
{"name" : " Épanchement choroïdien"
},
{"name" : " Néovascularisation choroïdienne"
},
{"name" : " Naevus choroïdien"
},
{"name" : " Choroïdite"
},
{"name" : " Chromatopsie"
},
{"name" : " Chromaturie"
},
{"name" : " Chromoblastomycose"
},
{"name" : " Mutation chromosomique"
},
{"name" : " Analyse chromosomique anormale"
},
{"name" : " UTI chronique"
},
{"name" : " Néphropathie d'allogreffe chronique"
},
{"name" : " Fissure anale chronique"
},
{"name" : " Glaucome chronique à angle fermé"
},
{"name" : " Anxiété chronique"
},
{"name" : " Fibrillation auriculaire chronique"
},
{"name" : " Conjonctivite chronique"
},
{"name" : " Diarrhée chronique"
},
{"name" : " Eczéma chronique"
},
{"name" : " Leucémie éosinophile chronique"
},
{"name" : " Syndrome de fatigue chronique"
},
{"name" : " Fièvre chronique"
},
{"name" : " Gastrite chronique"
},
{"name" : " Maladie chronique du greffon contre l'hôte"
},
{"name" : " Insuffisance hépatique chronique"
},
{"name" : " Hépatite chronique"
},
{"name" : " Hépatite B chronique"
},
{"name" : " Hépatite C chronique"
},
{"name" : " Constipation idiopathique chronique"
},
{"name" : " Insomnie chronique"
},
{"name" : " Néphrite interstitielle chronique"
},
{"name" : " Surcharge chronique en fer"
},
{"name" : " Maladie rénale chronique"
},
{"name" : " Leucémie chronique"
},
{"name" : " Maladie chronique du foie"
},
{"name" : " Leucémie lymphoïde chronique"
},
{"name" : " Leucémie lymphoïde chronique réfractaire"
},
{"name" : " Migraine chronique"
},
{"name" : " Candidose muco-cutanée chronique"
},
{"name" : " Leucémie myéloïde chronique"
},
{"name" : " Leucémie myélomonocytaire chronique"
},
{"name" : " Néphrite chronique"
},
{"name" : " Maladie pulmonaire obstructive chronique"
},
{"name" : " Glaucome chronique à angle ouvert"
},
{"name" : " Douleur chronique"
},
{"name" : " Ulcère gastro-duodénal chronique"
},
{"name" : " Parodontite chronique"
},
{"name" : " Leucémie myéloïde chronique en phase chronique"
},
{"name" : " Prostatite chronique"
},
{"name" : " Histoplasmose pulmonaire chronique"
},
{"name" : " Insuffisance rénale chronique"
},
{"name" : " Maladie respiratoire chronique"
},
{"name" : " Schizophrénie chronique"
},
{"name" : " Sinusite chronique"
},
{"name" : " Urticaire chronique spontanée"
},
{"name" : " Otite moyenne chronique suppurée"
},
{"name" : " Hypertension pulmonaire thromboembolique chronique"
},
{"name" : " Insuffisance veineuse chronique"
},
{"name" : " Chrysiasis"
},
{"name" : " Chylothorax"
},
{"name" : " Chylurie"
},
{"name" : " Fumeur de cigarettes"
},
{"name" : " Spasme musculaire ciliaire"
},
{"name" : " Cinchonisme"
},
{"name" : " Trouble du sommeil du rythme circadien"
},
{"name" : " Dépression circulatoire"
},
{"name" : " Insuffisance circulatoire"
},
{"name" : " Oedème circumoral"
},
{"name" : " Paresthésie circumorale"
},
{"name" : " Sclérodermie circonscrite"
},
{"name" : " Cirrhose alcoolique"
},
{"name" : " Cirrhose hépatique post-nécrotique"
},
{"name" : " Toxicité du citrate"
},
{"name" : " Migraine classique"
},
{"name" : " Claudication"
},
{"name" : " Claustrophobie"
},
{"name" : " Fracture de la clavicule"
},
{"name" : " Fente labiale"
},
{"name" : " Fente palatine"
},
{"name" : " Climatère"
},
{"name" : " Réaction de poussée clinique"
},
{"name" : " Engorgement clitoridien"
},
{"name" : " Exstrophie cloacale"
},
{"name" : " Convulsion clonique"
},
{"name" : " Mouvements cloniques"
},
{"name" : " Clonus"
},
{"name" : " Infection clostridienne"
},
{"name" : " Colite à Clostridium"
},
{"name" : " Colite à Clostridium difficile"
},
{"name" : " Infection à Clostridium difficile"
},
{"name" : " Coagulation"
},
{"name" : " Urine trouble"
},
{"name" : " Hippocratisme digital"
},
{"name" : " Maladresse"
},
{"name" : " Maux de tête en grappe"
},
{"name" : " Dépression du SNC NSA"
},
{"name" : " Toxicité pour le SNC"
},
{"name" : " Ventriculite du SNC"
},
{"name" : " Facteur de coagulation diminué"
},
{"name" : " Nécrose de coagulation"
},
{"name" : " Test de coagulation anormal"
},
{"name" : " Temps de coagulation prolongé"
},
{"name" : " Coagulopathie"
},
{"name" : " Coarctation de l'aorte"
},
{"name" : " Coccidioïdomycose"
},
{"name" : " Coccydynie"
},
{"name" : " Toxicité cochléaire"
},
{"name" : " Maladie coeliaque"
},
{"name" : " Détérioration cognitive"
},
{"name" : " Trouble cognitif"
},
{"name" : " Déficience cognitive"
},
{"name" : " Rigidité de la roue dentée"
},
{"name" : " Saignement coïtal"
},
{"name" : " Coitus interruptus"
},
{"name" : " Pieds froids"
},
{"name" : " Mains froides"
},
{"name" : " Mains et pieds froids"
},
{"name" : " Intolérance au froid"
},
{"name" : " Sueur froide"
},
{"name" : " Symptômes du rhume"
},
{"name" : " Urticaire froide"
},
{"name" : " Froideur"
},
{"name" : " Colite"
},
{"name" : " Colite ischémique"
},
{"name" : " Colite microscopique"
},
{"name" : " Colite ulcéreuse"
},
{"name" : " Trouble du collagène"
},
{"name" : " Maladie vasculaire-collagène"
},
{"name" : " Effondrement"
},
{"name" : " Adénome du côlon"
},
{"name" : " Colon atonique"
},
{"name" : " Cancer du colon"
},
{"name" : " Cancer du côlon stade III"
},
{"name" : " Obstruction du côlon"
},
{"name" : " Abcès colique"
},
{"name" : " Polype colique"
},
{"name" : " Pseudo-obstruction colique"
},
{"name" : " Changement de vision des couleurs"
},
{"name" : " Cancer colorectal"
},
{"name" : " Cancer colorectal métastatique"
},
{"name" : " Carcinome colorectal"
},
{"name" : " Daltonisme"
},
{"name" : " Daltonisme acquis"
},
{"name" : " Colpocele"
},
{"name" : " Coma"
},
{"name" : " Coma hépatique"
},
{"name" : " Hyperlipidémie combinée"
},
{"name" : " Comedone"
},
{"name" : " Rhume"
},
{"name" : " Verrue commune"
},
{"name" : " Infection acquise dans la communauté"
},
{"name" : " Pneumonie acquise dans la communauté"
},
{"name" : " Syndrome du compartiment"
},
{"name" : " Cirrhose compensée"
},
{"name" : " Perte auditive complète"
},
{"name" : " Suicide complété"
},
{"name" : " Crises partielles complexes"
},
{"name" : " Syndrome douloureux régional complexe"
},
{"name" : " Complication de livraison"
},
{"name" : " Complication de l'insertion de l'appareil"
},
{"name" : " Complication de la grossesse"
},
{"name" : " Complications de la greffe"
},
{"name" : " Fracture par compression"
},
{"name" : " Compulsions"
},
{"name" : " Trouble de la personnalité compulsive"
},
{"name" : " Comportement sexuel compulsif"
},
{"name" : " Achats compulsifs"
},
{"name" : " Commotion cérébrale"
},
{"name" : " Condition aggravée"
},
{"name" : " Trouble des conduites"
},
{"name" : " Trouble de la conduction"
},
{"name" : " Condylome"
},
{"name" : " Confusion aggravée"
},
{"name" : " Confusion postopératoire"
},
{"name" : " État confusionnel"
},
{"name" : " Absence congénitale de voies biliaires"
},
{"name" : " Hyperplasie surrénale congénitale"
},
{"name" : " Anomalie congénitale"
},
{"name" : " Anémie aplasique congénitale"
},
{"name" : " Malformation artérielle congénitale"
},
{"name" : " Anomalie congénitale du système nerveux central"
},
{"name" : " Pied bot congénital"
},
{"name" : " Insuffisance rénale kystique congénitale"
},
{"name" : " Infection congénitale à cytomégalovirus"
},
{"name" : " Hernie diaphragmatique congénitale"
},
{"name" : " Trouble oculaire congénital"
},
{"name" : " Malformation congénitale du pied"
},
{"name" : " Lipodystrophie généralisée congénitale"
},
{"name" : " Malformation génitale congénitale"
},
{"name" : " Anomalie génito-urinaire congénitale"
},
{"name" : " Infection à herpès simplex congénital"
},
{"name" : " Hydronéphrose congénitale"
},
{"name" : " Sténose pylorique hypertrophique congénitale"
},
{"name" : " Hypothyroïdie congénitale"
},
{"name" : " Malformation articulaire congénitale"
},
{"name" : " Hyperextension du membre congénital"
},
{"name" : " Mégacôlon congénital"
},
{"name" : " Anomalie musculo-squelettique congénitale"
},
{"name" : " Malformation buccale congénitale"
},
{"name" : " Atrésie des valves pulmonaires congénitales"
},
{"name" : " Kyste rénal congénital"
},
{"name" : " Trouble congénital de la peau"
},
{"name" : " Syphilis congénitale"
},
{"name" : " Atrésie valvulaire congénitale tricuspide"
},
{"name" : " Reflux vésico-urétéral congénital"
},
{"name" : " Cardiomyopathie congestive"
},
{"name" : " Siamois"
},
{"name" : " Bulle conjonctivale"
},
{"name" : " Congestion conjonctivale"
},
{"name" : " Kyste conjonctival"
},
{"name" : " Écoulement conjonctival"
},
{"name" : " Trouble conjonctival"
},
{"name" : " Follicules conjonctivaux"
},
{"name" : " Hémorragie conjonctivale"
},
{"name" : " Hyperémie conjonctivale"
},
{"name" : " Irritation conjonctivale"
},
{"name" : " Oedème conjonctival"
},
{"name" : " Ulcère conjonctival"
},
{"name" : " Xérose conjonctivale"
},
{"name" : " Conjonctivite"
},
{"name" : " Conjonctivite allergique"
},
{"name" : " Conjonctivite bactérienne"
},
{"name" : " Conjonctivite exacerbée"
},
{"name" : " Conjonctivite infectieuse"
},
{"name" : " Conjonctivite papillaire"
},
{"name" : " Trouble du tissu conjonctif"
},
{"name" : " Inflammation du tissu conjonctif"
},
{"name" : " Conscience anormale"
},
{"name" : " Conscience opacifiante"
},
{"name" : " Constipation"
},
{"name" : " Constipation aggravée"
},
{"name" : " Constipation chronique"
},
{"name" : " Intolérance aux lentilles de contact"
},
{"name" : " Complication du dispositif contraceptif"
},
{"name" : " Vessie contractée"
},
{"name" : " Muscle squelettique de contraction"
},
{"name" : " Cancer du sein controlatéral"
},
{"name" : " Réaction des milieux de contraste"
},
{"name" : " Contusion"
},
{"name" : " Convalescence"
},
{"name" : " Convalescent"
},
{"name" : " Conversion desordonee"
},
{"name" : " Convulsion"
},
{"name" : " Convulsion dans l'enfance"
},
{"name" : " Convulsion néonatale"
},
{"name" : " Convulsions aggravées"
},
{"name" : " Convulsions généralisées"
},
{"name" : " Trouble convulsif"
},
{"name" : " Crise convulsive"
},
{"name" : " Anémie de Cooley"
},
{"name" : " Test de Coombs direct positif"
},
{"name" : " Anémie hémolytique positive de Coombs"
},
{"name" : " Test de Coombs positif"
},
{"name" : " Coordination anormale"
},
{"name" : " Perturbation de la coordination"
},
{"name" : " Exacerbation de la MPOC"
},
{"name" : " Carence en cuivre"
},
{"name" : " Cor pulmonale"
},
{"name" : " Abrasion de la cornée"
},
{"name" : " Calcification cornéenne"
},
{"name" : " Décompensation cornéenne"
},
{"name" : " Défaut cornéen"
},
{"name" : " Dégénérescence cornéenne"
},
{"name" : " Dépôts cornéens"
},
{"name" : " Trouble cornéen"
},
{"name" : " Dystrophie cornéenne"
},
{"name" : " Défaut d'épithélium cornéen"
},
{"name" : " Trouble de l'épithélium cornéen"
},
{"name" : " Érosion cornéenne"
},
{"name" : " Infiltrats cornéens"
},
{"name" : " Irritation cornéenne"
},
{"name" : " Lésion cornéenne"
},
{"name" : " Oedème cornéen"
},
{"name" : " Opacité cornéenne"
},
{"name" : " Perforation cornéenne"
},
{"name" : " Pigmentation cornéenne"
},
{"name" : " Cicatrice cornéenne"
},
{"name" : " La sensibilité cornéenne a diminué"
},
{"name" : " Coloration cornéenne"
},
{"name" : " Oedème stromal cornéen"
},
{"name" : " Amincissement de la cornée"
},
{"name" : " Ulcère cornéen marginal"
},
{"name" : " Corns"
},
{"name" : " Maladie de l'artère coronaire"
},
{"name" : " Maladie coronarienne aggravée"
},
{"name" : " Insuffisance coronarienne"
},
{"name" : " Occlusion de l'artère coronaire"
},
{"name" : " Sténose de l'artère coronaire"
},
{"name" : " Thrombose de l'artère coronaire"
},
{"name" : " Maladie coronarienne"
},
{"name" : " Thrombose du stent coronaire"
},
{"name" : " Agénésie du corps calleux"
},
{"name" : " Kyste du corps jaune"
},
{"name" : " Infection à Corynebacterium"
},
{"name" : " Coryza"
},
{"name" : " Costochondrite"
},
{"name" : " Sensibilité de l'angle costovertebral"
},
{"name" : " Taches de coton"
},
{"name" : " La toux"
},
{"name" : " Toux diminuée"
},
{"name" : " Toux augmentée"
},
{"name" : " Suppression de la toux"
},
{"name" : " Coxalgie"
},
{"name" : " Crampe musculaire"
},
{"name" : " Crampe de membre"
},
{"name" : " Crampes des membres inférieurs"
},
{"name" : " Trouble du nerf crânien"
},
{"name" : " Paralysie du nerf crânien"
},
{"name" : " Craniopharyngiome"
},
{"name" : " Craniosynostose"
},
{"name" : " Augmentation de la créatine"
},
{"name" : " Augmentation de la créatine phosphokinase"
},
{"name" : " Créatine phosphokinase normale"
},
{"name" : " Augmentation du sérum de créatine phosphokinase"
},
{"name" : " Créatinine NOS anormale"
},
{"name" : " Augmentation de la créatinine"
},
{"name" : " Faible taux de créatinine"
},
{"name" : " Créatinine normale"
},
{"name" : " Clairance rénale de la créatinine diminuée"
},
{"name" : " Maladie de Crohn"
},
{"name" : " Iléocolite de Crohn"
},
{"name" : " Aggravation de la maladie de Crohn"
},
{"name" : " Hypersensibilité croisée aux médicaments"
},
{"name" : " Résistance croisée"
},
{"name" : " Croupe"
},
{"name" : " Croup infectieux"
},
{"name" : " Pleurs"
},
{"name" : " Pleurs anormaux"
},
{"name" : " Infection cutanée cryptococcique"
},
{"name" : " Cryptococcose"
},
{"name" : " Cryptorchisme"
},
{"name" : " Infection par cryptosporidiose"
},
{"name" : " Présence d'urine cristalline"
},
{"name" : " Cristallurie"
},
{"name" : " Cristallurie calcium"
},
{"name" : " Culture négative"
},
{"name" : " Culture positive"
},
{"name" : " syndrome de Cushing"
},
{"name" : " Cushingoïde"
},
{"name" : " Lymphome cutané à cellules T"
},
{"name" : " Hypersensibilité cutanée"
},
{"name" : " Larva migrans cutanée"
},
{"name" : " Lupus érythémateux cutané"
},
{"name" : " Sarcoïdose cutanée"
},
{"name" : " Vascularite cutanée"
},
{"name" : " Cutis anserina"
},
{"name" : " Cutis laxa"
},
{"name" : " Cyanopsie"
},
{"name" : " Cyanose"
},
{"name" : " Cyanose périphérique"
},
{"name" : " Maladie cardiaque cyanotique"
},
{"name" : " Syndrome de vomissements cycliques"
},
{"name" : " Cyclite"
},
{"name" : " Cyclophorie"
},
{"name" : " Cycloplegie"
},
{"name" : " Toxicité de la cyclosporine"
},
{"name" : " Trouble cyclothymique"
},
{"name" : " Kyste"
},
{"name" : " Kyste épidermique"
},
{"name" : " Fibrose kystique"
},
{"name" : " Urine de cystine"
},
{"name" : " Présence d'urine de cystine"
},
{"name" : " Cystinose"
},
{"name" : " Cystinurie"
},
{"name" : " Cystite"
},
{"name" : " Cystite hémorragique"
},
{"name" : " Cystite interstitielle"
},
{"name" : " Cystite non infectieuse"
},
{"name" : " Cystite virale"
},
{"name" : " Cystocèle"
},
{"name" : " Oedème maculaire cystoïde"
},
{"name" : " Syndrome de cytarabine"
},
{"name" : " Anomalie cytogénétique"
},
{"name" : " Syndrome de libération de cytokines"
},
{"name" : " Hépatite cytolytique"
},
{"name" : " Choriorétinite à cytomégalovirus"
},
{"name" : " Colite à cytomégalovirus"
},
{"name" : " Gastrite à cytomégalovirus"
},
{"name" : " Hépatite à cytomégalovirus"
},
{"name" : " Infection à cytomégalovirus"
},
{"name" : " Rétinite à cytomégalovirus"
},
{"name" : " Syndrome de cytomégalovirus"
},
{"name" : " Virémie à cytomégalovirus"
},
{"name" : " Cytopénie"
},
{"name" : "?dème cytotoxique"},
{"name" : " Dacryoadénite acquise"},
{"name" : " Dacryocanaliculite"
},
{"name" : " Dacryocystite"
},
{"name" : " Acquisition de la dacryosténose"
},
{"name" : " Dactylite"
},
{"name" : " Pellicules"
},
{"name" : " Cernes sous les yeux"
},
{"name" : " La somnolence diurne"
},
{"name" : " Foetus mort"
},
{"name" : " Surdité"
},
{"name" : " Surdité bilatérale"
},
{"name" : " Surdité neurosensorielle"
},
{"name" : " Surdité permanente"
},
{"name" : " Surdité transitoire"
},
{"name" : " Surdité unilatérale"
},
{"name" : " Décès"
},
{"name" : " Mort néonatale"
},
{"name" : " Cirrhose décompensée"
},
{"name" : " Décompensation cardiaque"
},
{"name" : " Diminution de l'appétit"
},
{"name" : " Diminution de la réponse immunitaire"
},
{"name" : " Diminution de l'intérêt"
},
{"name" : " Vision nocturne diminuée"
},
{"name" : " Diminution de la tolérance"
},
{"name" : " Sens vibratoire diminué"
},
{"name" : " Ulcère de décubitus"
},
{"name" : " Thrombose veineuse profonde"
},
{"name" : " Thrombose veineuse profonde postopératoire"
},
{"name" : " Urgence de défécation"
},
{"name" : " Défaut de conduction intraventriculaire"
},
{"name" : " Vision des couleurs défectueuse"
},
{"name" : " Anémie par carence"
},
{"name" : " Carence en sécrétion de bile"
},
{"name" : " Dégénérescence des fibromes utérins"
},
{"name" : " Myopie dégénérative"
},
{"name" : " Déshydratation"
},
{"name" : " Livraison retardée"
},
{"name" : " Vidange gastrique retardée"
},
{"name" : " Orgasme retardé"
},
{"name" : " Puberté retardée"
},
{"name" : " Retard de récupération après une anesthésie"
},
{"name" : " Délire"
},
{"name" : " Délire toxique"
},
{"name" : " Delirium tremens"
},
{"name" : " Illusion"
},
{"name" : " Délire de grandeur"
},
{"name" : " Troubles délirants"
},
{"name" : " Perception délirante"
},
{"name" : " Dément"
},
{"name" : " Démence"
},
{"name" : " Type de démence Alzheimer"
},
{"name" : " Démence à corps de Lewy"
},
{"name" : " Polyneuropathie démyélinisante"
},
{"name" : " Démyélinisation"
},
{"name" : " Trouble de démyélinisation SAI"
},
{"name" : " Kératite dendritique"
},
{"name" : " Caries dentaires"
},
{"name" : " Inconfort dentaire"
},
{"name" : " Abcès dento-alvéolaire"
},
{"name" : " Anomalie dento-faciale"
},
{"name" : " Dépendance"
},
{"name" : " Dépendance aux opiacés"
},
{"name" : " Dépendance physiologique"
},
{"name" : " Dépendance psychologique"
},
{"name" : " Dépersonnalisation"
},
{"name" : " Syndrome de dépersonnalisation"
},
{"name" : " Dépôt de calcium"
},
{"name" : " Oeil de dépôt"
},
{"name" : " Niveau de conscience déprimé"
},
{"name" : " Humeur dépressive"
},
{"name" : " Dépression"
},
{"name" : " Dépression aggravée"
},
{"name" : " Dépression suicidaire"
},
{"name" : " Dépression"
},
{"name" : " Épisode dépressif"
},
{"name" : " Symptôme dépressif"
},
{"name" : " Déréalisation"
},
{"name" : " Kyste cutané"
},
{"name" : " Dermatillomanie"
},
{"name" : " Dermatite"
},
{"name" : " Dermatite acnéiforme"
},
{"name" : " Dermatite atopique"
},
{"name" : " Dermatite bulleuse"
},
{"name" : " Contact avec la dermatite"
},
{"name" : " Couche de dermatite"
},
{"name" : " Exfoliation de la dermatite"
},
{"name" : " Paupière de dermatite"
},
{"name" : " Poussée de dermatite"
},
{"name" : " Dermatite hémorragique"
},
{"name" : " Dermatite herpétiforme"
},
{"name" : " Dermatite infectée"
},
{"name" : " Contact irritant avec la dermatite"
},
{"name" : " Dermatite périorale"
},
{"name" : " Dermatite psoriasiforme"
},
{"name" : " Rayonnement de la dermatite SAI"
},
{"name" : " Dermatochalasis"
},
{"name" : " Dermatofibrosarcome protuberans"
},
{"name" : " Dermatomyosite"
},
{"name" : " Dermatophytose"
},
{"name" : " Kyste dermoïde"
},
{"name" : " Kyste dermoïde de l'ovaire"
},
{"name" : " Descémétite"
},
{"name" : " Thyroïdite destructrice"
},
{"name" : " Détachement de l'épithélium pigmentaire rétinien"
},
{"name" : " Détachement psychologique"
},
{"name" : " Hyperréflexie détrusorienne"
},
{"name" : " Instabilité du détrusor"
},
{"name" : " Trouble de la coordination du développement"
},
{"name" : " Retard de développement"
},
{"name" : " Glaucome développemental"
},
{"name" : " Dysplasie développementale de la hanche"
},
{"name" : " Rupture de l'appareil"
},
{"name" : " Problème de capture de périphérique"
},
{"name" : " Dislocation de l'appareil"
},
{"name" : " Expulsion de l'appareil"
},
{"name" : " Interaction avec l'appareil"
},
{"name" : " Dysfonctionnement de l'appareil"
},
{"name" : " Occlusion de l'appareil"
},
{"name" : " Infection liée à l'appareil"
},
{"name" : " Septicémie liée à l'appareil"
},
{"name" : " Diabète insipide"
},
{"name" : " Diabète sucré"
},
{"name" : " Le diabète sucré exacerbé"
},
{"name" : " Contrôle insuffisant du diabète sucré"
},
{"name" : " Diabétique"
},
{"name" : " Neuropathie diabétique autonome"
},
{"name" : " Coma diabétique"
},
{"name" : " Complication diabétique"
},
{"name" : " Infection du pied diabétique"
},
{"name" : " Gastroparésie diabétique"
},
{"name" : " Coma hyperglycémique diabétique"
},
{"name" : " Coma hyperosmolaire diabétique"
},
{"name" : " Acidocétose diabétique"
},
{"name" : "?dème maculaire diabétique"
},
{"name" : " Néphropathie diabétique"
},
{"name" : " Neuropathie diabétique"
},
{"name" : " Douleur neuropathique diabétique périphérique"
},
{"name" : " Neuropathie périphérique diabétique"
},
{"name" : "?dème rétinien diabétique"
},
{"name" : " Rétinopathie diabétique"
},
{"name" : " Trouble vasculaire diabétique"
},
{"name" : " Démence de dialyse"
},
{"name" : " Anémie Diamond-Blackfan"
},
{"name" : " Hernie diaphragmatique"
},
{"name" : " La diarrhée"
},
{"name" : " Diarrhée hémorragique"
},
{"name" : " Syndrome du côlon irritable prédominant de diarrhée"
},
{"name" : " Diarrhée, Clostridium difficile"
},
{"name" : " Dysfonctionnement diastolique"
},
{"name" : " Hypertension diastolique"
},
{"name" : " Refus de régime"
},
{"name" : " Difficulté à concentrer les yeux"
},
{"name" : " Difficulté à dormir"
},
{"name" : " Difficulté à penser"
},
{"name" : " Alopécie diffuse"
},
{"name" : " Lymphome diffus à grandes cellules B"
},
{"name" : " Digestion altérée"
},
{"name" : " Ulcère numérique"
},
{"name" : " Intoxication digitalique (NOS)"
},
{"name" : " Toxicité digitalique"
},
{"name" : " Effet digoxine"
},
{"name" : " Augmentation du niveau de digoxine"
},
{"name" : " Toxicité de la digoxine"
},
{"name" : " Déficit en dihydropyrimidine déshydrogénase"
},
{"name" : " Dilatation auriculaire"
},
{"name" : " Dilatation ventriculaire"
},
{"name" : " Diphtérie"
},
{"name" : " Diphyllobothriase"
},
{"name" : " Diplégie"
},
{"name" : " Diplopie"
},
{"name" : " Augmentation de la bilirubine directe"
},
{"name" : " Invalidité"
},
{"name" : " Lupus érythémateux discoïde"
},
{"name" : " Malaise"
},
{"name" : " Gêne rectale"
},
{"name" : " Évolution de la maladie"
},
{"name" : " Récidive de la maladie"
},
{"name" : " Syndrome de déséquilibre"
},
{"name" : " Désinhibition"
},
{"name" : " Naissance trouble"
},
{"name" : " Trouble calcique (SAI)"
},
{"name" : " Trouble périosté"
},
{"name" : " Trouble de la vue"
},
{"name" : " Troubles de l'équilibre hydrique, électrolytique et acido-basique"
},
{"name" : " Troubles du métabolisme du cycle de l'urée"
},
{"name" : " Désorientation"
},
{"name" : " Adénocarcinome disséminé"
},
{"name" : " Coagulation intravasculaire disséminée"
},
{"name" : " Infection du complexe mycobacterium avium disséminé"
},
{"name" : " Tuberculose disséminée"
},
{"name" : " Dissociation"
},
{"name" : " Trouble dissociatif"
},
{"name" : " Dilatation"
},
{"name" : " Distractibilité"
},
{"name" : " Détresse"
},
{"name" : " Détresse gastro-intestinale"
},
{"name" : " Perturbation de l'attention"
},
{"name" : " Perturbation de l'excitation sexuelle"
},
{"name" : " Perturbation du comportement social"
},
{"name" : " Réaction de type disulfirame"
},
{"name" : " Désatrophier l'atrophie musculaire"
},
{"name" : " Diurèse"
},
{"name" : " Effet diurétique"
},
{"name" : " Perforation diverticulaire"
},
{"name" : " Diverticulite"
},
{"name" : " Diverticulite aggravée"
},
{"name" : " Diverticule"
},
{"name" : " Diverticule intestinal"
},
{"name" : " Vertiges"
},
{"name" : " Étourdissements aggravés"
},
{"name" : " Étourdissements à l'effort"
},
{"name" : " Vertiges postural"
},
{"name" : " Étourdissements"
},
{"name" : " Rêve excessif"
},
{"name" : " Etat de rêve"
},
{"name" : " Dribble d'urine"
},
{"name" : " Bave"
},
{"name" : " Drop attaques"
},
{"name" : " Battements perdus"
},
{"name" : " Somnolence"
},
{"name" : " Interaction médicament-aliment"
},
{"name" : " Abus de drogue"
},
{"name" : " Erreur d'administration du médicament"
},
{"name" : " Envie de drogue"
},
{"name" : " Dépendance aux drogues"
},
{"name" : " Effet du médicament diminué"
},
{"name" : " Effet médicamenteux augmenté"
},
{"name" : " Effet médicamenteux prolongé"
},
{"name" : " Toxidermie"
},
{"name" : " Fièvre du à un médicament"
},
{"name" : " Hypersensibilité médicamenteuse"
},
{"name" : " Médicament inefficace"
},
{"name" : " Interaction médicamenteuse"
},
{"name" : " Intolérance aux drogues"
},
{"name" : " Niveau de médicament changé"
},
{"name" : " Niveau de médicament diminué"
},
{"name" : " Augmentation du niveau du médicament"
},
{"name" : " Niveau thérapeutique du médicament"
},
{"name" : " Mauvaise administration du médicament"
},
{"name" : " Réaction médicamenteuse avec éosinophilie et symptômes systémiques"
},
{"name" : " Dépistage positif du médicament"
},
{"name" : " Comportement de recherche de médicament"
},
{"name" : " Tolérance aux médicaments"
},
{"name" : " Tolérance aux médicaments diminuée"
},
{"name" : " Toxicité médicamenteuse"
},
{"name" : " Convulsions de sevrage médicamenteux"
},
{"name" : " Syndrome de sevrage médicamenteux"
},
{"name" : " Syndrome de sevrage médicamenteux néonatal"
},
{"name" : " Toux d'origine médicamenteuse"
},
{"name" : " Hépatite d'origine médicamenteuse"
},
{"name" : " Syndrome d'hypersensibilité d'origine médicamenteuse"
},
{"name" : " Lésion hépatique d'origine médicamenteuse"
},
{"name" : " Lupus érythémateux d'origine médicamenteuse"
},
{"name" : " Parkinsonisme d'origine médicamenteuse"
},
{"name" : " Toux sèche"
},
{"name" : " Yeux secs"
},
{"name" : " Syndrome de l'?il sec"
},
{"name" : " Cheveux secs"
},
{"name" : " Bouche sèche"
},
{"name" : " Cuir chevelu sec"
},
{"name" : " Peau sèche"
},
{"name" : " Gorge sèche"
},
{"name" : " Syndrome de dumping gastrique"
},
{"name" : " Perforation duodénale"
},
{"name" : " Ulcère duodénal"
},
{"name" : " Ulcère duodénal aggravé"
},
{"name" : " Hémorragie d'ulcère duodénal"
},
{"name" : " Perforation de l'ulcère duodénal"
},
{"name" : " Duodénite"
},
{"name" : " Duodénite hémorragique"
},
{"name" : " Contracture de Dupuytren"
},
{"name" : " Nanisme"
},
{"name" : " Dysacousie"
},
{"name" : " Dysesthésie"
},
{"name" : " Dysesthésie pharynx"
},
{"name" : " Dysarthrie"
},
{"name" : " Dysautonomie"
},
{"name" : " Dyschezia"
},
{"name" : " Dyschromatopsie"
},
{"name" : " Dysdiadochokinesie"
},
{"name" : " Dysenterie"
},
{"name" : " Dysequilibrium"
},
{"name" : " Dysfonction surrénale"
},
{"name" : " Dysfonction thyroïdienne"
},
{"name" : " Dysgueusie"
},
{"name" : " Dysgraphie"
},
{"name" : " Eczéma dyshidrotique"
},
{"name" : " Dyskinésie"
},
{"name" : " Dyslexie"
},
{"name" : " Dyslipidémie"
},
{"name" : " Dyslipoprotéinémie"
},
{"name" : " Dysménorrhée"
},
{"name" : " Dysmetrie"
},
{"name" : " Dysmorphisme"
},
{"name" : " Dysosmie"
},
{"name" : " Dyspareunie"
},
{"name" : " Dyspepsie"
},
{"name" : " Dyspepsie aggravée"
},
{"name" : " Signes et symptômes dyspeptiques"
},
{"name" : " Dysphagie"
},
{"name" : " Dysphasie"
},
{"name" : " Dysphémie"
},
{"name" : " Dysphonie"
},
{"name" : " Dysphorie"
},
{"name" : " Dysplasie"
},
{"name" : " Dyspnée"
},
{"name" : " Dyspnée au repos"
},
{"name" : " Dyspnée exacerbée"
},
{"name" : " Dyspnée d'effort"
},
{"name" : " Dyspnée paroxystique nocturne"
},
{"name" : " Dyssomnie"
},
{"name" : " Dysstasie"
},
{"name" : " Dysthymie"
},
{"name" : " Dystonie"
},
{"name" : " Réaction dystonique"
},
{"name" : " Calcification dystrophique"
},
{"name" : " Dysurie"
},
{"name" : " Affections de l'oreille et du labyrinthe"
},
{"name" : " Bourdonnement d'oreille"
},
{"name" : " Érythème du conduit auditif"
},
{"name" : " Congestion auriculaire"
},
{"name" : " Inconfort d'oreille"
},
{"name" : " Trouble de l'oreille"
},
{"name" : " Affections de l'oreille NEC"
},
{"name" : " L'oreille est bouchée"
},
{"name" : " Hémorragie auriculaire"
},
{"name" : " Infection de l'oreille"
},
{"name" : " Malformation de l'oreille"
},
{"name" : " Douleur à l'oreille"
},
{"name" : " Prurit auriculaire"
},
{"name" : " Oreille rugissant"
},
{"name" : " Ménarche précoce"
},
{"name" : " Satiété précoce"
},
{"name" : " Trouble de l'alimentation"
},
{"name" : " Ecchymose"
},
{"name" : " Signes ECG d'ischémie myocardique"
},
{"name" : " Échinococcose"
},
{"name" : " Échoacousie"
},
{"name" : " Échocardiogramme anormal"
},
{"name" : " Écholalie"
},
{"name" : " Éclampsie"
},
{"name" : " Ecthyma"
},
{"name" : " Syndrome ectopique d'ACTH"
},
{"name" : " Ossification ectopique"
},
{"name" : " Grossesse extra-utérine"
},
{"name" : " Ectromelia"
},
{"name" : " Ectropion"
},
{"name" : " Ectropion du col de l'utérus"
},
{"name" : " Eczéma"
},
{"name" : " Eczéma allergique atopique"
},
{"name" : " Eczéma exacerbé"
},
{"name" : " Paupières d'eczéma"
},
{"name" : " Eczéma herpétique"
},
{"name" : " Eczéma infantile"
},
{"name" : " Eczéma infecté"
},
{"name" : " Eczéma nummulaire"
},
{"name" : "?dème cérébral"
},
{"name" : " Mains d'?dème"
},
{"name" : "?dème des membres inférieurs"
},
{"name" : "?dème transitoire"
},
{"name" : " Effusion"
},
{"name" : " Épanchement du genou"
},
{"name" : " Ejaculation diminuée"
},
{"name" : " Éjaculation retardée"
},
{"name" : " Trouble de l'éjaculation"
},
{"name" : " Échec de l'éjaculation"
},
{"name" : " Éjaculation inhibée"
},
{"name" : " Fraction d'éjection diminuée"
},
{"name" : " Elastosis perforans"
},
{"name" : " Choc électrique"
},
{"name" : " Prolongation de l'électrocardiogramme PR"
},
{"name" : " Électrocardiogramme PR raccourci"
},
{"name" : " Électrocardiogramme QRS complexe"
},
{"name" : " Électrocardiogramme complexe QRS anormal"
},
{"name" : " Électrocardiogramme QRS complexe prolongé"
},
{"name" : " Intervalle corrigé de l'électrocardiogramme QT"
},
{"name" : " Intervalle corrigé de l'électrocardiogramme QT prolongé"
},
{"name" : " Intervalle QT d'électrocardiogramme"
},
{"name" : " Intervalle QT d'électrocardiogramme anormal"
},
{"name" : " Électrocardiogramme QT prolongé"
},
{"name" : " Électrocardiogramme QT raccourci"
},
{"name" : " Segment électrocardiogramme ST"
},
{"name" : " Électrocardiogramme segment ST anormal"
},
{"name" : " Dépression du segment ST de l'électrocardiogramme"
},
{"name" : " Élévation du segment ST de l'électrocardiogramme"
},
{"name" : " Changement d'électrocardiogramme ST-T"
},
{"name" : " Électrocardiogramme segment ST-T anormal"
},
{"name" : " Électrocardiogramme onde T anormal"
},
{"name" : " Amplitude des ondes T de l'électrocardiogramme diminuée"
},
{"name" : " Inversion de l'onde T de l'électrocardiogramme"
},
{"name" : " Électrocardiogramme onde U présente"
},
{"name" : " Anomalie de l'onde U d'électrocardiogramme"
},
{"name" : " Électrocardiogramme anormal"
},
{"name" : " Électrocardiogramme anormal spécifique"
},
{"name" : " Changement d'électrocardiogramme"
},
{"name" : " Électrocardiogramme normal"
},
{"name" : " Électrocardiogramme mauvaise progression des ondes R"
},
{"name" : " Anomalie de repolarisation d'électrocardiogramme"
},
{"name" : " Électroencéphalogramme anormal"
},
{"name" : " Anomalie électrolytique"
},
{"name" : " Épuisement électrolytique"
},
{"name" : " Perturbation électrolytique"
},
{"name" : " Déséquilibre électrolytique"
},
{"name" : " Electrolytes NOS diminué"
},
{"name" : " Électrorétinogramme anormal"
},
{"name" : " Niveaux élevés d'enzymes hépatiques"
},
{"name" : " Humeur élevée"
},
{"name" : " AVC embolique"
},
{"name" : " Embolie"
},
{"name" : " Embolie artérielle"
},
{"name" : " Embolie artérielle (membre)"
},
{"name" : " Membre d'embolie"
},
{"name" : " Embolie veineuse"
},
{"name" : " Embolus"
},
{"name" : " Jambe d'embolie"
},
{"name" : " Trouble émotionnel"
},
{"name" : " Détresse émotionelle"
},
{"name" : " Troubles émotionnels SAI"
},
{"name" : " Pauvreté émotionnelle"
},
{"name" : " Problèmes émotionnels"
},
{"name" : " Emphysème"
},
{"name" : " Emprosthotonus"
},
{"name" : " Syndrome de sella vide"
},
{"name" : " Empyème"
},
{"name" : " Enanthema"
},
{"name" : " Encéphalite"
},
{"name" : " Encéphalite cytomégalovirus"
},
{"name" : " Encéphalite virale"
},
{"name" : " Encéphalocèle"
},
{"name" : " Encéphalomyélite"
},
{"name" : " Encéphalopathie"
},
{"name" : " Encéphalopathie aiguë"
},
{"name" : " SIDA en phase terminale"
},
{"name" : " Cancer en phase terminale"
},
{"name" : " Maladie hépatique au stade terminal"
},
{"name" : " Fibrose endocardique"
},
{"name" : " Endocardite"
},
{"name" : " Endocardite bactérienne"
},
{"name" : " Endocardite staphylococcique"
},
{"name" : " Trouble endocrinien"
},
{"name" : " Affections endocriniennes congénitales"
},
{"name" : " Tumeur endocrine"
},
{"name" : " Néoplasmes endocriniens malins et sans précision"
},
{"name" : " Dépression endogène"
},
{"name" : " Adénocarcinome de l'endomètre"
},
{"name" : " Cancer de l'endomètre"
},
{"name" : " Cancer de l'endomètre stade IV"
},
{"name" : " Trouble de l'endomètre"
},
{"name" : " Hyperplasie de l'endomètre"
},
{"name" : " Hypertrophie endométriale"
},
{"name" : " Tumeur de l'endomètre"
},
{"name" : " Tumeur maligne de l'endomètre"
},
{"name" : " Épaississement de l'endomètre"
},
{"name" : " Endométriose"
},
{"name" : " Endométrite"
},
{"name" : " Endomyométrite"
},
{"name" : " Endophtalmie"
},
{"name" : " Complication de l'intubation endotrachéale"
},
{"name" : " Obstruction de la sonde endotrachéale"
},
{"name" : " Augmentation de l'énergie"
},
{"name" : " Clitoris élargi"
},
{"name" : " Élargissement de l'abdomen"
},
{"name" : " Enophthalmos"
},
{"name" : " Entérite"
},
{"name" : " Entérite ulcéreuse"
},
{"name" : " Septicémie à Enterobacter"
},
{"name" : " Entérobiose"
},
{"name" : " Bactériémie entérococcique"
},
{"name" : " Infection entérococcique"
},
{"name" : " Entérocolite"
},
{"name" : " Entérocolite hémorragique"
},
{"name" : " Entérocolite infectieuse"
},
{"name" : " Fistule entérocutanée"
},
{"name" : " Énurésie"
},
{"name" : " Exposition environnementale"
},
{"name" : " Anomalie enzymatique"
},
{"name" : " Induction enzymatique"
},
{"name" : " Inhibition enzymatique"
},
{"name" : " Éosinopénie"
},
{"name" : " Nombre anormal d'éosinophiles"
},
{"name" : " Augmentation du nombre d'éosinophiles"
},
{"name" : " Éosinophilie"
},
{"name" : " Cystite éosinophile"
},
{"name" : " Myocardite éosinophile"
},
{"name" : " Pneumonie éosinophile"
},
{"name" : " Folliculite pustuleuse éosinophile"
},
{"name" : " Éosinophilurie"
},
{"name" : " Épendymome"
},
{"name" : " Ephelides"
},
{"name" : " Épicondylite"
},
{"name" : " Typhus épidémique"
},
{"name" : " Conditions épidermiques et dermiques"
},
{"name" : " Récepteur du facteur de croissance épidermique diminué"
},
{"name" : " Naevus épidermique"
},
{"name" : " Nécrose épidermique"
},
{"name" : " Épidermolyse"
},
{"name" : " Épidermolyse bulleuse"
},
{"name" : " Tendresse épididymaire"
},
{"name" : " Épididymite"
},
{"name" : " Épididymo-orchite"
},
{"name" : " Hémorragie épidurale"
},
{"name" : " Lipomatose épidurale"
},
{"name" : " Gêne épigastrique"
},
{"name" : " Détresse épigastrique"
},
{"name" : " Plénitude épigastrique"
},
{"name" : " Douleur épigastrique"
},
{"name" : " Douleurs épigastriques non liées à l'alimentation"
},
{"name" : " Épiglottite"
},
{"name" : " Épilepsie"
},
{"name" : " Épilepsie aggravée"
},
{"name" : " Epiphyses fusion prématurée"
},
{"name" : " Épiphysiolyse"
},
{"name" : " Épisclérite"
},
{"name" : " Épistaxis"
},
{"name" : " Cellules épithéliales urine"
},
{"name" : " Infection par le virus d'Epstein-Barr"
},
{"name" : " Perte d'équilibre"
},
{"name" : " Dysfonction érectile"
},
{"name" : " Érection augmentée"
},
{"name" : " Érection prolongée"
},
{"name" : " Empoisonnement à l'ergot"
},
{"name" : " Gastroduodénite érosive"
},
{"name" : " Oesophagite érosive"
},
{"name" : " Éructation"
},
{"name" : " Éruption"
},
{"name" : " Lichénoïde d'éruption"
},
{"name" : " Xanthome éruptif"
},
{"name" : " Érésipèle"
},
{"name" : " Érysipéloïde"
},
{"name" : " Érythème"
},
{"name" : " Erythema annulare"
},
{"name" : " Erythema annulare centrifugum"
},
{"name" : " Érythème facial"
},
{"name" : " Érythème infectieux"
},
{"name" : " Erythema migrans"
},
{"name" : " Érythème polymorphe"
},
{"name" : " Érythème polymorphe mineur"
},
{"name" : " Érythème polymorphe sévère"
},
{"name" : " Erythema nodosum"
},
{"name" : " Erythema nodosum leprosum"
},
{"name" : " Érythème de la paupière"
},
{"name" : " Érythème périorbitaire"
},
{"name" : " Erythrasma"
},
{"name" : " Érythroblastopénie"
},
{"name" : " Érythrocytose"
},
{"name" : " Psoriasis érythrodermique"
},
{"name" : " Érythroleucémie"
},
{"name" : " Érythromélalgie"
},
{"name" : " Érythropénie"
},
{"name" : " Érythropoïèse anormale"
},
{"name" : " Protoporphyrie érythropoïétique"
},
{"name" : " Érythropsie"
},
{"name" : " Érythrose"
},
{"name" : " Eschar"
},
{"name" : " Bactériémie d'Escherichia"
},
{"name" : " Infection à Escherichia coli"
},
{"name" : " Infection à Escherichia"
},
{"name" : " Escherichia sepsis"
},
{"name" : " Érosions ?sophagiennes"
},
{"name" : " Esotropia"
},
{"name" : " Hypertension artérielle essentielle"
},
{"name" : " Thrombocytémie essentielle"
},
{"name" : " Tremblement essentiel"
},
{"name" : " Éloignement"
},
{"name" : " Humeur euphorique"
},
{"name" : " Trouble de la trompe d'Eustache"
},
{"name" : " Goitre euthyroïdien"
},
{"name" : " Syndrome d'Evans"
},
{"name" : " Sarcome d'Ewing"
},
{"name" : " Exacerbation de l'acné"
},
{"name" : " Exacerbation de l'asthme"
},
{"name" : " Exacerbation des bouffées de chaleur"
},
{"name" : " Réponse de sursaut exagérée"
},
{"name" : " Somnolence diurne excessive"
},
{"name" : " Flatulence excessive"
},
{"name" : " Tissu de granulation excessif"
},
{"name" : " Soif excessive"
},
{"name" : " Excitabilité"
},
{"name" : " Excitable"
},
{"name" : " Excitation cérébrale"
},
{"name" : " Excitation"
},
{"name" : " Excoriation"
},
{"name" : " Exencéphalie"
},
{"name" : " Angine induite par l'exercice"
},
{"name" : " Anaphylaxie induite par l'exercice"
},
{"name" : " Bronchospasme induit par l'exercice"
},
{"name" : " Conditions d'exfoliation"
},
{"name" : " Éruption exfoliative"
},
{"name" : " Épuisement"
},
{"name" : " Exomphalos"
},
{"name" : " Exophtalmie"
},
{"name" : " Exostose"
},
{"name" : " Trouble de la personnalité explosive"
},
{"name" : " Exposition au plomb"
},
{"name" : " Exposition à une plante toxique"
},
{"name" : " Exposition à un agent toxique"
},
{"name" : " Trouble du langage expressif"
},
{"name" : " Brûlures étendues"
},
{"name" : " Réponse plantaire extenseur"
},
{"name" : " Trouble de l'oreille externe"
},
{"name" : " Ophtalmoplégie externe"
},
{"name" : " Abcès extradural"
},
{"name" : " Lymphome extranodal NK / T, de type nasal"
},
{"name" : " Lymphome à cellules B de la zone marginale extranodale (type MALT)"
},
{"name" : " Pneumocystose extrapulmonaire"
},
{"name" : " Tuberculose extrapulmonaire"
},
{"name" : " Trouble extrapyramidal"
},
{"name" : " Symptômes extrapyramidaux"
},
{"name" : " Ossification extrasquelettique"
},
{"name" : " Extrasystoles"
},
{"name" : " Extravasation"
},
{"name" : " Contracture des extrémités"
},
{"name" : " Nécrose des extrémités"
},
{"name" : " Allergie oculaire"
},
{"name" : " Saignement des yeux"
},
{"name" : " Brûlures oculaires"
},
{"name" : " Écoulement oculaire"
},
{"name" : " Trouble oculaire"
},
{"name" : " Hémorragie oculaire"
},
{"name" : " Infection oculaire"
},
{"name" : " Infection oculaire bactérienne"
},
{"name" : " Infection oculaire virale"
},
{"name" : " Blessure à l'?il"
},
{"name" : " Irritation de l'oeil"
},
{"name" : " Trouble du mouvement des yeux"
},
{"name" : " Naevus des yeux"
},
{"name" : " Oedème oculaire"
},
{"name" : " Douleur oculaire"
},
{"name" : " Pénétration oculaire"
},
{"name" : " Prurit oculaire"
},
{"name" : " Rougeur des yeux"
},
{"name" : " Roulement des yeux"
},
{"name" : " Gonflement des yeux"
},
{"name" : " Ulcère oculaire"
},
{"name" : " Perte de sourcils"
},
{"name" : " Assombrissement des cils"
},
{"name" : " Décoloration des cils"
},
{"name" : " Hyperpigmentation des cils"
},
{"name" : " Épaississement des cils"
},
{"name" : " Saignement des paupières"
},
{"name" : " Trouble des paupières"
},
{"name" : " Exfoliation des paupières"
},
{"name" : " Trouble de la fonction des paupières"
},
{"name" : " Infection des paupières"
},
{"name" : " Irritation des paupières"
},
{"name" : " Croûtes des bords des paupières"
},
{"name" : "?dème des paupières"
},
{"name" : " Douleur aux paupières"
},
{"name" : " Ptose des paupières"
},
{"name" : " Rétraction des paupières"
},
{"name" : " Prurit des paupières"
},
{"name" : " Blessure au visage"
},
{"name" : " Oedème du visage"
},
{"name" : " Fracture des os du visage"
},
{"name" : " Névralgie faciale"
},
{"name" : " Douleur faciale"
},
{"name" : " Paralysie faciale"
},
{"name" : " Parésie faciale"
},
{"name" : " Paresthésie faciale"
},
{"name" : " Éruption faciale"
},
{"name" : " Spasme facial"
},
{"name" : " Perte du visage"
},
{"name" : " Carence en facteur I"
},
{"name" : " Carence en facteur II"
},
{"name" : " Carence en facteur IX"
},
{"name" : " Carence en facteur VIII"
},
{"name" : " Carence en facteur XI"
},
{"name" : " Incontinence fécale"
},
{"name" : " Sang occulte fécal positif"
},
{"name" : " Fécalith"
},
{"name" : " Fécalome"
},
{"name" : " Fèces décolorées"
},
{"name" : " Les excréments durs"
},
{"name" : " Échec de l'induction du travail"
},
{"name" : " Retard de croissance"
},
{"name" : " Paludisme à Falciparum"
},
{"name" : " Chute"
},
{"name" : " Kyste des trompes de Fallope"
},
{"name" : " Obstruction des trompes de Fallope"
},
{"name" : " Tétralogie de Fallot"
},
{"name" : " Paralysie périodique familiale"
},
{"name" : " Hypertension artérielle pulmonaire familiale"
},
{"name" : " Tremblements familiaux"
},
{"name" : " Stress familial"
},
{"name" : " Syndrome de Fanconi"
},
{"name" : " Syndrome de Fanconi acquis"
},
{"name" : " Fascination"
},
{"name" : " Fasciite"
},
{"name" : " Jeûne"
},
{"name" : " Augmentation de la glycémie à jeun"
},
{"name" : " Hyperglycémie à jeun"
},
{"name" : " Atrophie des graisses"
},
{"name" : " Embolie graisseuse"
},
{"name" : " Intolérance aux graisses"
},
{"name" : " Nécrose graisseuse"
},
{"name" : " Redistribution des graisses"
},
{"name" : " Augmentation du tissu adipeux"
},
{"name" : " Résultats fatals"
},
{"name" : " Fatigabilité"
},
{"name" : " Fatigue"
},
{"name" : " Fatigue aggravée"
},
{"name" : " Peur"
},
{"name" : " Peur de la mort"
},
{"name" : " Aplasie médullaire fébrile"
},
{"name" : " Convulsion fièvreuse"
},
{"name" : " Troubles fébriles"
},
{"name" : " Neutropénie fébrile"
},
{"name" : " Fèces tachées de sang"
},
{"name" : " Sensation anormale"
},
{"name" : " Sensation de froid"
},
{"name" : " Sensation d'ébriété"
},
{"name" : " Sentiment de culpabilité"
},
{"name" : " Sensation de chaleur"
},
{"name" : " Sensation de chaud et de froid"
},
{"name" : " Sensation nervosité"
},
{"name" : " Sentiment de changement de température corporelle"
},
{"name" : " Sentiment de désespoir"
},
{"name" : " Sentiment de détente"
},
{"name" : " Sensation d'urine résiduelle"
},
{"name" : " Sentiment de tristesse"
},
{"name" : " Sensation de maladie"
},
{"name" : " Sensation étrange"
},
{"name" : " Sensation de tension"
},
{"name" : " Sentiments d'inutilité"
},
{"name" : " Ressenti faible"
},
{"name" : " Syndrome de Felty"
},
{"name" : " Trouble orgasmique féminin"
},
{"name" : " Tumeur reproductrice femelle"
},
{"name" : " Trouble d'excitation sexuelle féminine"
},
{"name" : " Dysfonction sexuelle féminine"
},
{"name" : " Féminisation acquise"
},
{"name" : " Féminisation"
},
{"name" : " Thrombose de l'artère fémorale"
},
{"name" : " Fracture du col fémoral"
},
{"name" : " Fracture du fémur"
},
{"name" : " Fracture du fémur sous-trochantérien"
},
{"name" : " Fracture du fémur"
},
{"name" : " Fertilité féminine diminuée"
},
{"name" : " Fertilité masculine diminuée"
},
{"name" : " Fertilisation"
},
{"name" : " Démarche fatidique"
},
{"name" : " Fièvre, frissons"
},
{"name" : " Fièvre néonatale"
},
{"name" : " Fièvre d'origine inconnue"
},
{"name" : " Fibrillation auriculaire aggravée"
},
{"name" : " Fibrinogène diminué"
},
{"name" : " Fibroadénome du sein"
},
{"name" : " Fibroadénose du sein"
},
{"name" : " Maladie fibrokystique du sein"
},
{"name" : " Maladie fibrokystique"
},
{"name" : " Fibrome"
},
{"name" : " Fibromyalgie"
},
{"name" : " Fibrose"
},
{"name" : " Filariose"
},
{"name" : " Filariose lymphatique"
},
{"name" : " Déformation des doigts"
},
{"name" : " Fistule"
},
{"name" : " Éruption fixe de drogue"
},
{"name" : " Éruption fixe"
},
{"name" : " Point de côté"
},
{"name" : " Retour en arrière"
},
{"name" : " Affect plat"
},
{"name" : " Flatulence"
},
{"name" : " Fuite des idées"
},
{"name" : " Sentiment flottant"
},
{"name" : " Bébé disquette"
},
{"name" : " Syndrome de l'iris de disquette"
},
{"name" : " Symptômes de la grippe"
},
{"name" : " Déséquilibre hydrique et électrolytique"
},
{"name" : " Déséquilibre fluide"
},
{"name" : " Augmentation de l'apport hydrique"
},
{"name" : " Réduction de l'apport hydrique"
},
{"name" : " Perte de liquide"
},
{"name" : " Surcharge fluide"
},
{"name" : " Rétention d'eau"
},
{"name" : " Augmentation du fluorure"
},
{"name" : " Fluorose"
},
{"name" : " Rinçage"
},
{"name" : " Glomérulosclérose segmentaire focale"
},
{"name" : " Acidose f?tale"
},
{"name" : " Syndrome d'alcoolisation f?tale"
},
{"name" : " Syndrome anticonvulsivant f?tal"
},
{"name" : " Anomalie chromosomique f?tale"
},
{"name" : " Dommages f?taux"
},
{"name" : " Mort f?tale"
},
{"name" : " Trouble f?tal"
},
{"name" : " Syndrome de détresse f?tale"
},
{"name" : " Fréquence cardiaque f?tale"
},
{"name" : " Foetor hepaticus"
},
{"name" : " Carence en folates"
},
{"name" : " Conjonctivite folliculaire"
},
{"name" : " Cancer folliculaire de la thyroïde"
},
{"name" : " Folliculite"
},
{"name" : " Fontanelle bombée"
},
{"name" : " Allergie alimentaire"
},
{"name" : " Aversion alimentaire"
},
{"name" : " Envie de nourriture"
},
{"name" : " Interaction alimentaire"
},
{"name" : " Intolérance alimentaire"
},
{"name" : " Intoxication alimentaire"
},
{"name" : " Fièvre aphteuse"
},
{"name" : " Oedème du pied"
},
{"name" : " Fracture du pied"
},
{"name" : " Infection fongique du pied SAI"
},
{"name" : " Douleur au pied"
},
{"name" : " Footdrop"
},
{"name" : " Foramen ovale patent"
},
{"name" : " Volume expiratoire forcé diminué"
},
{"name" : " Corps étranger"
},
{"name" : " Corps étranger dans l'?il"
},
{"name" : " Sensation de corps étranger dans les yeux"
},
{"name" : " Oubli"
},
{"name" : " Formication"
},
{"name" : " Trouvé mort"
},
{"name" : " Trouvé mort (cause indéterminée)"
},
{"name" : " Fraction d'oxygène inspiré"
},
{"name" : " Fracture"
},
{"name" : " Hématurie franche"
},
{"name" : " Lipidémie de Fredrickson Type III"
},
{"name" : " Augmentation de l'antigène libre spécifique de la prostate"
},
{"name" : " Phénomène de gel"
},
{"name" : " Mouvements intestinaux fréquents"
},
{"name" : " Maux de tête fréquents"
},
{"name" : " Frottement "
},
{"name" : " Frigidité"
},
{"name" : " Épaule gelée"
},
{"name" : " Intolérance au fructose"
},
{"name" : " Frustration"
},
{"name" : " Plénitude abdominale"
},
{"name" : " Fonction rénale diminuée"
},
{"name" : " Fonction hépatique diminuée"
},
{"name" : " Dyspepsie fonctionnelle"
},
{"name" : " Trouble gastro-intestinal fonctionnel"
},
{"name" : " Polype de la glande fundique"
},
{"name" : " Fungémie"
},
{"name" : " Infection fongique"
},
{"name" : " Péritonite fongique"
},
{"name" : " Éruption fongique"
},
{"name" : " Septicémie fongique"
},
{"name" : " Infection fongique de la peau"
},
{"name" : " Test fongique positif"
},
{"name" : " Test de crachat fongique positif"
},
{"name" : " Furoncle"
},
{"name" : " Furonculose"
},
{"name" : " Infection au fusarium"
},
{"name" : " Tête floue"
},
{"name" : " Bâillonnement"
},
{"name" : " Troubles de la marche"
},
{"name" : " Marche aléatoire"
},
{"name" : " Galactorrhée"
},
{"name" : " Cancer de la vésicule biliaire"
},
{"name" : " Trouble de la vésicule biliaire"
},
{"name" : " Infection de la vésicule biliaire"
},
{"name" : " Polype de la vésicule biliaire"
},
{"name" : " Boues de vésicule biliaire"
},
{"name" : " Rythme de galop"
},
{"name" : " Augmentation des globulines gamma"
},
{"name" : " Augmentation de la gamma-glutamyltransférase"
},
{"name" : " Les gammaglobulines ont diminué"
},
{"name" : " Gangrène"
},
{"name" : " Cholécystite gangreneuse"
},
{"name" : " Gaz"
},
{"name" : " Gangrène gazeuse"
},
{"name" : " Gaz dans l'estomac"
},
{"name" : " Douleur gazeuse"
},
{"name" : " Halètement"
},
{"name" : " Atonie gastrique"
},
{"name" : " Cancer de l'estomac"
},
{"name" : " Dilatation gastrique"
},
{"name" : " Trouble gastrique"
},
{"name" : " Érosions gastriques"
},
{"name" : " Grippe gastrique"
},
{"name" : " Hémorragie gastrique"
},
{"name" : " Irritation gastrique"
},
{"name" : " pH gastrique diminué"
},
{"name" : " Perforation gastrique"
},
{"name" : " Polypes gastriques"
},
{"name" : " Ulcère gastrique"
},
{"name" : " Hémorragie d'ulcère gastrique"
},
{"name" : " Ulcère gastrique helicobacter"
},
{"name" : " Perforation de l'ulcère gastrique"
},
{"name" : " Gastrinome"
},
{"name" : " Gastrite"
},
{"name" : " Gastrite aggravée"
},
{"name" : " Gastrite atrophique"
},
{"name" : " Gastrite érosive"
},
{"name" : " Gastrite hémorragique"
},
{"name" : " Gastrite virale"
},
{"name" : " Gastroduodénite"
},
{"name" : " Gastro-entérite"
},
{"name" : " Adénovirus de la gastro-entérite"
},
{"name" : " Gastro-entérite bactérienne"
},
{"name" : " Gastroentérite salmonelle"
},
{"name" : " Gastroentérite staphylococcique"
},
{"name" : " Gastroentérite yersinia"
},
{"name" : " Varices gastro-oesophagiennes"
},
{"name" : " Candidose gastro-intestinale"
},
{"name" : " Carcinome gastro-intestinal"
},
{"name" : " Crampes gastro-intestinales"
},
{"name" : " Gêne gastro-intestinale"
},
{"name" : " Trouble gastro-intestinal"
},
{"name" : " Fistule gastro-intestinale"
},
{"name" : " Plénitude gastro-intestinale"
},
{"name" : " Infection fongique gastro-intestinale"
},
{"name" : " Hémorragie gastro-intestinale"
},
{"name" : " Hypermotilité gastro-intestinale"
},
{"name" : " Hypomotilité gastro-intestinale"
},
{"name" : " Infection gastro-intestinale"
},
{"name" : " Inflammation gastro-intestinale"
},
{"name" : " Conditions inflammatoires gastro-intestinales"
},
{"name" : " Malformation gastro-intestinale"
},
{"name" : " Trouble de la motilité gastro-intestinale"
},
{"name" : " Nécrose gastro-intestinale"
},
{"name" : " Tumeur gastro-intestinale"
},
{"name" : " Tumeur gastro-intestinale maligne"
},
{"name" : " Obstruction gastro-intestinale"
},
{"name" : " Douleurs gastro-intestinales"
},
{"name" : " Perforation gastro-intestinale"
},
{"name" : " Signes et symptômes gastro-intestinaux"
},
{"name" : " Signes et symptômes gastro-intestinaux NCA"
},
{"name" : " Sons gastro-intestinaux anormaux"
},
{"name" : " Complication de la stomie gastro-intestinale"
},
{"name" : " Tumeur stromale gastro-intestinale"
},
{"name" : " Symptôme gastro-intestinal SAI"
},
{"name" : " Toxicité gastro-intestinale"
},
{"name" : " Irritation du tractus gastro-intestinal"
},
{"name" : " Ulcère gastro-intestinal"
},
{"name" : " Hémorragie d'ulcère gastro-intestinal"
},
{"name" : " Perforation de l'ulcère gastro-intestinal"
},
{"name" : " Cancer gastro-?sophagien"
},
{"name" : " Reflux gastro-?sophagien"
},
{"name" : " Insuffisance du sphincter gastro-?sophagien"
},
{"name" : " Gastrooesophagitis"
},
{"name" : " Maladie de Gaucher"
},
{"name" : " Paralysie du regard"
},
{"name" : " Gêne générale"
},
{"name" : " Troubles généraux et anomalies au site d'administration"
},
{"name" : " Détérioration générale de la santé physique"
},
{"name" : " Symptôme général"
},
{"name" : " Trouble d'anxiété généralisée"
},
{"name" : " Érythème généralisé"
},
{"name" : " Oedème généralisé"
},
{"name" : " Spasme généralisé"
},
{"name" : " Douleur généralisée"
},
{"name" : " Rinçage généralisé"
},
{"name" : " Maladie généralisée"
},
{"name" : " Adénopathie généralisée"
},
{"name" : " Éruption maculaire généralisée"
},
{"name" : " Urticaire généralisée"
},
{"name" : " Polymorphisme génétique"
},
{"name" : " Sensation de brûlure génitale"
},
{"name" : " Candidose génitale"
},
{"name" : " Écoulement génital"
},
{"name" : " Gêne génitale"
},
{"name" : " Trouble génital féminin"
},
{"name" : " Trouble génital masculin"
},
{"name" : " Hémorragie génitale"
},
{"name" : " L'herpès génital"
},
{"name" : " Hypoesthésie génitale"
},
{"name" : " Infection génitale"
},
{"name" : " Infection génitale féminine"
},
{"name" : " Infection génitale fongique"
},
{"name" : " Infection génitale masculine"
},
{"name" : " Lésion génitale"
},
{"name" : " Irritation génitale"
},
{"name" : " Démangeaisons génitales féminines"
},
{"name" : " Démangeaisons génitales chez l'homme"
},
{"name" : " Lésion génitale"
},
{"name" : " Douleur génitale"
},
{"name" : " Douleur génitale masculine"
},
{"name" : " Éruption cutanée génitale"
},
{"name" : " Gonflement génital"
},
{"name" : " Ulcération génitale"
},
{"name" : " Infection génito-urinaire à chlamydia"
},
{"name" : " Infection des voies génito-urinaires"
},
{"name" : " Tumeur des voies génito-urinaires"
},
{"name" : " Genu valgum (genou cagneux)"
},
{"name" : " Cancer des cellules germinales"
},
{"name" : " Germinome"
},
{"name" : " Diabète gestationnel"
},
{"name" : " Hypertension gestationnelle"
},
{"name" : " Tumeur trophoblastique gestationnelle"
},
{"name" : " Artérite à cellules géantes"
},
{"name" : " Conjonctivite papillaire géante"
},
{"name" : " Giardiase"
},
{"name" : " Gigantisme"
},
{"name" : " Syndrome de Gilbert"
},
{"name" : " Abcès gingival"
},
{"name" : " Saignement gingival"
},
{"name" : " Ampoule gingivale"
},
{"name" : " Trouble gingival"
},
{"name" : " Érythème gingival"
},
{"name" : " Hyperplasie gingivale"
},
{"name" : " Hypertrophie gingivale"
},
{"name" : " Infection gingivale"
},
{"name" : " Oedème gingival"
},
{"name" : " Douleur gingivale"
},
{"name" : " Récession gingivale"
},
{"name" : " Gonflement gingival"
},
{"name" : " Ulcération gingivale"
},
{"name" : " Gingivite"
},
{"name" : " Gingivite ulcéreuse"
},
{"name" : " Gingivostomatite"
},
{"name" : " Réflexe glabellaire anormal"
},
{"name" : " Glaucome"
},
{"name" : " Glaucome des deux yeux"
},
{"name" : " Glioblastome"
},
{"name" : " Glioblastome multiforme"
},
{"name" : " Gliome"
},
{"name" : " Globulines diminuées"
},
{"name" : " Globe hysterique"
},
{"name" : " Taux de filtration glomérulaire diminué"
},
{"name" : " Glomérulite"
},
{"name" : " Glomérulonéphrite"
},
{"name" : " Glomérulonéphrite aiguë"
},
{"name" : " Glomérulonéphrite chronique"
},
{"name" : " Glomérulonéphrite membranoproliférative"
},
{"name" : " Glomérulonéphrite membraneuse"
},
{"name" : " Lésion minimale de glomérulonéphrite"
},
{"name" : " Glomérulonéphrite rapidement évolutive"
},
{"name" : " Glomérulonéphropathie"
},
{"name" : " Glomérulosclérose"
},
{"name" : " Glossite"
},
{"name" : " Glossodynie"
},
{"name" : " Névralgie glossopharyngée"
},
{"name" : "?dème glottique"
},
{"name" : " Glucagonoma"
},
{"name" : " Glucocorticoïdes diminués"
},
{"name" : " Glucose diminué"
},
{"name" : " Augmentation du glucose"
},
{"name" : " Glucose bas"
},
{"name" : " Métabolisme du glucose anormal"
},
{"name" : " Glucose normal"
},
{"name" : " Tolérance au glucose anormale"
},
{"name" : " Tolérance au glucose diminuée"
},
{"name" : " Tolérance au glucose altérée"
},
{"name" : " Augmentation de l'urine de glucose"
},
{"name" : " Déficit en glucose-6-phosphate déshydrogénase"
},
{"name" : " Malabsorption du glucose-galactose"
},
{"name" : " Régime sans gluten"
},
{"name" : " Trouble de stockage du glycogène"
},
{"name" : " Glycosurie"
},
{"name" : " Hémoglobine glycosylée diminuée"
},
{"name" : " Augmentation de l'hémoglobine glycosylée"
},
{"name" : " Goitre diffus"
},
{"name" : " Goitre nodulaire"
},
{"name" : " Goitre"
},
{"name" : " Augmentation de l'hormone lutéinisante gonadotrope"
},
{"name" : " Gonadotrophines NOS faible"
},
{"name" : " Blennorragie"
},
{"name" : " Syndrome de Goodpasture"
},
{"name" : " Goutte"
},
{"name" : " Goutte aiguë"
},
{"name" : " Attaque de goutte"
},
{"name" : " Éruption de goutte"
},
{"name" : " Arthrite goutteuse"
},
{"name" : " Tophus goutteux"
},
{"name" : " Complication du greffon"
},
{"name" : " Dysfonctionnement du greffon"
},
{"name" : " Perte de greffe"
},
{"name" : " Thrombose du greffon"
},
{"name" : " Maladie du greffon contre l'hôte"
},
{"name" : " Réaction du greffon contre l'hôte"
},
{"name" : " Infection bactérienne à Gram négatif SAI"
},
{"name" : " Convulsion grand mal"
},
{"name" : " Granulocytose"
},
{"name" : " Granulome"
},
{"name" : " Granuloma annulare"
},
{"name" : " Granuloma inguinale"
},
{"name" : " Peau de granulome"
},
{"name" : " Granulomatose avec polyangéite"
},
{"name" : " Maladie granulomateuse du foie"
},
{"name" : " Oedème gravitationnel"
},
{"name" : " Syndrome de Gray néonatal"
},
{"name" : " Grimaçant"
},
{"name" : " Sensation granuleuse dans les yeux"
},
{"name" : " Douleur à l'aine"
},
{"name" : " Aspect du verre dépoli"
},
{"name" : " Accélération de la croissance"
},
{"name" : " Surproduction d'hormone de croissance"
},
{"name" : " Croissance des cils"
},
{"name" : " Retard de croissance"
},
{"name" : " Le syndrome de Guillain Barre"
},
{"name" : " Gynécomastie"
},
{"name" : " Infection gynécologique"
},
{"name" : " Douleurs gynécologiques"
},
{"name" : " Gynécomastie aggravée"
},
{"name" : " Hémangiome"
},
{"name" : " Hémangiome congénital"
},
{"name" : " Hémangiome cutané"
},
{"name" : " Hémarthrose"
},
{"name" : " Hématémèse"
},
{"name" : " Haematochezia"
},
{"name" : " Hématocrite diminué"
},
{"name" : " Hématocrite augmenté"
},
{"name" : " Tumeur hématologique"
},
{"name" : " Test d'hématologie anormal"
},
{"name" : " Hématome"
},
{"name" : " Hématospermie"
},
{"name" : " Hématotoxicité"
},
{"name" : " Hématurie"
},
{"name" : " Haemobilia"
},
{"name" : " Hémochromatose"
},
{"name" : " Instabilité hémodynamique"
},
{"name" : " Hémoglobine"
},
{"name" : " Hémoglobine anormale"
},
{"name" : " Hémoglobine diminuée"
},
{"name" : " Hémoglobine augmentée"
},
{"name" : " Hémoglobine normale"
},
{"name" : " Hémoglobinémie"
},
{"name" : " Hémoglobinurie"
},
{"name" : " Hémolyse"
},
{"name" : " Anémie hémolytique"
},
{"name" : " Syndrome hémolytique et urémique"
},
{"name" : " Hémophilie"
},
{"name" : " Hémoptysie"
},
{"name" : " Hémorragie"
},
{"name" : " Hémorragie pendant la grossesse"
},
{"name" : " Hémorragie intracrânienne"
},
{"name" : " Hémorragie sous-cutanée"
},
{"name" : " Hémorragie des voies urinaires"
},
{"name" : " Anémie hémorragique"
},
{"name" : " Maladie hémorragique du nouveau-né"
},
{"name" : " Trouble hémorragique"
},
{"name" : " Gastrite érosive hémorragique"
},
{"name" : " Kyste ovarien hémorragique"
},
{"name" : " AVC hémorragique"
},
{"name" : " Urticaire hémorragique"
},
{"name" : " Hémorragie hémorroïdaire"
},
{"name" : " Hémorroïdes"
},
{"name" : " Hémosidérose"
},
{"name" : " Hémothorax"
},
{"name" : " Changements de couleur des cheveux"
},
{"name" : " Décoloration des cheveux"
},
{"name" : " Trouble capillaire"
},
{"name" : " Croissance anormale des cheveux"
},
{"name" : " Croissance des cheveux augmentée"
},
{"name" : " Texture anormale des cheveux"
},
{"name" : " Leucémie à tricholeucocytes"
},
{"name" : " Hallucination"
},
{"name" : " Hallucination, auditive"
},
{"name" : " Hallucination, tactile"
},
{"name" : " Hallucination, visuelle"
},
{"name" : " Hallucinations, mixtes"
},
{"name" : " Vision Halo"
},
{"name" : " Hamartome"
},
{"name" : " Syndrome de Hamman-Rich"
},
{"name" : " Syndrome de la main et du pied secondaire à l'anémie falciforme"
},
{"name" : " Dermatite des mains"
},
{"name" : " Fracture de la main"
},
{"name" : " Arthrose de la main"
},
{"name" : " Douleur à la main"
},
{"name" : " Éruption cutanée"
},
{"name" : " Gonflement de la main"
},
{"name" : " Faiblesse des mains"
},
{"name" : " Gueule de bois"
},
{"name" : " Haptoglobine augmentée"
},
{"name" : " Maladie de Hashimoto"
},
{"name" : " L'ADN du VHB a diminué"
},
{"name" : " Co-infection HBV"
},
{"name" : " Co-infection par le VHC"
},
{"name" : " Augmentation du cholestérol HDL"
},
{"name" : " Gêne à la tête"
},
{"name" : " Blessure à la tête"
},
{"name" : " Décalage de la tête anormal"
},
{"name" : " Pression de tête"
},
{"name" : " Titubation de la tête"
},
{"name" : " Mal de crâne"
},
{"name" : " Maux de tête aggravés"
},
{"name" : " Maux de tête ternes"
},
{"name" : " Plénitude des maux de tête"
},
{"name" : " Maux de tête"
},
{"name" : " Malentendants"
},
{"name" : " Alternance cardiaque"
},
{"name" : " Maladie cardiaque congénitale"
},
{"name" : " Signes et symptômes d'insuffisance cardiaque"
},
{"name" : " Malformation cardiaque"
},
{"name" : " C?ur battant"
},
{"name" : " Coeur battant"
},
{"name" : " Fréquence cardiaque anormale"
},
{"name" : " Fréquence cardiaque irrégulière"
},
{"name" : " Fréquence cardiaque normale"
},
{"name" : " C?ur a un bruit anormal"
},
{"name" : " Brûlures d'estomac"
},
{"name" : " Épuisement par la chaleur"
},
{"name" : " Intolérance à la chaleur"
},
{"name" : " Coup de chaleur"
},
{"name" : " Lourdeur dans les membres"
},
{"name" : " Lourdeur de tête"
},
{"name" : " Syndrome HELLP"
},
{"name" : " Gastrite à Helicobacter"
},
{"name" : " Infection à Helicobacter"
},
{"name" : " Acquisition d'un hémangiome"
},
{"name" : " Hemangioma simplex"
},
{"name" : " Muscle hématome"
},
{"name" : " Hématurie aggravée"
},
{"name" : " Hémianopie"
},
{"name" : " Hémiballisme"
},
{"name" : " Hemiblock NOS"
},
{"name" : " Hemimelie"
},
{"name" : " Hémiparésie"
},
{"name" : " Hémiparésie (gauche)"
},
{"name" : " Hémiplégie"
},
{"name" : " Hémiplégie transitoire"
},
{"name" : " Migraine hémiplégique"
},
{"name" : " Réaction hémolytique"
},
{"name" : " Lymphohistiocytose hémophagocytaire"
},
{"name" : " Hémorragie anormale"
},
{"name" : " Hémorragie du côlon"
},
{"name" : " Symptôme d'hémorragie"
},
{"name" : " Colite hémorragique"
},
{"name" : " Hémorroïdes aggravées"
},
{"name" : " Purpura de Henoch-Schonlein"
},
{"name" : " Thrombocytopénie induite par l'héparine"
},
{"name" : " Adénome hépatique"
},
{"name" : " Amibiase hépatique"
},
{"name" : " Angiosarcome hépatique"
},
{"name" : " Thrombose de l'artère hépatique"
},
{"name" : " Atrophie hépatique"
},
{"name" : " Cancer hépatique"
},
{"name" : " Cancer hépatique métastatique"
},
{"name" : " Cirrhose hépatique"
},
{"name" : " Congestion hépatique"
},
{"name" : " Kyste hépatique"
},
{"name" : " Encéphalopathie hépatique"
},
{"name" : " Enzyme hépatique anormale"
},
{"name" : " Enzyme hépatique diminuée"
},
{"name" : " Augmentation de l'enzyme hépatique"
},
{"name" : " Défaillance hépatique"
},
{"name" : " Fibrose hépatique"
},
{"name" : " Fonction hépatique anormale"
},
{"name" : " Granulome hépatique"
},
{"name" : " Hémorragie hépatique"
},
{"name" : " Insuffisance hépatique"
},
{"name" : " Infiltration hépatique éosinophile"
},
{"name" : " Insuffisance hépatique"
},
{"name" : " Lymphome hépatique"
},
{"name" : " Nécrose hépatique"
},
{"name" : " Néoplasme hépatique"
},
{"name" : " Douleur hépatique"
},
{"name" : " Stéatose hépatique"
},
{"name" : " Occlusion de veine hépatique"
},
{"name" : " Thrombose veineuse hépatique"
},
{"name" : " Hépatite"
},
{"name" : " Hépatite A"
},
{"name" : " Hépatite B"
},
{"name" : " ADN de l'hépatite B diminué"
},
{"name" : " Antigène E de l'hépatite B positif"
},
{"name" : " Réactivation de l'hépatite B"
},
{"name" : " Antigène de surface de l'hépatite B positif"
},
{"name" : " Hépatite C"
},
{"name" : " Anticorps positifs pour l'hépatite C"
},
{"name" : " Hépatite C positive"
},
{"name" : " Test positif pour le virus de l'hépatite C"
},
{"name" : " Hépatite D"
},
{"name" : " Hépatite E"
},
{"name" : " Hépatite F"
},
{"name" : " Hépatite aiguë"
},
{"name" : " Hépatite aggravée"
},
{"name" : " Hépatite alcoolique"
},
{"name" : " Hépatite cholestatique"
},
{"name" : " Hépatite chronique active"
},
{"name" : " Hépatite fulminante"
},
{"name" : " Hépatite granulomateuse"
},
{"name" : " Symptôme d'hépatite"
},
{"name" : " Hépatite toxique"
},
{"name" : " Hépatite virale"
},
{"name" : " Dégénérescence hépato-lenticulaire"
},
{"name" : " Maladie hépatobiliaire"
},
{"name" : " Hépatoblastome"
},
{"name" : " Adénome hépatocellulaire"
},
{"name" : " Carcinome hépatocellulaire"
},
{"name" : " Lésion hépatocellulaire"
},
{"name" : " Hépatomégalie"
},
{"name" : " Syndrome hépatorénal"
},
{"name" : " Lymphome hépatosplénique à cellules T"
},
{"name" : " Candidose hépatosplénique"
},
{"name" : " Hépatosplénomégalie"
},
{"name" : " Hépatotoxicité"
},
{"name" : " Angioedème héréditaire"
},
{"name" : " Coproporphyrie héréditaire"
},
{"name" : " Atrophie optique héréditaire"
},
{"name" : " Hernie"
},
{"name" : " Hernie congénitale"
},
{"name" : " Hernie douloureuse"
},
{"name" : " Dépendance à l'héroïne"
},
{"name" : " Herpangina"
},
{"name" : " Herpès NOS"
},
{"name" : " Dermatite herpétique"
},
{"name" : " Herpès labial"
},
{"name" : " Herpès simplex"
},
{"name" : " Dermatite à herpès simplex"
},
{"name" : " Encéphalite à herpès simplex"
},
{"name" : " Hépatite à herpès simplex"
},
{"name" : " Infection par le virus de l'herpès"
},
{"name" : " Zona"
},
{"name" : " Zona disséminé"
},
{"name" : " Herpès zoster kératite"
},
{"name" : " Hypercholestérolémie familiale hétérozygote"
},
{"name" : " Hernie hiatale"
},
{"name" : " Hoquet"
},
{"name" : " Hidradénite"
},
{"name" : " Taux de cholestérol élevé"
},
{"name" : " Lipoprotéines de haute densité diminuées"
},
{"name" : " Augmentation des lipoprotéines de haute densité"
},
{"name" : " Surdité haute fréquence"
},
{"name" : " Ostéopathie à renouvellement élevé"
},
{"name" : " Pleurs aigus"
},
{"name" : " Luxation de la hanche"
},
{"name" : " Dysplasie de la hanche"
},
{"name" : " Fracture de la hanche"
},
{"name" : " Hirsutisme"
},
{"name" : " Histiocytose"
},
{"name" : " Histiocytose X du poumon"
},
{"name" : " Histiocytose hématophage"
},
{"name" : " Histoplasmose"
},
{"name" : " Néphropathie associée au VIH"
},
{"name" : " Infection par le VIH"
},
{"name" : " Enrouement"
},
{"name" : " la maladie de Hodgkin"
},
{"name" : " Stade de type de déplétion lymphocytaire de la maladie de Hodgkin, sans précision"
},
{"name" : " Stade de type de prédominance lymphocytaire de la maladie de Hodgkin non spécifié"
},
{"name" : " Syndrome de Hoigne"
},
{"name" : " Idée homicide"
},
{"name" : " Homocystinurie"
},
{"name" : " Hypercholestérolémie familiale homozygote"
},
{"name" : " Infection par l'ankylostome"
},
{"name" : " Hordeolum"
},
{"name" : " Niveau hormonal anormal"
},
{"name" : " Cancer de la prostate hormono-dépendant"
},
{"name" : " Cancer de la prostate réfractaire aux hormones"
},
{"name" : " Syndrome de Horner"
},
{"name" : " Hostilité"
},
{"name" : " Peau sèche et chaude"
},
{"name" : " Rinçage à chaud"
},
{"name" : " Allergie aux poussières domestiques"
},
{"name" : " Infection par l'herpèsvirus humain 6"
},
{"name" : " Type de virus d'immunodéficience humaine"
},
{"name" : " Fracture de l'humérus"
},
{"name" : " Faim"
},
{"name" : " Faim anormale"
},
{"name" : " Maladie de Huntington"
},
{"name" : " Taupe hydatidiforme"
},
{"name" : " Hydremie"
},
{"name" : " Hydrocèle"
},
{"name" : " Hydrocéphalie"
},
{"name" : " Acquisition de l'hydrocéphalie"
},
{"name" : " Hydrocortisone diminuée"
},
{"name" : " Hydromètre"
},
{"name" : " Hydronéphrose"
},
{"name" : " Hydrops foetalis"
},
{"name" : " Hydrothorax"
},
{"name" : " Hydroureter"
},
{"name" : " Hyperacousie"
},
{"name" : " Hyperadrénocorticisme"
},
{"name" : " Hyperémie"
},
{"name" : " Hyperesthésie"
},
{"name" : " Hyperalbuminémie"
},
{"name" : " Hyperaldostéronisme"
},
{"name" : " Hyperammoniémie"
},
{"name" : " Encéphalopathie hyperammoniémique"
},
{"name" : " Hyperamylasémie"
},
{"name" : " Hyperbilirubinémie"
},
{"name" : " Hyperbilirubinémie aggravée"
},
{"name" : " Hypercalcémie"
},
{"name" : " Hypercalcémie de malignité"
},
{"name" : " Hypercalciurie"
},
{"name" : " Hypercapnie"
},
{"name" : " Hyperchlorémie"
},
{"name" : " Hyperchlorhydrie"
},
{"name" : " Hypercholestérolémie"
},
{"name" : " Hypercholestérolémie aggravée"
},
{"name" : " Hyperchylomicronémie"
},
{"name" : " Hypercoagulation"
},
{"name" : " Hyperémèse"
},
{"name" : " Hyperémèse gravidique"
},
{"name" : " Hyperéosinophilie"
},
{"name" : " Syndrome hyperéosinophile"
},
{"name" : " Hyperexcitation"
},
{"name" : " Hyperfibrinogenaemia"
},
{"name" : " Hypergammaglobulinémie"
},
{"name" : " Hypergastrinémie"
},
{"name" : " Hyperglycémie"
},
{"name" : " Hyperhémoglobinémie"
},
{"name" : " Hyperhidrose"
},
{"name" : " Hyperinsulinisme"
},
{"name" : " Hyperkaliémie"
},
{"name" : " Hyperkaliurie"
},
{"name" : " Hyperkératose"
},
{"name" : " Hyperkinésie"
},
{"name" : " Syndrome cardiaque hyperkinétique"
},
{"name" : " Hyperlactacidémie"
},
{"name" : " Hyperlipidémie"
},
{"name" : " Hyperlipoprotéinémie"
},
{"name" : " Hypermagnésémie"
},
{"name" : " Hypermétabolisme"
},
{"name" : " Hyperméthioninémie"
},
{"name" : " Hypernatrémie"
},
{"name" : " Hyperostose"
},
{"name" : " Hyperoxalurie"
},
{"name" : " Hyperparathyroïdie"
},
{"name" : " Hyperparathyroïdie primaire"
},
{"name" : " Hyperparathyroïdie secondaire"
},
{"name" : " Hyperpathie"
},
{"name" : " Hyperphagie"
},
{"name" : " Hyperphosphatémie"
},
{"name" : " Hyperplasie"
},
{"name" : " Hyperplasie surrénale"
},
{"name" : " Hyperplasie érythroïde"
},
{"name" : " Hyperpnée"
},
{"name" : " Hyperprolactinémie"
},
{"name" : " Hyperprotéinémie"
},
{"name" : " Hyperpyrexie"
},
{"name" : " Hyperréflexie"
},
{"name" : " Peau hypersensible"
},
{"name" : " Syndrome hypersensible"
},
{"name" : " Hypersensibilité"
},
{"name" : " Hypersexualité"
},
{"name" : " Hypersomnie"
},
{"name" : " Hypersplénisme"
},
{"name" : " Hypertension"
},
{"name" : " Hypertension paroxystique"
},
{"name" : " Hypertension aggravée"
},
{"name" : " Hypertendu"
},
{"name" : " Crise d'hypertension"
},
{"name" : " Urgence hypertensive"
},
{"name" : " Encéphalopathie hypertensive"
},
{"name" : " Épisode hypertensif"
},
{"name" : " Néphropathie hypertensive"
},
{"name" : " Hyperthyroïdie"
},
{"name" : " Hypertonie"
},
{"name" : " Vessie hypertonique"
},
{"name" : " Hypertonicité"
},
{"name" : " Hypertransaminasaemia"
},
{"name" : " Hypertrichose"
},
{"name" : " Hypertriglycéridémie"
},
{"name" : " Cardiomyopathie hypertrophique"
},
{"name" : " Arthrose hypertrophique"
},
{"name" : " Cicatrice hypertrophique"
},
{"name" : " Hypertrophie"
},
{"name" : " Hypertrophie du sein"
},
{"name" : " Hyperuricémie"
},
{"name" : " Hyperuricosurie"
},
{"name" : " Hyperventilation"
},
{"name" : " Hypervigilance"
},
{"name" : " Syndrome d'hyperviscosité"
},
{"name" : " Hypervitaminose A"
},
{"name" : " Hypervitaminose D"
},
{"name" : " Hyphaème"
},
{"name" : " Hallucination hypnagogique"
},
{"name" : " Hallucination hypnopompique"
},
{"name" : " Trouble du désir sexuel hypoactif"
},
{"name" : " Hypoesthésie"
},
{"name" : " Oeil d'hypoesthésie"
},
{"name" : " Soin du visage hypoesthésie"
},
{"name" : " Hypoesthésie orale"
},
{"name" : " Hypoalbuminémie"
},
{"name" : " Hypoaldostéronisme"
},
{"name" : " Hypoalgésie"
},
{"name" : " Hypocalcémie"
},
{"name" : " Tétanie hypocalcémique"
},
{"name" : " Hypocalciurie"
},
{"name" : " Hypocapnie"
},
{"name" : " Hypochlorémie"
},
{"name" : " Hypocholestérolémie"
},
{"name" : " Hypocondrie"
},
{"name" : " Hypochromasie"
},
{"name" : " Anémie hypochromique"
},
{"name" : " Anémie microcytaire hypochromique"
},
{"name" : " Langue d'hypoesthésie"
},
{"name" : " Hypofibrinogenaemia"
},
{"name" : " Hypogammaglobulinémie"
},
{"name" : " Hypogeusie"
},
{"name" : " Hypoglycémie"
},
{"name" : " Hypoglycémie néonatale"
},
{"name" : " Coma hypoglycémique"
},
{"name" : " Épisode hypoglycémique"
},
{"name" : " Crise hypoglycémique"
},
{"name" : " Inconscience hypoglycémique"
},
{"name" : " Réaction hypoglycémique"
},
{"name" : " Hypogonadisme"
},
{"name" : " Hypogonadisme féminin"
},
{"name" : " Hypogonadisme masculin"
},
{"name" : " Hypohidrose"
},
{"name" : " Hypokaliémie"
},
{"name" : " Hypokinésie"
},
{"name" : " Hypolipidémie"
},
{"name" : " Hypomagnésémie"
},
{"name" : " Hypomanie"
},
{"name" : " Hypoménorrhée"
},
{"name" : " Hyponatrémie"
},
{"name" : " Hyponatrémique"
},
{"name" : " Hypoparathyroïdie"
},
{"name" : " Hypoperfusion"
},
{"name" : " Hypophagie"
},
{"name" : " Hypophosphatémie"
},
{"name" : " Rachitisme hypophosphatémique"
},
{"name" : " Hypopituitarisme"
},
{"name" : " Émail hypoplasie"
},
{"name" : " Hypoplasie érythroïde"
},
{"name" : " Anémie hypoplasique"
},
{"name" : " Syndrome d'hypopnée"
},
{"name" : " Hypopnée"
},
{"name" : " Hypoprotéinémie"
},
{"name" : " Hypoprothrombinémie"
},
{"name" : " Hypopyon"
},
{"name" : " Hyporeflexie"
},
{"name" : " Hyposmie"
},
{"name" : " Hyposthénurie"
},
{"name" : " Hypotension"
},
{"name" : " Hypotension asymptomatique"
},
{"name" : " Hypotension orthostatique symptomatique"
},
{"name" : " Hypotension symptomatique"
},
{"name" : " Hypotensive"
},
{"name" : " Hypothermie"
},
{"name" : " Hypothrombinémie"
},
{"name" : " Hypothyroïdie"
},
{"name" : " Hypotonie"
},
{"name" : " Hypotonie néonatale"
},
{"name" : " Épisode hypotonique-hyporéactif"
},
{"name" : " Hypotonie de l'?il"
},
{"name" : " Hypotrichose"
},
{"name" : " Hypouricémie"
},
{"name" : " Hypoventilation"
},
{"name" : " Hypovitaminose"
},
{"name" : " Hypovolémie"
},
{"name" : " Choc hypovolémique"
},
{"name" : " Hypoxémie"
},
{"name" : " Hypoxie"
},
{"name" : " Encéphalopathie hypoxique-ischémique"
},
{"name" : " Hypsarythmie"
},
{"name" : " Hystérie"
},
{"name" : " Ichtyose"
},
{"name" : " Ichtyose acquise"
},
{"name" : " Ichtyose vulgaire"
},
{"name" : "?dème idiopathique"
},
{"name" : " Épilepsie généralisée idiopathique"
},
{"name" : " Hirsutisme idiopathique"
},
{"name" : " Sténose sous-aortique hypertrophique idiopathique"
},
{"name" : " Syndrome de pneumonie idiopathique"
},
{"name" : " Hypertension artérielle pulmonaire idiopathique"
},
{"name" : " Fibrose pulmonaire idiopatique"
},
{"name" : " Thrombocytopénie idiopathique"
},
{"name" : " Purpura thrombocytopénique idiopathique"
},
{"name" : " Dystonie de torsion idiopathique"
},
{"name" : " Réaction médicamenteuse idiosyncratique"
},
{"name" : " IIIe paralysie nerveuse"
},
{"name" : " Obstruction iléale"
},
{"name" : " Perforation iléale"
},
{"name" : " Ulcère iléal"
},
{"name" : " Ileitis"
},
{"name" : " Ileitis régional"
},
{"name" : " Ileus"
},
{"name" : " Iléus paralytique"
},
{"name" : " Trouble mal défini"
},
{"name" : " Illusion"
},
{"name" : " Déséquilibre hormonal"
},
{"name" : " Réaction post-injection immédiate"
},
{"name" : " Avortement imminent"
},
{"name" : " Immobile"
},
{"name" : " Réaction complexe immunitaire"
},
{"name" : " Statut immunitaire"
},
{"name" : " Trouble du système immunitaire"
},
{"name" : " Myopathie nécrosante à médiation immunitaire"
},
{"name" : " Immunodéprimé"
},
{"name" : " Immunodéficience"
},
{"name" : " Variable commune d'immunodéficience"
},
{"name" : " Immunoglobuline G faible"
},
{"name" : " Immunoglobulines diminuées"
},
{"name" : " Augmentation des immunoglobulines"
},
{"name" : " Test d'immunologie"
},
{"name" : " Augmentation du niveau de médicament immunosuppresseur"
},
{"name" : " Immunosuppression"
},
{"name" : " Glycémie à jeun altérée"
},
{"name" : " Vidange gastrique altérée"
},
{"name" : " Guérison altérée"
},
{"name" : " Dépréciation de l'attention"
},
{"name" : " Impatience"
},
{"name" : " Imperforation d'hymen"
},
{"name" : " Impétigo"
},
{"name" : " Rupture d'implant"
},
{"name" : " Expulsion d'implant"
},
{"name" : " Infection d'implant"
},
{"name" : " Douleur au site implantaire"
},
{"name" : " Réaction au site implantaire"
},
{"name" : " Complication d'implantation"
},
{"name" : " Emprisonnement"
},
{"name" : " Trouble du contrôle des impulsions"
},
{"name" : " Affect inapproprié"
},
{"name" : " Sécrétion inappropriée d'hormone antidiurétique"
},
{"name" : " Erreur innée du métabolisme"
},
{"name" : " Tachycardie ventriculaire incessante"
},
{"name" : " Complication du site d'incision"
},
{"name" : " Hématome au site d'incision"
},
{"name" : " Hémorragie au site d'incision"
},
{"name" : "?dème au site d'incision"},
{"name" : " Douleur au site d'incision"
},
{"name" : " Hernie incisive"
},
{"name" : " Conjonctivite d'inclusion"
},
{"name" : " Incohérent"
},
{"name" : " Vidange incomplète de la vessie"
},
{"name" : " Puberté précoce incomplète"
},
{"name" : " Incontinence"
},
{"name" : " Activité accrue"
},
{"name" : " Agitation accrue"
},
{"name" : " Effet anticoagulant accru"
},
{"name" : " Augmentation de l'appétit"
},
{"name" : " Augmentation de la sécrétion bronchique"
},
{"name" : " Effet accru"
},
{"name" : " Augmentation des besoins en insuline"
},
{"name" : " Augmentation du niveau de prolactine"
},
{"name" : " Augmentation de la sensibilité cutanée"
},
{"name" : " Tendance accrue aux ecchymoses"
},
{"name" : " Augmentation de la soif"
},
{"name" : " Augmentation de la sécrétion des voies aériennes supérieures"
},
{"name" : " Augmentation de la viscosité de la sécrétion bronchique"
},
{"name" : " Induration"
},
{"name" : " Avortement inévitable"
},
{"name" : " Colique infantile"
},
{"name" : " Spasmes infantiles"
},
{"name" : " Infarctus"
},
{"name" : " Infarctus mésentérique"
},
{"name" : " Morsures infectées"
},
{"name" : " Kyste infecté"
},
{"name" : " Infection"
},
{"name" : " Infection induite"
},
{"name" : " Infection mixte"
},
{"name" : " Infection parasitaire"
},
{"name" : " Infection pseudomonas aeruginosa"
},
{"name" : " Réactivation de l'infection"
},
{"name" : " La sensibilité aux infections a augmenté"
},
{"name" : " Méningite infectieuse"
},
{"name" : " Mononucléose infectieuse"
},
{"name" : " Péritonite infectieuse"
},
{"name" : " Pneumonite infectieuse"
},
{"name" : " Thyroïdite infectieuse"
},
{"name" : " Myosite infectieuse"
},
{"name" : " Otite externe infectieuse"
},
{"name" : " Ténosynovite infectieuse"
},
{"name" : " Infarctus du myocarde inférieur"
},
{"name" : " Syndrome de la veine cave inférieure"
},
{"name" : " Infertilité"
},
{"name" : " Infertilité féminine"
},
{"name" : " Infertilité masculine"
},
{"name" : " Infestation"
},
{"name" : " Infestation SAI"
},
{"name" : " Inflammation"
},
{"name" : " Inflammation localisée"
},
{"name" : " Maladie inflammatoire de l'intestin"
},
{"name" : " Gonflement inflammatoire"
},
{"name" : " Blessure infligée"
},
{"name" : " Grippe"
},
{"name" : " Infection par le virus de la grippe A"
},
{"name" : " Maladie de type grippal"
},
{"name" : " Infections virales grippales"
},
{"name" : " Symptômes pseudo-grippaux"
},
{"name" : " Mouvements intestinaux peu fréquents"
},
{"name" : " Douleur liée à la perfusion"
},
{"name" : " Réaction liée à la perfusion"
},
{"name" : " Brûlure du site de perfusion"
},
{"name" : " Érythème au site de perfusion"
},
{"name" : " Extravasation du site de perfusion"
},
{"name" : " Hypersensibilité au site de perfusion"
},
{"name" : " Induration du site de perfusion"
},
{"name" : " Infection au site de perfusion"
},
{"name" : " Inflammation au site de perfusion"
},
{"name" : " Irritation du site de perfusion"
},
{"name" : "?dème au site de perfusion"
},
{"name" : " Douleur au point de perfusion"
},
{"name" : " Paresthésie au site de perfusion"
},
{"name" : " Phlébite au point de perfusion"
},
{"name" : " Prurit au site de perfusion"
},
{"name" : " Éruption cutanée au site de perfusion"
},
{"name" : " Réaction au site de perfusion"
},
{"name" : " Réactions au site de perfusion"
},
{"name" : " Gonflement au site de perfusion"
},
{"name" : " Thrombophlébite au site de perfusion"
},
{"name" : " Thrombose au site de perfusion"
},
{"name" : " Urticaire au site de perfusion"
},
{"name" : " Chaleur au point de perfusion"
},
{"name" : " Ongle incarnant"
},
{"name" : " Poils incarnés"
},
{"name" : " Hernie inguinale"
},
{"name" : " Inhibition de l'activité enzymatique"
},
{"name" : " Insomnie initiale"
},
{"name" : " Abcès au site d'injection"
},
{"name" : " Abcès au point d'injection stérile"
},
{"name" : " Atrophie au site d'injection"
},
{"name" : " Ecchymoses au site d'injection"
},
{"name" : " Brûlure au site d'injection"
},
{"name" : " Cellulite au site d'injection"
},
{"name" : " Froideur au point d'injection"
},
{"name" : " Kyste au site d'injection"
},
{"name" : " Dermatite au site d'injection"
},
{"name" : " Décoloration du site d'injection"
},
{"name" : " Gêne au point d'injection"
},
{"name" : " Sécheresse du site d'injection"
},
{"name" : " Érythème au site d'injection"
},
{"name" : " Exfoliation au site d'injection"
},
{"name" : " Extravasation au site d'injection"
},
{"name" : " Fibrose au site d'injection"
},
{"name" : " Granulome au site d'injection"
},
{"name" : " Hématome au site d'injection"
},
{"name" : " Hémorragie au site d'injection"
},
{"name" : " Hypersensibilité au site d'injection"
},
{"name" : " Hypertrophie au site d'injection"
},
{"name" : " Induration au site d'injection"
},
{"name" : " Infection au site d'injection"
},
{"name" : " Inflammation au site d'injection"
},
{"name" : " Blessure au site d'injection"
},
{"name" : " Irritation au point d'injection"
},
{"name" : " Douleurs articulaires au site d'injection"
},
{"name" : " Masse du site d'injection"
},
{"name" : " Nécrose au site d'injection"
},
{"name" : " Nodule au site d'injection"
},
{"name" : " Douleur au site d'injection"
},
{"name" : " Pâleur du site d'injection"
},
{"name" : " Paresthésie au site d'injection"
},
{"name" : " Phlébite au site d'injection"
},
{"name" : " Changements de pigmentation au site d'injection"
},
{"name" : " Prurit au site d'injection"
},
{"name" : " Réaction au site d'injection"
},
{"name" : " Piqûre au site d'injection"
},
{"name" : " Gonflement au site d'injection"
},
{"name" : " Sensibilité au site d'injection"
},
{"name" : " Thrombose au site d'injection"
},
{"name" : " Ulcère au point d'injection"
},
{"name" : " Urticaire au site d'injection"
},
{"name" : " Vésicules au site d'injection"
},
{"name" : " Chaleur au point d'injection"
},
{"name" : " Blessure"
},
{"name" : " Asphyxie par blessure"
},
{"name" : " Blessure associée à l'appareil"
},
{"name" : " Blessure cornéenne"
},
{"name" : " Trouble de l'oreille interne"
},
{"name" : " Infection de l'oreille interne"
},
{"name" : " Piqûre d'insecte NSA"
},
{"name" : " Insomnie"
},
{"name" : " Insomnie NEC"
},
{"name" : " Insomnie exacerbée"
},
{"name" : " Instabilité vasomotrice"
},
{"name" : " Irritation du site d'instillation"
},
{"name" : " Douleur au site d'instillation"
},
{"name" : " Insuline C-peptide diminuée"
},
{"name" : " Augmentation de l'insuline C-peptide"
},
{"name" : " Syndrome auto-immun de l'insuline"
},
{"name" : " Hypoglycémie à l'insuline"
},
{"name" : " Résistance à l'insuline"
},
{"name" : " Diabète insulino-résistant"
},
{"name" : " Insulinome"
},
{"name" : " Abus intentionnel de drogues"
},
{"name" : " Blessure intentionnelle"
},
{"name" : " Détournement intentionnel"
},
{"name" : " Auto-blessure intentionnelle"
},
{"name" : " Glomérulosclérose intercapillaire"
},
{"name" : " Claudication intermittente"
},
{"name" : " Le trouble explosif intermittent"
},
{"name" : " Fièvre intermittente"
},
{"name" : " Céphalées intermittentes"
},
{"name" : " Hordeolum interne"
},
{"name" : " Ratio normalisé international anormal"
},
{"name" : " Ratio normalisé international diminué"
},
{"name" : " Augmentation du ratio normalisé international"
},
{"name" : " Maladie pulmonaire interstitielle"
},
{"name" : " Pneumonie interstitielle"
},
{"name" : " Intertrigo"
},
{"name" : " Intertrigo candida"
},
{"name" : " Dégénérescence du disque intervertébral"
},
{"name" : " Trouble du disque intervertébral"
},
{"name" : " Protrusion de disque intervertébral"
},
{"name" : " Discite intervertébrale"
},
{"name" : " Atonie intestinale"
},
{"name" : " Crampes intestinales"
},
{"name" : " Maladie du diaphragme intestinal"
},
{"name" : " Trouble fonctionnel intestinal"
},
{"name" : " Hémorragie intestinale"
},
{"name" : " Hypomotilité intestinale"
},
{"name" : " Infarctus intestinal"
},
{"name" : " Infection intestinale due à un staphylocoque"
},
{"name" : " Infections intestinales"
},
{"name" : " Ischémie intestinale"
},
{"name" : " Masse intestinale"
},
{"name" : " Nécrose intestinale"
},
{"name" : " Obstruction intestinale"
},
{"name" : " Parasitisme intestinal, sans précision"
},
{"name" : " Perforation intestinale"
},
{"name" : " Polype intestinal"
},
{"name" : " Pseudo-obstruction intestinale"
},
{"name" : " Sténose intestinale"
},
{"name" : " Complication de la stomie intestinale"
},
{"name" : " Ulcère intestinal"
},
{"name" : " Intoxication"
},
{"name" : " Hématome intra-abdominal"
},
{"name" : " Hémorragie intra-abdominale"
},
{"name" : " Thrombus intracardiaque"
},
{"name" : " Anévrisme intracrânien"
},
{"name" : " Augmentation de la pression intracrânienne"
},
{"name" : " Thrombose du sinus veineux intracrânien"
},
{"name" : " Épilepsie intraitable"
},
{"name" : " Hoquet intraitable"
},
{"name" : " Douleur intraitable"
},
{"name" : " Lésion mammaire proliférative intra-canalaire"
},
{"name" : " Hypoesthésie intranasale"
},
{"name" : " Augmentation de la pression intraoculaire"
},
{"name" : " Syndrome de l'iris de disquette peropératoire"
},
{"name" : " Hémorragie peropératoire"
},
{"name" : " Hypotension peropératoire"
},
{"name" : " Saignement intrarachidien"
},
{"name" : " Lymphome intravasculaire à grandes cellules B"
},
{"name" : " Hémorragie intraventriculaire"
},
{"name" : " Intussusception"
},
{"name" : " Aspergillose broncho-pulmonaire invasive"
},
{"name" : " Candidose invasive"
},
{"name" : " Dépression involutive"
},
{"name" : " Iodisme"
},
{"name" : " Iridocyclite"
},
{"name" : " Adhérences de l'iris"
},
{"name" : " Trouble de l'iris"
},
{"name" : " Hyperpigmentation de l'iris"
},
{"name" : " Iritis"
},
{"name" : " Capacité totale de liaison au fer"
},
{"name" : " Carence en fer"
},
{"name" : " Anémie ferriprive"
},
{"name" : " Surcharge en fer"
},
{"name" : " Insuffisance rénale irréversible"
},
{"name" : " Irritabilité"
},
{"name" : " Syndrome de l'intestin irritable"
},
{"name" : " Gomme irritante"
},
{"name" : " Ischémie"
},
{"name" : " Cardiomyopathie ischémique"
},
{"name" : " Infarctus cérébral ischémique"
},
{"name" : " Troubles coronariens ischémiques"
},
{"name" : " Hépatite ischémique"
},
{"name" : " Neuropathie ischémique"
},
{"name" : " AVC ischémique"
},
{"name" : " Névralgie ischiatique"
},
{"name" : " Démangeaisons brûlantes"
},
{"name" : " Démangeaisons du cuir chevelu"
},
{"name" : " Complication du DIU"
},
{"name" : " DIU expulsé"
},
{"name" : " Crises jacksoniennes"
},
{"name" : " Réaction de Jarisch-Herxheimer"
},
{"name" : " Jaunisse"
},
{"name" : " Jaunisse cholestatique"
},
{"name" : " Jaunisse hépatocellulaire"
},
{"name" : " Jaunisse néonatale"
},
{"name" : " Trouble de la mâchoire"
},
{"name" : " Rigidité de la mâchoire"
},
{"name" : " Mouvement saccadé NOS"
},
{"name" : " Infiltration lymphocytaire de Jessner"
},
{"name" : " Contracture articulaire"
},
{"name" : " Crépitation articulaire"
},
{"name" : " Destruction conjointe"
},
{"name" : " Luxation articulaire"
},
{"name" : " Épanchement articulaire"
},
{"name" : " Hyperextension articulaire"
},
{"name" : " Blessure articulaire"
},
{"name" : " Instabilité articulaire"
},
{"name" : " Serrure commune"
},
{"name" : " Amplitude articulaire réduite"
},
{"name" : " Signes et symptômes liés aux articulations"
},
{"name" : " Entorse articulaire"
},
{"name" : " Raideur articulaire"
},
{"name" : " Gonflement des articulations"
},
{"name" : " Tendresse articulaire"
},
{"name" : " Tuberculose articulaire"
},
{"name" : " Jugement altéré"
},
{"name" : " Bradycardie jonctionnelle"
},
{"name" : " Tachycardie jonctionnelle"
},
{"name" : " Arthrite juvénile idiopathique"
},
{"name" : " Épilepsie myoclonique juvénile"
},
{"name" : " Kalurèse"
},
{"name" : " Sarcome de Kaposi"
},
{"name" : " Sarcome de Kaposi lié au SIDA"
},
{"name" : " Éruption varicelliforme de Kaposi"
},
{"name" : " Bague Kayser-Fleischer"
},
{"name" : " Syndrome de Kearns-Sayre"
},
{"name" : " Cicatrice chéloïde"
},
{"name" : " Précipités kératiques"
},
{"name" : " Kératite"
},
{"name" : " Kératite bactérienne"
},
{"name" : " Champignon de kératite"
},
{"name" : " Keratitis sicca"
},
{"name" : " Kératoacanthome"
},
{"name" : " Kératoconjonctivite"
},
{"name" : " Kératoconjonctivite sèche"
},
{"name" : " Kératocône"
},
{"name" : " Kératopathie"
},
{"name" : " Kératose"
},
{"name" : " Kératose folliculaire"
},
{"name" : " Kératose palmaris"
},
{"name" : " Kératose pilaire"
},
{"name" : " Acidocétose"
},
{"name" : " Régime cétogène"
},
{"name" : " Cétonémie"
},
{"name" : " Ketonuria"
},
{"name" : " Cétose"
},
{"name" : " Fibrose rénale"
},
{"name" : " Fonction rénale anormale"
},
{"name" : " Infection rénale"
},
{"name" : " Rejet d'une greffe de rein"
},
{"name" : " Klebsiella sepsis"
},
{"name" : " Syndrome de Klinefelter"
},
{"name" : " Déformation du genou"
},
{"name" : " Douleur au genou"
},
{"name" : " Entorse du genou"
},
{"name" : " Phénomène de Koebner"
},
{"name" : " Psychose de Korsakoff (non alcoolique)"
},
{"name" : " Syndrome de Kounis"
},
{"name" : " Cyphose"
},
{"name" : " Pression artérielle labile"
},
{"name" : " Hypertension labile"
},
{"name" : " Test de laboratoire anormal"
},
{"name" : " Respiration difficile"
},
{"name" : " Douleur du travail"
},
{"name" : " Trouble labyrinthique"
},
{"name" : " Labyrinthite"
},
{"name" : " Lacération"
},
{"name" : " Absence d'effet médicamenteux"
},
{"name" : " Manque de discours spontané"
},
{"name" : " Trouble lacrymal"
},
{"name" : " Obstruction du canal lacrymal"
},
{"name" : " Trouble de la glande lacrymale"
},
{"name" : " Trouble structurel lacrymal"
},
{"name" : " Lacrimation"
},
{"name" : " Lacrymation anormale SAI"
},
{"name" : " Lacrimation diminuée"
},
{"name" : " Lacrimation augmentée"
},
{"name" : " Carence en lactase"
},
{"name" : " Augmentation du lactate"
},
{"name" : " Lactation femelle"
},
{"name" : " Acidose lactique"
},
{"name" : " Syndrome d'acidose lactique"
},
{"name" : " Augmentation de l'activité de la déshydrogénase lactique"
},
{"name" : " Intolérance au lactose"
},
{"name" : " Infarctus lacunaire"
},
{"name" : " Cirrhose de Laennec"
},
{"name" : " Syndrome myasthénique de Lambert-Eaton"
},
{"name" : " Histiocytose à cellules de Langerhans"
},
{"name" : " Grande hémorragie intestinale"
},
{"name" : " Grande obstruction intestinale"
},
{"name" : " Gros ulcère intestinal"
},
{"name" : " Perforation du gros intestin"
},
{"name" : " Polype du gros intestin"
},
{"name" : " Cancer du larynx"
},
{"name" : " Trouble laryngé"
},
{"name" : " Dystonie laryngée"
},
{"name" : " Hémorragie laryngée"
},
{"name" : " Néoplasme laryngé"
},
{"name" : " Oedème laryngé"
},
{"name" : " Douleur laryngée"
},
{"name" : " Laryngite"
},
{"name" : " Dysesthésie laryngopharyngée"
},
{"name" : " Laryngopharyngite"
},
{"name" : " Laryngospasme"
},
{"name" : " Oedème laryngotrachéal"
},
{"name" : " Laryngotrachéite"
},
{"name" : " Lassitude"
},
{"name" : " Tétanie latente"
},
{"name" : " Tuberculose latente"
},
{"name" : " Allergie au latex"
},
{"name" : " Empoisonnement au plomb"
},
{"name" : " Trouble d'apprentissage"
},
{"name" : " Troubles d'apprentissage"
},
{"name" : " Neuropathie d'atrophie optique héréditaire de Leber"
},
{"name" : " Dysfonction ventriculaire gauche"
},
{"name" : " Fraction d'éjection du ventricule gauche diminuée"
},
{"name" : " Insuffisance ventriculaire gauche"
},
{"name" : " Hypertrophie ventriculaire gauche"
},
{"name" : " Dysfonction systolique ventriculaire gauche"
},
{"name" : " Colite ulcéreuse (chronique) du côté gauche"
},
{"name" : " Oedème des jambes"
},
{"name" : " Douleur aux jambes"
},
{"name" : " Ulcère de jambe"
},
{"name" : " Infection à Legionella"
},
{"name" : " Léiomyome"
},
{"name" : " Léiomyosarcome"
},
{"name" : " Leishmaniose"
},
{"name" : " Syndrome de Lennox-Gastaut"
},
{"name" : " Opacités lenticulaires"
},
{"name" : " Pigmentation lenticulaire"
},
{"name" : " Lentigo"
},
{"name" : " Lentigo maligna"
},
{"name" : " Lèpre lépromateuse"
},
{"name" : " Lèpre"
},
{"name" : " Métastases leptoméningées"
},
{"name" : " Syndrome de Leriche"
},
{"name" : " Léthargie"
},
{"name" : " Letterer-Siwe disease"
},
{"name" : " Leucémie"
},
{"name" : " Leucémie cutanée"
},
{"name" : " Leucémie monocytaire"
},
{"name" : " Cerveau d'infiltration leucémique"
},
{"name" : " Réaction leucémoïde"
},
{"name" : " Leucémie secondaire"
},
{"name" : " Vascularite leucocytoclastique"
},
{"name" : " Leucocytose"
},
{"name" : " Leucodermie"
},
{"name" : " Leucoencéphalopathie"
},
{"name" : " Leukonychia"
},
{"name" : " Leucopenie"
},
{"name" : " Leucoplaquie"
},
{"name" : " Leucoplaquie oral"
},
{"name" : " Leucorrhée"
},
{"name" : " Leucostasie"
},
{"name" : " Signe de Lhermitte"
},
{"name" : " Libido diminuée"
},
{"name" : " Trouble de la libido"
},
{"name" : " Libido augmentée"
},
{"name" : " Infestation par les poux"
},
{"name" : " Lichen planus"
},
{"name" : " Lichen scléro-atrophique"
},
{"name" : " Lichen simplex chronicus"
},
{"name" : " Lichénification"
},
{"name" : " Kératose lichénoïde"
},
{"name" : " Couvercle sulcus approfondi"
},
{"name" : " Lésion ligamentaire"
},
{"name" : " Entorse ligamentaire"
},
{"name" : " Anesthésie légère"
},
{"name" : " Sommeil léger"
},
{"name" : " Étourdissements"
},
{"name" : " Déformation des membres"
},
{"name" : " Gêne des membres"
},
{"name" : " Blessure aux membres"
},
{"name" : " Malformation des membres"
},
{"name" : " Parésie des membres"
},
{"name" : " Défaut de réduction des membres"
},
{"name" : " Maladie à IgA linéaire"
},
{"name" : " Ampoule de lèvre"
},
{"name" : " Sensation de brûlure des lèvres"
},
{"name" : " Lèvres sèches"
},
{"name" : " Hémorragie labiale"
},
{"name" : "?dème des lèvres"
},
{"name" : " Douleur aux lèvres"
},
{"name" : " Gonflement des lèvres"
},
{"name" : " Ulcération des lèvres"
},
{"name" : " Lipase anormale"
},
{"name" : " Lipase augmentée"
},
{"name" : " Trouble du métabolisme lipidique"
},
{"name" : " Lipidose"
},
{"name" : " Lipides anormaux"
},
{"name" : " Augmentation des lipides"
},
{"name" : " Lipoatrophie"
},
{"name" : " Lipodystrophie"
},
{"name" : " Acquisition d'une lipodystrophie"
},
{"name" : " Lipoedema"
},
{"name" : " Lipohypertrophie"
},
{"name" : " Néphrose lipoïde"
},
{"name" : " Lipome"
},
{"name" : " Lipomatose"
},
{"name" : " Liposarcome"
},
{"name" : " Listériose"
},
{"name" : " Intoxication au lithium"
},
{"name" : " Toxicité du lithium"
},
{"name" : " Livedo reticularis"
},
{"name" : " Abcès du foie"
},
{"name" : " Trouble hépatique"
},
{"name" : " Foie gras"
},
{"name" : " Dépôt graisseux hépatique"
},
{"name" : " Test de fonction hépatique anormal"
},
{"name" : " Test de fonction hépatique normal"
},
{"name" : " Lésion hépatique"
},
{"name" : " Nodule hépatique"
},
{"name" : " Sensibilité au foie"
},
{"name" : " Rejet d'une greffe de foie"
},
{"name" : " Lividité"
},
{"name" : " Pneumonie lobaire"
},
{"name" : " Carcinome lobulaire du sein in situ"
},
{"name" : " Réaction locale"
},
{"name" : " Gonflement local"
},
{"name" : " Irritation locale de la gorge"
},
{"name" : " Infection localisée"
},
{"name" : " Collecte de liquide intra-abdominale localisée"
},
{"name" : " Engourdissement localisé"
},
{"name" : " Oedème localisé"
},
{"name" : " Réaction cutanée localisée"
},
{"name" : " Érythème localisé"
},
{"name" : " Exfoliation localisée"
},
{"name" : " Arthrose localisée"
},
{"name" : " Éruption cutanée localisée"
},
{"name" : " Cancer du sein localement avancé"
},
{"name" : " Tétanos"
},
{"name" : " Syndrome de Loeffler"
},
{"name" : " Logorrhée"
},
{"name" : " Douleurs aux reins"
},
{"name" : " Syndrome du QT long"
},
{"name" : " Syndrome du QT long congénital"
},
{"name" : " Perte de mémoire à long terme"
},
{"name" : " Selles molles"
},
{"name" : " Lordose"
},
{"name" : " Perte de confiance"
},
{"name" : " Perte de conscience"
},
{"name" : " Perte de contrôle des jambes"
},
{"name" : " Perte de libido"
},
{"name" : " Perte de proprioception"
},
{"name" : " Perte de marques cutanées"
},
{"name" : " Douleur dans le bas du dos"
},
{"name" : " Bébé de faible poids à la naissance"
},
{"name" : " Augmentation des lipoprotéines de basse densité"
},
{"name" : " Faible revenu"
},
{"name" : " pH bas"
},
{"name" : " Oreilles basses"
},
{"name" : " Hémorragie gastro-intestinale inférieure"
},
{"name" : " Fracture du membre inférieur"
},
{"name" : " Lésion des neurones moteurs inférieurs"
},
{"name" : " Infection des voies respiratoires inférieures"
},
{"name" : " Symptômes des voies urinaires inférieures"
},
{"name" : " Lésion du disque lombaire"
},
{"name" : " Céphalée de ponction lombaire"
},
{"name" : " Radiculopathie lombaire"
},
{"name" : " Douleur lombo-sacrée"
},
{"name" : " Abcès pulmonaire"
},
{"name" : " Adénocarcinome pulmonaire stade I"
},
{"name" : " Cancer du poumon métastatique"
},
{"name" : " Trouble pulmonaire"
},
{"name" : " Fibrose pulmonaire interstitielle"
},
{"name" : " Infection pulmonaire"
},
{"name" : " Infiltration pulmonaire"
},
{"name" : " Tumeur pulmonaire"
},
{"name" : " Néoplasme pulmonaire malin"
},
{"name" : " Nodule pulmonaire"
},
{"name" : " Lupus érythémateux"
},
{"name" : " Néphrite lupique"
},
{"name" : " Syndrome de type lupus"
},
{"name" : " Déficit en phase lutéale"
},
{"name" : " Maladie de Lyme"
},
{"name" : " Abcès ganglionnaire"
},
{"name" : " Douleur ganglionnaire"
},
{"name" : " Sensibilité aux ganglions lymphatiques"
},
{"name" : " Lymphadénite"
},
{"name" : " Adénopathie"
},
{"name" : " Adénopathie axillaire"
},
{"name" : " Adénopathie cervicale"
},
{"name" : " Lymphadénopathie inguinale"
},
{"name" : " Lymphangioleiomyomatosis"
},
{"name" : " Lymphangite"
},
{"name" : " Trouble lymphatique"
},
{"name" : " Lymphome lymphoblastique"
},
{"name" : " Lymphocèle"
},
{"name" : " Lymphocyte anormal"
},
{"name" : " Numération lymphocytaire anormale"
},
{"name" : " Nombre de lymphocytes diminué"
},
{"name" : " Augmentation du nombre de lymphocytes"
},
{"name" : " Test de transformation des lymphocytes positif"
},
{"name" : " Colite lymphocytaire"
},
{"name" : " Infiltration lymphocytaire"
},
{"name" : " Leucémie lymphocytaire"
},
{"name" : " Lymphocytoma cutis"
},
{"name" : " Lymphocytose"
},
{"name" : " Lymphoedeme"
},
{"name" : " Lymphogranulome venereum"
},
{"name" : " Lymphome"
},
{"name" : " Lymphome cutis"
},
{"name" : " Lymphopénie"
},
{"name" : " Trouble lymphoprolifératif"
},
{"name" : " Lymphorrhée"
},
{"name" : " Lymphostase"
},
{"name" : " Macroangiopathie"
},
{"name" : " Maladie macrovasculaire"
},
{"name" : " Dégénérescence maculaire"
},
{"name" : " Fibrose maculaire"
},
{"name" : " Trou maculaire"
},
{"name" : " Oedème maculaire"
},
{"name" : " Pigmentation maculaire"
},
{"name" : " Macule"
},
{"name" : " Maculopathie"
},
{"name" : " Madarosis"
},
{"name" : " Carence en magnésium"
},
{"name" : " Saignement majeur"
},
{"name" : " Dépression majeure"
},
{"name" : " Trouble dépressif majeur, épisode unique"
},
{"name" : " Lymphome MALT"
},
{"name" : " Malabsorption"
},
{"name" : " Malaise"
},
{"name" : " Malaise et fatigue"
},
{"name" : " Paludisme"
},
{"name" : " Contraception masculine"
},
{"name" : " Trouble orgasmique masculin"
},
{"name" : " Dysfonction sexuelle masculine"
},
{"name" : " Malformation veineuse"
},
{"name" : " Gliome malin"
},
{"name" : " Histiocytose maligne"
},
{"name" : " Taupe hydatidiforme maligne"
},
{"name" : " Hypertension maligne"
},
{"name" : " Mélanome malin"
},
{"name" : " Mésenchymome malin"
},
{"name" : " Tumeur maligne de l'?sophage"
},
{"name" : " Tumeur maligne des îlots de Langerhans"
},
{"name" : " Tumeur maligne du pancréas"
},
{"name" : " Tumeur maligne du bassin rénal"
},
{"name" : " Progression du néoplasme malin"
},
{"name" : " Kyste ovarien malin"
},
{"name" : " Épanchement pleural malin"
},
{"name" : " Tumeur solide maligne"
},
{"name" : " Syndrome malin SAI"
},
{"name" : " Transformation maligne"
},
{"name" : " Syndrome de Mallory-Weiss"
},
{"name" : " Malnutrition"
},
{"name" : " Mammographie anormale"
},
{"name" : " La manie"
},
{"name" : " Manie aiguë"
},
{"name" : " Épisode maniaque"
},
{"name" : " Psychose maniaque"
},
{"name" : " Lymphome à cellules du manteau"
},
{"name" : " Réfractaire au lymphome à cellules du manteau"
},
{"name" : " Apport alimentaire considérablement réduit"
},
{"name" : " Hyperplasie médullaire"
},
{"name" : " Faciès masqués"
},
{"name" : " Masse"
},
{"name" : " Trouble de la mastication"
},
{"name" : " Mastite"
},
{"name" : " Mastite femelle aiguë"
},
{"name" : " Mastite masculine"
},
{"name" : " Mastocytose"
},
{"name" : " Mastoïdite"
},
{"name" : " Sinusite maxillaire"
},
{"name" : " Signifie pression artérielle"
},
{"name" : " La pression artérielle moyenne a diminué"
},
{"name" : " Augmentation du volume cellulaire moyen"
},
{"name" : " Le volume plaquettaire moyen a diminué"
},
{"name" : " Rougeole"
},
{"name" : " Complication mécanique de l'implant"
},
{"name" : " Urticaire mécanique"
},
{"name" : " Trouble médiastinal"
},
{"name" : " Médiastinite"
},
{"name" : " Tumeur du médiastin"
},
{"name" : " Complication du dispositif médical"
},
{"name" : " Gêne pour les dispositifs médicaux"
},
{"name" : " Maux de tête dus à une surutilisation de médicaments"
},
{"name" : " Résidu de médicament"
},
{"name" : " Présence de résidus de médicaments"
},
{"name" : " Cancer médullaire de la thyroïde"
},
{"name" : " Médulloblastome"
},
{"name" : " Megacolon"
},
{"name" : " Mégacôlon toxique"
},
{"name" : " Meibomianite"
},
{"name" : " Melena"
},
{"name" : " Mélancolie"
},
{"name" : " Naevus mélanocytaire"
},
{"name" : " Mélanodermie"
},
{"name" : " Peau de mélanome"
},
{"name" : " Mélanonychie"
},
{"name" : " Mélanose"
},
{"name" : " Déficience de mémoire"
},
{"name" : " Perte de mémoire"
},
{"name" : " Menarche"
},
{"name" : " Syndrome de Mendelson"
},
{"name" : " Maladie de Ménière"
},
{"name" : " Maladie de Ménière aggravée"
},
{"name" : " Leucémie méningée"
},
{"name" : " Tumeur méningée"
},
{"name" : " Méningiome"
},
{"name" : " Méningiome bénin"
},
{"name" : " Méningisme"
},
{"name" : " Méningite"
},
{"name" : " Méningite aseptique"
},
{"name" : " Méningite bactérienne"
},
{"name" : " Méningite chimique"
},
{"name" : " Méningite cryptococcique"
},
{"name" : " Méningite fongique"
},
{"name" : " Méningite méningococcique"
},
{"name" : " Méningite tuberculeuse"
},
{"name" : " Méningite virale"
},
{"name" : " Méningocèle"
},
{"name" : " Infection à méningocoque"
},
{"name" : " Méningoencéphalite"
},
{"name" : " Méningoencéphalite herpétique"
},
{"name" : " Méningomyélocèle"
},
{"name" : " Ménométrorrhagie"
},
{"name" : " Dépression ménopausique"
},
{"name" : " Trouble de la ménopause"
},
{"name" : " Symptômes de la ménopause"
},
{"name" : " Ménopause"
},
{"name" : " Ménorragie"
},
{"name" : " Cycle menstruel anormal"
},
{"name" : " Cycle menstruel prolongé"
},
{"name" : " Trouble menstruel"
},
{"name" : " Menstruation retardée"
},
{"name" : " Menstruations irrégulières"
},
{"name" : " Aberration mentale"
},
{"name" : " Déficit mental"
},
{"name" : " Détérioration mentale"
},
{"name" : " Maladie mentale"
},
{"name" : " Trouble mental"
},
{"name" : " Trouble mental dû à un état de santé général"
},
{"name" : " Troubles de déficience mentale"
},
{"name" : " Retard mental"
},
{"name" : " État mental anormal"
},
{"name" : " Changements de l'état mental"
},
{"name" : " Empoisonnement au mercure"
},
{"name" : " Thrombose de l'artère mésentérique"
},
{"name" : " Ischémie mésentérique"
},
{"name" : " Occlusion mésentérique"
},
{"name" : " Insuffisance vasculaire mésentérique"
},
{"name" : " Mésothéliome"
},
{"name" : " Acidose métabolique"
},
{"name" : " Alcalose métabolique"
},
{"name" : " Trouble métabolique"
},
{"name" : " Encéphalopathie métabolique"
},
{"name" : " Syndrome métabolique"
},
{"name" : " Empoisonnement aux métaux"
},
{"name" : " Dysplasie métaphysaire"
},
{"name" : " Métaplasie"
},
{"name" : " Métastases au système nerveux central"
},
{"name" : " Métastases au foie"
},
{"name" : " Métastases aux méninges"
},
{"name" : " Métastases au pancréas"
},
{"name" : " Métastases au péritoine"
},
{"name" : " Métastases à la colonne vertébrale"
},
{"name" : " Métastase"
},
{"name" : " Douleur osseuse métastatique"
},
{"name" : " Carcinome métastatique"
},
{"name" : " Maladie métastatique"
},
{"name" : " Adénocarcinome gastrique métastatique"
},
{"name" : " Mélanome malin métastatique"
},
{"name" : " Mélanome métastatique"
},
{"name" : " Tumeur métastatique"
},
{"name" : " Douleur métastatique"
},
{"name" : " Carcinome rénal métastatique"
},
{"name" : " Carcinome épidermoïde métastatique"
},
{"name" : " Méthémoglobinémie"
},
{"name" : " Infection à Staphylococcus aureus résistante à la méthicilline"
},
{"name" : " Métrorragie"
},
{"name" : " Mg réduit"
},
{"name" : " Mg ++ augmenté"
},
{"name" : " Microalbuminurie"
},
{"name" : " Anémie hémolytique microangiopathique"
},
{"name" : " Microangiopathie"
},
{"name" : " Microcéphalie"
},
{"name" : " Microcytaire"
},
{"name" : " Anémie microcytaire"
},
{"name" : " Microcytose"
},
{"name" : " Microembolie"
},
{"name" : " Microhémorragie"
},
{"name" : " Hématurie microscopique"
},
{"name" : " Microsomie"
},
{"name" : " Brûlure par miction"
},
{"name" : " Trouble de la miction"
},
{"name" : " Urgence mictionnelle"
},
{"name" : " Épanchement de l'oreille moyenne"
},
{"name" : " Insomnie moyenne"
},
{"name" : " Clic mi-systolique"
},
{"name" : " Migraine"
},
{"name" : " Migraine aggravée"
},
{"name" : " Migraine avec aura"
},
{"name" : " Migraine sans aura"
},
{"name" : " Migration de l'implant"
},
{"name" : " Milium"
},
{"name" : " Miliaria"
},
{"name" : " Miliaria rubra"
},
{"name" : " Tuberculose miliaire"
},
{"name" : " Carence en minéralocorticoïdes"
},
{"name" : " Dysfonctionnement cérébral minimal"
},
{"name" : " Saignement mineur"
},
{"name" : " Myosis"
},
{"name" : " Toxicité mitochondriale"
},
{"name" : " Atrésie des valvules mitrales"
},
{"name" : " Maladie de la valve mitrale"
},
{"name" : " Incompétence de la valve mitrale"
},
{"name" : " Prolapsus valvulaire mitral"
},
{"name" : " Sténose valvulaire mitrale"
},
{"name" : " Maladie du tissu conjonctif mixte"
},
{"name" : " Hyperlipidémie mixte"
},
{"name" : " Lésion hépatique mixte"
},
{"name" : " Gémissant"
},
{"name" : " Mobilité réduite"
},
{"name" : " Molluscum contagiosum"
},
{"name" : " Monarthrite"
},
{"name" : " Moniliasis femelle génitale"
},
{"name" : " Gammapathie monoclonale"
},
{"name" : " Nombre de monocytes diminué"
},
{"name" : " Augmentation du nombre de monocytes"
},
{"name" : " Monocytose"
},
{"name" : " Tachycardie ventriculaire monomorphe"
},
{"name" : " Mononévrite"
},
{"name" : " Mononeuropathie"
},
{"name" : " Monoparésie"
},
{"name" : " Monoplégie"
},
{"name" : " Altération de l'humeur NSA"
},
{"name" : " Altérations de l'humeur avec symptômes dépressifs"
},
{"name" : " Sautes d'humeur"
},
{"name" : " Rêves morbides"
},
{"name" : " Pensées morbides"
},
{"name" : " Morphée"
},
{"name" : " Piqure de moustique"
},
{"name" : " Mal des transports"
},
{"name" : " Dysfonctionnement moteur"
},
{"name" : " Maladie des neurones moteurs"
},
{"name" : " Agitation motrice"
},
{"name" : " Tic moteur"
},
{"name" : " Mal des montagnes aigu"
},
{"name" : " Hémorragie buccale"
},
{"name" : " Blessure à la bouche"
},
{"name" : " Irritation de la bouche"
},
{"name" : " Ulcération de la bouche"
},
{"name" : " Trouble du mouvement"
},
{"name" : " Mouvements involontaires"
},
{"name" : " Candidose muco-cutanée"
},
{"name" : " Herpès simplex cutanéo-muqueux"
},
{"name" : " Leishmaniose mucocutanée"
},
{"name" : " Mucormycose"
},
{"name" : " Atrophie muqueuse"
},
{"name" : " Saignement muqueux"
},
{"name" : " Décoloration des muqueuses"
},
{"name" : " Sécheresse muqueuse"
},
{"name" : " Érosion muqueuse"
},
{"name" : " Excoriation muqueuse"
},
{"name" : " Hémorragie muqueuse"
},
{"name" : " Inflammation muqueuse"
},
{"name" : " Pigmentation muqueuse"
},
{"name" : " Gonflement des muqueuses"
},
{"name" : " Ulcération muqueuse"
},
{"name" : " Trouble de la membrane muqueuse"
},
{"name" : " Tabourets muqueux"
},
{"name" : " Démence multi-infarctus"
},
{"name" : " Défaillance multi-organes"
},
{"name" : " Tuberculose multirésistante"
},
{"name" : " Tachycardie auriculaire multifocale"
},
{"name" : " Neuropathie motrice multifocale"
},
{"name" : " Tachycardie ventriculaire multifocale"
},
{"name" : " Multipare"
},
{"name" : " Allergies multiples"
},
{"name" : " Anomalies congénitales multiples"
},
{"name" : " Fractures multiples"
},
{"name" : " Grossesse multiple"
},
{"name" : " Sclérose en plaque"
},
{"name" : " Exacerbation de la sclérose en plaques"
},
{"name" : " Rechute de sclérose en plaques"
},
{"name" : " Atrophie multisystématisée"
},
{"name" : " Typhus murin"
},
{"name" : " Effets muscariniques"
},
{"name" : " Atrophie musculaire"
},
{"name" : " Contractions musculaires involontaires"
},
{"name" : " Contracture musculaire"
},
{"name" : " Dommages musculaires"
},
{"name" : " Enzyme musculaire augmentée"
},
{"name" : " Fatigue musculaire"
},
{"name" : " Fibrose musculaire"
},
{"name" : " Hémorragie musculaire"
},
{"name" : " Blessure musculaire"
},
{"name" : " Masse musculaire"
},
{"name" : " Mouvement musculaire involontaire"
},
{"name" : " Nécrose musculaire"
},
{"name" : " Thérapie relaxante musculaire"
},
{"name" : " Relaxation musculaire"
},
{"name" : " Rigidité musculaire"
},
{"name" : " Rupture musculaire"
},
{"name" : " Spasmes musculaires"
},
{"name" : " Spasticité musculaire"
},
{"name" : " Rigidité musculaire"
},
{"name" : " Fatigue musculaire"
},
{"name" : " Gonflement musculaire"
},
{"name" : " Étanchéité musculaire"
},
{"name" : " Trouble du tonus musculaire"
},
{"name" : " Tonus musculaire flasque"
},
{"name" : " Contractions musculaires"
},
{"name" : " Incoordination musculaire"
},
{"name" : " Anomalie septale ventriculaire musculaire"
},
{"name" : " Faiblesse musculaire"
},
{"name" : " Douleurs musculo-squelettiques à la poitrine"
},
{"name" : " Déformation musculo-squelettique"
},
{"name" : " Gêne musculo-squelettique"
},
{"name" : " Trouble musculo-squelettique"
},
{"name" : " Douleurs musculo-squelettiques"
},
{"name" : " Raideur musculo-squelettique"
},
{"name" : " Mutisme"
},
{"name" : " Myalgie"
},
{"name" : " Myasthénie"
},
{"name" : " Myasthénie grave"
},
{"name" : " Syndrome de myasthénie grave"
},
{"name" : " Syndrome myasthénique"
},
{"name" : " Mycétome SAI"
},
{"name" : " Mycétome mycotique"
},
{"name" : " Infection mycobactérienne"
},
{"name" : " Infection au complexe Mycobacterium avium"
},
{"name" : " Test de Mycobacterium"
},
{"name" : " Mycose fongoïde"
},
{"name" : " Anévrisme mycotique"
},
{"name" : " Endophtalmie mycotique"
},
{"name" : " Mydriasis"
},
{"name" : " Myélite"
},
{"name" : " Myélite transversale"
},
{"name" : " Myélodysplasie"
},
{"name" : " Syndrome myélodysplasique"
},
{"name" : " Transformation du syndrome myélodysplasique"
},
{"name" : " Myélofibrose"
},
{"name" : " Leucémie myéloïde"
},
{"name" : " Métaplasie myéloïde"
},
{"name" : " Trouble myéloprolifératif"
},
{"name" : " Myélosuppression"
},
{"name" : " Dépression myocardique"
},
{"name" : " Trouble myocardique"
},
{"name" : " Hémorragie myocardique"
},
{"name" : " Hypertrophie myocardique"
},
{"name" : " Infarctus du myocarde"
},
{"name" : " Ischémie myocardique"
},
{"name" : " Nécrose myocardique"
},
{"name" : " Réinfarctus du myocarde"
},
{"name" : " Rupture myocardique"
},
{"name" : " Myocardite"
},
{"name" : " Épilepsie myoclonique"
},
{"name" : " Myoclonie"
},
{"name" : " Syndrome de douleur myofasciale"
},
{"name" : " Présence d'urine de myoglobine"
},
{"name" : " Myoglobinémie"
},
{"name" : " Myoglobinurie"
},
{"name" : " Myopathie"
},
{"name" : " Myopathie toxique"
},
{"name" : " Myopéricardite"
},
{"name" : " Myopie"
},
{"name" : " Transitoire de myopie"
},
{"name" : " Myosite"
},
{"name" : " Myotonie"
},
{"name" : " Myringite"
},
{"name" : " Myx?dème"
},
{"name" : " Coma myxoedème"
},
{"name" : " Carence en N-acétylglutamate synthase"
},
{"name" : " Anomalie des ongles SAI"
},
{"name" : " Infection du lit de l'ongle"
},
{"name" : " Tendresse du lit de l'ongle"
},
{"name" : " Changements des ongles"
},
{"name" : " Décoloration des ongles"
},
{"name" : " Inconfort des ongles"
},
{"name" : " Trouble des ongles"
},
{"name" : " Dystrophie des ongles"
},
{"name" : " Hypertrophie des ongles"
},
{"name" : " Infection des ongles"
},
{"name" : " Ongles stries longitudinales"
},
{"name" : " Pigmentation des ongles"
},
{"name" : " Crête des ongles"
},
{"name" : " Amincissement des ongles"
},
{"name" : " Toxicité des ongles"
},
{"name" : " Narcolepsie"
},
{"name" : " Narcose"
},
{"name" : " Brûlure nasale"
},
{"name" : " Congestion nasale"
},
{"name" : " Gêne nasale"
},
{"name" : " Trouble nasal"
},
{"name" : " Sécheresse nasale"
},
{"name" : " Inflammation nasale"
},
{"name" : " Irritation nasale"
},
{"name" : " Démangeaisons nasales"
},
{"name" : " Atrophie de la muqueuse nasale"
},
{"name" : " Trouble de la muqueuse nasale"
},
{"name" : " Érythème muqueux nasal"
},
{"name" : " Sang de mucus teinté"
},
{"name" : " Obstruction nasale"
},
{"name" : " Odeur nasale"
},
{"name" : " Oedème nasal"
},
{"name" : " Douleur nasale"
},
{"name" : " Irritation du passage nasal"
},
{"name" : " Polypes nasaux"
},
{"name" : " Déviation du septum nasal"
},
{"name" : " Trouble du septum nasal"
},
{"name" : " Perforation du septum nasal"
},
{"name" : " Ulcération du septum nasal"
},
{"name" : " Drainage des sinus nasaux"
},
{"name" : " Douleur nasale"
},
{"name" : " Ulcère nasal"
},
{"name" : " Cancer du nasopharynx"
},
{"name" : " Carcinome du nasopharynx"
},
{"name" : " Trouble nasopharyngé"
},
{"name" : " Rhinopharyngite"
},
{"name" : " Ménopause naturelle"
},
{"name" : " Nausées"
},
{"name" : " Nausées aggravées"
},
{"name" : " Nausée seule"
},
{"name" : " Nausée postopératoire"
},
{"name" : " Blessure au cou"
},
{"name" : " Oedème du cou "
},
{"name" : " Douleur du cou"
},
{"name" : " Raideur de la nuque"
},
{"name" : " Gonflement du cou"
},
{"name" : " Serrage au cou"
},
{"name" : " Necrobiosis lipoidica diabeticorum"
},
{"name" : " Nécrolyse épidermique"
},
{"name" : " Nécrose"
},
{"name" : " Nécrose ischémique"
},
{"name" : " Colite nécrosante"
},
{"name" : " Entérocolite nécrosante néonatale"
},
{"name" : " Fasciite nécrosante"
},
{"name" : " Gingivostomatite ulcéreuse nécrosante"
},
{"name" : " Entérocolite nécrosante"
},
{"name" : " Blessure à l'aiguille"
},
{"name" : " Négativisme"
},
{"name" : " Infection à Neisseria"
},
{"name" : " Trouble néonatal et infantile"
},
{"name" : " Trouble néonatal"
},
{"name" : " Hyponatrémie néonatale"
},
{"name" : " Infection néonatale"
},
{"name" : " Syndrome de détresse respiratoire néonatale"
},
{"name" : " Tachypnée néonatale"
},
{"name" : " Tétanie néonatale"
},
{"name" : " Néoplasme"
},
{"name" : " Tumeur maligne"
},
{"name" : " Tumeur maligne aggravée"
},
{"name" : " Progression du néoplasme"
},
{"name" : " Néoplasme prostate"
},
{"name" : " Récidive du néoplasme"
},
{"name" : " Peau néoplasique"
},
{"name" : " Syndrome néphritique"
},
{"name" : " Néphrite"
},
{"name" : " Néphrite interstitielle"
},
{"name" : " Néphroblastome"
},
{"name" : " Néphrocalcinose"
},
{"name" : " Diabète insipide néphrogénique"
},
{"name" : " Fibrose systémique néphrogénique"
},
{"name" : " Néphrolithiase"
},
{"name" : " Néphropathie"
},
{"name" : " Néphropathie toxique"
},
{"name" : " Néphrosclérose"
},
{"name" : " Néphrose"
},
{"name" : " Néphrose néphron inférieur"
},
{"name" : " Syndrome néphrotique"
},
{"name" : " Syndrome néphrotique avec lésion de glomérulonéphrite à changement minimal"
},
{"name" : " Néphrotoxicité"
},
{"name" : " Compression nerveuse"
},
{"name" : " Études de conduction nerveuse anormales"
},
{"name" : " Lésion nerveuse"
},
{"name" : " Paralysie nerveuse"
},
{"name" : " Lésion de la racine nerveuse"
},
{"name" : " Trouble du système nerveux"
},
{"name" : " Tremblements nerveux"
},
{"name" : " Nervosité"
},
{"name" : " Syndrome de Netherton"
},
{"name" : " Urticaire"
},
{"name" : " Perte auditive neurale"
},
{"name" : " Anomalie du tube neural"
},
{"name" : " Névralgie"
},
{"name" : " Névrite"
},
{"name" : " Névrite rétrobulbaire"
},
{"name" : " Neuroblastome"
},
{"name" : " Asthénie neurocirculatoire"
},
{"name" : " Neurocysticercose"
},
{"name" : " Trouble neurodégénératif"
},
{"name" : " Neurodermatite"
},
{"name" : " Tumeur neuroectodermique"
},
{"name" : " Tumeur neuroendocrine"
},
{"name" : " Neurofibrome"
},
{"name" : " Neurofibromatose"
},
{"name" : " Vessie neurogène"
},
{"name" : " Intestin neurogène"
},
{"name" : " Neuroglycopénie"
},
{"name" : " Syndrome malin des neuroleptiques"
},
{"name" : " Réaction neurologique"
},
{"name" : " Affections neurologiques NEC"
},
{"name" : " Examen neurologique anormal"
},
{"name" : " Atteinte neurologique"
},
{"name" : " Symptôme neurologique"
},
{"name" : " Névrome"
},
{"name" : " Bloc neuromusculaire prolongé"
},
{"name" : " Toxicité neuromusculaire"
},
{"name" : " Neuromyopathie"
},
{"name" : " Arthropathie neuropathique"
},
{"name" : " Neuropathie"
},
{"name" : " Neuropathie périphérique"
},
{"name" : " Syndrome neuropsychiatrique"
},
{"name" : " Névrose"
},
{"name" : " Neurosyphilis"
},
{"name" : " Dépression névrotique"
},
{"name" : " Neurotoxicité"
},
{"name" : " Modification du niveau des neurotransmetteurs"
},
{"name" : " Neutropénie"
},
{"name" : " Neutropénie aggravée"
},
{"name" : " Colite neutropénique"
},
{"name" : " Entérocolite neutropénique"
},
{"name" : " Infection neutropénique"
},
{"name" : " Septicémie neutropénique"
},
{"name" : " Nombre de neutrophiles diminué"
},
{"name" : " Augmentation du nombre de neutrophiles"
},
{"name" : " Augmentation du pourcentage de neutrophiles"
},
{"name" : " Neutrophilie"
},
{"name" : " Dermatose neutrophile"
},
{"name" : " Nevus"
},
{"name" : " Dépendance à la nicotine"
},
{"name" : " Empoisonnement à la nicotine"
},
{"name" : " Carence en acide nicotinique"
},
{"name" : " Effets nicotiniques"
},
{"name" : " Cécité nocturne"
},
{"name" : " Crampes nocturnes"
},
{"name" : " Sueurs nocturnes"
},
{"name" : " Cauchemar"
},
{"name" : " Trouble du mamelon"
},
{"name" : " Douleur au mamelon"
},
{"name" : " Gonflement des mamelons"
},
{"name" : " Tendresse du mamelon"
},
{"name" : " Bilan azoté négatif"
},
{"name" : " Nocardiose"
},
{"name" : " Nocturie"
},
{"name" : " Nocturie aggravée"
},
{"name" : " Éveil nocturne"
},
{"name" : " Confusion nocturne"
},
{"name" : " Dyspnée nocturne"
},
{"name" : " Émission nocturne"
},
{"name" : " Énurésie nocturne"
},
{"name" : " Polyurie nocturne"
},
{"name" : " Arythmie nodale"
},
{"name" : " Bloc nodal"
},
{"name" : " Rythme nodal"
},
{"name" : " Tachycardie nodale"
},
{"name" : " Cancer du sein ganglionnaire négatif"
},
{"name" : " Cancer du sein à ganglions positifs"
},
{"name" : " Carcinome basocellulaire nodulaire"
},
{"name" : " Glomérulosclérose nodulaire"
},
{"name" : " Lymphome nodulaire"
},
{"name" : " Hyperplasie régénérative nodulaire"
},
{"name" : " Nodule"
},
{"name" : " Lymphome non hodgkinien"
},
{"name" : " MI sans onde Q"
},
{"name" : " Blessure non accidentelle"
},
{"name" : " Douleur thoracique non cardiaque"
},
{"name" : " Oedème pulmonaire non cardiogénique"
},
{"name" : " Maladie de reflux non érosive"
},
{"name" : " Cardiomyopathie non ischémique"
},
{"name" : " Psoriasis non-cuir chevelu"
},
{"name" : " Cancer du poumon non à petites cellules"
},
{"name" : " Cancer du poumon non à petites cellules métastatique"
},
{"name" : " Cancer du poumon non à petites cellules, stade III"
},
{"name" : " Non fumeur"
},
{"name" : " Tachycardie ventriculaire non soutenue"
},
{"name" : " Consommateur non-tabac"
},
{"name" : " État de mal épileptique non convulsif"
},
{"name" : " Péritonite non infectieuse"
},
{"name" : " Hyperglycinémie non cétotique"
},
{"name" : " Goitre non toxique"
},
{"name" : " Grossesse normale"
},
{"name" : " Anémie normocytaire normochromique"
},
{"name" : " Anémie normocytaire"
},
{"name" : " Gale norvégienne"
},
{"name" : " Infection du nez SAI"
},
{"name" : " Infection nosocomiale"
},
{"name" : " Pneumonie nosocomiale"
},
{"name" : " NPN augmenté"
},
{"name" : " Rigidité nucale"
},
{"name" : " Nullipares"
},
{"name" : " Engourdissement"
},
{"name" : " Engourdissement du visage"
},
{"name" : " Engourdissement généralisé"
},
{"name" : " Engourdissement des doigts"
},
{"name" : " Engourdissement dans la jambe"
},
{"name" : " Lèvres engourdies"
},
{"name" : " Engourdissement des membres"
},
{"name" : " Engourdissement de la langue"
},
{"name" : " Nystagmus"
},
{"name" : " Obésité"
},
{"name" : " Bronchiolite oblitérante"
},
{"name" : " Obnubilation"
},
{"name" : " Névrose obsessionnelle"
},
{"name" : " Rumination obsessionnelle"
},
{"name" : " Pensées obsessionnelles"
},
{"name" : " Trouble obsessionnel compulsif"
},
{"name" : " Trouble de la personnalité obsessionnelle-compulsive"
},
{"name" : " Complication de procédure obstétricale"
},
{"name" : " Obstipation"
},
{"name" : " Obstruction"
},
{"name" : " Obstruction pylorique"
},
{"name" : " Trouble obstructif des voies respiratoires"
},
{"name" : " Bronchite chronique obstructive"
},
{"name" : " Syndrome d'apnée obstructive du sommeil"
},
{"name" : " Céphalées occipitales"
},
{"name" : " Névralgie occipitale"
},
{"name" : " Sang occulte positif"
},
{"name" : " Asthme professionnel"
},
{"name" : " Expositions professionnelles"
},
{"name" : " Ochronose"
},
{"name" : " Inconfort oculaire"
},
{"name" : " Hyperémie oculaire"
},
{"name" : " Hypertension oculaire"
},
{"name" : " Icterus oculaire"
},
{"name" : " Troubles de la sensation oculaire"
},
{"name" : " Piqûre oculaire"
},
{"name" : " Maladie de la surface oculaire"
},
{"name" : " Toxicité oculaire"
},
{"name" : " Trouble vasculaire oculaire"
},
{"name" : " Syndrome oculo-respiratoire"
},
{"name" : " Oculogyration"
},
{"name" : " Crise oculogyrique"
},
{"name" : " Syndrome oculomucocutané"
},
{"name" : " Syndrome oculo-respiratoire"
},
{"name" : " Odynophagie"
},
{"name" : "?dème"
},
{"name" : " Oedème aggravé"
},
{"name" : " Oedème auriculaire"
},
{"name" : " Oedème dû à une maladie cardiaque"
},
{"name" : " Oedème génital"
},
{"name" : " Oedème génital labial"
},
{"name" : " Bouche d'?dème"
},
{"name" : " Oedème muqueux"
},
{"name" : " Oedème périphérique"
},
{"name" : " Achalasie ?sophagienne"
},
{"name" : " Adénocarcinome ?sophagien"
},
{"name" : " Atrésie ?sophagienne"
},
{"name" : " Candidose ?sophagienne"
},
{"name" : " Carcinome ?sophagien"
},
{"name" : " Gêne ?sophagienne"
},
{"name" : " Trouble ?sophagien"
},
{"name" : " Hémorragie ?sophagienne"
},
{"name" : " Irritation ?sophagienne"
},
{"name" : " Trouble de la motilité ?sophagienne"
},
{"name" : " Tumeur ?sophagienne"
},
{"name" : " Obstruction ?sophagienne"
},
{"name" : "?dème ?sophagien"
},
{"name" : " Douleur ?sophagienne"
},
{"name" : " Perforation ?sophagienne"
},
{"name" : " Reflux ?sophagien aggravé"
},
{"name" : " Rupture ?sophagienne"
},
{"name" : " Spasme ?sophagien"
},
{"name" : " Sténose ?sophagienne"
},
{"name" : " Acquisition d'une sténose ?sophagienne"
},
{"name" : " Ulcère ?sophagien"
},
{"name" : " Hémorragie des varices ?sophagiennes"
},
{"name" : "?sophagite"
},
{"name" : " Oesophagite ulcéreuse"
},
{"name" : " Oestradiol augmenté"
},
{"name" : " Carence en ?strogènes"
},
{"name" : " Oestrogène faible"
},
{"name" : " Effet ?strogénique"
},
{"name" : " Cheveux gras"
},
{"name" : " Peau grasse"
},
{"name" : " Ancien infarctus du myocarde"
},
{"name" : " Bursite de l'olécrane"
},
{"name" : " Oligohydramnios"
},
{"name" : " Oligoménorrhée"
},
{"name" : " Oligospermie"
},
{"name" : " Oligurie"
},
{"name" : " Omphalocèle"
},
{"name" : " Onchocercose"
},
{"name" : " Onychia"
},
{"name" : " Onychoclasis"
},
{"name" : " Onycholyse"
},
{"name" : " Onychomadesis"
},
{"name" : " Onychomycose"
},
{"name" : " Glaucome à angle ouvert"
},
{"name" : " Blessure ouverte"
},
{"name" : " Saignement opératoire"
},
{"name" : " Ophthalmia neonatorum"
},
{"name" : " Herpès simplex ophtalmique"
},
{"name" : " Zona herpès ophtalmique"
},
{"name" : " Ophtalmoplégie"
},
{"name" : " Abus d'opioïdes"
},
{"name" : " Constipation induite par les opioïdes"
},
{"name" : " Opioïde naïf"
},
{"name" : " Opisthotonus"
},
{"name" : " Infection opportuniste"
},
{"name" : " Mycose opportuniste"
},
{"name" : " Oppositionnel"
},
{"name" : " Atrophie optique"
},
{"name" : " Trouble vasculaire du disque optique"
},
{"name" : " Neuropathie ischémique optique"
},
{"name" : " Ventilation du nerf optique"
},
{"name" : " Trouble du nerf optique"
},
{"name" : " Névrite optique"
},
{"name" : " Candidose buccale"
},
{"name" : " Inconfort buccal"
},
{"name" : " Trouble buccal"
},
{"name" : " Infection fongique orale"
},
{"name" : " Herpès buccal"
},
{"name" : " Infection buccale"
},
{"name" : " Lésion buccale"
},
{"name" : " Érosion de la muqueuse buccale"
},
{"name" : " Mal de muqueuse buccale"
},
{"name" : " Cloques muqueuses buccales"
},
{"name" : " Décoloration des muqueuses buccales"
},
{"name" : " Trouble de la muqueuse buccale"
},
{"name" : " Exfoliation muqueuse buccale"
},
{"name" : " Irritation des muqueuses buccales"
},
{"name" : " Pétéchies muqueuses buccales"
},
{"name" : " Tumeur buccale"
},
{"name" : " Néoplasme buccal bénin"
},
{"name" : " Douleur buccale"
},
{"name" : " Papillome oral"
},
{"name" : " Prurit oral"
},
{"name" : " Pustule orale"
},
{"name" : " Trouble des tissus mous buccaux SAI"
},
{"name" : " Toxicité orale"
},
{"name" : "?dème orbital"
},
{"name" : " Orchite"
},
{"name" : " Orchite non infectieuse"
},
{"name" : " Insuffisance d'organe"
},
{"name" : " Syndrome cérébral organique"
},
{"name" : " Organiser la pneumonie"
},
{"name" : " Orgasme anormal"
},
{"name" : " Sensation orgasmique diminuée"
},
{"name" : " Déficit en ornithine transcarbamoylase"
},
{"name" : " Dyskinésie orofaciale"
},
{"name" : " Oedème orofacial"
},
{"name" : " Dystonie oromandibulaire"
},
{"name" : " Cloques oropharyngées"
},
{"name" : " Candidose oropharyngée"
},
{"name" : " Gêne oropharyngée"
},
{"name" : " Douleur oropharyngée"
},
{"name" : " Spasme oropharyngé"
},
{"name" : " Carcinome épidermoïde oropharyngé"
},
{"name" : " Gonflement oropharyngé"
},
{"name" : " Orthopnée"
},
{"name" : " Effondrement orthostatique"
},
{"name" : " Dérégulation orthostatique"
},
{"name" : " Hypertension orthostatique"
},
{"name" : " Hypotension orthostatique"
},
{"name" : " Intolérance orthostatique"
},
{"name" : " Oscillopsie"
},
{"name" : " Osmolalité augmentée"
},
{"name" : " Syndrome de démyélinisation osmotique"
},
{"name" : " Ostéite"
},
{"name" : " Ostéite déformante"
},
{"name" : " Arthrose"
},
{"name" : " Arthrose aggravée"
},
{"name" : " Arthrose de la colonne cervicale"
},
{"name" : " Douleur ostéoarticulaire"
},
{"name" : " Ostéocalcine augmentée"
},
{"name" : " Ostéochondrose"
},
{"name" : " Ostéodystrophie"
},
{"name" : " Ostéogenèse imparfaite"
},
{"name" : " Ostéolyse"
},
{"name" : " Lésion ostéolytique"
},
{"name" : " Ostéomalacie"
},
{"name" : " Ostéomyélite"
},
{"name" : " Ostéonécrose"
},
{"name" : " Ostéonécrose de la mâchoire"
},
{"name" : " Ostéopénie"
},
{"name" : " Ostéoporose"
},
{"name" : " Ostéoporose postménopausique"
},
{"name" : " Fracture ostéoporotique"
},
{"name" : " Ostéosarcome"
},
{"name" : " Ostéosarcome métastatique"
},
{"name" : " Ostéosclérose"
},
{"name" : " Autre acné"
},
{"name" : " Autres maladies bactériennes"
},
{"name" : " Autres conjonctivites"
},
{"name" : " Autres dermatoses"
},
{"name" : " Autres troubles oculaires"
},
{"name" : " Autres formes d'épilepsie"
},
{"name" : " Autres sclérites"
},
{"name" : " Autres troubles du sommeil"
},
{"name" : " Otite"
},
{"name" : " Otite externe"
},
{"name" : " Otite externe fongique"
},
{"name" : " Otite moyenne"
},
{"name" : " Otite moyenne aiguë"
},
{"name" : " Otite moyenne bactérienne"
},
{"name" : " Otite moyenne chronique"
},
{"name" : " Otite moyenne séreuse"
},
{"name" : " Otorrhée"
},
{"name" : " Otosalpingite"
},
{"name" : " Ototoxicité"
},
{"name" : " Adénocarcinome ovarien"
},
{"name" : " Atrophie ovarienne"
},
{"name" : " Cancer des ovaires"
},
{"name" : " Carcinome ovarien"
},
{"name" : " Kyste de l'ovaire"
},
{"name" : " Trouble ovarien"
},
{"name" : " Hypertrophie ovarienne"
},
{"name" : " Cancer épithélial ovarien"
},
{"name" : " Cancer épithélial ovarien récurrent"
},
{"name" : " Cancer épithélial ovarien stade IV"
},
{"name" : " Insuffisance ovarienne"
},
{"name" : " Tératome des cellules germinales ovariennes bénin"
},
{"name" : " Hémorragie ovarienne"
},
{"name" : " Hyperstimulation ovarienne"
},
{"name" : " Syndrome d'hyperstimulation ovarienne"
},
{"name" : " Tumeur ovarienne"
},
{"name" : " Douleur ovarienne"
},
{"name" : " Hyperactivité"
},
{"name" : " Surdosage"
},
{"name" : " Effet de surdosage"
},
{"name" : " Prolifération bactérienne"
},
{"name" : " Oversedation"
},
{"name" : " Surpoids"
},
{"name" : " Surmenage"
},
{"name" : " Trouble de l'ovulation"
},
{"name" : " Ovulation inhibée"
},
{"name" : " Douleur d'ovulation"
},
{"name" : " Saturation en oxygène diminuée"
},
{"name" : " Douleur"
},
{"name" : " Douleur au repos"
},
{"name" : " Douleur brûlante"
},
{"name" : " Douleur lors de l'injection"
},
{"name" : " Faim, douleur"
},
{"name" : " Douleur au bras"
},
{"name" : " Douleur au coude"
},
{"name" : " Douleur aux extrémités"
},
{"name" : " Douleur aux doigts"
},
{"name" : " Douleur à la mâchoire"
},
{"name" : " Douleur localisée"
},
{"name" : " Douleur cou / épaule"
},
{"name" : " Nerf douloureux"
},
{"name" : " Douleur des membres inférieurs"
},
{"name" : " Douleur de peau"
},
{"name" : " Douleur aggravée"
},
{"name" : " Cheville douloureuse"
},
{"name" : " Éjaculation douloureuse"
},
{"name" : " Érection douloureuse"
},
{"name" : " Yeux rouges douloureux"
},
{"name" : " Respiration douloureuse"
},
{"name" : " Réponse douloureuse à des stimuli normaux"
},
{"name" : " Pallanesthésie"
},
{"name" : " Pâleur"
},
{"name" : " Facial pâleur"
},
{"name" : " Pâleur de la peau"
},
{"name" : " Érythème palmaire"
},
{"name" : " Érythème palmo-plantaire"
},
{"name" : " Syndrome d'érythrodysesthésie palmo-plantaire"
},
{"name" : " Kératodermie palmoplantaire"
},
{"name" : " Purpura palpable"
},
{"name" : " Palpitations"
},
{"name" : " Panaritium"
},
{"name" : " Pancolitis"
},
{"name" : " Abcès pancréatique"
},
{"name" : " Carcinome pancréatique"
},
{"name" : " Carcinome pancréatique métastatique"
},
{"name" : " Trouble pancréatique"
},
{"name" : " Enzymes pancréatiques anormales"
},
{"name" : " Augmentation des enzymes pancréatiques"
},
{"name" : " Fistule pancréatique"
},
{"name" : " Insuffisance pancréatique"
},
{"name" : " Nécrose pancréatique"
},
{"name" : " Tumeur pancréatique"
},
{"name" : " Pseudokyste pancréatique"
},
{"name" : " Pancréatite"
},
{"name" : " Pancréatite aiguë"
},
{"name" : " Pancréatite aiguë sur chronique"
},
{"name" : " Pancréatite aggravée"
},
{"name" : " Pancréatite chronique"
},
{"name" : " Pancréatite due à une obstruction biliaire"
},
{"name" : " Pancréatite hémorragique"
},
{"name" : " Pancréatite nécrosante"
},
{"name" : " Pancytopénie"
},
{"name" : " Panhypopituitarisme"
},
{"name" : " Attaque de panique"
},
{"name" : " Trouble panique"
},
{"name" : " Réaction de panique"
},
{"name" : " Panniculite"
},
{"name" : " Panophtalmie"
},
{"name" : " Panuveitis"
},
{"name" : " Papanicolaou frottis suspect"
},
{"name" : " Rupture du muscle papillaire"
},
{"name" : " Cancer papillaire de la thyroïde"
},
{"name" : "?dème papillaire"
},
{"name" : " Papillome"
},
{"name" : " Papillomatose"
},
{"name" : " Papule"
},
{"name" : " Éruption papulopustuleuse"
},
{"name" : " Infection à Paracoccidioides"
},
{"name" : " Réponse paradoxale du presseur"
},
{"name" : " Paresthésie"
},
{"name" : " Paresthésie NEC"
},
{"name" : " Pied de paresthésie"
},
{"name" : " Main de paresthésie"
},
{"name" : " Paresthésie orale"
},
{"name" : " Peau de paresthésie"
},
{"name" : " Paresthésies et dysesthésies"
},
{"name" : " Tumeur paraganglionnaire"
},
{"name" : " Infection par le virus Parainfluenzae"
},
{"name" : " Paralysie"
},
{"name" : " Paralysie flasque"
},
{"name" : " Paralysie de la vessie"
},
{"name" : " Paramétrite"
},
{"name" : " Hypersécrétion des sinus paranasaux"
},
{"name" : " Paranoïa"
},
{"name" : " Délires paranoïdes"
},
{"name" : " Réaction paranoïaque"
},
{"name" : " État paranoïaque"
},
{"name" : " Paraparésie"
},
{"name" : " Paraplégie"
},
{"name" : " Paraprotéinémie"
},
{"name" : " Gastro-entérite parasitaire"
},
{"name" : " Parasomnie"
},
{"name" : " Parasuicide"
},
{"name" : " Trouble parathyroïdien"
},
{"name" : " Tumeur parathyroïdienne"
},
{"name" : " Tumeur parathyroïdienne bénigne"
},
{"name" : " Fièvre paratyphoïde"
},
{"name" : " Parésie"
},
{"name" : " Paresthésie généralisée"
},
{"name" : " Lèvres paresthésiques"
},
{"name" : " Paresthésie du membre inférieur"
},
{"name" : " Paresthésie des doigts"
},
{"name" : " Paresthésie des membres"
},
{"name" : " Paresthésie du cuir chevelu"
},
{"name" : " Maladie de Parkinson"
},
{"name" : " Maladie de Parkinson aggravée"
},
{"name" : " Démarche parkinsonienne"
},
{"name" : " Tremblements du repos parkinsonien"
},
{"name" : " Parkinsonisme"
},
{"name" : " Parkinsonisme aggravé"
},
{"name" : " Parkinsonisme post-encéphalitique"
},
{"name" : " Paronychia"
},
{"name" : " Parosmie"
},
{"name" : " Obstruction du canal parotide"
},
{"name" : " Elargissement de la glande parotide"
},
{"name" : " Inflammation de la glande parotide"
},
{"name" : " Gonflement parotide"
},
{"name" : " Parotidite"
},
{"name" : " Fibrillation auriculaire paroxystique"
},
{"name" : " Flutter auriculaire paroxystique"
},
{"name" : " Tachycardie auriculaire paroxystique"
},
{"name" : " Hémoglobinurie nocturne paroxystique"
},
{"name" : " Tachycardie supraventriculaire paroxystique"
},
{"name" : " Tachycardie ventriculaire paroxystique"
},
{"name" : " Pars planite"
},
{"name" : " Épilepsie partielle"
},
{"name" : " Perte auditive partielle"
},
{"name" : " Surdité permanente partielle"
},
{"name" : " Saisies partielles"
},
{"name" : " Surdité transitoire partielle"
},
{"name" : " Stress du partenaire"
},
{"name" : " Infection à Pasteurella"
},
{"name" : " Brevet canalaire artériel"
},
{"name" : " Résistance aux agents pathogènes"
},
{"name" : " Myopie pathologique"
},
{"name" : " Jeu pathologique"
},
{"name" : " PCO2"
},
{"name" : " Débit expiratoire de pointe"
},
{"name" : " Débit de pointe"
},
{"name" : " Allergie aux arachides"
},
{"name" : " Pectus excavatum"
},
{"name" : " Pouls de la pédale diminué"
},
{"name" : " Pédiculose capitis"
},
{"name" : " Pédiculose corporelle"
},
{"name" : " Péliose hépatique"
},
{"name" : " Obstruction pelvi-urétérale"
},
{"name" : " Abcès pelvien"
},
{"name" : " Gêne pelvienne"
},
{"name" : " Fibrose pelvienne"
},
{"name" : " Fracture pelvienne"
},
{"name" : " Hématome pelvien"
},
{"name" : " Hémorragie pelvienne"
},
{"name" : " Infection pelvienne"
},
{"name" : " Maladie inflammatoire pelvienne"
},
{"name" : " Tumeur pelvienne"
},
{"name" : " Douleur pelvienne"
},
{"name" : " Douleur pelvienne femelle"
},
{"name" : " Adhérences péritonéales pelviennes"
},
{"name" : " Péritonite pelvienne"
},
{"name" : " Thrombose veineuse pelvienne"
},
{"name" : " Pemphigoïde"
},
{"name" : " Réaction pemphigoïde"
},
{"name" : " Pemphigus"
},
{"name" : " Pemphigus vulgaris"
},
{"name" : " Allergie à la pénicilline"
},
{"name" : " Cancer du pénis"
},
{"name" : " Courbure du pénis"
},
{"name" : " Écoulement du pénis"
},
{"name" : " Hématome pénien"
},
{"name" : " Hémorragie pénienne"
},
{"name" : " Infection du pénis"
},
{"name" : " Oedème pénien"
},
{"name" : " Douleur pénienne"
},
{"name" : " Gonflement du pénis"
},
{"name" : " Trouble du pénis"
},
{"name" : " Ulcère peptique"
},
{"name" : " Hémorragie ulcéreuse gastroduodénale"
},
{"name" : " Perforation de l'ulcère peptique"
},
{"name" : " Ulcère peptique réactivé"
},
{"name" : " Distorsions perceptuelles"
},
{"name" : " Perturbation perceptuelle"
},
{"name" : " Rhinite allergique pérenne"
},
{"name" : " Peur de la performance"
},
{"name" : " Statut de performance diminué"
},
{"name" : " Verrues périanales"
},
{"name" : " Périarthrite"
},
{"name" : " Maladie péricardique"
},
{"name" : " Épanchement péricardique"
},
{"name" : " Hémorragie péricardique"
},
{"name" : " Frottement péricardique"
},
{"name" : " Péricardite"
},
{"name" : " Péricardite constrictive"
},
{"name" : " Péricoronite"
},
{"name" : " Abcès péridiverticulaire"
},
{"name" : " Abcès périnéal"
},
{"name" : " Blessure périnéale"
},
{"name" : " Lacération périnéale"
},
{"name" : " Douleur périnéale"
},
{"name" : " Douleur périnéale femelle"
},
{"name" : " Abcès périnéphrique"
},
{"name" : " Collection périnéphrique"
},
{"name" : " Destruction parodontale"
},
{"name" : " Maladie parodontale"
},
{"name" : " Parodontite"
},
{"name" : " Paresthésie périorale"
},
{"name" : " Picotements périoraux"
},
{"name" : " Hématome périorbitaire"
},
{"name" : " Oedème périorbitaire"
},
{"name" : " Douleur périorbitaire"
},
{"name" : " Gonflement périorbitaire"
},
{"name" : " Périostite"
},
{"name" : " Lymphome à cellules T périphérique, sans précision"
},
{"name" : " Maladie artérielle périphérique"
},
{"name" : " Maladie occlusive artérielle périphérique"
},
{"name" : " Anévrisme de l'artère périphérique"
},
{"name" : " Sténose artérielle périphérique"
},
{"name" : " Thrombose de l'artère périphérique"
},
{"name" : " Froideur périphérique"
},
{"name" : " Embolie périphérique"
},
{"name" : " Gangrène périphérique"
},
{"name" : " Ischémie périphérique"
},
{"name" : " Neuropathie motrice périphérique"
},
{"name" : " Lésion du nerf périphérique"
},
{"name" : " Paralysie du nerf périphérique"
},
{"name" : " Neuropathie périphérique aggravée"
},
{"name" : " Neuropathie sensorimotrice périphérique"
},
{"name" : " Neuropathie sensorielle périphérique"
},
{"name" : " Gonflement périphérique"
},
{"name" : " Trouble vasculaire périphérique"
},
{"name" : " Vasodilatation périphérique"
},
{"name" : " Abcès périrectal"
},
{"name" : " Hématome périrénal"
},
{"name" : " Adhérences péritonéales"
},
{"name" : " Effluent nuageux péritonéal"
},
{"name" : " Hémorragie péritonéale"
},
{"name" : " Infection péritonéale"
},
{"name" : " Péritonite"
},
{"name" : " Péritonite bactérienne"
},
{"name" : " Abcès péri-amygdalien"
},
{"name" : " Péritonsillite"
},
{"name" : " Érythème périungual"
},
{"name" : " Leucomalacie périventriculaire"
},
{"name" : " Fibrillation auriculaire permanente"
},
{"name" : " Anémie pernicieuse"
},
{"name" : " Atrophie musculaire péronière"
},
{"name" : " Paralysie du nerf péronier"
},
{"name" : " Persévération"
},
{"name" : " Fibrillation auriculaire persistante"
},
{"name" : " Toux persistante"
},
{"name" : " Toux sèche persistante"
},
{"name" : " Circulation f?tale persistante"
},
{"name" : " Vomissements persistants"
},
{"name" : " Changement de personnalité"
},
{"name" : " Trouble de la personnalité"
},
{"name" : " Coqueluche"
},
{"name" : " Pétéchie"
},
{"name" : " Épilepsie de petit mal"
},
{"name" : " Statut de petit mal, épileptique"
},
{"name" : " Maladie de Peyronie"
},
{"name" : " pH normal"
},
{"name" : " pH urinaire diminué"
},
{"name" : " pH urinaire augmenté"
},
{"name" : " Phaeochromocytome"
},
{"name" : " Phaéochromocytome malin"
},
{"name" : " Phagocytose"
},
{"name" : " Douleur des membres fantômes"
},
{"name" : " Douleur fantôme"
},
{"name" : " Interaction pharmacocinétique"
},
{"name" : " Trouble pharyngé"
},
{"name" : " Érythème pharyngé"
},
{"name" : " Hémorragie pharyngée"
},
{"name" : " Lésion pharyngée"
},
{"name" : " Mucosite pharyngée"
},
{"name" : " Oedème pharyngé"
},
{"name" : " Pharyngite"
},
{"name" : " Pharyngite streptococcique"
},
{"name" : " Pharyngite ulcéreuse"
},
{"name" : " Irritation pharyngo-orale"
},
{"name" : " Douleur pharyngolaryngée"
},
{"name" : " Pharyngotonsillite"
},
{"name" : " Phénylcétonurie"
},
{"name" : " Chromosome de Philadelphie positif"
},
{"name" : " Phimosis"
},
{"name" : " Phlébite"
},
{"name" : " Phlébite superficielle"
},
{"name" : " Phlébosclérose"
},
{"name" : " Phobie"
},
{"name" : " Évitement phobique"
},
{"name" : " Phocomelia"
},
{"name" : " Trouble phonologique"
},
{"name" : " Phonophobie"
},
{"name" : " Augmentation de la phosphatase alcaline"
},
{"name" : " Augmentation du phosphate"
},
{"name" : " Phosphate Faible"
},
{"name" : " Phosphore faible"
},
{"name" : " Dermatite à photocontact"
},
{"name" : " Peau photo-endommagée"
},
{"name" : " Photodermatose"
},
{"name" : " Photoonycholyse"
},
{"name" : " Photophobie"
},
{"name" : " Photopsie"
},
{"name" : " Photosensibilité"
},
{"name" : " Réaction allergique de photosensibilité"
},
{"name" : " Réaction de photosensibilité"
},
{"name" : " Phototoxicité"
},
{"name" : " Agression physique"
},
{"name" : " Handicap physique"
},
{"name" : " Erection physique"
},
{"name" : " Phytostérolémie"
},
{"name" : " Pica"
},
{"name" : " Syndrome de dispersion des pigments"
},
{"name" : " Trouble pigmentaire"
},
{"name" : " Peau pigmentaire"
},
{"name" : " Roulement de pilules"
},
{"name" : " Piloérection"
},
{"name" : " Kyste pilonidal"
},
{"name" : " Boutons"
},
{"name" : " Pinealoma"
},
{"name" : " Pinta"
},
{"name" : "?dèmes"
},
{"name" : " Adénome hypophysaire"
},
{"name" : " Apoplexie hypophysaire"
},
{"name" : " Nanisme hypophysaire"
},
{"name" : " Hémorragie hypophysaire"
},
{"name" : " Carence en hormone hypophysaire"
},
{"name" : " Infarctus hypophysaire"
},
{"name" : " Microadénome hypophysaire"
},
{"name" : " Tumeur hypophysaire"
},
{"name" : " Tumeur hypophysaire bénigne"
},
{"name" : " Syndrome de Cushing hypophysaire"
},
{"name" : " Pityriasis"
},
{"name" : " Pityriasis lichenoides et varioliformis acuta"
},
{"name" : " Pityriasis rubra pilaris"
},
{"name" : " Trouble placentaire"
},
{"name" : " Peste"
},
{"name" : " Septicémie de peste"
},
{"name" : " Érythème plantaire"
},
{"name" : " Fasciite plantaire"
},
{"name" : " Verrues plantaires"
},
{"name" : " Psoriasis en plaques"
},
{"name" : " Calcium plasmatique diminué"
},
{"name" : " Leucémie à cellules plasmatiques"
},
{"name" : " Myélome à cellules plasmatiques"
},
{"name" : " Augmentation du cholestérol plasmatique"
},
{"name" : " Augmentation de la créatinine plasmatique"
},
{"name" : " Osmolalité plasmatique diminué"
},
{"name" : " Augmentation de l'osmolalité plasmatique"
},
{"name" : " Augmentation des triglycérides plasmatiques"
},
{"name" : " Plasmacytome"
},
{"name" : " Infection à Plasmodium falciparum"
},
{"name" : " Infection à Plasmodium malariae"
},
{"name" : " Infection à Plasmodium ovale"
},
{"name" : " Infection à Plasmodium vivax"
},
{"name" : " Adhésivité plaquettaire"
},
{"name" : " Agrégation plaquettaire anormale"
},
{"name" : " Agrégation plaquettaire augmentée"
},
{"name" : " Inhibition de l'agrégation plaquettaire"
},
{"name" : " Numération plaquettaire anormale"
},
{"name" : " Nombre de plaquettes diminué"
},
{"name" : " Numération plaquettaire normale"
},
{"name" : " Trouble plaquettaire"
},
{"name" : " Dysfonctionnement plaquettaire"
},
{"name" : " Production de plaquettes diminué"
},
{"name" : " Plateletcrit diminué"
},
{"name" : " Trouble pleural"
},
{"name" : " Épanchement pleural"
},
{"name" : " Fibrose pleurale"
},
{"name" : " Infection pleurale"
},
{"name" : " Mésothéliome pleural malin"
},
{"name" : " Frottement pleural"
},
{"name" : " Épaississement pleural"
},
{"name" : " Pleurésie"
},
{"name" : " Douleur pleurétique"
},
{"name" : " Pleuropéricardite"
},
{"name" : " Pleurothotonus"
},
{"name" : " Pneumatose"
},
{"name" : " Pneumatose cystoïde intestinale"
},
{"name" : " Pneumatose intestinale"
},
{"name" : " Infection à pneumocoque"
},
{"name" : " Infection à Pneumocystis carinii"
},
{"name" : " Infection à Pneumocystis jirovecii"
},
{"name" : " Pneumonie à Pneumocystis jirovecii"
},
{"name" : " Pneumomédiastin"
},
{"name" : " Pneumonie"
},
{"name" : " Pneumonie à charbon"
},
{"name" : " Aspiration de pneumonie"
},
{"name" : " Pneumonie bactérienne"
},
{"name" : " Pneumonie chlamydiale"
},
{"name" : " Pneumonie cytomégalovirale"
},
{"name" : " Pneumonie due à Streptococcus, groupe b"
},
{"name" : " Champignon de pneumonie"
},
{"name" : " Pneumonie hypostatique"
},
{"name" : " Pneumonie klebsiella"
},
{"name" : " Pneumonie légionelle"
},
{"name" : " Pneumonie mycoplasmique"
},
{"name" : " Pneumonie nécrosante"
},
{"name" : " Pneumonie récurrente"
},
{"name" : " Pneumonie staphylococcique"
},
{"name" : " Pneumonie streptococcique"
},
{"name" : " Pneumopéricarde"
},
{"name" : " Pneumopéritoine"
},
{"name" : " Pneumothorax"
},
{"name" : " Poikilocytose"
},
{"name" : " Empoisonnement"
},
{"name" : " Empoisonnement par les salicylates"
},
{"name" : " Poliomyélite"
},
{"name" : " Pollakiurie"
},
{"name" : " Polyangéite"
},
{"name" : " Polyartérite noueuse"
},
{"name" : " Polyarthralgie"
},
{"name" : " Polyarthrite"
},
{"name" : " Polyarthropathie"
},
{"name" : " Polychondrite"
},
{"name" : " Rein polykystique"
},
{"name" : " Ovaires polykystiques"
},
{"name" : " Polycytémie"
},
{"name" : " Polycytémie vera"
},
{"name" : " Polydactylie"
},
{"name" : " Polydipsie"
},
{"name" : " Polydipsie psychogène"
},
{"name" : " Polyhydramnios"
},
{"name" : " Polyménorrhée"
},
{"name" : " Éruption de lumière polymorphe"
},
{"name" : " Leucocytose polymorphonucléaire"
},
{"name" : " Polymyalgie"
},
{"name" : " Pseudopolyarthrite rhizomélique"
},
{"name" : " Polymyosite"
},
{"name" : " Polynévrite"
},
{"name" : " Polyneuropathie"
},
{"name" : " Infections à polyomavirus"
},
{"name" : " Néphropathie associée aux polyomavirus"
},
{"name" : " Polype"
},
{"name" : " Polyradiculonévrite"
},
{"name" : " Polysérosite"
},
{"name" : " Polyurie"
},
{"name" : " Mauvaise concentration"
},
{"name" : " Mauvaise circulation périphérique"
},
{"name" : " Sommeil de mauvaise qualité"
},
{"name" : " Mauvais flux urinaire"
},
{"name" : " Mauvais accès veineux"
},
{"name" : " Porphyrie aiguë"
},
{"name" : " Porphyrie aggravée"
},
{"name" : " Porphyria cutanea tarda"
},
{"name" : " Porphyrie hépatique"
},
{"name" : " Porphyrie non aiguë"
},
{"name" : " Trouble du métabolisme de la porphyrine"
},
{"name" : " Hypertension portale"
},
{"name" : " Thrombose de la veine porte"
},
{"name" : " Hypertension portopulmonaire"
},
{"name" : " Post MI"
},
{"name" : " Hémorragie post-avortement"
},
{"name" : " Syndrome post-chirurgie gastrique"
},
{"name" : " Névralgie post-herpétique"
},
{"name" : " Syndrome de ponction lombaire"
},
{"name" : " Complication post-procédurale"
},
{"name" : " Constipation post-procédurale"
},
{"name" : " Diarrhée post-procédurale"
},
{"name" : " Décharge post-procédurale"
},
{"name" : " Hématome post-opératoire"
},
{"name" : " Hémorragie post-procédurale"
},
{"name" : " Infection post-procédurale"
},
{"name" : " Nausées post-procédurales"
},
{"name" : " Oedème post-procédural"
},
{"name" : " Douleur post-procédurale"
},
{"name" : " Gonflement post-procédural"
},
{"name" : " Syndrome post thrombotique"
},
{"name" : " Diabète sucré post-transplantation"
},
{"name" : " Trouble lymphoprolifératif post-transplantation"
},
{"name" : " Diarrhée post-vagotomie"
},
{"name" : " Syndrome du cou post-traumatique"
},
{"name" : " Douleur post-traumatique"
},
{"name" : " Trouble de stress post-traumatique"
},
{"name" : " Vomissements post-tussifs"
},
{"name" : " Opacification de la capsule postérieure"
},
{"name" : " Syndrome d'encéphalopathie réversible postérieure"
},
{"name" : " Cataracte sous-capsulaire postérieure"
},
{"name" : " Synéchies postérieures de l'iris"
},
{"name" : " Uvéite postérieure"
},
{"name" : " Décollement postérieur du vitré"
},
{"name" : " État postictal"
},
{"name" : " Postinfarction"
},
{"name" : " Angine post-infarctus"
},
{"name" : " Bébé post-mature"
},
{"name" : " Postmaturité"
},
{"name" : " Hémorragie post-ménopausique"
},
{"name" : " Repérage postménopausique"
},
{"name" : " Syndrome postménopausique"
},
{"name" : " Post-ménopause"
},
{"name" : " Sécrétions post-nasales"
},
{"name" : " Complications postopératoires SAI"
},
{"name" : " Constipation postopératoire"
},
{"name" : " Fièvre postopératoire"
},
{"name" : " Hémorragie postopératoire"
},
{"name" : " Hypertension postopératoire"
},
{"name" : " Iléus postopératoire"
},
{"name" : " Infection postopératoire"
},
{"name" : " Douleur postopératoire"
},
{"name" : " Frissons postopératoires"
},
{"name" : " Vomissements postopératoires"
},
{"name" : " Complication d'une plaie postopératoire"
},
{"name" : " Infection de plaie postopératoire"
},
{"name" : " Trouble post-partum"
},
{"name" : " Hémorragie post-partum"
},
{"name" : " Hypopituitarisme post-partum"
},
{"name" : " Septicémie post-partum"
},
{"name" : " Syndrome postphlébitique"
},
{"name" : " Syndrome de tachycardie orthostatique posturale"
},
{"name" : " Posture anormale"
},
{"name" : " Potassium anormal NOS"
},
{"name" : " Carence en potassium"
},
{"name" : " Déséquilibre potassique"
},
{"name" : " Potassium augmenté"
},
{"name" : " Potassium bas"
},
{"name" : " Pauvreté de la parole"
},
{"name" : " Pré-éclampsie"
},
{"name" : " Syndrome de pré-excitation"
},
{"name" : " Maladie préexistante"
},
{"name" : " Syndrome de tension pré-menstruelle"
},
{"name" : " Puberté précoce"
},
{"name" : " Precome"
},
{"name" : " Douleur précordiale"
},
{"name" : " Grossesse"
},
{"name" : " Trouble de grossesse"
},
{"name" : " Perte de grossesse"
},
{"name" : " Test de grossesse faux positif"
},
{"name" : " Test de grossesse positif"
},
{"name" : " Préhypertension"
},
{"name" : " Prématuré"
},
{"name" : " Accouchement prématuré"
},
{"name" : " Éjaculation précoce"
},
{"name" : " Travail prématuré"
},
{"name" : " Ménopause prématurée"
},
{"name" : " Rupture prématurée des membranes"
},
{"name" : " Séparation prématurée du placenta"
},
{"name" : " Cancer du sein préménopausique"
},
{"name" : " Préménopause"
},
{"name" : " Trouble dysphorique prémenstruel"
},
{"name" : " Syndrome prémenstruel"
},
{"name" : " Tension prémenstruelle"
},
{"name" : " Presbytie"
},
{"name" : " Pression de la parole"
},
{"name" : " Presyncope"
},
{"name" : " Priapisme"
},
{"name" : " Amylose primaire"
},
{"name" : " Apnée primaire des nouveau-nés prématurés"
},
{"name" : " Dysménorrhée primaire"
},
{"name" : " Dysfonctionnement primaire du greffon"
},
{"name" : " Hyperaldostéronisme primaire"
},
{"name" : " Hypogonadisme primaire"
},
{"name" : " Hypothyroïdie primaire"
},
{"name" : " Insomnie primaire"
},
{"name" : " Tumeur maligne primitive du foie"
},
{"name" : " Énurésie nocturne primaire"
},
{"name" : " Glaucome à angle ouvert primaire"
},
{"name" : " Insuffisance ovarienne primaire"
},
{"name" : " Hypertension pulmonaire primaire"
},
{"name" : " Syphilis primaire"
},
{"name" : " Infection tuberculeuse primaire"
},
{"name" : " Angor de Prinzmetal"
},
{"name" : " PRL augmenté"
},
{"name" : " Proarythmie"
},
{"name" : " Effet proarythmique"
},
{"name" : " Complication procédurale"
},
{"name" : " Hémorragie procédurale"
},
{"name" : " Hypertension procédurale"
},
{"name" : " Hypotension procédurale"
},
{"name" : " Nausées procédurales"
},
{"name" : " Douleur procédurale"
},
{"name" : " Réaction au site de la procédure"
},
{"name" : " Vomissements procéduraux"
},
{"name" : " Proctalgie"
},
{"name" : " Proctite"
},
{"name" : " Herpès proctite"
},
{"name" : " Proctite ulcéreuse"
},
{"name" : " Proctocolite"
},
{"name" : " Proctosigmoïdite"
},
{"name" : " Goût anormal du produit"
},
{"name" : " Toux productive"
},
{"name" : " Progestérone"
},
{"name" : " Niveaux de progestérone"
},
{"name" : " Leucoencéphalopathie multifocale progressive"
},
{"name" : " Insuffisance rénale progressive"
},
{"name" : " Paralysie supranucléaire progressive"
},
{"name" : " Prolactinome"
},
{"name" : " Travail prolongé"
},
{"name" : " Règles prolongées"
},
{"name" : " Cancer de la prostate"
},
{"name" : " Cancer de la prostate métastatique"
},
{"name" : " Carcinome de la prostate"
},
{"name" : " Examen de la prostate anormal"
},
{"name" : " Induration de la prostate"
},
{"name" : " Infection de la prostate"
},
{"name" : " Augmentation de la phosphatase acide prostatique"
},
{"name" : " Adénome prostatique"
},
{"name" : " Trouble prostatique"
},
{"name" : " Dysplasie prostatique"
},
{"name" : " Hypertrophie prostatique"
},
{"name" : " Néoplasie intraépithéliale prostatique"
},
{"name" : " Douleur prostatique"
},
{"name" : " Augmentation de l'antigène prostatique spécifique"
},
{"name" : " Prostatisme"
},
{"name" : " Prostatite"
},
{"name" : " Prostatomégalie"
},
{"name" : " Thrombose prothétique valvulaire cardiaque"
},
{"name" : " Endocardite valvulaire prothétique"
},
{"name" : " Prostration"
},
{"name" : " Carence en protéine C"
},
{"name" : " Allergie aux protéines"
},
{"name" : " Total des protéines diminué"
},
{"name" : " Présence d'urine protéique"
},
{"name" : " Gastro-entéropathie perdante en protéines"
},
{"name" : " Protéinurie"
},
{"name" : " Niveau anormal de prothrombine"
},
{"name" : " Niveau de prothrombine diminué"
},
{"name" : " Augmentation du niveau de prothrombine"
},
{"name" : " Temps de prothrombine anormal"
},
{"name" : " Rapport de temps de prothrombine"
},
{"name" : " Temps de prothrombine raccourci"
},
{"name" : " Langue saillante"
},
{"name" : " Myopathie proximale"
},
{"name" : " Acidose tubulaire rénale proximale"
},
{"name" : " Prurigo"
},
{"name" : " Prurigo nodularis"
},
{"name" : " Prurit"
},
{"name" : " Prurit NEC"
},
{"name" : " Prurit généralisé"
},
{"name" : " Prurit génital"
},
{"name" : " Pruritus vulvae"
},
{"name" : " Syndrome de pseudo-Bartter"
},
{"name" : " Déficit en pseudocholinestérase"
},
{"name" : " Pseudocroup"
},
{"name" : " Pseudodémence"
},
{"name" : " Pseudofolliculitis barbae"
},
{"name" : " Pseudohyperkaliémie"
},
{"name" : " Pseudohypoparathyroïdie"
},
{"name" : " Pseudolymphoma"
},
{"name" : " Colite pseudomembraneuse"
},
{"name" : " Entérocolite pseudomembraneuse"
},
{"name" : " Septicémie pseudomonale"
},
{"name" : " Infection à Pseudomonas"
},
{"name" : " Pseudomononucléose"
},
{"name" : " Pseudoparkinsonisme"
},
{"name" : " Pseudoporphyrie"
},
{"name" : " Pseudotumeur"
},
{"name" : " Psittacose"
},
{"name" : " Psoriasis"
},
{"name" : " Poussée de psoriasis"
},
{"name" : " Psoriasis du cuir chevelu"
},
{"name" : " Psoriasis vulgaris"
},
{"name" : " Arthropathie psoriasique"
},
{"name" : " Plaque psoriasique"
},
{"name" : " Décompensation psychiatrique"
},
{"name" : " Évaluation psychiatrique anormale"
},
{"name" : " Symptôme psychiatrique"
},
{"name" : " Perturbation psychique"
},
{"name" : " Retard psychomoteur"
},
{"name" : " Compétences psychomotrices altérées"
},
{"name" : " Trouble psychosexuel"
},
{"name" : " Psychose dépressive"
},
{"name" : " Maladie psychosomatique"
},
{"name" : " Comportement psychotique"
},
{"name" : " Dépression psychotique"
},
{"name" : " Trouble psychotique"
},
{"name" : " Épisode psychotique"
},
{"name" : " État psychotique"
},
{"name" : " Ptérygion"
},
{"name" : " PTH élevé"
},
{"name" : " Ptosis"
},
{"name" : " Puberté"
},
{"name" : " Pyrexie puerpérale"
},
{"name" : " Hémorragie alvéolaire pulmonaire"
},
{"name" : " Alvéolite pulmonaire"
},
{"name" : " Hypertension artérielle pulmonaire"
},
{"name" : " Augmentation de la pression artérielle pulmonaire en coin"
},
{"name" : " Congestion pulmonaire"
},
{"name" : " Embolie pulmonaire"
},
{"name" : " Éosinophilie pulmonaire"
},
{"name" : " Fibrose pulmonaire"
},
{"name" : " Test de fonction pulmonaire anormal"
},
{"name" : " Test de la fonction pulmonaire diminué"
},
{"name" : " Granulome pulmonaire"
},
{"name" : " Hémorragie pulmonaire"
},
{"name" : " Hypertension pulmonaire"
},
{"name" : " Hypertension pulmonaire secondaire"
},
{"name" : " Hypoplasie pulmonaire"
},
{"name" : " Infarctus pulmonaire"
},
{"name" : " Lymphome pulmonaire"
},
{"name" : " Masse pulmonaire"
},
{"name" : " Microembolies pulmonaires"
},
{"name" : "?dème pulmonaire"
},
{"name" : " Microembolie pulmonaire à l'huile"
},
{"name" : " Ossification pulmonaire"
},
{"name" : " Sténose pulmonaire"
},
{"name" : " Thromboembolie pulmonaire"
},
{"name" : " Thrombose pulmonaire"
},
{"name" : " Toxicité pulmonaire"
},
{"name" : " Tuberculose pulmonaire"
},
{"name" : " Incompétence valvulaire pulmonaire"
},
{"name" : " Sténose valvulaire pulmonaire"
},
{"name" : " Vascularite pulmonaire"
},
{"name" : " Maladie veino-occlusive pulmonaire"
},
{"name" : " Pulpite dentaire"
},
{"name" : " Pouls anormal"
},
{"name" : " Pouls absent"
},
{"name" : " Pouls irrégulier"
},
{"name" : " Pression d'impulsion diminuée"
},
{"name" : " Baisse de la fréquence du pouls marquée"
},
{"name" : " Activité électrique sans impulsion"
},
{"name" : " Érosion épithéliale ponctuée"
},
{"name" : " Kératite ponctuée"
},
{"name" : " Hémorragie au site de ponction"
},
{"name" : " Douleur au point de ponction"
},
{"name" : " Réaction au site de ponction"
},
{"name" : " Punding"
},
{"name" : " Déformation pupillaire"
},
{"name" : " Trouble pupillaire"
},
{"name" : " Réflexe pupillaire altéré"
},
{"name" : " Pupilles dilatées "
},
{"name" : " Pupilles inégales"
},
{"name" : " Purge"
},
{"name" : " Trouble du métabolisme des purines"
},
{"name" : " Syndrome du gant violet"
},
{"name" : " Syndrome des orteils violets"
},
{"name" : " Purpura"
},
{"name" : " Purpura fulminans"
},
{"name" : " Purpura non thrombocytopénique"
},
{"name" : " Purpura senile"
},
{"name" : " Éruption cutanée purpurique"
},
{"name" : " Psoriasis pustuleux"
},
{"name" : " Pustule"
},
{"name" : " Pyélite"
},
{"name" : " Pyélocystite"
},
{"name" : " Pyélonéphrite"
},
{"name" : " Pyélonéphrite aiguë"
},
{"name" : " Pyélonéphrite chronique"
},
{"name" : " Sténose pylorique"
},
{"name" : " Pylorospasme"
},
{"name" : " Pyoderma"
},
{"name" : " Pyoderma gangrenosum"
},
{"name" : " Granulome pyogène"
},
{"name" : " Pyometra"
},
{"name" : " Syndrome des voies pyramidales"
},
{"name" : " Carence en pyridoxine"
},
{"name" : " Pyuria"
},
{"name" : " Fièvre Q"
},
{"name" : " Axe QRS anormal"
},
{"name" : " Complexe QRS"
},
{"name" : " Tension QRS diminuée"
},
{"name" : " Quadriparesie"
},
{"name" : " Quadriplégie"
},
{"name" : " Paludisme à Quartan"
},
{"name" : " Typhus à tiques du Queensland"
},
{"name" : " Pensées de course"
},
{"name" : " Paralysie du nerf radial"
},
{"name" : " Blessure par radiation"
},
{"name" : " Myélopathie radiologique"
},
{"name" : " Oesophagite radiologique"
},
{"name" : " Pneumopathie radiologique"
},
{"name" : " Réaction de rappel de rayonnement (dermatologique)"
},
{"name" : " Syndrome de rappel radiologique"
},
{"name" : " Radiation lésion cutanée"
},
{"name" : " Douleur radiculaire"
},
{"name" : " Radiculite"
},
{"name" : " Radiculopathie"
},
{"name" : " Fracture du rayon"
},
{"name" : " Rage"
},
{"name" : " Augmentation des tests de la fonction hépatique"
},
{"name" : " Augmentation des taux de lipides sériques"
},
{"name" : " Augmentation de l'acide urique sérique"
},
{"name" : " Rales"
},
{"name" : " Éruption"
},
{"name" : " Éruption cutanée des deux jambes"
},
{"name" : " Éruption cutanée bulleuse"
},
{"name" : " Éruption érythémateuse"
},
{"name" : " Éruption folliculaire"
},
{"name" : " Éruption cutanée généralisée"
},
{"name" : " Éruption maculaire"
},
{"name" : " Éruption maculo-papulaire"
},
{"name" : " Éruption morbilliforme"
},
{"name" : " Éruption cutanée"
},
{"name" : " Éruption papuleuse"
},
{"name" : " Éruption pemphigoïde"
},
{"name" : " Éruption psoriaform"
},
{"name" : " Éruption cutanée pustuleuse"
},
{"name" : " Éruption cutanée récurrente"
},
{"name" : " Éruption cutanée écailleuse"
},
{"name" : " Éruption cutanée scarlatiniforme"
},
{"name" : " Éruption vésiculaire"
},
{"name" : " Fièvre par morsure de rat"
},
{"name" : " Maladie de Raynaud"
},
{"name" : " Phénomène de raynaud"
},
{"name" : " Trouble de type Raynaud"
},
{"name" : " Aggravation de la réaction"
},
{"name" : " Réaction fébrile"
},
{"name" : " Réaction gastro-intestinale"
},
{"name" : " Réaction aux excipients médicamenteux"
},
{"name" : " Dépression réactive"
},
{"name" : " Effet de rebondissement"
},
{"name" : " Hypertension de rebond"
},
{"name" : " Phénomène de rappel"
},
{"name" : " Tachycardie alternative"
},
{"name" : " Abcès rectal"
},
{"name" : " Cancer rectal"
},
{"name" : " Crampes rectales"
},
{"name" : " Décharge rectale"
},
{"name" : " Trouble rectal"
},
{"name" : " Fistule rectale"
},
{"name" : " Hémorragie rectale"
},
{"name" : " Masse rectale"
},
{"name" : " Polype rectal"
},
{"name" : " Prolapsus rectal"
},
{"name" : " Spasme rectal"
},
{"name" : " Ténesme rectal"
},
{"name" : " Ulcère rectal"
},
{"name" : " Rectocèle"
},
{"name" : " Récurrence du blocage neuromusculaire"
},
{"name" : " Trouble dépressif récurrent"
},
{"name" : " Érosion récurrente de la cornée"
},
{"name" : " Infection récurrente"
},
{"name" : " Embolie pulmonaire récurrente"
},
{"name" : " Infection récurrente des voies urinaires"
},
{"name" : " Fibrillation ventriculaire récurrente"
},
{"name" : " Anomalie des globules rouges"
},
{"name" : " Nombre de globules rouges diminuée"
},
{"name" : " Augmentation du nombre de globules rouges"
},
{"name" : " Troubles des globules rouges"
},
{"name" : " Augmentation du taux de sédimentation des globules rouges"
},
{"name" : " Sérum des globules rouges positif"
},
{"name" : " Taches rouges"
},
{"name" : " Aplasie des globules rouges"
},
{"name" : " Augmentation de la largeur de distribution des globules rouges"
},
{"name" : " Syndrome de l'homme rouge"
},
{"name" : " Col rouge"
},
{"name" : " Rougeur"
},
{"name" : " Gomme de rougeur"
},
{"name" : " Rougeur du visage"
},
{"name" : " Intérêt réduit pour les activités habituelles"
},
{"name" : " Bradycardie réflexe"
},
{"name" : " Dystrophie sympathique réflexe"
},
{"name" : " Tachycardie réflexe"
},
{"name" : " Réflexes anormaux"
},
{"name" : " Oesophagite par reflux"
},
{"name" : " Gastrite par reflux"
},
{"name" : " Trouble de réfraction"
},
{"name" : " Anémie réfractaire avec excès de blastes"
},
{"name" : " Anémie réfractaire"
},
{"name" : " Anémie réfractaire avec excès de blastes en transformation"
},
{"name" : " Cytopénie réfractaire avec dysplasie unilineage"
},
{"name" : " Hypertension réfractaire"
},
{"name" : " Régurgitation"
},
{"name" : " Régurgitation des aliments"
},
{"name" : " Rejet aigu rénal"
},
{"name" : " Fièvre récurrente"
},
{"name" : " Polychondrite en rechute"
},
{"name" : " Sclérose en plaques récurrente-rémittente"
},
{"name" : " Abcès rénal"
},
{"name" : " Agénésie rénale"
},
{"name" : " Aplasie rénale"
},
{"name" : " Sténose de l'artère rénale"
},
{"name" : " Thrombose de l'artère rénale"
},
{"name" : " Cancer du rein"
},
{"name" : " Carcinome rénal"
},
{"name" : " Carcinome à cellules rénales"
},
{"name" : " Dégagements rénaux faibles"
},
{"name" : " Colique rénale"
},
{"name" : " Nécrose corticale rénale"
},
{"name" : " Kyste rénal"
},
{"name" : " Dysgénésie rénale"
},
{"name" : " Insuffisance rénale"
},
{"name" : " Insuffisance rénale aiguë"
},
{"name" : " Insuffisance rénale aggravée"
},
{"name" : " Insuffisance rénale chronique"
},
{"name" : " Test de fonction rénale anormal"
},
{"name" : " Perte de greffe rénale"
},
{"name" : " Hémorragie rénale"
},
{"name" : " Hypertension rénale"
},
{"name" : " Insuffisance rénale"
},
{"name" : " Infarctus rénal"
},
{"name" : " Insuffisance rénale aggravée"
},
{"name" : " Masse rénale"
},
{"name" : " Néoplasme rénal"
},
{"name" : " Ostéodystrophie rénale"
},
{"name" : " Douleur rénale"
},
{"name" : " Nécrose papillaire rénale"
},
{"name" : " Rachitisme rénal"
},
{"name" : " Acidose tubulaire rénale"
},
{"name" : " Trouble tubulaire rénal"
},
{"name" : " Nécrose tubulaire rénale"
},
{"name" : " Vascularite rénale"
},
{"name" : " Thrombose veineuse rénale"
},
{"name" : " Trouble des vaisseaux rénaux"
},
{"name" : " Rénine diminuée"
},
{"name" : " Hypertension rénovasculaire"
},
{"name" : " Blessure de reperfusion"
},
{"name" : " Discours répétitif"
},
{"name" : " Lésion de fatigue répétitive"
},
{"name" : " Hémorragies du système reproducteur"
},
{"name" : " Toxicité pour la reproduction"
},
{"name" : " Trouble de l'appareil reproducteur"
},
{"name" : " Volume d'urine résiduel"
},
{"name" : " Respiration anormale"
},
{"name" : " Irrégularité respiratoire"
},
{"name" : " Acidose respiratoire"
},
{"name" : " Alcalose respiratoire"
},
{"name" : " Arrêt respiratoire"
},
{"name" : " Dépression respiratoire"
},
{"name" : " Augmentation de la profondeur respiratoire"
},
{"name" : " Trouble respiratoire"
},
{"name" : " Trouble respiratoire néonatal"
},
{"name" : " Affections respiratoires NCA"
},
{"name" : " Détresse respiratoire"
},
{"name" : " Syndrome de détresse respiratoire"
},
{"name" : " Arrêt respiratoire"
},
{"name" : " Insuffisance respiratoire aggravée"
},
{"name" : " Trouble d'inhalation des fumées respiratoires"
},
{"name" : " Insuffisance respiratoire"
},
{"name" : " Moniliase respiratoire"
},
{"name" : " Paralysie respiratoire"
},
{"name" : " Fréquence respiratoire diminuée"
},
{"name" : " Soupirs respiratoires"
},
{"name" : " Sons respiratoires diminués"
},
{"name" : " Infection par le virus respiratoire syncytial"
},
{"name" : " Congestion des voies respiratoires"
},
{"name" : " Hémorragie des voies respiratoires"
},
{"name" : " Infection des voies respiratoires"
},
{"name" : " Infection des voies respiratoires virale"
},
{"name" : " Oedème des voies respiratoires"
},
{"name" : " Syndrome des jambes sans repos"
},
{"name" : " Agitation aggravée"
},
{"name" : " Cardiomyopathie restrictive"
},
{"name" : " Placenta conservé"
},
{"name" : " Placenta ou membranes conservés"
},
{"name" : " Céchage"
},
{"name" : " Réflexe de vomissement diminué"
},
{"name" : " Rétention gastrique"
},
{"name" : " Réticulocytopénie"
},
{"name" : " Réticulocytose"
},
{"name" : " Système réticuloendothélial stimulé"
},
{"name" : " Réticuloendothéliose"
},
{"name" : " Anévrisme rétinien"
},
{"name" : " Occlusion de l'artère rétinienne"
},
{"name" : " Atrophie rétinienne"
},
{"name" : " Lésions rétiniennes"
},
{"name" : " Dégénérescence rétinienne"
},
{"name" : " Dépigmentation rétinienne"
},
{"name" : " Dépôts rétiniens"
},
{"name" : " Décollement de la rétine"
},
{"name" : " Trouble rétinien"
},
{"name" : " Exsudats rétiniens"
},
{"name" : " Hémorragie rétinienne"
},
{"name" : " Lésion rétinienne"
},
{"name" : " Ischémie rétinienne"
},
{"name" : " Oedème rétinien"
},
{"name" : " Déchirure épithéliale du pigment rétinien"
},
{"name" : " Pigmentation rétinienne"
},
{"name" : " Cicatrice rétinienne"
},
{"name" : " Déchirure rétinienne"
},
{"name" : " Toxicité rétinienne"
},
{"name" : " Trouble vasculaire rétinien"
},
{"name" : " Occlusion vasculaire rétinienne"
},
{"name" : " Thrombose vasculaire rétinienne"
},
{"name" : " Occlusion d'une branche veineuse rétinienne"
},
{"name" : " Occlusion veineuse rétinienne"
},
{"name" : " Thrombose veineuse rétinienne"
},
{"name" : " Rétinite"
},
{"name" : " Rétinoblastome"
},
{"name" : " Rétinogramme anormal"
},
{"name" : " Syndrome d'acide rétinoïque"
},
{"name" : " Rétinopathie de prématurité"
},
{"name" : " Rétinopathie proliférative"
},
{"name" : " Amnésie rétrograde"
},
{"name" : " Éjaculation rétrograde"
},
{"name" : " Fibrose rétropéritonéale"
},
{"name" : " Hématome rétropéritonéal"
},
{"name" : " Hémorragie rétropéritonéale"
},
{"name" : " Gêne rétrosternale"
},
{"name" : " Douleur rétrosternale"
},
{"name" : " Obstruction réversible des voies respiratoires"
},
{"name" : " Syndrome de vasoconstriction cérébrale réversible"
},
{"name" : " Déficit neurologique ischémique réversible"
},
{"name" : " Syndrome de Reye"
},
{"name" : " Rhabdomyolyse"
},
{"name" : " Rhabdomyosarcome"
},
{"name" : " Incompatibilité rhésus"
},
{"name" : " Trouble rhumatismal"
},
{"name" : " Rhumatisme articulaire aigu"
},
{"name" : " Cardiopathie rhumatismale"
},
{"name" : " Rhumatisme"
},
{"name" : " Polyarthrite rhumatoïde"
},
{"name" : " Arthrite rhumatoïde aggravée"
},
{"name" : " Rhinalgie"
},
{"name" : " Rhinite"
},
{"name" : " Rhinite allergique"
},
{"name" : " Rhinite atrophique"
},
{"name" : " Rhinite vivace"
},
{"name" : " Rhinite saisonnière"
},
{"name" : " Rhinite ulcéreuse"
},
{"name" : " Rhinorrhée"
},
{"name" : " Rhinosinusite"
},
{"name" : " Rhonchi"
},
{"name" : " Rythme idioventriculaire"
},
{"name" : " Fracture des côtes"
},
{"name" : " Douleur aux côtes"
},
{"name" : " Rachitisme"
},
{"name" : " Rickets (résistant à la vitamine D)"
},
{"name" : " Hypophosphatémie familiale de rachitisme"
},
{"name" : " Rickettsialpox"
},
{"name" : " Douleur dans le quadrant supérieur droit"
},
{"name" : " Insuffisance ventriculaire droite"
},
{"name" : " Rigueur"
},
{"name" : " Risus sardonicus"
},
{"name" : " Accident de la circulation"
},
{"name" : " Fièvre pourprée"
},
{"name" : " Rosacée"
},
{"name" : " Syndrome de la coiffe des rotateurs"
},
{"name" : " Sensibilité au caoutchouc"
},
{"name" : " Rubéole"
},
{"name" : " Sacroiliite"
},
{"name" : " Tic de Salaam"
},
{"name" : " Salive altérée"
},
{"name" : " Obstruction du canal salivaire"
},
{"name" : " Conditions des glandes salivaires"
},
{"name" : " Trouble des glandes salivaires"
},
{"name" : " L'élargissement des glandes salivaires"
},
{"name" : " Douleurs des glandes salivaires"
},
{"name" : " Gonflement des glandes salivaires"
},
{"name" : " Hypersécrétion salivaire"
},
{"name" : " Salivation"
},
{"name" : " Salmonella sepsis"
},
{"name" : " Salmonellose"
},
{"name" : " Salpingite"
},
{"name" : " Salpingo-ovarite"
},
{"name" : " Sarcoïdose"
},
{"name" : " Sarcome"
},
{"name" : " Sarcome utérus"
},
{"name" : " Gale"
},
{"name" : " Gale"
},
{"name" : " Ébouillanter"
},
{"name" : " Cicatrice"
},
{"name" : " Douleur cicatricielle"
},
{"name" : " Scarlatine"
},
{"name" : " Trouble schizo-affectif"
},
{"name" : " Schizophrénie"
},
{"name" : " Schizophrénie et autres troubles psychotiques"
},
{"name" : " Schizophrénie, type paranoïaque"
},
{"name" : " Réaction schizophrénique"
},
{"name" : " Trouble schizophréniforme"
},
{"name" : " Schwannome"
},
{"name" : " Sciatique"
},
{"name" : " Scotome scintillant"
},
{"name" : " Décoloration sclérale"
},
{"name" : " Trouble scléral"
},
{"name" : " Hémorragie sclérale"
},
{"name" : " Hyperémie sclérale"
},
{"name" : " Icterus scléral"
},
{"name" : " Pigmentation sclérale"
},
{"name" : " Amincissement scléral"
},
{"name" : " Sclérite"
},
{"name" : " Sclérodermie"
},
{"name" : " Scléromalacie"
},
{"name" : " Péritonite encapsulante sclérosante"
},
{"name" : " Scoliose"
},
{"name" : " Scotoma"
},
{"name" : " Scotoma annulaire"
},
{"name" : " Scotoma de la zone d'angle mort"
},
{"name" : " Rayure"
},
{"name" : " En hurlant"
},
{"name" : " Trouble du scrotum"
},
{"name" : " Érythème scrotal"
},
{"name" : "?dème scrotal"
},
{"name" : " Douleur scrotale"
},
{"name" : " Gonflement du scrotum"
},
{"name" : " Ulcère du scrotum"
},
{"name" : " Gommage typhus"
},
{"name" : " Scorbut"
},
{"name" : " Trouble affectif saisonnier"
},
{"name" : " Allergie saisonnière"
},
{"name" : " Trouble de la glande sébacée"
},
{"name" : " Hyperplasie sébacée"
},
{"name" : " Dermatite séborrhéique"
},
{"name" : " Kératose séborrhéique"
},
{"name" : " Insuffisance surrénalienne secondaire"
},
{"name" : " Insuffisance corticosurrénale secondaire"
},
{"name" : " Aldostéronisme secondaire"
},
{"name" : " Anémie secondaire"
},
{"name" : " Glaucome secondaire"
},
{"name" : " Goutte secondaire"
},
{"name" : " Hypertension secondaire"
},
{"name" : " Hypogonadisme secondaire"
},
{"name" : " Infection secondaire"
},
{"name" : " Parkinsonisme secondaire"
},
{"name" : " Sclérose en plaques progressive secondaire"
},
{"name" : " Syphilis secondaire"
},
{"name" : " Thrombocytopénie secondaire"
},
{"name" : " Sédation"
},
{"name" : " Crise cérébrale"
},
{"name" : " Comportement d'automutilation"
},
{"name" : " Auto-mutilation"
},
{"name" : " Idéation d'automutilation"
},
{"name" : " Sperme anormal"
},
{"name" : " Analyse de sperme anormale"
},
{"name" : " Volume de sperme diminué"
},
{"name" : " Hyperostose vertébrale ankylosante sénile"
},
{"name" : " Démence sénile"
},
{"name" : " Prurit sénile"
},
{"name" : " Psychose sénile"
},
{"name" : " Sénilité"
},
{"name" : " Sensation de circulation sanguine"
},
{"name" : " Sensation de corps étranger"
},
{"name" : " Sensation de chaleur"
},
{"name" : " Sensation de lourdeur"
},
{"name" : " Sensation de pression"
},
{"name" : " Sensation de chaleur"
},
{"name" : " Sentiment d'oppression"
},
{"name" : " Sensibilisation"
},
{"name" : " Sensibilité des dents"
},
{"name" : " Trouble sensorimoteur"
},
{"name" : " Ataxie sensorielle"
},
{"name" : " Perturbation sensorielle"
},
{"name" : " Perte sensorielle"
},
{"name" : " Séparation"
},
{"name" : " État septique"
},
{"name" : " Septicémie néonatale"
},
{"name" : " Septicémie secondaire"
},
{"name" : " Streptobacille arthrite septique"
},
{"name" : " Articulation septique"
},
{"name" : " Choc septique"
},
{"name" : " Septicémie due à un organisme gram négatif, sans précision"
},
{"name" : " Septicémie"
},
{"name" : " Serum"
},
{"name" : " Sérite"
},
{"name" : " Syndrome sérotoninergique"
},
{"name" : " Décollement séreux de la rétine"
},
{"name" : " Albumine sérique diminuée"
},
{"name" : " Amylase sérique augmentée"
},
{"name" : " Augmentation du bicarbonate sérique"
},
{"name" : " Augmentation de la bilirubine sérique"
},
{"name" : " Calcium sérique diminué"
},
{"name" : " Calcium sérique augmenté"
},
{"name" : " Cholestérol sérique normal"
},
{"name" : " Créatinine sérique anormale"
},
{"name" : " Créatinine sérique diminuée"
},
{"name" : " Augmentation de la créatinine sérique"
},
{"name" : " Ferritine sérique a diminué"
},
{"name" : " Augmentation de la ferritine sérique"
},
{"name" : " Augmentation de la gastrine sérique"
},
{"name" : " Fer sérique diminué"
},
{"name" : " Fer sérique augmenté"
},
{"name" : " Augmentation de l'osmolalité sérique"
},
{"name" : " Phosphate sérique augmenté"
},
{"name" : " Potassium sérique anormal"
},
{"name" : " Potassium sérique diminué"
},
{"name" : " Potassium sérique augmenté"
},
{"name" : " Prolactine sérique diminuée"
},
{"name" : " Augmentation de la prolactine sérique"
},
{"name" : " Maladie sérique"
},
{"name" : " Réaction de type maladie sérique"
},
{"name" : " Anémie sodique"
},
{"name" : " Testostérone sérique diminuée"
},
{"name" : " Augmentation de la testostérone sérique"
},
{"name" : " Protéines sériques totales diminuées"
},
{"name" : " Augmentation de la transaminase sérique"
},
{"name" : " Augmentation des triglycérides sériques"
},
{"name" : " Augmentation de l'urée sérique"
},
{"name" : " Syndrome respiratoire aigu sévère"
},
{"name" : " Abus sexuel"
},
{"name" : " Agression sexuelle"
},
{"name" : " Victime d'agression sexuelle"
},
{"name" : " Troubles du désir sexuel"
},
{"name" : " Dysfonction sexuelle"
},
{"name" : " Sexuellement actif"
},
{"name" : " Maladie sexuellement transmissible"
},
{"name" : " Tremblement"
},
{"name" : " Sentiments tremblants"
},
{"name" : " Respiration superficielle"
},
{"name" : " Déplacer vers la gauche"
},
{"name" : " Infection à Shigella"
},
{"name" : " Frissonnant"
},
{"name" : " Choc"
},
{"name" : " Choc hémorragique"
},
{"name" : " Hypoglycémie de choc"
},
{"name" : " Insuline de choc"
},
{"name" : " Courte période"
},
{"name" : " Syndrome de l'intestin court"
},
{"name" : " Perte de mémoire à court terme"
},
{"name" : " Col raccourci"
},
{"name" : " Mal d'épaule"
},
{"name" : " Infection shunt"
},
{"name" : " Thrombose shunt"
},
{"name" : " Arrêt rénal"
},
{"name" : " Syndrome de Shy-Drager"
},
{"name" : " Sialoadénite"
},
{"name" : " Maladie du sinus"
},
{"name" : " Anémie falciforme"
},
{"name" : " Anémie falciforme avec crise"
},
{"name" : " Maladie"
},
{"name" : " Anémie sidéroblastique"
},
{"name" : " Silicose"
},
{"name" : " Saisies partielles simples"
},
{"name" : " Rein simple fonctionnel"
},
{"name" : " Artère ombilicale unique"
},
{"name" : " Bloc sino-auriculaire"
},
{"name" : " Dysfonctionnement ganglionnaire sino-auriculaire"
},
{"name" : " Sinobronchite"
},
{"name" : " Arrestation des sinus"
},
{"name" : " Arythmie sinusale"
},
{"name" : " Bradycardie sinusale"
},
{"name" : " Congestion des sinus"
},
{"name" : " Trouble des sinus"
},
{"name" : " Mal de tête sinus"
},
{"name" : " Fonctionnement des sinus"
},
{"name" : " Douleur des sinus"
},
{"name" : " Rythme sinusal"
},
{"name" : " Tachycardie sinusale"
},
{"name" : " Sinusite"
},
{"name" : " Sinusite bactérienne"
},
{"name" : " Syndrome de Sjogren"
},
{"name" : " Blessure squelettique"
},
{"name" : " Paralysie des muscles squelettiques"
},
{"name" : " Atrophie cutanée"
},
{"name" : " Infection bactérienne cutanée"
},
{"name" : " Saignement cutané"
},
{"name" : " Décomposition de la peau"
},
{"name" : " Sensation de brûlure cutanée"
},
{"name" : " Callus cutané"
},
{"name" : " Cancer de la peau"
},
{"name" : " Candidose cutanée"
},
{"name" : " Carcinome cutané"
},
{"name" : " Peau moite et froide"
},
{"name" : " Dépigmentation cutanée"
},
{"name" : " Décoloration de la peau"
},
{"name" : " Gêne cutanée"
},
{"name" : " Troubles de la peau"
},
{"name" : " Érosion cutanée"
},
{"name" : " Exfoliation cutanée"
},
{"name" : " Fibrose cutanée"
},
{"name" : " Fissures cutanées"
},
{"name" : " Fragilité cutanée"
},
{"name" : " Hémorragie cutanée"
},
{"name" : " Hyperpigmentation cutanée"
},
{"name" : " Hypertrophie cutanée"
},
{"name" : " Induration cutanée"
},
{"name" : " Infection de la peau"
},
{"name" : " Irritation de la peau"
},
{"name" : " Lacération cutanée"
},
{"name" : " Lésion de la peau"
},
{"name" : " Macération cutanée"
},
{"name" : " Masse cutanée"
},
{"name" : " Nécrose cutanée"
},
{"name" : " Nodule cutané"
},
{"name" : " Odeur cutanée anormale"
},
{"name" : " Oedème cutané"
},
{"name" : " Papillome cutané"
},
{"name" : " Réaction cutanée"
},
{"name" : " Rugosité de la peau"
},
{"name" : " Peau écailleuse"
},
{"name" : " Cicatrices cutanées"
},
{"name" : " Sensibilisation cutanée"
},
{"name" : " Stries cutanées"
},
{"name" : " Gonflement de la peau"
},
{"name" : " Déchirure de la peau"
},
{"name" : " Sensibilité cutanée"
},
{"name" : " Test cutané positif"
},
{"name" : " Réaction au test cutané"
},
{"name" : " Épaississement de la peau"
},
{"name" : " Amincissement de la peau"
},
{"name" : " Tiraillement cutané"
},
{"name" : " Toxicité cutanée"
},
{"name" : " Ulcère cutané"
},
{"name" : " Peau chaude"
},
{"name" : " Blessure cutanée"
},
{"name" : " Rides de la peau"
},
{"name" : " Xérose cutanée"
},
{"name" : " Battements ignorés"
},
{"name" : " Hypoplasie du crâne"
},
{"name" : " Malformation du crâne"
},
{"name" : " Syndrome d'apnée du sommeil"
},
{"name" : " Attaques de sommeil"
},
{"name" : " Troubles du sommeil"
},
{"name" : " Trouble du sommeil"
},
{"name" : " Paralysie du sommeil"
},
{"name" : " Perturbation du rythme de la phase de sommeil"
},
{"name" : " Parler en dormant"
},
{"name" : " Terreur du sommeil"
},
{"name" : " Épiphyse du capital fémoral glissé"
},
{"name" : " Site d'injection Slough"
},
{"name" : " Discours lent"
},
{"name" : " Lenteur"
},
{"name" : " Troubles de l'élocution"
},
{"name" : " Angio-?dème de l'intestin grêle"
},
{"name" : " Carcinome à petites cellules"
},
{"name" : " Cancer du poumon à petites cellules"
},
{"name" : " Cancer du poumon à petites cellules récurrent"
},
{"name" : " Petite obstruction intestinale"
},
{"name" : " Petite perforation intestinale"
},
{"name" : " Ulcère de l'intestin grêle"
},
{"name" : " Picotement"
},
{"name" : " Frottis cervical anormal"
},
{"name" : " Frottis cervical normal"
},
{"name" : " Inhalation de fumée"
},
{"name" : " Éternuements"
},
{"name" : " Éternuements excessifs"
},
{"name" : " Ronflement"
},
{"name" : " Comportement d'évitement social"
},
{"name" : " Peur sociale"
},
{"name" : " Phobie sociale"
},
{"name" : " Retrait social"
},
{"name" : " Sodium diminué"
},
{"name" : " Sodium élevé"
},
{"name" : " Tabourets mous"
},
{"name" : " Trouble des tissus mous"
},
{"name" : " Infection des tissus mous"
},
{"name" : " Inflammation des tissus mous"
},
{"name" : " Lésion des tissus mous"
},
{"name" : " Nécrose des tissus mous"
},
{"name" : " Dermatite solaire"
},
{"name" : " Lentigo solaire"
},
{"name" : " Tumeur solide"
},
{"name" : " Hallucination somatique"
},
{"name" : " Trouble somatoforme"
},
{"name" : " Trouble somatoforme cardiovasculaire"
},
{"name" : " Somnambulisme"
},
{"name" : " Somnolence"
},
{"name" : " Somnolence néonatale"
},
{"name" : " Douleur occulaire"
},
{"name" : " Bouche endolorie"
},
{"name" : " Nez douloureux"
},
{"name" : " Aigreurs d'estomac"
},
{"name" : " Spasme biliaire"
},
{"name" : " Spasme d'hébergement"
},
{"name" : " Spasme du sphincter d'Oddi"
},
{"name" : " Dysphonie spasmodique"
},
{"name" : " Paralysie spastique"
},
{"name" : " Paraparésie spastique"
},
{"name" : " Anomalies de la parole et du langage"
},
{"name" : " Trouble de la parole"
},
{"name" : " Atteinte à la parole SAI"
},
{"name" : " Perte de la parole"
},
{"name" : " Concentration de sperme"
},
{"name" : " Concentration de sperme diminuée"
},
{"name" : " Nombre de spermatozoïdes diminué"
},
{"name" : " Spermatocèle"
},
{"name" : " Spermatogenèse anormale"
},
{"name" : " Arrêt de la spermatogenèse"
},
{"name" : " Spermatozoïdes anormaux"
},
{"name" : " Sphincter de la dysfonction Oddi"
},
{"name" : " Morsure d'araignée"
},
{"name" : " Spina bifida"
},
{"name" : " Spina bifida occulta"
},
{"name" : " Anesthésie rachidienne"
},
{"name" : " Fracture de compression vertébrale"
},
{"name" : " Compression de la moelle épinière"
},
{"name" : " Trouble de la moelle épinière"
},
{"name" : " Hémorragie médullaire"
},
{"name" : " Infarctus de la moelle épinière"
},
{"name" : " Lésion de la moelle épinière"
},
{"name" : " Paralysie médullaire"
},
{"name" : " Trouble vertébral"
},
{"name" : " Hématome épidural rachidien"
},
{"name" : " Fracture vertébrale"
},
{"name" : " Hématome vertébral"
},
{"name" : " Arthrose vertébrale"
},
{"name" : " Malformation de la colonne vertébrale"
},
{"name" : " Trouble de la rate"
},
{"name" : " Rate palpable"
},
{"name" : " Syndrome de flexion splénique"
},
{"name" : " Infarctus splénique"
},
{"name" : " Péliose splénique"
},
{"name" : " Rupture splénique"
},
{"name" : " Séquestration splénique"
},
{"name" : " Splénomégalie"
},
{"name" : " Hémorragies éclatantes"
},
{"name" : " Fendre les ongles"
},
{"name" : " Spondylarthrite"
},
{"name" : " Spondylarthropathie"
},
{"name" : " Spondylose"
},
{"name" : " Ecchymoses spontanées"
},
{"name" : " Hématome spontané"
},
{"name" : " Érection du pénis spontanée"
},
{"name" : " Sporotrichose"
},
{"name" : " Blessure sportive"
},
{"name" : " Taches sous les yeux"
},
{"name" : " Repérer les règles"
},
{"name" : " Repérer le vagin"
},
{"name" : " Entorse"
},
{"name" : " Sprue"
},
{"name" : " Crachats décolorés"
},
{"name" : " Crachats augmentés"
},
{"name" : " Crachats purulents"
},
{"name" : " Carcinome épidermoïde"
},
{"name" : " Carcinome épidermoïde de la tête et du cou"
},
{"name" : " Carcinome épidermoïde du poumon"
},
{"name" : " Carcinome épidermoïde de la peau"
},
{"name" : " Infarctus du myocarde avec sus-décalage du segment ST"
},
{"name" : " Angine de poitrine stable"
},
{"name" : " Démarche stupéfiante"
},
{"name" : " Bactériémie staphylococcique"
},
{"name" : " Infection staphylococcique"
},
{"name" : " Syndrome de peau échaudée staphylococcique"
},
{"name" : " Infection cutanée staphylococcique"
},
{"name" : " Bactériémie à Staphylococcus aureus"
},
{"name" : " Maladie de Stargardt"
},
{"name" : " Regarder"
},
{"name" : " Dermatite de stase"
},
{"name" : " Syndrome de stase"
},
{"name" : " Statut asthmatique"
},
{"name" : " État de mal épileptique"
},
{"name" : " Statut epilepticus grand mal"
},
{"name" : " Stéatorrhée"
},
{"name" : " Occlusion de stent"
},
{"name" : " Stéréotypie"
},
{"name" : " Acné stéroïde"
},
{"name" : " Myopathie stéroïdienne"
},
{"name" : " Psychose stéroïdienne"
},
{"name" : " Syndrome de sevrage des stéroïdes"
},
{"name" : " Syndrome néphrotique résistant aux stéroïdes"
},
{"name" : " Syndrome de Stevens-Johnson"
},
{"name" : " Peau collante"
},
{"name" : " Retour raide"
},
{"name" : " Syndrome des personnes rigides"
},
{"name" : " Raideur"
},
{"name" : " Maladie de Still"
},
{"name" : " Mortinaissance"
},
{"name" : " Piquer"
},
{"name" : " Piqûre"
},
{"name" : " Piqûre de nez"
},
{"name" : " Piqure de la peau"
},
{"name" : " Maux d'estomac"
},
{"name" : " Crampes d'estomac"
},
{"name" : " Procédure de dilatation d'estomac"
},
{"name" : " Ulcère stomal"
},
{"name" : " Stomatite"
},
{"name" : " Stomatite nécrosante"
},
{"name" : " Strabisme"
},
{"name" : " Étranglement"
},
{"name" : " Étrangeté"
},
{"name" : " Fièvre streptobacillaire"
},
{"name" : " Endocardite streptococcique"
},
{"name" : " Infection streptococcique"
},
{"name" : " Septicémie streptococcique"
},
{"name" : " Pharyngite à Streptococcus pyogenes"
},
{"name" : " Stress"
},
{"name" : " Stress au travail"
},
{"name" : " Fracture de stress"
},
{"name" : " Symptômes de stress"
},
{"name" : " Ulcère de stress"
},
{"name" : " Incontinence urinaire d'effort"
},
{"name" : " Stridor"
},
{"name" : " Stridor inspiratoire"
},
{"name" : " Augmentation du volume de course"
},
{"name" : " Strongyloidiasis"
},
{"name" : " Stupeur"
},
{"name" : " Bégaiement"
},
{"name" : " Bursite sous-acromiale"
},
{"name" : " Endocardite bactérienne subaiguë"
},
{"name" : " Endocardite subaiguë"
},
{"name" : " Hémorragie sous-arachnoïdienne"
},
{"name" : " Hypothyroïdie subclinique"
},
{"name" : " Infection subclinique"
},
{"name" : " Kyste sous-conjonctival"
},
{"name" : " Hémorragie sous-conjonctivale"
},
{"name" : " Abcès sous-cutané"
},
{"name" : " Saignement sous-cutané"
},
{"name" : " Hématome sous-cutané"
},
{"name" : " Nodule sous-cutané"
},
{"name" : " Épanchement sous-dural"
},
{"name" : " Hématome sous-dural"
},
{"name" : " Astrocytome sous-épendymaire à cellules géantes"
},
{"name" : " Opacités sous-épithéliales"
},
{"name" : " Oedème sous-glottique"
},
{"name" : " Subiléus "
},
{"name" : " Troubles visuels subjectifs"
},
{"name" : " Subluxation hanche"
},
{"name" : " Masse submandibulaire"
},
{"name" : " Abus de substance"
},
{"name" : " Trouble psychotique induit par une substance"
},
{"name" : " Déficit en sucrase-isomaltase"
},
{"name" : " Mort cardiaque subite"
},
{"name" : " Surdité soudaine"
},
{"name" : " Mort subite"
},
{"name" : " Mort subite, cause inconnue"
},
{"name" : " Perte auditive soudaine"
},
{"name" : " Syndrome de mort subite du nourrisson"
},
{"name" : " Début de sommeil soudain"
},
{"name" : " Mort subite inexpliquée dans l'épilepsie"
},
{"name" : " Perte visuelle soudaine"
},
{"name" : " Comportement suicidaire"
},
{"name" : " Idées suicidaires"
},
{"name" : " Tendance suicidaire"
},
{"name" : " Suicide"
},
{"name" : " Tentative de suicide"
},
{"name" : " Sulphémoglobinémie"
},
{"name" : " Coup de soleil"
},
{"name" : " Yeux enfoncés"
},
{"name" : " Carcinome basocellulaire superficiel"
},
{"name" : " Phlébothrombose superficielle"
},
{"name" : " Kératopathie ponctuée superficielle"
},
{"name" : " Thrombophlébite superficielle de la jambe"
},
{"name" : " Surinfection"
},
{"name" : " Thrombose du sinus sagittal supérieur"
},
{"name" : " Syndrome de la veine cave supérieure"
},
{"name" : " Mamelon surnuméraire"
},
{"name" : " Superovulation"
},
{"name" : " Hypotension couchée"
},
{"name" : " Suppression de la lactation"
},
{"name" : " Douleur sus-pubienne"
},
{"name" : " Tendinite supraspinatus"
},
{"name" : " Extrasystoles supraventriculaires"
},
{"name" : " Tachyarythmie supraventriculaire"
},
{"name" : " Tachycardie supraventriculaire"
},
{"name" : " Chirurgie"
},
{"name" : " Intervention chirurgicale"
},
{"name" : " Ménopause chirurgicale"
},
{"name" : " Réaction au site opératoire"
},
{"name" : " Suspicion"
},
{"name" : " Tachycardie ventriculaire soutenue"
},
{"name" : " Complication liée à la suture"
},
{"name" : " Trouble des glandes sudoripares"
},
{"name" : " Tumeur des glandes sudoripares"
},
{"name" : " Transpiration"
},
{"name" : " Transpiration diminuée"
},
{"name" : " Transpiration accrue"
},
{"name" : " Gonflement"
},
{"name" : " Visage gonflé"
},
{"name" : " Gonflement des paupières"
},
{"name" : " Gonflement des genoux"
},
{"name" : " Gonflement des jambes"
},
{"name" : " Gonflement d'un membre"
},
{"name" : " Bras gonflé"
},
{"name" : " Langue enflée"
},
{"name" : " Sycosis barbae"
},
{"name" : " Ophtalmie sympathique"
},
{"name" : " Effet sympathomimétique"
},
{"name" : " Hyperlactatémie symptomatique"
},
{"name" : " Syncope"
},
{"name" : " Syncope vasovagal"
},
{"name" : " Syndactylie"
},
{"name" : " Syndrome de type Fanconi"
},
{"name" : " Syndrome hurlant"
},
{"name" : " Syndrome sicca"
},
{"name" : " Kyste synovial"
},
{"name" : " Synovite"
},
{"name" : " Syphilis"
},
{"name" : " Syringomyélie"
},
{"name" : " Syrinx"
},
{"name" : " Réaction allergique systémique"
},
{"name" : " Candida systémique"
},
{"name" : " Syndrome de réponse inflammatoire systémique"
},
{"name" : " Lupus érythémateux disséminé"
},
{"name" : " Éruption cutanée du lupus érythémateux disséminé"
},
{"name" : " Mastocytose systémique"
},
{"name" : " Mycose systémique"
},
{"name" : " Sclérose systémique"
},
{"name" : " Dysfonction systolique"
},
{"name" : " Murmure d'éjection systolique"
},
{"name" : " Hypertension systolique"
},
{"name" : " Murmure systolique"
},
{"name" : " Lymphome à cellules T"
},
{"name" : " Leucémie aiguë de type T"
},
{"name" : " Tachyarythmie"
},
{"name" : " Tachycardie"
},
{"name" : " Tachycardie f?tale"
},
{"name" : " Tachycardie nerveuse"
},
{"name" : " Tachycardie paroxystique"
},
{"name" : " Tachyphrenie"
},
{"name" : " Tachyphylaxie"
},
{"name" : " Tachypnée"
},
{"name" : " Talipes"
},
{"name" : " Loquacité"
},
{"name" : " Test de marche en tandem anormal"
},
{"name" : " Dyskinésie tardive"
},
{"name" : " Goût altéré"
},
{"name" : " Goût amer"
},
{"name" : " Troubles du goût"
},
{"name" : " Goût métallique"
},
{"name" : " Goût particulier"
},
{"name" : " Goût salé"
},
{"name" : " Goût aigre"
},
{"name" : " Goût sucré"
},
{"name" : " Larme"
},
{"name" : " Yeux déchirants"
},
{"name" : " Serrage des dents"
},
{"name" : " Dentition"
},
{"name" : " Douleur de dentition"
},
{"name" : " Télangiectasie"
},
{"name" : " Télangiectasie du visage"
},
{"name" : " Effluvium télogène"
},
{"name" : " Crise de colère"
},
{"name" : " Intolérance à la température"
},
{"name" : " Trouble de la régulation de la température"
},
{"name" : " Artérite temporale"
},
{"name" : " Désorientation temporelle"
},
{"name" : " Épilepsie du lobe temporal"
},
{"name" : " Syndrome de l'articulation temporo-mandibulaire"
},
{"name" : " Tendresse"
},
{"name" : " Contracture tendineuse"
},
{"name" : " Trouble tendineux"
},
{"name" : " Blessure au tendon"
},
{"name" : " Douleur tendineuse"
},
{"name" : " Réflexe tendineux diminué"
},
{"name" : " Rupture tendineuse"
},
{"name" : " Tendinite"
},
{"name" : " Ténosynovite"
},
{"name" : " Tension"
},
{"name" : " Céphalée de tension"
},
{"name" : " Tératogénicité"
},
{"name" : " Insomnie terminale"
},
{"name" : " Atrophie testiculaire"
},
{"name" : " Trouble testiculaire"
},
{"name" : " Insuffisance testiculaire primaire"
},
{"name" : " Tumeur testiculaire"
},
{"name" : " Douleur testiculaire"
},
{"name" : " Gonflement testiculaire"
},
{"name" : " Cancer des testicules"
},
{"name" : " Carence en testostérone"
},
{"name" : " Faible taux de testostérone"
},
{"name" : " Tétanos"
},
{"name" : " Similaire au tétanos"
},
{"name" : " Tetany"
},
{"name" : " Carence en tétrahydrobioptérine"
},
{"name" : " Thalassémie"
},
{"name" : " Thalassémie bêta"
},
{"name" : " Réponse thérapeutique diminuée"
},
{"name" : " Augmentation de la réponse thérapeutique"
},
{"name" : " Réponse thérapeutique inattendue"
},
{"name" : " Thérapie naïve"
},
{"name" : " Brûlure thermique"
},
{"name" : " Penser anormal"
},
{"name" : " Soif"
},
{"name" : " Fracture vertébrale thoracique"
},
{"name" : " Blocage de la pensée"
},
{"name" : " Pouls filant"
},
{"name" : " Irritation de la gorge"
},
{"name" : " Mal de gorge"
},
{"name" : " Oppression dans la gorge"
},
{"name" : " Maux de tête lancinants"
},
{"name" : " Thromboangiitis obliterans"
},
{"name" : " Thrombocytopénie"
},
{"name" : " Thrombocytopénie aggravée"
},
{"name" : " Thrombocytopénie toxique"
},
{"name" : " Purpura thrombocytopénique"
},
{"name" : " Thrombocytose"
},
{"name" : " Événement thromboembolique"
},
{"name" : " AVC thromboembolique"
},
{"name" : " Thromboembolie"
},
{"name" : " Thrombophilie"
},
{"name" : " Thrombophlébite"
},
{"name" : " Site d'injection de thrombophlébite"
},
{"name" : " Thrombophlébite jambe profonde"
},
{"name" : " Thrombophlébite de la jambe"
},
{"name" : " Thrombophlébite superficielle"
},
{"name" : " Thromboplastine diminuée"
},
{"name" : " Thrombose"
},
{"name" : " Thrombose dans l'appareil"
},
{"name" : " Jambe de thrombose"
},
{"name" : " Vaisseau mésentérique de thrombose"
},
{"name" : " Microangiopathie thrombotique"
},
{"name" : " Purpura thrombotique thrombotique"
},
{"name" : " Thymome"
},
{"name" : " Augmentation de la thyroglobuline"
},
{"name" : " Adénome thyroïdien"
},
{"name" : " Cancer de la thyroïde"
},
{"name" : " Carcinome thyroïdien"
},
{"name" : " Trouble thyroïdien"
},
{"name" : " Fonction thyroïdienne anormale"
},
{"name" : " Test de la fonction thyroïdienne anormal"
},
{"name" : " Tumeur thyroïdienne"
},
{"name" : " Nodule thyroïdien"
},
{"name" : " Thyroïdite"
},
{"name" : " Thyroïdite subaiguë"
},
{"name" : " Crise thyréotoxique"
},
{"name" : " Thyrotoxicose"
},
{"name" : " Thyrotropine élevée"
},
{"name" : " Thyrotropine faible"
},
{"name" : " Thyroxine diminuée"
},
{"name" : " Sans thyroxine diminuée"
},
{"name" : " TIBC"
},
{"name" : " Torsion tibiale"
},
{"name" : " Tic"
},
{"name" : " Prépuce serré"
},
{"name" : " Étanchéité dans la mâchoire"
},
{"name" : " Tinea barbae"
},
{"name" : " Teigne"
},
{"name" : " Tinea cruris"
},
{"name" : " Infection de teigne"
},
{"name" : " Pied d'athlète"
},
{"name" : " Tinea versicolour"
},
{"name" : " Picotements des pieds / mains"
},
{"name" : " Picotements aux extrémités"
},
{"name" : " Sensation de picotements"
},
{"name" : " Picotements cutanés"
},
{"name" : " Acouphène"
},
{"name" : " Acouphènes aggravés"
},
{"name" : " Fatigué et lourd"
},
{"name" : " Abus de tabac"
},
{"name" : " Empoisonnement au tabac"
},
{"name" : " Symptômes de sevrage tabagique"
},
{"name" : " Marche des orteils"
},
{"name" : " Développement de la tolérance"
},
{"name" : " Cloquage de la langue"
},
{"name" : " Langue enduite"
},
{"name" : " Décoloration de la langue"
},
{"name" : " Trouble de la langue"
},
{"name" : " Langue sèche"
},
{"name" : " Langue géographique"
},
{"name" : " Langue poilue"
},
{"name" : " Irritation de la langue"
},
{"name" : " Tumeur de la langue"
},
{"name" : " Stade malin du néoplasme de la langue, sans précision"
},
{"name" : " Oedème de la langue"
},
{"name" : " Paralysie de la langue"
},
{"name" : " Pigmentation de la langue"
},
{"name" : " Spasme de la langue"
},
{"name" : " Ulcération de la langue"
},
{"name" : " Mouvements cloniques toniques"
},
{"name" : " Convulsion tonique"
},
{"name" : " Crises tonico-cloniques"
},
{"name" : " Trouble amygdalien"
},
{"name" : " Hypertrophie amygdalienne"
},
{"name" : " Amygdalite"
},
{"name" : " Abcès dentaire"
},
{"name" : " Caries dentaires aggravées SAI"
},
{"name" : " Décoloration des dents"
},
{"name" : " Trouble dentaire"
},
{"name" : " Érosion dentaire"
},
{"name" : " Fracture dentaire"
},
{"name" : " Hypoplasie dentaire"
},
{"name" : " Infection dentaire"
},
{"name" : " Blessure dentaire"
},
{"name" : " Perte de dents"
},
{"name" : " Malformation dentaire"
},
{"name" : " Mal aux dents"
},
{"name" : " Torsade de pointes"
},
{"name" : " Torsion de l'ovaire"
},
{"name" : " Torticolis"
},
{"name" : " Déficit total en hypoxanthine-guanine phosphoribosyl transférase"
},
{"name" : " Bloc vertébral total"
},
{"name" : " Trouble de la tourette"
},
{"name" : " Toxémie"
},
{"name" : " État confusionnel toxique"
},
{"name" : " Dilatation toxique de l'intestin"
},
{"name" : " Encéphalopathie toxique"
},
{"name" : " Nécrolyse épidermique toxique"
},
{"name" : " Goitre multinodulaire toxique"
},
{"name" : " Neuropathie toxique"
},
{"name" : " Goitre nodulaire toxique"
},
{"name" : " Pustuloderma toxique"
},
{"name" : " Réaction toxique (NOS)"
},
{"name" : " Syndrome de choc toxique"
},
{"name" : " Éruption cutanée toxique"
},
{"name" : " Symptôme toxique"
},
{"name" : " Toxicité pour divers agents"
},
{"name" : " Toxoplasmose"
},
{"name" : " Trouble trachéal"
},
{"name" : " Fistule trachéale"
},
{"name" : " Trachéite"
},
{"name" : " Fistule trachéo-?sophagienne"
},
{"name" : " Trachéobronchite"
},
{"name" : " Infection par trachéotomie"
},
{"name" : " Trachome"
},
{"name" : " Accident de la circulation"
},
{"name" : " Tranquillisation excessive"
},
{"name" : " Transaminases diminuées"
},
{"name" : " Augmentation des transaminases"
},
{"name" : " Transaminite"
},
{"name" : " Anémie transfusionnelle"
},
{"name" : " Réaction transfusionnelle"
},
{"name" : " Ischémie cérébrale transitoire"
},
{"name" : " Événements cérébrovasculaires transitoires"
},
{"name" : " Amnésie mondiale transitoire"
},
{"name" : " Insomnie transitoire"
},
{"name" : " Attaque ischémique transitoire"
},
{"name" : " Carcinome à cellules transitionnelles"
},
{"name" : " Infarctus du myocarde transmural"
},
{"name" : " Échec de la transplantation"
},
{"name" : " Rejet de greffe"
},
{"name" : " Transposition des grands vaisseaux"
},
{"name" : " Thrombose des sinus transverses"
},
{"name" : " Traumatisme"
},
{"name" : " Arthropathie traumatique"
},
{"name" : " Lésion cérébrale traumatique"
},
{"name" : " Fracture traumatique"
},
{"name" : " Hématome traumatique"
},
{"name" : " Hémorragie traumatique"
},
{"name" : " Lésion hépatique traumatique"
},
{"name" : " Lésion pulmonaire traumatique"
},
{"name" : " Diarrhée du voyageur"
},
{"name" : " Tremblant"
},
{"name" : " Tremblement"
},
{"name" : " Tremblements grossiers"
},
{"name" : " Tremblement bien"
},
{"name" : " Membre tremblement"
},
{"name" : " Muscle tremblant"
},
{"name" : " Tremblement des mains"
},
{"name" : " Tremulousness"
},
{"name" : " Bouche de tranchée"
},
{"name" : " Infections à tréponème"
},
{"name" : " Tri-iodothyronine normale"
},
{"name" : " Trichiniasis"
},
{"name" : " Vaginite trichomonale"
},
{"name" : " Trichomonase"
},
{"name" : " Trichorrhexis"
},
{"name" : " Trichotillomanie"
},
{"name" : " Trichurie"
},
{"name" : " Incompétence de la valve tricuspide"
},
{"name" : " Névralgie du trijumeau"
},
{"name" : " Doigt déclencheur"
},
{"name" : " Triglycérides normaux"
},
{"name" : " Trismus"
},
{"name" : " Trisomie 18"
},
{"name" : " Trisomie 21"
},
{"name" : " Troubles trophiques"
},
{"name" : " Sprue tropicale"
},
{"name" : " Troponin I augmentée"
},
{"name" : " Troponine augmentée"
},
{"name" : " Grossesse tubaire"
},
{"name" : " Test de tuberculose positif"
},
{"name" : " Lèpre tuberculeuse"
},
{"name" : " Tuberculose"
},
{"name" : " Tuberculose des os et des articulations, sans précision"
},
{"name" : " Tuberculose du système génito-urinaire"
},
{"name" : " Sclérose tubéreuse"
},
{"name" : " Abcès tubo-ovarien"
},
{"name" : " Néphrite tubulo-interstitielle"
},
{"name" : " Tularémie"
},
{"name" : " Mobilisation des cellules tumorales"
},
{"name" : " Compression tumorale"
},
{"name" : " Poussée tumorale"
},
{"name" : " Hémorragie tumorale"
},
{"name" : " Invasion de tumeurs"
},
{"name" : " Syndrome de lyse tumorale"
},
{"name" : " Nécrose tumorale"
},
{"name" : " Douleur tumorale"
},
{"name" : " Vision en tunnel"
},
{"name" : " Syndrome de Turner"
},
{"name" : " Trouble de la membrane tympanique"
},
{"name" : " Hyperémie membranaire tympanique"
},
{"name" : " Perforation de la membrane tympanique"
},
{"name" : " Diabète sucré de type 1"
},
{"name" : " Diabète sucré de type 2"
},
{"name" : " Réaction lépreuse de type 2"
},
{"name" : " Hyperlipidémie de type I"
},
{"name" : " Hypersensibilité de type I"
},
{"name" : " Hyperlipidémie de type II"
},
{"name" : " Hyperlipidémie de type III"
},
{"name" : " Réaction induite par un complexe immun de type III"
},
{"name" : " Hyperlipidémie de type IIa"
},
{"name" : " Hyperlipidémie de type IIb"
},
{"name" : " Hyperlipoprotéinémie de type IIb"
},
{"name" : " Hyperlipidémie de type IV"
},
{"name" : " Réaction d'hypersensibilité de type IV"
},
{"name" : " Hyperlipidémie de type V"
},
{"name" : " Fièvre typhoïde"
},
{"name" : " Typhus"
},
{"name" : " Tyrosinémie"
},
{"name" : " Ulcère"
},
{"name" : " Pied ulcère"
},
{"name" : " Hémorragie ulcéreuse"
},
{"name" : " Proctosigmoïdite ulcéreuse (chronique)"
},
{"name" : " Entérocolite ulcéreuse"
},
{"name" : " Kératite ulcéreuse"
},
{"name" : " Stomatite ulcéreuse"
},
{"name" : " Fracture de l'ulna"
},
{"name" : " Échographie mammaire anormale"
},
{"name" : " Échographie ovarienne anormale"
},
{"name" : " Hernie ombilicale"
},
{"name" : " Incapable de marcher"
},
{"name" : " Incirconcis"
},
{"name" : " Hypertension non contrôlée"
},
{"name" : " Insuffisance pondérale"
},
{"name" : " Effet thérapeutique inattendu"
},
{"name" : " Agénésie rénale unilatérale"
},
{"name" : " Perte de vision unilatérale"
},
{"name" : " Grossesse non désirée"
},
{"name" : " Ne répond pas aux stimulis"
},
{"name" : " Ne répond pas aux stimulis verbaux"
},
{"name" : " Troubles"
},
{"name" : " Trouble du système circulatoire, sans précision"
},
{"name" : " Affection non précisée provenant de la période périnatale"
},
{"name" : " Anomalie congénitale non précisée du cerveau, de la moelle épinière et du système nerveux"
},
{"name" : " Trouble non spécifié du système nerveux autonome"
},
{"name" : " Trouble non spécifié de l'intestin"
},
{"name" : " Trouble non spécifié de la peau et du tissu sous-cutané"
},
{"name" : " Urétrite non gonococcique non spécifiée (NGU)"
},
{"name" : " Perte visuelle non spécifiée"
},
{"name" : " Déséquilibre"
},
{"name" : " Démarche instable"
},
{"name" : " Conscience indésirable pendant l'anesthésie"
},
{"name" : " Indisposé"
},
{"name" : " Gêne abdominale haute"
},
{"name" : " Obstruction des voies aériennes supérieures"
},
{"name" : " Hémorragie gastro-intestinale supérieure"
},
{"name" : " Symptômes gastro-intestinaux supérieurs"
},
{"name" : " Fracture du membre supérieur"
},
{"name" : "?dème des membres supérieurs"
},
{"name" : " Lésion des neurones moteurs supérieurs"
},
{"name" : " Congestion des voies respiratoires supérieures"
},
{"name" : " Infection des voies respiratoires supérieures"
},
{"name" : " Inflammation des voies respiratoires supérieures"
},
{"name" : " Signes et symptômes des voies respiratoires supérieures"
},
{"name" : " Syndrome de toux des voies respiratoires supérieures"
},
{"name" : " Maux d'estomac"
},
{"name" : " Syndrome urémique"
},
{"name" : " Cristallurie urate"
},
{"name" : " Néphropathie urate"
},
{"name" : " Urée augmentée"
},
{"name" : " Urémie"
},
{"name" : " Spasme urétéral"
},
{"name" : " Cancer urétéral"
},
{"name" : " Obstruction urétérale"
},
{"name" : " Urétérite"
},
{"name" : " Gêne au site d'urétérostomie"
},
{"name" : " Écoulement urétral"
},
{"name" : " Trouble urétral"
},
{"name" : " Hémorragie urétrale"
},
{"name" : " Obstruction urétrale"
},
{"name" : " Douleur urétrale"
},
{"name" : " Sténose urétrale"
},
{"name" : " Syndrome urétral"
},
{"name" : " Urétrite"
},
{"name" : " Urétrite gonococcique"
},
{"name" : " Urétrite non infectieuse"
},
{"name" : " Urétrite non spécifique"
},
{"name" : " Incontinence par impériosité"
},
{"name" : " Acide urique anormal"
},
{"name" : " Acide urique élevé"
},
{"name" : " Augmentation de l'acide urique"
},
{"name" : " Augmentation du niveau d'acide urique"
},
{"name" : " Uricacidurie"
},
{"name" : " Anomalies urinaires"
},
{"name" : " Polype de la vessie urinaire"
},
{"name" : " Fréquence urinaire aggravée"
},
{"name" : " Hésitation urinaire"
},
{"name" : " Incontinence urinaire"
},
{"name" : " Augmentation des protéines urinaires"
},
{"name" : " Rétention urinaire"
},
{"name" : " Sédiment urinaire anormal"
},
{"name" : " Présence de sédiments urinaires"
},
{"name" : " Trouble des voies urinaires"
},
{"name" : " Infection urinaire"
},
{"name" : " Infection des voies urinaires fongique"
},
{"name" : " Obstruction des voies urinaires"
},
{"name" : " Douleurs des voies urinaires"
},
{"name" : " Signes et symptômes des voies urinaires"
},
{"name" : " Miction altérée"
},
{"name" : " Anomalie urinaire"
},
{"name" : " Analyse d'urine anormale"
},
{"name" : " Calcium urinaire augmenté"
},
{"name" : " Couleur urinaire anormale"
},
{"name" : " Dépistage des drogues dans l'urine positif"
},
{"name" : " Électrolytes urinaires anormaux"
},
{"name" : " Débit urinaire diminuée"
},
{"name" : " Présence de corps cétonique dans l'urine"
},
{"name" : " Odeur d'urine anormale"
},
{"name" : " Mauvaise odeur d'urine "
},
{"name" : " Sortie d'urine"
},
{"name" : " Augmentation du débit urinaire"
},
{"name" : " Phosphate d'urine augmenté"
},
{"name" : " Augmentation du phosphore urinaire"
},
{"name" : " Augmentation du sodium urinaire"
},
{"name" : " Trouble urogénital"
},
{"name" : " Hémorragie urogénitale"
},
{"name" : " Trichomonase urogénitale"
},
{"name" : " Urolithiase"
},
{"name" : " Urosepsie"
},
{"name" : " Urticaire"
},
{"name" : " Urticaire chronique"
},
{"name" : " Urticaire localisée"
},
{"name" : " Urticaire physique"
},
{"name" : " Urticaire récurrente"
},
{"name" : " Urticaria vesiculosa"
},
{"name" : " Atonie utérine"
},
{"name" : " Cancer de l'utérus"
},
{"name" : " Érosion cervicale utérine"
},
{"name" : " Lésion cervicale utérine"
},
{"name" : " Métaplasie épidermoïde cervicale utérine"
},
{"name" : " Contractions utérines"
},
{"name" : " Contractions utérines pendant la grossesse"
},
{"name" : " Crampes utérines"
},
{"name" : " Kyste utérin"
},
{"name" : " Trouble utérin"
},
{"name" : " Hypertrophie utérine"
},
{"name" : " Fibromes utérins aggravés"
},
{"name" : " Fibromes utérins hypertrophiés"
},
{"name" : " Hémorragie utérine"
},
{"name" : " Hypertonus utérin"
},
{"name" : " Hypotonus utérin"
},
{"name" : " Inflammation utérine"
},
{"name" : " Léiomyome utérin"
},
{"name" : " Masse utérine"
},
{"name" : " Néoplasme utérin"
},
{"name" : " Douleur utérine"
},
{"name" : " Perforation utérine"
},
{"name" : " Polype utérin"
},
{"name" : " Prolapsus utérin"
},
{"name" : " Relaxation utérine"
},
{"name" : " Rupture utérine"
},
{"name" : " Spasme utérin"
},
{"name" : " Prolapsus utérovaginal"
},
{"name" : " Uvéite"
},
{"name" : " Vaccinie"
},
{"name" : " Infection par le virus de la vaccine"
},
{"name" : " Sensation de brûlure vaginale"
},
{"name" : " Expulsion d'un dispositif contraceptif vaginal"
},
{"name" : " Kyste vaginal"
},
{"name" : " Écoulement vaginal"
},
{"name" : " Gêne vaginale"
},
{"name" : " Trouble vaginal"
},
{"name" : " Sécheresse vaginale"
},
{"name" : " Dysplasie vaginale"
},
{"name" : " Érosion vaginale"
},
{"name" : " Érythème vaginal"
},
{"name" : " Hémorragie vaginale"
},
{"name" : " Infection vaginale"
},
{"name" : " Inflammation vaginale"
},
{"name" : " Irritation vaginale"
},
{"name" : " Démangeaisons vaginales"
},
{"name" : " Moniliase vaginale"
},
{"name" : " Cloques muqueuses vaginales"
},
{"name" : " Mycose vaginale"
},
{"name" : " Néoplasme vaginal"
},
{"name" : " Odeur vaginale"
},
{"name" : " Douleurs vaginales"
},
{"name" : " Prolapsus vaginal"
},
{"name" : " Gonflement vaginal"
},
{"name" : " Ulcération vaginale"
},
{"name" : " Congestion des parois vaginales"
},
{"name" : " Levure vaginale"
},
{"name" : " Vaginisme"
},
{"name" : " Vaginite atrophique"
},
{"name" : " Vaginite bactérienne"
},
{"name" : " Vaginitis gardnerella"
},
{"name" : " Vaginite ulcéreuse"
},
{"name" : " Vagotonie"
},
{"name" : " Syndrome des canaux biliaires en voie de disparition"
},
{"name" : " Variantes de migraine"
},
{"name" : " Varicelle"
},
{"name" : " Varicelle zona"
},
{"name" : " Varices ?sophagiennes"
},
{"name" : " Varicocèle"
},
{"name" : " Varice"
},
{"name" : " Varices vulvaires"
},
{"name" : " Variegate porphyria"
},
{"name" : " Anomalie vasculaire"
},
{"name" : " Calcification vasculaire"
},
{"name" : " La démence vasculaire"
},
{"name" : " Occlusion de greffe vasculaire"
},
{"name" : " Céphalées vasculaires"
},
{"name" : " Troubles hypertensifs vasculaires"
},
{"name" : " Troubles hypotensifs vasculaires"
},
{"name" : " Insuffisance vasculaire"
},
{"name" : " Occlusion vasculaire"
},
{"name" : " Douleurs vasculaires"
},
{"name" : " Pseudoanévrisme vasculaire"
},
{"name" : " Purpura vasculaire"
},
{"name" : " Résistance vasculaire"
},
{"name" : " Résistance vasculaire pulmonaire augmentée"
},
{"name" : " Résistance vasculaire systémique"
},
{"name" : " Résistance vasculaire systémique diminuée"
},
{"name" : " Rupture vasculaire"
},
{"name" : " Sténose vasculaire"
},
{"name" : " Éruption cutanée vasculitique"
},
{"name" : " Vascularite"
},
{"name" : " Vascularite cérébrale"
},
{"name" : " Vascularite gastro-intestinale"
},
{"name" : " Vascularite nécrosante"
},
{"name" : " Crise vaso-occlusive"
},
{"name" : " Vasoconstriction"
},
{"name" : " Vasoconstriction périphérique"
},
{"name" : " Vaso-dilatation"
},
{"name" : " Vasodilatation"
},
{"name" : " Procédure de vasodilatation"
},
{"name" : " Effondrement vasomoteur"
},
{"name" : " Rhinite vasomotrice"
},
{"name" : " Vasospasme"
},
{"name" : " Vasospasme cérébral"
},
{"name" : " Symptômes vasovagaux"
},
{"name" : " Végétarien"
},
{"name" : " Dystonie végétative"
},
{"name" : " Décoloration des veines"
},
{"name" : " Trouble veineux"
},
{"name" : " Veine distendue"
},
{"name" : " Douleur veineuse"
},
{"name" : " Thrombose de la veine cave"
},
{"name" : " Ecchymose au site de ponction veineuse"
},
{"name" : " Hémorragie au site de ponction veineuse"
},
{"name" : " Morsure venimeuse"
},
{"name" : " Maladie veino-occlusive"
},
{"name" : " Maladie hépato-occlusive"
},
{"name" : " Vénospasme"
},
{"name" : " Insuffisance veineuse"
},
{"name" : " Occlusion veineuse"
},
{"name" : " Augmentation de la pression veineuse"
},
{"name" : " Augmentation de la jugulaire de la pression veineuse"
},
{"name" : " Thromboembolie veineuse"
},
{"name" : " Thrombose veineuse"
},
{"name" : " Thrombose veineuse membre profond"
},
{"name" : " Membre de thrombose veineuse"
},
{"name" : " Pneumonie associée au ventilateur"
},
{"name" : " Anévrisme ventriculaire"
},
{"name" : " Arythmie ventriculaire"
},
{"name" : " Bigéminisme ventriculaire"
},
{"name" : " Dysfonction ventriculaire"
},
{"name" : " Extrasystoles ventriculaires"
},
{"name" : " Insuffisance ventriculaire"
},
{"name" : " Fibrillation ventriculaire"
},
{"name" : " Flutter ventriculaire"
},
{"name" : " Hypertrophie ventriculaire"
},
{"name" : " Hypokinésie ventriculaire"
},
{"name" : " Défaut septal ventriculaire"
},
{"name" : " Tachycardie ventriculaire"
},
{"name" : " Ventriculite"
},
{"name" : " Vermiculation"
},
{"name" : " Conjonctivite vernale"
},
{"name" : " Insuffisance vertébrobasilaire"
},
{"name" : " Transmission d'infection verticale"
},
{"name" : " Vertige"
},
{"name" : " Vertigo origine SNC"
},
{"name" : " Vertigo positionnel"
},
{"name" : " Reflux vésico-urétérique"
},
{"name" : " Éruption cutanée vésiculobulleuse"
},
{"name" : " Perforation du vaisseau"
},
{"name" : " Ecchymose au site de ponction du vaisseau"
},
{"name" : " Hématome au site de ponction du vaisseau"
},
{"name" : " Hémorragie au site de ponction du vaisseau"
},
{"name" : " Inflammation du site de ponction du vaisseau"
},
{"name" : " Ataxie vestibulaire"
},
{"name" : " Trouble vestibulaire"
},
{"name" : " Neuronite vestibulaire"
},
{"name" : " Toxicité vestibulaire"
},
{"name" : " Victime d'abus sexuels"
},
{"name" : " VIIe paralysie nerveuse"
},
{"name" : " Violence"
},
{"name" : " Violent"
},
{"name" : " Comportement violent"
},
{"name" : " Vipome"
},
{"name" : " Virémie"
},
{"name" : " Diarrhée virale"
},
{"name" : " Infection virale"
},
{"name" : " Infections virales NCA"
},
{"name" : " Pharyngite virale"
},
{"name" : " Infection virale cutanée"
},
{"name" : " Syndrome viral"
},
{"name" : " Infection virale des voies respiratoires supérieures"
},
{"name" : " Virilisme"
},
{"name" : " Larve migrans viscérale"
},
{"name" : " Leishmaniose viscérale"
},
{"name" : " Douleur viscérale"
},
{"name" : " Vision floue"
},
{"name" : " Vision diminuée"
},
{"name" : " Acuité visuelle réduite"
},
{"name" : " Luminosité visuelle"
},
{"name" : " Distorsions visuelles des couleurs"
},
{"name" : " Perturbation visuelle"
},
{"name" : " Potentiels évoqués visuels anormaux"
},
{"name" : " Constriction du champ visuel"
},
{"name" : " Déficience visuelle"
},
{"name" : " VIe paralysie nerveuse"
},
{"name" : " Présence d'une teinture vitale sur la cornée"
},
{"name" : " Carence en vitamine A"
},
{"name" : " Carence en complexe de vitamine B"
},
{"name" : " Carence en vitamine B1"
},
{"name" : " Absorption de la vitamine B12 diminuée"
},
{"name" : " Carence en vitamine B12"
},
{"name" : " Carence en vitamine B6"
},
{"name" : " Carence en vitamine C"
},
{"name" : " Carence en vitamine D"
},
{"name" : " Vitamine E diminuée"
},
{"name" : " Carence en vitamine E"
},
{"name" : " Vitamine K diminuée"
},
{"name" : " Carence en vitamine K"
},
{"name" : " Vitiligo"
},
{"name" : " Détachement vitréen"
},
{"name" : " Trouble vitréen"
},
{"name" : " Flotteurs vitreux"
},
{"name" : " Hémorragie vitréenne"
},
{"name" : " Opacités vitreuses"
},
{"name" : " Prolapsus vitréen"
},
{"name" : " Paludisme à Vivax"
},
{"name" : " Rêves vifs"
},
{"name" : " Trouble des cordes vocales"
},
{"name" : " Paralysie des cordes vocales"
},
{"name" : " Parésie des cordes vocales"
},
{"name" : " Tic vocal"
},
{"name" : " Syndrome de Vogt-Koyanagi-Harada"
},
{"name" : " Perturbation de la voix"
},
{"name" : " Augmentation du volume sanguin"
},
{"name" : " Augmentation du plasma plasmatique"
},
{"name" : " Volvulus"
},
{"name" : " Vomissement"
},
{"name" : " Vomissements aggravés"
},
{"name" : " Vomissements pendant la grossesse"
},
{"name" : " Vomissement néonatal"
},
{"name" : " Maladie de von Willebrand"
},
{"name" : " Vermont"
},
{"name" : " Gêne vulvaire"
},
{"name" : " Abcès vulvaire"
},
{"name" : " Trouble vulvaire"
},
{"name" : " Érythème vulvaire"
},
{"name" : " Leucoplasie vulvaire"
},
{"name" : " Ulcération vulvaire"
},
{"name" : " Vulvite"
},
{"name" : " Atrophie vulvo-vaginale"
},
{"name" : " Sensation de brûlure vulvo-vaginale"
},
{"name" : " Candidose vulvo-vaginale"
},
{"name" : " Gêne vulvo-vaginale"
},
{"name" : " Trouble vulvo-vaginal"
},
{"name" : " Sécheresse vulvo-vaginale"
},
{"name" : " Érythème vulvo-vaginal"
},
{"name" : " Infection mycosique vulvo-vaginale"
},
{"name" : " Douleur vulvo-vaginale"
},
{"name" : " Prurit vulvo-vaginal"
},
{"name" : " Gonflement vulvo-vaginal"
},
{"name" : " Vulvovaginite"
},
{"name" : " Vulvovaginite trichomonale"
},
{"name" : " Tour de taille augmenté"
},
{"name" : " Vigilance"
},
{"name" : " Macroglobulinémie de Waldenstrom"
},
{"name" : " Handicap de marche"
},
{"name" : " Stimulateur vagabond"
},
{"name" : " Anémie hémolytique de type chaud"
},
{"name" : " Chaleur"
},
{"name" : " Verrues"
},
{"name" : " Gaspillage généralisé"
},
{"name" : " Intoxication à l'eau"
},
{"name" : " Rétention d'eau"
},
{"name" : " Diarrhée aqueuse"
},
{"name" : " Ralentissement des vagues"
},
{"name" : " Flexibilité cireuse"
},
{"name" : " WBC anormal NOS"
},
{"name" : " Granulomatose de Wegener"
},
{"name" : " Poids diminué"
},
{"name" : " Fluctuation du poids"
},
{"name" : " Prise de poids médiocre"
},
{"name" : " Augmentation du poids"
},
{"name" : " Welts"
},
{"name" : " Phénomène de Wenckebach"
},
{"name" : " Encéphalopathie de Wernicke"
},
{"name" : " Syndrome de Wernicke-Korsakoff"
},
{"name" : " Respiration sifflante"
},
{"name" : " Respiration sifflante expiratoire"
},
{"name" : " Respiration inspirante"
},
{"name" : " Blessure par coup de fouet cervical"
},
{"name" : " Numération des globules blancs anormale"
},
{"name" : " Nombre de globules blancs diminué"
},
{"name" : " Nombre de globules blancs augmenté"
},
{"name" : " Faible nombre de globules blancs"
},
{"name" : " Trouble des globules blancs"
},
{"name" : " Globules blancs urinaires positifs"
},
{"name" : " Lésion de la substance blanche"
},
{"name" : " Coqueluche"
},
{"name" : " Tachycardie complexe large"
},
{"name" : " Saignement de retrait"
},
{"name" : " Retrait émotionnel"
},
{"name" : " Hypertension de retrait"
},
{"name" : " Saisies de retrait"
},
{"name" : " Symptôme de sevrage"
},
{"name" : " Syndrome de sevrage"
},
{"name" : " Syndrome de Wolff-Parkinson-White"
},
{"name" : " Difficulté à trouver des mots"
},
{"name" : " Inquiétude"
},
{"name" : " Aggravation du diabète"
},
{"name" : " Blessure"
},
{"name" : " Complication d'une plaie"
},
{"name" : " Désintégration de la plaie"
},
{"name" : " Décharge des plaies augmentée"
},
{"name" : " Hématome de plaie"
},
{"name" : " Hémorragie de la plaie"
},
{"name" : " Cicatrisation normale"
},
{"name" : " Infection de la plaie"
},
{"name" : " Sécrétion de plaie"
},
{"name" : " Septicémie de plaie"
},
{"name" : " Chute de poignet"
},
{"name" : " Fracture du poignet"
},
{"name" : " Écriture altérée"
}
]
