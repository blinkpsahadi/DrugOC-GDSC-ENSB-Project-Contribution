export default [{
    name: "5'nucleotidase increased"
}, {
    name: 'Abasia'
}, {
    name: 'Abdominal abscess'
}, {
    name: 'Abdominal adhesions'
}, {
    name: 'Abdominal aortic aneurysm'
}, {
    name: 'Abdominal aortic bruit'
}, {
    name: 'Abdominal aortic rupture'
}, {
    name: 'Abdominal bloating'
}, {
    name: 'Abdominal colic'
}, {
    name: 'Abdominal cramps'
}, {
    name: 'Abdominal discomfort'
}, {
    name: 'Abdominal disorder'
}, {
    name: 'Abdominal distension'
}, {
    name: 'Abdominal distension gaseous'
}, {
    name: 'Abdominal distress'
}, {
    name: 'Abdominal hernia'
}, {
    name: 'Abdominal infection'
}, {
    name: 'Abdominal injury'
}, {
    name: 'Abdominal neoplasm'
}, {
    name: 'Abdominal pain'
}, {
    name: 'Abdominal pain aggravated'
}, {
    name: 'Abdominal pain generalised'
}, {
    name: 'Abdominal pain localised'
}, {
    name: 'Abdominal pain lower'
}, {
    name: 'Abdominal pain upper'
}, {
    name: 'Abdominal rigidity'
}, {
    name: 'Abdominal sepsis'
}, {
    name: 'Abdominal spasm'
}, {
    name: 'Abdominal strangulated hernia'
}, {
    name: 'Abdominal symptom'
}, {
    name: 'Abdominal tenderness'
}, {
    name: 'Abdominal wall abscess'
}, {
    name: 'Abnormal behaviour'
}, {
    name: 'Abnormal bowel sounds'
}, {
    name: 'Abnormal chest sounds NOS'
}, {
    name: 'Abnormal clotting factor'
}, {
    name: 'Abnormal dreams'
}, {
    name: 'Abnormal ejaculation'
}, {
    name: 'Abnormal eye movements NOS'
}, {
    name: 'Abnormal faeces'
}, {
    name: 'Abnormal involuntary movements'
}, {
    name: 'Abnormal labour'
}, {
    name: 'Abnormal pigmentation'
}, {
    name: 'Abnormal platelets'
}, {
    name: 'Abnormal sensation in eye'
}, {
    name: 'Abnormal sleep-related event'
}, {
    name: 'Abnormal vision'
}, {
    name: 'Abnormal withdrawal bleeding'
}, {
    name: 'Abnormalities of the hair'
}, {
    name: 'Abortion'
}, {
    name: 'Abortion incomplete'
}, {
    name: 'Abortion infected'
}, {
    name: 'Abortion missed'
}, {
    name: 'Abortion spontaneous'
}, {
    name: 'Abrasion NOS'
}, {
    name: 'Abscess'
}, {
    name: 'Abscess limb'
}, {
    name: 'Abscess periodontal'
}, {
    name: 'Abscess sterile'
}, {
    name: 'Abscesses of skin'
}, {
    name: 'Absence congenital'
}, {
    name: 'Absolute neutrophil count decreased'
}, {
    name: 'Acalculous cholecystitis'
}, {
    name: 'Acanthamoeba keratitis'
}, {
    name: 'Acanthosis nigricans'
}, {
    name: 'Acarodermatitis'
}, {
    name: 'Accelerated hair loss'
}, {
    name: 'Accident'
}, {
    name: 'Accident at home'
}, {
    name: 'Accidental exposure to product'
}, {
    name: 'Accidental ingestion'
}, {
    name: 'Accidental injury'
}, {
    name: 'Accidental overdose'
}, {
    name: 'Accommodation disorder'
}, {
    name: 'Accommodative component in esotropia'
}, {
    name: 'Acetonaemia'
}, {
    name: 'Ache'
}, {
    name: 'Ache wrists'
}, {
    name: 'Achlorhydria'
}, {
    name: 'Acholia'
}, {
    name: 'Acid indigestion'
}, {
    name: 'Acid phosphatase high'
}, {
    name: 'Acid-base disorders'
}, {
    name: 'Acidemia'
}, {
    name: 'Acidosis'
}, {
    name: 'Acidosis hyperchloraemic'
}, {
    name: 'Acne'
}, {
    name: 'Acne conglobata'
}, {
    name: 'Acne cystic'
}, {
    name: 'Acne fulminans'
}, {
    name: 'Acne infantile'
}, {
    name: 'Acne pustular'
}, {
    name: 'Acne vulgaris'
}, {
    name: 'Acneiform eruption'
}, {
    name: 'Acquired haemophilia'
}, {
    name: 'Acquired hemolytic anemia'
}, {
    name: 'Acquired immunodeficiency syndrome'
}, {
    name: 'Acquired keratoderma'
}, {
    name: 'Acquired lipoatrophic diabetes'
}, {
    name: 'Acquired megacolon'
}, {
    name: 'Acquired night blindness'
}, {
    name: 'Acral erythema'
}, {
    name: 'Acrochordon'
}, {
    name: 'Acrocyanosis'
}, {
    name: 'Acrodynia'
}, {
    name: 'Acromegaly'
}, {
    name: 'Actinic elastosis'
}, {
    name: 'Actinic keratosis'
}, {
    name: 'Actinomycosis'
}, {
    name: 'Action tremor'
}, {
    name: 'Activated partial thromboplastin time prolonged'
}, {
    name: 'Activated partial thromboplastin time shortened'
}, {
    name: 'Activation syndrome'
}, {
    name: 'Active tuberculosis'
}, {
    name: 'Acute abdomen'
}, {
    name: 'Acute allergic reaction'
}, {
    name: 'Acute allograft rejection'
}, {
    name: 'Acute anaphylaxis'
}, {
    name: 'Acute angle-closure glaucoma'
}, {
    name: 'Acute appendicitis'
}, {
    name: 'Acute bronchitis'
}, {
    name: 'Acute cardiac toxicity'
}, {
    name: 'Acute chest pain'
}, {
    name: 'Acute chest syndrome'
}, {
    name: 'Acute cholestatic hepatitis'
}, {
    name: 'Acute confusional state'
}, {
    name: 'Acute conjunctivitis'
}, {
    name: 'Acute coronary syndrome'
}, {
    name: 'Acute cystitis'
}, {
    name: 'Acute cytolytic hepatitis'
}, {
    name: 'Acute depression'
}, {
    name: 'Acute diarrhea'
}, {
    name: 'Acute disseminated encephalomyelitis'
}, {
    name: 'Acute duodenal ulcer'
}, {
    name: 'Acute dyspnea'
}, {
    name: 'Acute dystonia'
}, {
    name: 'Acute enterocolitis'
}, {
    name: 'Acute exacerbation of chronic bronchitis'
}, {
    name: 'Acute fatty liver'
}, {
    name: 'Acute febrile illness'
}, {
    name: 'Acute febrile neutrophilic dermatosis'
}, {
    name: 'Acute gastritis'
}, {
    name: 'Acute gastroenteritis'
}, {
    name: 'Acute generalised exanthematous pustulosis'
}, {
    name: 'Acute glaucoma'
}, {
    name: 'Acute graft rejection'
}, {
    name: 'Acute graft versus host disease'
}, {
    name: 'Acute haemolytic anaemia'
}, {
    name: 'Acute hemorrhage'
}, {
    name: 'Acute hepatic failure'
}, {
    name: 'Acute hepatitis B'
}, {
    name: 'Acute hypotension'
}, {
    name: 'Acute interstitial nephritis'
}, {
    name: 'Acute interstitial pneumonitis'
}, {
    name: 'Acute kidney injury'
}, {
    name: 'Acute left ventricular failure'
}, {
    name: 'Acute leukaemia'
}, {
    name: 'Acute liver damage'
}, {
    name: 'Acute liver injury'
}, {
    name: 'Acute lymphocytic leukaemia'
}, {
    name: 'Acute maxillary sinusitis'
}, {
    name: 'Acute migraine'
}, {
    name: 'Acute myeloid leukaemia'
}, {
    name: 'Acute myelomonocytic leukaemia'
}, {
    name: 'Acute myocardial infarction'
}, {
    name: 'Acute myocardial ischemia'
}, {
    name: 'Acute nephritis'
}, {
    name: 'Acute overdose'
}, {
    name: 'Acute pain'
}, {
    name: 'Acute pharyngitis'
}, {
    name: 'Acute phase reaction'
}, {
    name: 'Acute phosphate nephropathy'
}, {
    name: 'Acute pneumonia'
}, {
    name: 'Acute prerenal failure'
}, {
    name: 'Acute promyelocytic leukaemia'
}, {
    name: 'Acute promyelocytic leukaemia differentiation syndrome'
}, {
    name: 'Acute prostatitis'
}, {
    name: 'Acute psychosis'
}, {
    name: 'Acute pulmonary oedema'
}, {
    name: 'Acute renal insufficiency'
}, {
    name: 'Acute respiratory distress syndrome'
}, {
    name: 'Acute respiratory failure'
}, {
    name: 'Acute respiratory insufficiency'
}, {
    name: 'Acute retention of urine'
}, {
    name: 'Acute schizophrenia'
}, {
    name: 'Acute sinusitis'
}, {
    name: 'Acute stress disorder'
}, {
    name: "Acute swimmers' ear"
}, {
    name: 'Acute tonsillitis'
}, {
    name: 'Acute ulcerative colitis'
}, {
    name: 'Acute urticaria'
}, {
    name: 'Acute uveitis'
}, {
    name: 'Acute yellow liver atrophy'
}, {
    name: 'Adams-Stokes syndrome'
}, {
    name: "Addison's disease"
}, {
    name: 'Adenitis'
}, {
    name: 'Adenocarcinoma'
}, {
    name: 'Adenocarcinoma gastric'
}, {
    name: 'Adenocarcinoma of prostate'
}, {
    name: 'Adenocarcinoma of the gastroesophageal junction'
}, {
    name: 'Adenocarcinoma of the prostate metastatic'
}, {
    name: 'Adenocarcinoma pancreas'
}, {
    name: 'Adenoma benign'
}, {
    name: 'Adenomatous polyposis coli'
}, {
    name: 'Adenomyosis'
}, {
    name: 'Adenovirus infection'
}, {
    name: 'ADHF'
}, {
    name: 'Adhesion'
}, {
    name: 'Adjustment disorder'
}, {
    name: 'Administration site infection'
}, {
    name: 'Administration site reaction'
}, {
    name: 'Adnexa uteri cyst'
}, {
    name: 'Adnexa uteri mass'
}, {
    name: 'Adnexa uteri pain'
}, {
    name: 'Adnexal torsion'
}, {
    name: 'Adnexitis'
}, {
    name: 'Adrenal adenoma'
}, {
    name: 'Adrenal atrophy'
}, {
    name: 'Adrenal carcinoma'
}, {
    name: 'Adrenal cortex atrophy'
}, {
    name: 'Adrenal cortical hypofunction'
}, {
    name: 'Adrenal disorder'
}, {
    name: 'Adrenal gland cancer'
}, {
    name: 'Adrenal haemorrhage'
}, {
    name: 'Adrenal insufficiency'
}, {
    name: 'Adrenal neoplasm'
}, {
    name: 'Adrenergic syndrome'
}, {
    name: 'Adrenocortical carcinoma'
}, {
    name: 'Adrenocortical insufficiency acute'
}, {
    name: 'Adrenocorticotropic hormone deficiency'
}, {
    name: 'Adrenogenital syndrome'
}, {
    name: 'Advanced breast cancer'
}, {
    name: 'Advanced cancer'
}, {
    name: 'Adverse reaction'
}, {
    name: 'Aerophagia'
}, {
    name: 'Affect lability'
}, {
    name: 'Affective disorder'
}, {
    name: 'African trypanosomiasis'
}, {
    name: 'Agammaglobulinemia'
}, {
    name: 'AGEP'
}, {
    name: 'Age-related macular degeneration'
}, {
    name: 'Ageusia'
}, {
    name: 'Aggravation of existing disorder'
}, {
    name: 'Aggression'
}, {
    name: 'Aggressive reaction'
}, {
    name: 'Aggressive systemic mastocytosis'
}, {
    name: 'Agitated depression'
}, {
    name: 'Agitation'
}, {
    name: 'Agitation postoperative'
}, {
    name: 'Agnosia'
}, {
    name: 'Agoraphobia'
}, {
    name: 'Agranulocytosis'
}, {
    name: 'AIDS dementia complex'
}, {
    name: 'AION'
}, {
    name: 'Airway complication of anaesthesia'
}, {
    name: 'Airway edema'
}, {
    name: 'Airway obstruction NOS'
}, {
    name: 'Akathisia'
}, {
    name: 'Akinaesthesia'
}, {
    name: 'Akinesia'
}, {
    name: 'Akinetic seizures'
}, {
    name: 'Alanine aminotransferase abnormal'
}, {
    name: 'Alanine aminotransferase decreased'
}, {
    name: 'Alanine aminotransferase increased'
}, {
    name: 'Alanine aminotransferase normal'
}, {
    name: 'Albinism'
}, {
    name: "Albright's disease"
}, {
    name: 'Albumin globulin ratio abnormal'
}, {
    name: 'Albumin high'
}, {
    name: 'Albumin low'
}, {
    name: 'Albumin urine increased'
}, {
    name: 'Albumin urine present'
}, {
    name: 'Albuminuria'
}, {
    name: 'Alcohol abuse'
}, {
    name: 'Alcohol craving'
}, {
    name: 'Alcohol intolerance'
}, {
    name: 'Alcohol intoxication'
}, {
    name: 'Alcohol poisoning'
}, {
    name: 'Alcohol problem'
}, {
    name: 'Alcohol withdrawal syndrome'
}, {
    name: 'Alcoholic liver disease'
}, {
    name: 'Alcoholic pancreatitis'
}, {
    name: 'Alcoholic psychosis'
}, {
    name: 'Alcoholism'
}, {
    name: 'Aldosterone low'
}, {
    name: 'Alertness decreased'
}, {
    name: 'Algodystrophy'
}, {
    name: 'Alkalemia'
}, {
    name: 'Alkaline phosphatase serum increased'
}, {
    name: 'Alkalosis'
}, {
    name: 'Alkalosis hypochloraemic'
}, {
    name: 'Alkalosis hypokalaemic'
}, {
    name: 'Allergic asthma'
}, {
    name: 'Allergic bronchitis'
}, {
    name: 'Allergic bronchospasm'
}, {
    name: 'Allergic conditions'
}, {
    name: 'Allergic contact dermatitis'
}, {
    name: 'Allergic cutaneous angiitis'
}, {
    name: 'Allergic exanthema'
}, {
    name: 'Allergic granulomatous angiitis'
}, {
    name: 'Allergic hepatitis'
}, {
    name: 'Allergic oedema'
}, {
    name: 'Allergic rash'
}, {
    name: 'Allergic sinusitis'
}, {
    name: 'Allergic skin reaction'
}, {
    name: 'Allergic urticaria'
}, {
    name: 'Allergy aggravated'
}, {
    name: 'Allergy to nuts'
}, {
    name: 'Allodynia'
}, {
    name: 'Alopecia'
}, {
    name: 'Alopecia areata'
}, {
    name: 'Alopecia reversible'
}, {
    name: 'Altered state of consciousness'
}, {
    name: 'Altered visual depth perception'
}, {
    name: 'Aluminium overload'
}, {
    name: 'Alveolar osteitis'
}, {
    name: 'Alveolar proteinosis'
}, {
    name: 'Alveolitis'
}, {
    name: 'Alveolitis allergic'
}, {
    name: 'Amaurosis'
}, {
    name: 'Amaurosis fugax'
}, {
    name: 'Amblyopia'
}, {
    name: 'Amblyopia tobacco'
}, {
    name: 'Amelia'
}, {
    name: 'Amenorrhea secondary'
}, {
    name: 'Amenorrhoea'
}, {
    name: 'Amino acid metabolism disorder'
}, {
    name: 'Aminoaciduria'
}, {
    name: 'AML progression'
}, {
    name: 'Ammonia increased'
}, {
    name: 'Amnesia'
}, {
    name: 'Amnesia transient'
}, {
    name: 'Amnestic symptoms'
}, {
    name: 'Amniotic cavity infection'
}, {
    name: 'Amniotic fluid embolism'
}, {
    name: 'Amoebiasis'
}, {
    name: 'Amoebic colitis'
}, {
    name: 'Amylase decreased'
}, {
    name: 'Amylase increased'
}, {
    name: 'Amyloidosis'
}, {
    name: 'Amyotrophic lateral sclerosis'
}, {
    name: 'ANA increased'
}, {
    name: 'Anaemia'
}, {
    name: 'Anaemia NOS aggravated'
}, {
    name: 'Anaemia macrocytic'
}, {
    name: 'Anaemia megaloblastic'
}, {
    name: 'Anaemia neonatal'
}, {
    name: 'Anaemia of pregnancy'
}, {
    name: 'Anaemia postoperative'
}, {
    name: 'Anaemia vitamin B12 deficiency'
}, {
    name: 'Anaemias NEC'
}, {
    name: 'Anaemias haemolytic immune'
}, {
    name: 'Anaesthetic complication'
}, {
    name: 'Anaesthetic complication neurological'
}, {
    name: 'Anal abscess'
}, {
    name: 'Anal atresia'
}, {
    name: 'Anal cancer'
}, {
    name: 'Anal candidiasis'
}, {
    name: 'Anal discomfort'
}, {
    name: 'Anal fissure'
}, {
    name: 'Anal fistula'
}, {
    name: 'Anal haemorrhage'
}, {
    name: 'Anal inflammation'
}, {
    name: 'Anal irritation'
}, {
    name: 'Anal pruritus'
}, {
    name: 'Anal skin tags'
}, {
    name: 'Anal spasm'
}, {
    name: 'Anal sphincter atony'
}, {
    name: 'Analgesic asthma syndrome'
}, {
    name: 'Analgesic effect'
}, {
    name: 'Analgesic therapy'
}, {
    name: 'Anaphylactic responses'
}, {
    name: 'Anaphylactic shock'
}, {
    name: 'Anaphylactoid reaction'
}, {
    name: 'Anaphylactoid syndrome of pregnancy'
}, {
    name: 'Anaplastic astrocytoma'
}, {
    name: 'Anaplastic large-cell lymphoma'
}, {
    name: 'Anaplastic thyroid cancer'
}, {
    name: 'Anastomotic leak'
}, {
    name: 'Anastomotic ulcer'
}, {
    name: 'Androgen deficiency'
}, {
    name: 'Androgenetic alopecia'
}, {
    name: 'Anemic'
}, {
    name: 'Anencephaly'
}, {
    name: 'Aneurysm'
}, {
    name: 'Anger'
}, {
    name: 'Angiitis necrotising'
}, {
    name: 'Angina decubitus'
}, {
    name: 'Angina pectoris'
}, {
    name: 'Angina pectoris aggravated'
}, {
    name: 'Angina symptom'
}, {
    name: 'Angina unstable'
}, {
    name: 'Anginal attack'
}, {
    name: 'Angiodermatitis'
}, {
    name: 'Angioedema'
}, {
    name: 'Angioedema of larynx'
}, {
    name: 'Angioimmunoblastic T-cell lymphoma'
}, {
    name: 'Angiomyolipoma'
}, {
    name: 'Angiopathy'
}, {
    name: 'Angle closure glaucoma'
}, {
    name: 'Angular cheilitis'
}, {
    name: 'Anhedonia'
}, {
    name: 'Anhidrosis'
}, {
    name: 'Animal bite'
}, {
    name: 'Animal scratch'
}, {
    name: 'Anion gap increased'
}, {
    name: 'Anisocytosis'
}, {
    name: 'Ankle edema'
}, {
    name: 'Ankle fracture'
}, {
    name: 'Ankle sprain'
}, {
    name: 'Ankylosing spondylitis'
}, {
    name: 'Anogenital warts'
}, {
    name: 'Anophthalmos'
}, {
    name: 'Anorectal discomfort'
}, {
    name: 'Anorectal disorder'
}, {
    name: 'Anorectal human papilloma virus infection'
}, {
    name: 'Anorectal infection'
}, {
    name: 'Anorexia'
}, {
    name: 'Anorexia nervosa'
}, {
    name: 'Anorgasmia'
}, {
    name: 'Anosmia'
}, {
    name: 'Anosognosia'
}, {
    name: 'Anovulation'
}, {
    name: 'Anovulatory cycle'
}, {
    name: 'Anoxia'
}, {
    name: 'Antepartum hemorrhage'
}, {
    name: 'Anterior chamber cell'
}, {
    name: 'Anterior chamber flare'
}, {
    name: 'Anterior chamber inflammation'
}, {
    name: 'Anterior chamber pigmentation'
}, {
    name: 'Anterior horn cell disease'
}, {
    name: 'Anterior ischemic optic neuropathy'
}, {
    name: 'Anterior myocardial infarction'
}, {
    name: 'Anterior spinal artery syndrome'
}, {
    name: 'Anterior uveitis'
}, {
    name: 'Anterograde amnesia'
}, {
    name: 'Anthrax'
}, {
    name: 'Anti-thyroid antibody positive'
}, {
    name: 'Antibiotic associated colitis'
}, {
    name: 'Antibiotic-associated diarrhea'
}, {
    name: 'Antibody NOS negative'
}, {
    name: 'Antibody test negative'
}, {
    name: 'Antibody test positive'
}, {
    name: 'Anticholinergic syndrome'
}, {
    name: 'Antidiuresis'
}, {
    name: 'Antidiuretic hormone abnormality'
}, {
    name: 'Antineutrophil cytoplasmic antibody positive'
}, {
    name: 'Antinuclear antibody increased'
}, {
    name: 'Antinuclear antibody positive'
}, {
    name: 'Antisocial behaviour'
}, {
    name: 'Antisocial personality disorder'
}, {
    name: 'Antitussive therapy'
}, {
    name: 'Anuria'
}, {
    name: 'Anus disorder'
}, {
    name: 'Anxiety'
}, {
    name: 'Anxiety NEC'
}, {
    name: 'Anxiety aggravated'
}, {
    name: 'Anxiety attack'
}, {
    name: 'Anxiety depression'
}, {
    name: 'Anxiety disorder'
}, {
    name: 'Anxiety neurosis'
}, {
    name: 'Anxiety state'
}, {
    name: 'Anxiety symptoms NOS'
}, {
    name: 'Anxious mood'
}, {
    name: 'Aortic aneurysm'
}, {
    name: 'Aortic aneurysm rupture'
}, {
    name: 'Aortic arteriosclerosis'
}, {
    name: 'Aortic bruit'
}, {
    name: 'Aortic disorder'
}, {
    name: 'Aortic dissection'
}, {
    name: 'Aortic embolus'
}, {
    name: 'Aortic rupture'
}, {
    name: 'Aortic valve incompetence'
}, {
    name: 'Aortic valve sclerosis'
}, {
    name: 'Aortic valve stenosis'
}, {
    name: 'Apathy'
}, {
    name: 'Apgar score low'
}, {
    name: 'Aphagia'
}, {
    name: 'Aphakia'
}, {
    name: 'Aphakic cystoid macular oedema'
}, {
    name: 'Aphasia'
}, {
    name: 'Aphonia'
}, {
    name: 'Aphthous stomatitis'
}, {
    name: 'Aplasia'
}, {
    name: 'Aplasia cutis congenita'
}, {
    name: 'Aplasia pure red cell'
}, {
    name: 'Aplastic anaemia'
}, {
    name: 'Apnoea'
}, {
    name: 'Apnoea neonatal'
}, {
    name: 'Apocrine and eccrine gland disorders'
}, {
    name: 'Apoptosis'
}, {
    name: 'Appendicitis'
}, {
    name: 'Appetite absent'
}, {
    name: 'Appetite disorder'
}, {
    name: 'Appetite exaggerated'
}, {
    name: 'Application and instillation site reactions'
}, {
    name: 'Application site anaesthesia'
}, {
    name: 'Application site atrophy'
}, {
    name: 'Application site burn'
}, {
    name: 'Application site cellulitis'
}, {
    name: 'Application site discharge'
}, {
    name: 'Application site discolouration'
}, {
    name: 'Application site discomfort'
}, {
    name: 'Application site dryness'
}, {
    name: 'Application site eczema'
}, {
    name: 'Application site erosion'
}, {
    name: 'Application site erythema'
}, {
    name: 'Application site excoriation'
}, {
    name: 'Application site exfoliation'
}, {
    name: 'Application site folliculitis'
}, {
    name: 'Application site haematoma'
}, {
    name: 'Application site haemorrhage'
}, {
    name: 'Application site hyperaesthesia'
}, {
    name: 'Application site hypersensitivity'
}, {
    name: 'Application site induration'
}, {
    name: 'Application site infection'
}, {
    name: 'Application site inflammation'
}, {
    name: 'Application site irritation'
}, {
    name: 'Application site oedema'
}, {
    name: 'Application site pain'
}, {
    name: 'Application site papules'
}, {
    name: 'Application site paraesthesia'
}, {
    name: 'Application site pigmentation changes'
}, {
    name: 'Application site pruritus'
}, {
    name: 'Application site pustules'
}, {
    name: 'Application site rash'
}, {
    name: 'Application site reaction'
}, {
    name: 'Application site scab'
}, {
    name: 'Application site scar'
}, {
    name: 'Application site skin breakdown'
}, {
    name: 'Application site stinging'
}, {
    name: 'Application site swelling'
}, {
    name: 'Application site ulcer'
}, {
    name: 'Application site urticaria'
}, {
    name: 'Application site vesicles'
}, {
    name: 'Application site warmth'
}, {
    name: 'Apprehension'
}, {
    name: 'Apraxia'
}, {
    name: 'Arachnoiditis'
}, {
    name: 'Arcus juvenilis'
}, {
    name: 'Arcus lipoides'
}, {
    name: 'Arcus senilis'
}, {
    name: 'Areflexia'
}, {
    name: 'Argininosuccinate synthetase deficiency'
}, {
    name: 'Argumentativeness'
}, {
    name: 'Arrhythmia'
}, {
    name: 'Arrhythmia supraventricular'
}, {
    name: 'Arterial aneurysm'
}, {
    name: 'Arterial anomaly'
}, {
    name: 'Arterial disorder'
}, {
    name: 'Arterial insufficiency'
}, {
    name: 'Arterial occlusion'
}, {
    name: 'Arterial occlusive disease'
}, {
    name: 'Arterial spasm'
}, {
    name: 'Arterial stenosis limb'
}, {
    name: 'Arterial thromboembolism'
}, {
    name: 'Arterial thrombosis'
}, {
    name: 'Arteriosclerosis'
}, {
    name: 'Arteriosclerosis coronary artery'
}, {
    name: 'Arteriosclerosis obliterans'
}, {
    name: 'Arteriosclerotic retinopathy'
}, {
    name: 'Arteriospasm coronary'
}, {
    name: 'Arteriovenous fistula'
}, {
    name: 'Arteriovenous fistula thrombosis'
}, {
    name: 'Arteriovenous malformation'
}, {
    name: 'Arteritic anterior ischaemic optic neuropathy'
}, {
    name: 'Arteritis'
}, {
    name: 'Artery dissection'
}, {
    name: 'Arthralgia'
}, {
    name: 'Arthralgia aggravated'
}, {
    name: 'Arthralgia of temporomandibular joint'
}, {
    name: 'Arthritic pains'
}, {
    name: 'Arthritis'
}, {
    name: 'Arthritis aggravated'
}, {
    name: 'Arthritis bacterial'
}, {
    name: 'Arthritis infective'
}, {
    name: 'Arthropathy'
}, {
    name: 'Arthropod bite'
}, {
    name: 'Arthropod sting'
}, {
    name: 'Artificial kidney clotting during dialysis'
}, {
    name: 'Artificial menopause'
}, {
    name: 'Ascariasis'
}, {
    name: 'Ascites'
}, {
    name: 'Ascites chylous'
}, {
    name: 'Aseptic necrosis'
}, {
    name: 'Aseptic necrosis of bone'
}, {
    name: 'Aseptic peritonitis'
}, {
    name: 'Asocial behaviour'
}, {
    name: 'Aspartate aminotransferase decreased'
}, {
    name: 'Aspartate aminotransferase increased'
}, {
    name: 'Aspartate aminotransferase normal'
}, {
    name: 'Aspergilloma'
}, {
    name: 'Aspergillosis'
}, {
    name: 'Aspergillus infection'
}, {
    name: 'Aspermia'
}, {
    name: 'Asphyxia'
}, {
    name: 'Aspiration'
}, {
    name: 'Aspiration pneumonitis'
}, {
    name: 'Asplenia'
}, {
    name: 'Assault'
}, {
    name: 'Assisted fertilisation'
}, {
    name: 'Asteatosis'
}, {
    name: 'Asterixis'
}, {
    name: 'Asthenia'
}, {
    name: 'Asthenic conditions'
}, {
    name: 'Asthenopia'
}, {
    name: 'Asthma'
}, {
    name: 'Asthma aggravated'
}, {
    name: 'Asthma aspirin-sensitive'
}, {
    name: 'Asthma chronic'
}, {
    name: 'Asthma exercise induced'
}, {
    name: 'Asthma late onset'
}, {
    name: 'Asthmatic attack'
}, {
    name: 'Astrocytoma'
}, {
    name: 'Astrocytoma, low grade'
}, {
    name: 'Asymptomatic bacteriuria'
}, {
    name: 'Asymptomatic hyperlactatemia'
}, {
    name: 'Ataxia'
}, {
    name: 'Ataxic gait'
}, {
    name: 'Atelectasis'
}, {
    name: 'Atheroma'
}, {
    name: 'Atherosclerosis'
}, {
    name: 'Atherosclerosis cerebral'
}, {
    name: 'Atherothrombosis'
}, {
    name: 'Athetosis'
}, {
    name: 'Atonia'
}, {
    name: 'Atonic seizures'
}, {
    name: 'Atonic urinary bladder'
}, {
    name: 'Atopic rhinitis'
}, {
    name: 'Atopy'
}, {
    name: 'Atresia biliary'
}, {
    name: 'Atrial arrhythmia'
}, {
    name: 'Atrial fibrillation'
}, {
    name: 'Atrial fibrillation and flutter'
}, {
    name: 'Atrial flutter'
}, {
    name: 'Atrial hypertrophy'
}, {
    name: 'Atrial pressure'
}, {
    name: 'Atrial rhythm'
}, {
    name: 'Atrial septal defect'
}, {
    name: 'Atrial tachycardia'
}, {
    name: 'Atrioventricular block'
}, {
    name: 'Atrioventricular block complete'
}, {
    name: 'Atrioventricular block first degree'
}, {
    name: 'Atrioventricular block second degree'
}, {
    name: 'Atrioventricular dissociation'
}, {
    name: 'Atrophic glossitis'
}, {
    name: 'Atrophic vulvovaginitis'
}, {
    name: 'Atrophy'
}, {
    name: 'Atrophy of vulva'
}, {
    name: 'Attention concentration difficulty'
}, {
    name: 'Attention deficit disorder'
}, {
    name: 'Attention deficit/hyperactivity disorder'
}, {
    name: 'Atypical femur fracture'
}, {
    name: 'Atypical fracture'
}, {
    name: 'Atypical mycobacterial infection'
}, {
    name: 'Atypical pneumonia'
}, {
    name: 'Atypical stress fracture'
}, {
    name: 'Auditory and visual hallucinations'
}, {
    name: 'Auditory disorder NOS'
}, {
    name: 'Aura'
}, {
    name: 'Auricular swelling'
}, {
    name: 'Autism'
}, {
    name: 'Autism spectrum disorder'
}, {
    name: 'Autoimmune disorder'
}, {
    name: 'Autoimmune haemolytic anaemia'
}, {
    name: 'Autoimmune hepatitis'
}, {
    name: 'Autoimmune thrombocytopenia'
}, {
    name: 'Autoimmune thyroiditis'
}, {
    name: 'Automatic bladder'
}, {
    name: 'Automatism'
}, {
    name: 'Autonomic dysfunction'
}, {
    name: 'Autonomic failure syndrome'
}, {
    name: 'Autonomic nervous system imbalance'
}, {
    name: 'Autonomic neuropathy'
}, {
    name: 'Autonomy of thyroid gland'
}, {
    name: 'AV nodal reentrant tachycardia'
}, {
    name: 'AV reentrant tachycardia'
}, {
    name: 'Avascular necrosis femoral head'
}, {
    name: 'Avitaminosis'
}, {
    name: 'Axonal neuropathy'
}, {
    name: 'Azoospermia'
}, {
    name: 'Azotaemia'
}, {
    name: 'Azotaemia of renal origin'
}, {
    name: 'Azotemia prerenal'
}, {
    name: 'B-cell chronic lymphocytic leukemia'
}, {
    name: 'B-cell lymphoma'
}, {
    name: 'B-cell type acute leukaemia'
}, {
    name: 'Babesiosis'
}, {
    name: 'Bacillary dysentery'
}, {
    name: 'Bacillary infections'
}, {
    name: 'Back disorder'
}, {
    name: 'Back distress'
}, {
    name: 'Back injury'
}, {
    name: 'Back pain'
}, {
    name: 'Back pain aggravated'
}, {
    name: 'Back strain'
}, {
    name: 'Background diabetic retinopathy'
}, {
    name: 'Bacteraemia'
}, {
    name: 'Bacteria urine identified'
}, {
    name: 'Bacterial colonisation'
}, {
    name: 'Bacterial disease carrier'
}, {
    name: 'Bacterial infection'
}, {
    name: 'Bacterial infection due to helicobacter pylori (H. pylori)'
}, {
    name: 'Bacterial infections NEC'
}, {
    name: 'Bacterial prostatitis'
}, {
    name: 'Bacterial rhinitis'
}, {
    name: 'Bacterial sepsis'
}, {
    name: 'Bacterial test positive'
}, {
    name: 'Bacterial toxaemia'
}, {
    name: 'Bacteriuria'
}, {
    name: 'Bacteriuria NOS present'
}, {
    name: 'Bad dreams'
}, {
    name: 'Bad taste'
}, {
    name: 'Balance difficulty'
}, {
    name: 'Balance disorder'
}, {
    name: 'Balanitis'
}, {
    name: 'Balanitis candida'
}, {
    name: 'Balanoposthitis'
}, {
    name: 'Ballismus'
}, {
    name: 'Band neutrophil count increased'
}, {
    name: 'Barium impaction'
}, {
    name: "Barrett's oesophagus"
}, {
    name: "Bartholin's cyst"
}, {
    name: 'Bartonellosis'
}, {
    name: 'Basal cell carcinoma'
}, {
    name: 'Basal cell naevus syndrome'
}, {
    name: "Basedow's disease"
}, {
    name: 'Basilar artery syndrome'
}, {
    name: 'Basilar migraine'
}, {
    name: 'Basophilia'
}, {
    name: 'Battery'
}, {
    name: 'BCG infection'
}, {
    name: 'Beckwith-Wiedemann syndrome'
}, {
    name: 'Bedridden'
}, {
    name: 'Behavior disorder'
}, {
    name: "Bell's palsy"
}, {
    name: 'Benign breast neoplasm'
}, {
    name: 'Benign essential hypertension'
}, {
    name: 'Benign gastrointestinal neoplasm'
}, {
    name: 'Benign hepatic neoplasm'
}, {
    name: 'Benign hydatidiform mole'
}, {
    name: 'Benign intracranial hypertension'
}, {
    name: 'Benign neoplasm'
}, {
    name: 'Benign neoplasm of skin'
}, {
    name: 'Benign prostatic hyperplasia'
}, {
    name: 'Benign prostatic hypertrophy'
}, {
    name: 'Benign vaginal neoplasm'
}, {
    name: 'Beriberi'
}, {
    name: 'Berry aneurysm'
}, {
    name: 'Berylliosis'
}, {
    name: 'Beta 2 microglobulin increased'
}, {
    name: 'Beta 2 microglobulin urine increased'
}, {
    name: 'Bezoar'
}, {
    name: 'Bicarbonate decreased serum'
}, {
    name: 'Bicarbonate level'
}, {
    name: 'Bicytopenia'
}, {
    name: 'Bilateral hydronephrosis'
}, {
    name: 'Bile duct cancer'
}, {
    name: 'Bile duct disorders'
}, {
    name: 'Bile duct neoplasms malignant'
}, {
    name: 'Bile duct stenosis'
}, {
    name: 'Biliary cirrhosis'
}, {
    name: 'Biliary cirrhosis primary'
}, {
    name: 'Biliary colic'
}, {
    name: 'Biliary fibrosis'
}, {
    name: 'Biliary fistula'
}, {
    name: 'Biliary sludge'
}, {
    name: 'Biliary tract disorder'
}, {
    name: 'Bilious vomiting'
}, {
    name: 'Bilirubin abnormal'
}, {
    name: 'Bilirubin conjugated increased'
}, {
    name: 'Bilirubin normal'
}, {
    name: 'Bilirubin total decreased'
}, {
    name: 'Bilirubin total increased'
}, {
    name: 'Bilirubin total low'
}, {
    name: 'Bilirubin unconjugated increased'
}, {
    name: 'Bilirubin value increased'
}, {
    name: 'Binge eating'
}, {
    name: 'Bipolar I disorder'
}, {
    name: 'Bipolar II disorder'
}, {
    name: 'Bipolar depression'
}, {
    name: 'Bipolar disorder'
}, {
    name: 'Birth weight low'
}, {
    name: 'Bite'
}, {
    name: 'Bizarre dreams'
}, {
    name: 'BK virus infection'
}, {
    name: 'Black hairy tongue'
}, {
    name: 'Black spot'
}, {
    name: 'Blacked-out (not amnesia)'
}, {
    name: 'Blackwater fever'
}, {
    name: 'Bladder and urethral symptoms'
}, {
    name: 'Bladder cancer'
}, {
    name: 'Bladder cancer stage IV'
}, {
    name: 'Bladder carcinoma'
}, {
    name: 'Bladder constriction'
}, {
    name: 'Bladder dilatation'
}, {
    name: 'Bladder discomfort'
}, {
    name: 'Bladder disorder'
}, {
    name: 'Bladder distension'
}, {
    name: 'Bladder diverticulum'
}, {
    name: 'Bladder dysfunction'
}, {
    name: 'Bladder fibrosis'
}, {
    name: 'Bladder infection'
}, {
    name: 'Bladder irritation'
}, {
    name: 'Bladder neck contracture'
}, {
    name: 'Bladder neck obstruction'
}, {
    name: 'Bladder neck stricture'
}, {
    name: 'Bladder necrosis'
}, {
    name: 'Bladder neoplasm'
}, {
    name: 'Bladder pain'
}, {
    name: 'Bladder spasm'
}, {
    name: 'Bladder stenosis'
}, {
    name: 'Bladder transitional cell carcinoma'
}, {
    name: 'Bladder transitional cell carcinoma metastatic'
}, {
    name: 'Blanching'
}, {
    name: 'Blanching of skin'
}, {
    name: 'Blast cell crisis'
}, {
    name: 'Blastomycosis'
}, {
    name: 'Bleeding breakthrough'
}, {
    name: 'Bleeding tendency'
}, {
    name: 'Bleeding time prolonged'
}, {
    name: 'Blepharal pigmentation'
}, {
    name: 'Blepharitis'
}, {
    name: 'Blepharitis allergic'
}, {
    name: 'Blepharoconjunctivitis'
}, {
    name: 'Blepharospasm'
}, {
    name: 'Blighted ovum'
}, {
    name: 'Blindness'
}, {
    name: 'Blindness cortical'
}, {
    name: 'Blindness day'
}, {
    name: 'Blindness transient'
}, {
    name: 'Blindness unilateral'
}, {
    name: 'Blindness, both eyes'
}, {
    name: 'Blister'
}, {
    name: 'Bloated feeling'
}, {
    name: 'Block heart'
}, {
    name: 'Blood acid phosphatase increased'
}, {
    name: 'Blood albumin decreased'
}, {
    name: 'Blood albumin increased'
}, {
    name: 'Blood aldosterone decreased'
}, {
    name: 'Blood alkaline phosphatase increased'
}, {
    name: 'Blood amylase increased'
}, {
    name: 'Blood and lymphatic system disorders'
}, {
    name: 'Blood antidiuretic hormone abnormal'
}, {
    name: 'Blood bicarbonate'
}, {
    name: 'Blood bicarbonate decreased'
}, {
    name: 'Blood bicarbonate increased'
}, {
    name: 'Blood bilirubin abnormal'
}, {
    name: 'Blood bilirubin decreased'
}, {
    name: 'Blood bilirubin increased'
}, {
    name: 'Blood bilirubin normal'
}, {
    name: 'Blood bilirubin unconjugated increased'
}, {
    name: 'Blood calcium abnormal'
}, {
    name: 'Blood calcium decreased'
}, {
    name: 'Blood chloride decreased'
}, {
    name: 'Blood chloride increased'
}, {
    name: 'Blood cholesterol abnormal'
}, {
    name: 'Blood cholesterol decreased'
}, {
    name: 'Blood cholesterol increased'
}, {
    name: 'Blood cholesterol normal'
}, {
    name: 'Blood copper decreased'
}, {
    name: 'Blood cortisol decreased'
}, {
    name: 'Blood cortisol increased'
}, {
    name: 'Blood count abnormal'
}, {
    name: 'Blood creatine increased'
}, {
    name: 'Blood creatine phosphokinase MB increased'
}, {
    name: 'Blood creatine phosphokinase MM increased'
}, {
    name: 'Blood creatine phosphokinase abnormal'
}, {
    name: 'Blood creatine phosphokinase increased'
}, {
    name: 'Blood creatine phosphokinase normal'
}, {
    name: 'Blood creatinine abnormal'
}, {
    name: 'Blood creatinine decreased'
}, {
    name: 'Blood creatinine increased'
}, {
    name: 'Blood creatinine normal'
}, {
    name: 'Blood culture negative'
}, {
    name: 'Blood culture positive'
}, {
    name: 'Blood disorder'
}, {
    name: 'Blood electrolytes abnormal'
}, {
    name: 'Blood electrolytes decreased'
}, {
    name: 'Blood fibrinogen decreased'
}, {
    name: 'Blood fibrinogen increased'
}, {
    name: 'Blood follicle stimulating hormone increased'
}, {
    name: 'Blood gases abnormal'
}, {
    name: 'Blood gastrin increased'
}, {
    name: 'Blood glucose abnormal'
}, {
    name: 'Blood glucose decreased'
}, {
    name: 'Blood glucose fluctuation'
}, {
    name: 'Blood glucose increased'
}, {
    name: 'Blood glucose normal'
}, {
    name: 'Blood gonadotrophin decreased'
}, {
    name: 'Blood gonadotrophin increased'
}, {
    name: 'Blood growth hormone increased'
}, {
    name: 'Blood immunoglobulin G decreased'
}, {
    name: 'Blood in stool'
}, {
    name: 'Blood insulin decreased'
}, {
    name: 'Blood insulin increased'
}, {
    name: 'Blood iron abnormal'
}, {
    name: 'Blood iron decreased'
}, {
    name: 'Blood iron increased'
}, {
    name: 'Blood lactate dehydrogenase increased'
}, {
    name: 'Blood luteinising hormone increased'
}, {
    name: 'Blood magnesium decreased'
}, {
    name: 'Blood magnesium increased'
}, {
    name: 'Blood methaemoglobin present'
}, {
    name: 'Blood monocytes increased'
}, {
    name: 'Blood neutrophil count decreased'
}, {
    name: 'Blood oestrogen decreased'
}, {
    name: 'Blood oestrogen increased'
}, {
    name: 'Blood osmolarity decreased'
}, {
    name: 'Blood osmolarity increased'
}, {
    name: 'Blood pH decreased'
}, {
    name: 'Blood pH increased'
}, {
    name: 'Blood pH normal'
}, {
    name: 'Blood pancreatic amylase increased'
}, {
    name: 'Blood parathyroid hormone increased'
}, {
    name: 'Blood phosphate increased'
}, {
    name: 'Blood phosphorus decreased'
}, {
    name: 'Blood phosphorus increased'
}, {
    name: 'Blood potassium abnormal'
}, {
    name: 'Blood potassium decreased'
}, {
    name: 'Blood potassium increased'
}, {
    name: 'Blood pressure abnormal'
}, {
    name: 'Blood pressure diastolic decreased'
}, {
    name: 'Blood pressure diastolic increased'
}, {
    name: 'Blood pressure fluctuation'
}, {
    name: 'Blood pressure inadequately controlled'
}, {
    name: 'Blood pressure increased'
}, {
    name: 'Blood pressure normal'
}, {
    name: 'Blood pressure systolic decreased'
}, {
    name: 'Blood pressure systolic increased'
}, {
    name: 'Blood prolactin decreased'
}, {
    name: 'Blood prolactin increased'
}, {
    name: 'Blood sodium abnormal'
}, {
    name: 'Blood sodium increased'
}, {
    name: 'Blood test abnormal'
}, {
    name: 'Blood testosterone decreased'
}, {
    name: 'Blood testosterone free increased'
}, {
    name: 'Blood testosterone increased'
}, {
    name: 'Blood thromboplastin decreased'
}, {
    name: 'Blood thyroid stimulating hormone decreased'
}, {
    name: 'Blood thyroid stimulating hormone increased'
}, {
    name: 'Blood triglycerides decreased'
}, {
    name: 'Blood triglycerides increased'
}, {
    name: 'Blood triglycerides normal'
}, {
    name: 'Blood urea abnormal'
}, {
    name: 'Blood urea decreased'
}, {
    name: 'Blood urea increased'
}, {
    name: 'Blood urea normal'
}, {
    name: 'Blood uric acid abnormal'
}, {
    name: 'Blood uric acid decreased'
}, {
    name: 'Blood uric acid increased'
}, {
    name: 'Blood urine'
}, {
    name: 'Blood urine present'
}, {
    name: 'Blood zinc decreased'
}, {
    name: 'Bloodshot eye'
}, {
    name: 'Bloody discharge'
}, {
    name: 'Blotchy rash'
}, {
    name: 'Blue toe syndrome'
}, {
    name: 'Blunted affect'
}, {
    name: 'Body fat disorder'
}, {
    name: 'Body hair loss'
}, {
    name: 'Body height decreased'
}, {
    name: 'Body mass index decreased'
}, {
    name: 'Body odor'
}, {
    name: 'Body temperature altered'
}, {
    name: 'Body temperature decreased'
}, {
    name: 'Body temperature fluctuation'
}, {
    name: 'Body temperature increased'
}, {
    name: 'Body tinea'
}, {
    name: 'Bone and joint infections'
}, {
    name: 'Bone cancer metastatic'
}, {
    name: 'Bone deformity'
}, {
    name: 'Bone density decreased'
}, {
    name: 'Bone development abnormal'
}, {
    name: 'Bone disorder'
}, {
    name: 'Bone formation increased'
}, {
    name: 'Bone lesion'
}, {
    name: 'Bone marrow aplastic'
}, {
    name: 'Bone marrow depression'
}, {
    name: 'Bone marrow disorder'
}, {
    name: 'Bone marrow granuloma'
}, {
    name: 'Bone marrow toxicity'
}, {
    name: 'Bone mass decreased'
}, {
    name: 'Bone metabolism disorder'
}, {
    name: 'Bone neoplasm'
}, {
    name: 'Bone pain'
}, {
    name: 'Bone pain aggravated'
}, {
    name: 'Bone sarcoma'
}, {
    name: 'Bone spur'
}, {
    name: 'Bone tenderness'
}, {
    name: 'Borborygmi'
}, {
    name: 'Borderline leprosy'
}, {
    name: 'Borderline personality disorder'
}, {
    name: 'Borrelia infection'
}, {
    name: 'Botulism'
}, {
    name: 'Bovine tuberculosis'
}, {
    name: 'Bowel sounds decreased'
}, {
    name: 'Bowel spasm'
}, {
    name: "Bowen's disease"
}, {
    name: 'Bowenoid papulosis'
}, {
    name: 'Brachial plexus injury'
}, {
    name: 'Bradyarrhythmia'
}, {
    name: 'Bradycardia'
}, {
    name: 'Bradycardia foetal'
}, {
    name: 'Bradycardia-tachycardia syndrome'
}, {
    name: 'Bradykinesia'
}, {
    name: 'Bradyphrenia'
}, {
    name: 'Bradypsychic response'
}, {
    name: 'Brain abscess'
}, {
    name: 'Brain cancer metastatic'
}, {
    name: 'Brain disorder NOS'
}, {
    name: 'Brain herniation'
}, {
    name: 'Brain hypoxia'
}, {
    name: 'Brain infarction'
}, {
    name: 'Brain injury'
}, {
    name: 'Brain lesion'
}, {
    name: 'Brain mass'
}, {
    name: 'Brain neoplasm'
}, {
    name: 'Brain neoplasm benign'
}, {
    name: 'Brain neoplasm malignant'
}, {
    name: 'Brain oedema'
}, {
    name: 'Brain stem glioma'
}, {
    name: 'Brain stem haemorrhage'
}, {
    name: 'Brain stem syndrome'
}, {
    name: 'Breakthrough cancer pain'
}, {
    name: 'Breakthrough pain'
}, {
    name: 'Breast abscess'
}, {
    name: 'Breast atrophy'
}, {
    name: 'Breast calcifications'
}, {
    name: 'Breast cancer'
}, {
    name: 'Breast cancer female'
}, {
    name: 'Breast cancer invasive NOS'
}, {
    name: 'Breast cancer male'
}, {
    name: 'Breast cancer recurrent'
}, {
    name: 'Breast cancer stage IV'
}, {
    name: 'Breast cyst'
}, {
    name: 'Breast discharge'
}, {
    name: 'Breast discomfort'
}, {
    name: 'Breast disorder'
}, {
    name: 'Breast disorder female'
}, {
    name: 'Breast engorgement'
}, {
    name: 'Breast enlargement'
}, {
    name: 'Breast enlargement female'
}, {
    name: 'Breast feeding'
}, {
    name: 'Breast fibroma'
}, {
    name: 'Breast fibrosis'
}, {
    name: 'Breast induration'
}, {
    name: 'Breast malformation'
}, {
    name: 'Breast mass'
}, {
    name: 'Breast microcalcification'
}, {
    name: 'Breast neoplasm'
}, {
    name: 'Breast neoplasm NOS male'
}, {
    name: 'Breast neoplasm benign female'
}, {
    name: 'Breast oedema'
}, {
    name: 'Breast pain'
}, {
    name: 'Breast pain female'
}, {
    name: 'Breast pain male'
}, {
    name: 'Breast swelling'
}, {
    name: 'Breast tenderness'
}, {
    name: 'Breast tension'
}, {
    name: 'Breath holding'
}, {
    name: 'Breath holding attack'
}, {
    name: 'Breath odour'
}, {
    name: 'Breath odour ketones'
}, {
    name: 'Breath sounds abnormal'
}, {
    name: 'Breech presentation'
}, {
    name: 'Bronchial carcinoma'
}, {
    name: 'Bronchial disorder'
}, {
    name: 'Bronchial haemorrhage'
}, {
    name: 'Bronchial hyperreactivity'
}, {
    name: 'Bronchial infection'
}, {
    name: 'Bronchial mucus plug'
}, {
    name: 'Bronchial obstruction'
}, {
    name: 'Bronchial secretion retention'
}, {
    name: 'Bronchial ulceration'
}, {
    name: 'Bronchiectasis'
}, {
    name: 'Bronchiolitis'
}, {
    name: 'Bronchiolitis obliterans with organizing pneumonia'
}, {
    name: 'Bronchioloalveolar carcinoma'
}, {
    name: 'Bronchitis'
}, {
    name: 'Bronchitis asthmatic'
}, {
    name: 'Bronchitis bacterial'
}, {
    name: 'Bronchitis chronic'
}, {
    name: 'Bronchitis viral'
}, {
    name: 'Bronchoconstriction'
}, {
    name: 'Bronchopneumonia'
}, {
    name: 'Bronchopneumopathy'
}, {
    name: 'Bronchopulmonary aspergillosis'
}, {
    name: 'Bronchopulmonary aspergillosis allergic'
}, {
    name: 'Bronchopulmonary disease'
}, {
    name: 'Bronchopulmonary dysplasia'
}, {
    name: 'Bronchospasm'
}, {
    name: 'Bronchospasm aggravated'
}, {
    name: 'Bronchospasm paradoxical'
}, {
    name: 'Bronchostenosis'
}, {
    name: 'Brown tumour'
}, {
    name: 'Brown urine'
}, {
    name: 'Brucellosis'
}, {
    name: 'Brugada syndrome'
}, {
    name: "Bruton's agammaglobulinaemia"
}, {
    name: 'Bruxism'
}, {
    name: 'Buccal inflammation'
}, {
    name: 'Buccal mucosa ulceration'
}, {
    name: 'Buccal mucosal roughening'
}, {
    name: 'Buccoglossal syndrome'
}, {
    name: 'Bucking'
}, {
    name: 'Budd-Chiari syndrome'
}, {
    name: 'Buffalo hump'
}, {
    name: 'Bulimia'
}, {
    name: 'Bulimia nervosa'
}, {
    name: 'Bullous conditions'
}, {
    name: 'Bullous eruption'
}, {
    name: 'Bullous impetigo'
}, {
    name: 'Bullous keratopathy'
}, {
    name: 'Bullous lichen planus'
}, {
    name: 'Bundle branch block'
}, {
    name: 'Bundle branch block left'
}, {
    name: 'Bundle branch block right'
}, {
    name: "Burkitt's lymphoma"
}, {
    name: 'Burn'
}, {
    name: 'Burning anal'
}, {
    name: 'Burning feeling vagina'
}, {
    name: 'Burning foot'
}, {
    name: 'Burning in throat'
}, {
    name: 'Burning mouth'
}, {
    name: 'Burning mouth syndrome'
}, {
    name: 'Burning rectal'
}, {
    name: 'Burning sensation'
}, {
    name: 'Burning sensation in eye'
}, {
    name: 'Burning tongue'
}, {
    name: 'Burns second degree'
}, {
    name: 'Burns third degree'
}, {
    name: 'Bursitis'
}, {
    name: 'Buttock pain'
}, {
    name: 'C-reactive protein increased'
}, {
    name: 'C1 esterase deficiency acquired'
}, {
    name: 'Ca++ increased'
}, {
    name: 'Cachexia'
}, {
    name: 'Caecitis'
}, {
    name: 'Cafe au lait spots'
}, {
    name: 'Calcaneal spur'
}, {
    name: 'Calcification metastatic'
}, {
    name: 'Calcinosis'
}, {
    name: 'Calciphylaxis'
}, {
    name: 'Calcium abnormal NOS'
}, {
    name: 'Calcium deficiency'
}, {
    name: 'Calcium intoxication'
}, {
    name: 'Calcium low'
}, {
    name: 'Calcium metabolism disorder'
}, {
    name: 'Calculus bladder'
}, {
    name: 'Calculus of kidney'
}, {
    name: 'Calculus ureteric'
}, {
    name: 'Calculus urinary'
}, {
    name: 'Call-Fleming syndrome'
}, {
    name: 'Campylobacter gastroenteritis'
}, {
    name: 'Cancer pain'
}, {
    name: 'Candida albicans infection'
}, {
    name: 'Candida cervicitis'
}, {
    name: 'Candida infection'
}, {
    name: 'Candida sepsis'
}, {
    name: 'Candidemia'
}, {
    name: 'Candiduria'
}, {
    name: 'Cannula site reaction'
}, {
    name: 'Capillary fragility'
}, {
    name: 'Capillary fragility increased'
}, {
    name: 'Capillary leak syndrome'
}, {
    name: 'Capillary permeability'
}, {
    name: 'Capsulitis'
}, {
    name: 'Carbamoyl phosphate synthetase deficiency'
}, {
    name: 'Carbohydrate craving'
}, {
    name: 'Carbohydrate tolerance decreased'
}, {
    name: 'Carbon dioxide decreased'
}, {
    name: 'Carbon dioxide increased'
}, {
    name: 'Carbon monoxide poisoning'
}, {
    name: 'Carbuncle'
}, {
    name: 'Carcinogenicity'
}, {
    name: 'Carcinoid syndrome'
}, {
    name: 'Carcinoid tumour'
}, {
    name: 'Carcinoma'
}, {
    name: 'Carcinoma breast'
}, {
    name: 'Carcinoma colon'
}, {
    name: 'Carcinoma endometrial metastatic'
}, {
    name: 'Carcinoma in situ'
}, {
    name: 'Carcinoma in situ of breast ductal'
}, {
    name: 'Carcinoma of lung'
}, {
    name: 'Carcinoma of tongue'
}, {
    name: 'Carcinoma stomach'
}, {
    name: 'Carcinoma testes'
}, {
    name: 'Carcinomatosis'
}, {
    name: 'Cardiac amyloidosis'
}, {
    name: 'Cardiac aneurysm'
}, {
    name: 'Cardiac arrest'
}, {
    name: 'Cardiac death'
}, {
    name: 'Cardiac discomfort'
}, {
    name: 'Cardiac disorder'
}, {
    name: 'Cardiac enzymes increased'
}, {
    name: 'Cardiac failure'
}, {
    name: 'Cardiac failure acute'
}, {
    name: 'Cardiac failure chronic'
}, {
    name: 'Cardiac failure congestive'
}, {
    name: 'Cardiac failure high output'
}, {
    name: 'Cardiac failure right'
}, {
    name: 'Cardiac fibrillation'
}, {
    name: 'Cardiac flutter'
}, {
    name: 'Cardiac hypertrophy'
}, {
    name: 'Cardiac index'
}, {
    name: 'Cardiac murmur'
}, {
    name: 'Cardiac output decreased'
}, {
    name: 'Cardiac output increased'
}, {
    name: 'Cardiac pain'
}, {
    name: 'Cardiac septal defect'
}, {
    name: 'Cardiac syncope'
}, {
    name: 'Cardiac tamponade'
}, {
    name: 'Cardiac valve disease'
}, {
    name: 'Cardiac valve replacement complication'
}, {
    name: 'Cardio-respiratory arrest'
}, {
    name: 'Cardio-respiratory distress'
}, {
    name: 'Cardioactive drug level above therapeutic'
}, {
    name: 'Cardioactive drug level increased'
}, {
    name: 'Cardiogenic shock'
}, {
    name: 'Cardiomegaly'
}, {
    name: 'Cardiomyopathy'
}, {
    name: 'Cardiomyopathy secondary NOS'
}, {
    name: 'Cardiopulmonary failure'
}, {
    name: 'Cardiotoxicity'
}, {
    name: 'Cardiovascular disorder'
}, {
    name: 'Cardiovascular insufficiency'
}, {
    name: 'Carditis'
}, {
    name: 'Carnitine deficiency'
}, {
    name: 'Carotene decreased'
}, {
    name: 'Carotid arteriosclerosis'
}, {
    name: 'Carotid artery disease'
}, {
    name: 'Carotid artery occlusion'
}, {
    name: 'Carotid artery stenosis'
}, {
    name: 'Carotid artery thrombosis'
}, {
    name: 'Carotid bruit'
}, {
    name: 'Carotid pulse'
}, {
    name: 'Carotid sinus hypersensitivity'
}, {
    name: 'Carotid sinus syndrome'
}, {
    name: 'Carpal tunnel syndrome'
}, {
    name: 'Carpo-pedal spasm'
}, {
    name: 'Cat scratch disease'
}, {
    name: 'Catalepsy'
}, {
    name: 'Cataplexy'
}, {
    name: 'Cataract'
}, {
    name: 'Cataract conditions'
}, {
    name: 'Cataract cortical'
}, {
    name: 'Cataract diabetic'
}, {
    name: 'Cataract nuclear'
}, {
    name: 'Cataract specified'
}, {
    name: 'Cataract subcapsular'
}, {
    name: 'Cataract traumatic'
}, {
    name: 'Cataract unilateral'
}, {
    name: 'Catatonia'
}, {
    name: 'Catatonic reaction'
}, {
    name: 'Catheter blockage'
}, {
    name: 'Catheter infection'
}, {
    name: 'Catheter related complication'
}, {
    name: 'Catheter related infection'
}, {
    name: 'Catheter sepsis'
}, {
    name: 'Catheter site cellulitis'
}, {
    name: 'Catheter site erythema'
}, {
    name: 'Catheter site haemorrhage'
}, {
    name: 'Catheter site infection'
}, {
    name: 'Catheter site inflammation'
}, {
    name: 'Catheter site pain'
}, {
    name: 'Catheter site phlebitis'
}, {
    name: 'Catheter site related reaction'
}, {
    name: 'Catheter thrombosis'
}, {
    name: 'Cauda equina syndrome'
}, {
    name: 'Causalgia'
}, {
    name: 'Caustic injury'
}, {
    name: 'CD4 lymphocytes decreased'
}, {
    name: 'Cell death'
}, {
    name: 'Cellulitis'
}, {
    name: 'Cellulitis gangrenous'
}, {
    name: 'Cellulitis staphylococcal'
}, {
    name: 'Central diabetes insipidus'
}, {
    name: 'Central line infection'
}, {
    name: 'Central nervous system disorder'
}, {
    name: 'Central nervous system haemorrhage'
}, {
    name: 'Central nervous system infection'
}, {
    name: 'Central nervous system lesion'
}, {
    name: 'Central nervous system leukaemia'
}, {
    name: 'Central nervous system neoplasm'
}, {
    name: 'Central nervous system stimulation'
}, {
    name: 'Central obesity'
}, {
    name: 'Central precocious puberty'
}, {
    name: 'Central retinal vein occlusion'
}, {
    name: 'Central scotoma'
}, {
    name: 'Central serous retinopathy'
}, {
    name: 'Cerebellar ataxia'
}, {
    name: 'Cerebellar atrophy'
}, {
    name: 'Cerebellar infarction'
}, {
    name: 'Cerebellar oedema'
}, {
    name: 'Cerebellar syndrome'
}, {
    name: 'Cerebral arterial aneurysm'
}, {
    name: 'Cerebral arteriosclerosis'
}, {
    name: 'Cerebral arteritis'
}, {
    name: 'Cerebral artery embolism'
}, {
    name: 'Cerebral artery stenosis'
}, {
    name: 'Cerebral atrophy'
}, {
    name: 'Cerebral dysfunction'
}, {
    name: 'Cerebral haematoma'
}, {
    name: 'Cerebral haemorrhage'
}, {
    name: 'Cerebral hypoperfusion'
}, {
    name: 'Cerebral infarction'
}, {
    name: 'Cerebral ischaemia'
}, {
    name: 'Cerebral palsy'
}, {
    name: 'Cerebral thrombosis'
}, {
    name: 'Cerebral toxoplasmosis'
}, {
    name: 'Cerebral vasoconstriction'
}, {
    name: 'Cerebral venous thrombosis'
}, {
    name: 'Cerebration impaired'
}, {
    name: 'Cerebritis'
}, {
    name: 'Cerebrosclerosis'
}, {
    name: 'Cerebrospinal fluid leakage'
}, {
    name: 'Cerebrospinal fluid rhinorrhea'
}, {
    name: 'Cerebrovascular accident'
}, {
    name: 'Cerebrovascular disorder'
}, {
    name: 'Cerebrovascular infarction'
}, {
    name: 'Cerebrovascular insufficiency'
}, {
    name: 'Cerumen impaction'
}, {
    name: 'Ceruminosis'
}, {
    name: 'Cervical adenitis'
}, {
    name: 'Cervical discharge'
}, {
    name: 'Cervical dysplasia'
}, {
    name: 'Cervical incompetence'
}, {
    name: 'Cervical polyp'
}, {
    name: 'Cervical smear test positive'
}, {
    name: 'Cervical vertebral fracture'
}, {
    name: 'Cervicitis'
}, {
    name: 'Cervicobrachial syndrome'
}, {
    name: 'Cervix carcinoma'
}, {
    name: 'Cervix carcinoma stage 0'
}, {
    name: 'Cervix disorder'
}, {
    name: 'Cervix haemorrhage uterine'
}, {
    name: 'Cervix neoplasm'
}, {
    name: 'Chalazion'
}, {
    name: 'Chalky taste'
}, {
    name: 'Chancroid'
}, {
    name: 'Change in blood pressure'
}, {
    name: 'Change of bowel habit'
}, {
    name: 'Chapped lips'
}, {
    name: 'Chapped skin'
}, {
    name: 'Cheilitis'
}, {
    name: 'Cheilosis'
}, {
    name: 'Chemical burn'
}, {
    name: 'Chemical conjunctivitis'
}, {
    name: 'Chemical cystitis'
}, {
    name: 'Chemical eye injury'
}, {
    name: 'Chemical injury'
}, {
    name: 'Chemical peritonitis'
}, {
    name: 'Chemical phlebitis'
}, {
    name: 'Chemosis'
}, {
    name: 'Chest X-ray abnormal'
}, {
    name: 'Chest X-ray normal'
}, {
    name: 'Chest discomfort'
}, {
    name: 'Chest heaviness'
}, {
    name: 'Chest mass NOS'
}, {
    name: 'Chest pain'
}, {
    name: 'Chest pain exertional'
}, {
    name: 'Chest pressure'
}, {
    name: 'Chest pressure sensation of'
}, {
    name: 'Chest tightness'
}, {
    name: 'Chest wall pain'
}, {
    name: 'Cheyne-Stokes respiration'
}, {
    name: 'Childhood schizophrenia'
}, {
    name: 'Chills'
}, {
    name: 'Chlamydia trachomatis infection'
}, {
    name: 'Chlamydial infection'
}, {
    name: 'Chloasma'
}, {
    name: 'Chloropsia'
}, {
    name: 'Choking'
}, {
    name: 'Choking sensation'
}, {
    name: 'Cholangiocarcinoma'
}, {
    name: 'Cholangitis'
}, {
    name: 'Cholangitis sclerosing'
}, {
    name: 'Cholecystitis'
}, {
    name: 'Cholecystitis acute'
}, {
    name: 'Cholecystitis and cholelithiasis'
}, {
    name: 'Cholecystitis chronic'
}, {
    name: 'Cholecystitis infective'
}, {
    name: 'Cholecystolithiasis'
}, {
    name: 'Cholelithiasis'
}, {
    name: 'Cholera'
}, {
    name: 'Cholestasis'
}, {
    name: 'Cholestasis extrahepatic'
}, {
    name: 'Cholestasis intrahepatic'
}, {
    name: 'Cholestatic liver disease'
}, {
    name: 'Cholestatic liver injury'
}, {
    name: 'Cholesterol serum elevated'
}, {
    name: 'Cholinergic crisis'
}, {
    name: 'Cholinergic syndrome'
}, {
    name: 'Choluria'
}, {
    name: 'Chondrocalcinosis'
}, {
    name: 'Chondrodystrophy'
}, {
    name: 'Chondrolysis'
}, {
    name: 'Chondropathy'
}, {
    name: 'Chorea'
}, {
    name: 'Choreiform'
}, {
    name: 'Choreoathetoid movements'
}, {
    name: 'Choreoathetosis'
}, {
    name: 'Choriocarcinoma'
}, {
    name: 'Chorioretinitis'
}, {
    name: 'Chorioretinopathy'
}, {
    name: 'Choroidal detachment'
}, {
    name: 'Choroidal effusion'
}, {
    name: 'Choroidal neovascularisation'
}, {
    name: 'Choroidal nevus'
}, {
    name: 'Choroiditis'
}, {
    name: 'Chromatopsia'
}, {
    name: 'Chromaturia'
}, {
    name: 'Chromoblastomycosis'
}, {
    name: 'Chromosomal mutation'
}, {
    name: 'Chromosome analysis abnormal'
}, {
    name: 'Chronic UTI'
}, {
    name: 'Chronic allograft nephropathy'
}, {
    name: 'Chronic anal fissure'
}, {
    name: 'Chronic angle-closure glaucoma'
}, {
    name: 'Chronic anxiety'
}, {
    name: 'Chronic atrial fibrillation'
}, {
    name: 'Chronic conjunctivitis'
}, {
    name: 'Chronic diarrhea'
}, {
    name: 'Chronic eczema'
}, {
    name: 'Chronic eosinophilic leukaemia'
}, {
    name: 'Chronic fatigue syndrome'
}, {
    name: 'Chronic fever'
}, {
    name: 'Chronic gastritis'
}, {
    name: 'Chronic graft versus host disease'
}, {
    name: 'Chronic hepatic failure'
}, {
    name: 'Chronic hepatitis'
}, {
    name: 'Chronic hepatitis B'
}, {
    name: 'Chronic hepatitis C'
}, {
    name: 'Chronic idiopathic constipation'
}, {
    name: 'Chronic insomnia'
}, {
    name: 'Chronic interstitial nephritis'
}, {
    name: 'Chronic iron overload'
}, {
    name: 'Chronic kidney disease'
}, {
    name: 'Chronic leukaemia'
}, {
    name: 'Chronic liver disease'
}, {
    name: 'Chronic lymphocytic leukaemia'
}, {
    name: 'Chronic lymphocytic leukaemia refractory'
}, {
    name: 'Chronic migraine'
}, {
    name: 'Chronic mucocutaneous candidiasis'
}, {
    name: 'Chronic myeloid leukaemia'
}, {
    name: 'Chronic myelomonocytic leukaemia'
}, {
    name: 'Chronic nephritis'
}, {
    name: 'Chronic obstructive pulmonary disease'
}, {
    name: 'Chronic open angle glaucoma'
}, {
    name: 'Chronic pain'
}, {
    name: 'Chronic peptic ulcer'
}, {
    name: 'Chronic periodontitis'
}, {
    name: 'Chronic phase chronic myeloid leukemia'
}, {
    name: 'Chronic prostatitis'
}, {
    name: 'Chronic pulmonary histoplasmosis'
}, {
    name: 'Chronic renal insufficiency'
}, {
    name: 'Chronic respiratory disease'
}, {
    name: 'Chronic schizophrenia'
}, {
    name: 'Chronic sinusitis'
}, {
    name: 'Chronic spontaneous urticaria'
}, {
    name: 'Chronic suppurative otitis media'
}, {
    name: 'Chronic thromboembolic pulmonary hypertension'
}, {
    name: 'Chronic venous insufficiency'
}, {
    name: 'Chrysiasis'
}, {
    name: 'Chylothorax'
}, {
    name: 'Chyluria'
}, {
    name: 'Cigarette smoker'
}, {
    name: 'Ciliary muscle spasm'
}, {
    name: 'Cinchonism'
}, {
    name: 'Circadian rhythm sleep disorder'
}, {
    name: 'Circulatory depression'
}, {
    name: 'Circulatory insufficiency'
}, {
    name: 'Circumoral oedema'
}, {
    name: 'Circumoral paresthesia'
}, {
    name: 'Circumscribed scleroderma'
}, {
    name: 'Cirrhosis alcoholic'
}, {
    name: 'Cirrhosis liver postnecrotic'
}, {
    name: 'Citrate toxicity'
}, {
    name: 'Classical migraine'
}, {
    name: 'Claudication'
}, {
    name: 'Claustrophobia'
}, {
    name: 'Clavicle fracture'
}, {
    name: 'Cleft lip'
}, {
    name: 'Cleft palate'
}, {
    name: 'Climacteric'
}, {
    name: 'Clinical flare reaction'
}, {
    name: 'Clitoral engorgement'
}, {
    name: 'Cloacal exstrophy'
}, {
    name: 'Clonic convulsion'
}, {
    name: 'Clonic movements'
}, {
    name: 'Clonus'
}, {
    name: 'Clostridial infection'
}, {
    name: 'Clostridium colitis'
}, {
    name: 'Clostridium difficile colitis'
}, {
    name: 'Clostridium difficile infection'
}, {
    name: 'Clotting'
}, {
    name: 'Cloudy urine'
}, {
    name: 'Clubbing'
}, {
    name: 'Clumsiness'
}, {
    name: 'Cluster headache'
}, {
    name: 'CNS depression NOS'
}, {
    name: 'CNS toxicity'
}, {
    name: 'CNS ventriculitis'
}, {
    name: 'Coagulation factor decreased'
}, {
    name: 'Coagulation necrosis'
}, {
    name: 'Coagulation test abnormal'
}, {
    name: 'Coagulation time prolonged'
}, {
    name: 'Coagulopathy'
}, {
    name: 'Coarctation of the aorta'
}, {
    name: 'Coccidioidomycosis'
}, {
    name: 'Coccydynia'
}, {
    name: 'Cochlear toxicity'
}, {
    name: 'Coeliac disease'
}, {
    name: 'Cognitive deterioration'
}, {
    name: 'Cognitive disorder'
}, {
    name: 'Cognitive impairment'
}, {
    name: 'Cogwheel rigidity'
}, {
    name: 'Coital bleeding'
}, {
    name: 'Coitus interruptus'
}, {
    name: 'Cold feet'
}, {
    name: 'Cold hands'
}, {
    name: 'Cold hands & feet'
}, {
    name: 'Cold intolerance'
}, {
    name: 'Cold sweat'
}, {
    name: 'Cold symptoms'
}, {
    name: 'Cold urticaria'
}, {
    name: 'Coldness'
}, {
    name: 'Colitis'
}, {
    name: 'Colitis ischaemic'
}, {
    name: 'Colitis microscopic'
}, {
    name: 'Colitis ulcerative'
}, {
    name: 'Collagen disorder'
}, {
    name: 'Collagen-vascular disease'
}, {
    name: 'Collapse'
}, {
    name: 'Colon adenoma'
}, {
    name: 'Colon atonic'
}, {
    name: 'Colon cancer'
}, {
    name: 'Colon cancer stage III'
}, {
    name: 'Colon obstruction'
}, {
    name: 'Colonic abscess'
}, {
    name: 'Colonic polyp'
}, {
    name: 'Colonic pseudo-obstruction'
}, {
    name: 'Color vision change'
}, {
    name: 'Colorectal cancer'
}, {
    name: 'Colorectal cancer metastatic'
}, {
    name: 'Colorectal carcinoma'
}, {
    name: 'Colour blindness'
}, {
    name: 'Colour blindness acquired'
}, {
    name: 'Colpocele'
}, {
    name: 'Coma'
}, {
    name: 'Coma hepatic'
}, {
    name: 'Combined hyperlipidaemia'
}, {
    name: 'Comedone'
}, {
    name: 'Common cold'
}, {
    name: 'Common wart'
}, {
    name: 'Community acquired infection'
}, {
    name: 'Community acquired pneumonia'
}, {
    name: 'Compartment syndrome'
}, {
    name: 'Compensated cirrhosis'
}, {
    name: 'Complete hearing loss'
}, {
    name: 'Completed suicide'
}, {
    name: 'Complex partial seizures'
}, {
    name: 'Complex regional pain syndrome'
}, {
    name: 'Complication of delivery'
}, {
    name: 'Complication of device insertion'
}, {
    name: 'Complication of pregnancy'
}, {
    name: 'Complications of transplant surgery'
}, {
    name: 'Compression fracture'
}, {
    name: 'Compulsions'
}, {
    name: 'Compulsive personality disorder'
}, {
    name: 'Compulsive sexual behaviour'
}, {
    name: 'Compulsive shopping'
}, {
    name: 'Concussion'
}, {
    name: 'Condition aggravated'
}, {
    name: 'Conduct disorder'
}, {
    name: 'Conduction disorder'
}, {
    name: 'Condyloma'
}, {
    name: 'Confusion aggravated'
}, {
    name: 'Confusion postoperative'
}, {
    name: 'Confusional state'
}, {
    name: 'Congenital absence of bile ducts'
}, {
    name: 'Congenital adrenal hyperplasia'
}, {
    name: 'Congenital anomaly'
}, {
    name: 'Congenital aplastic anaemia'
}, {
    name: 'Congenital arterial malformation'
}, {
    name: 'Congenital central nervous system anomaly'
}, {
    name: 'Congenital clubfoot'
}, {
    name: 'Congenital cystic kidney disease'
}, {
    name: 'Congenital cytomegalovirus infection'
}, {
    name: 'Congenital diaphragmatic hernia'
}, {
    name: 'Congenital eye disorder'
}, {
    name: 'Congenital foot malformation'
}, {
    name: 'Congenital generalised lipodystrophy'
}, {
    name: 'Congenital genital malformation'
}, {
    name: 'Congenital genitourinary abnormality'
}, {
    name: 'Congenital herpes simplex infection'
}, {
    name: 'Congenital hydronephrosis'
}, {
    name: 'Congenital hypertrophic pyloric stenosis'
}, {
    name: 'Congenital hypothyroidism'
}, {
    name: 'Congenital joint malformation'
}, {
    name: 'Congenital limb hyperextension'
}, {
    name: 'Congenital megacolon'
}, {
    name: 'Congenital musculoskeletal anomaly'
}, {
    name: 'Congenital oral malformation'
}, {
    name: 'Congenital pulmonary valve atresia'
}, {
    name: 'Congenital renal cyst'
}, {
    name: 'Congenital skin disorder'
}, {
    name: 'Congenital syphilis'
}, {
    name: 'Congenital tricuspid valve atresia'
}, {
    name: 'Congenital vesicoureteric reflux'
}, {
    name: 'Congestive cardiomyopathy'
}, {
    name: 'Conjoined twins'
}, {
    name: 'Conjunctival bleb'
}, {
    name: 'Conjunctival congestion'
}, {
    name: 'Conjunctival cyst'
}, {
    name: 'Conjunctival discharge'
}, {
    name: 'Conjunctival disorder'
}, {
    name: 'Conjunctival follicles'
}, {
    name: 'Conjunctival haemorrhage'
}, {
    name: 'Conjunctival hyperaemia'
}, {
    name: 'Conjunctival irritation'
}, {
    name: 'Conjunctival oedema'
}, {
    name: 'Conjunctival ulcer'
}, {
    name: 'Conjunctival xerosis'
}, {
    name: 'Conjunctivitis'
}, {
    name: 'Conjunctivitis allergic'
}, {
    name: 'Conjunctivitis bacterial'
}, {
    name: 'Conjunctivitis exacerbated'
}, {
    name: 'Conjunctivitis infective'
}, {
    name: 'Conjunctivitis papillary'
}, {
    name: 'Connective tissue disorder'
}, {
    name: 'Connective tissue inflammation'
}, {
    name: 'Consciousness abnormal'
}, {
    name: 'Consciousness clouding'
}, {
    name: 'Constipation'
}, {
    name: 'Constipation aggravated'
}, {
    name: 'Constipation chronic'
}, {
    name: 'Contact lens intolerance'
}, {
    name: 'Contraceptive device complication'
}, {
    name: 'Contracted bladder'
}, {
    name: 'Contraction skeletal muscle'
}, {
    name: 'Contralateral breast cancer'
}, {
    name: 'Contrast media reaction'
}, {
    name: 'Contusion'
}, {
    name: 'Convalescence'
}, {
    name: 'Convalescent'
}, {
    name: 'Conversion disorder'
}, {
    name: 'Convulsion'
}, {
    name: 'Convulsion in childhood'
}, {
    name: 'Convulsion neonatal'
}, {
    name: 'Convulsions aggravated'
}, {
    name: 'Convulsions generalised'
}, {
    name: 'Convulsive disorder'
}, {
    name: 'Convulsive seizure'
}, {
    name: "Cooley's anemia"
}, {
    name: 'Coombs direct test positive'
}, {
    name: 'Coombs positive haemolytic anaemia'
}, {
    name: 'Coombs test positive'
}, {
    name: 'Coordination abnormal'
}, {
    name: 'Coordination disturbance'
}, {
    name: 'COPD exacerbation'
}, {
    name: 'Copper deficiency'
}, {
    name: 'Cor pulmonale'
}, {
    name: 'Corneal abrasion'
}, {
    name: 'Corneal calcification'
}, {
    name: 'Corneal decompensation'
}, {
    name: 'Corneal defect'
}, {
    name: 'Corneal degeneration'
}, {
    name: 'Corneal deposits'
}, {
    name: 'Corneal disorder'
}, {
    name: 'Corneal dystrophy'
}, {
    name: 'Corneal epithelium defect'
}, {
    name: 'Corneal epithelium disorder'
}, {
    name: 'Corneal erosion'
}, {
    name: 'Corneal infiltrates'
}, {
    name: 'Corneal irritation'
}, {
    name: 'Corneal lesion'
}, {
    name: 'Corneal oedema'
}, {
    name: 'Corneal opacity'
}, {
    name: 'Corneal perforation'
}, {
    name: 'Corneal pigmentation'
}, {
    name: 'Corneal scar'
}, {
    name: 'Corneal sensitivity decreased'
}, {
    name: 'Corneal staining'
}, {
    name: 'Corneal stromal edema'
}, {
    name: 'Corneal thinning'
}, {
    name: 'Corneal ulcer marginal'
}, {
    name: 'Corns'
}, {
    name: 'Coronary artery disease'
}, {
    name: 'Coronary artery disease aggravated'
}, {
    name: 'Coronary artery insufficiency'
}, {
    name: 'Coronary artery occlusion'
}, {
    name: 'Coronary artery stenosis'
}, {
    name: 'Coronary artery thrombosis'
}, {
    name: 'Coronary heart disease'
}, {
    name: 'Coronary stent thrombosis'
}, {
    name: 'Corpus callosum agenesis'
}, {
    name: 'Corpus luteum cyst'
}, {
    name: 'Corynebacterium infection'
}, {
    name: 'Coryza'
}, {
    name: 'Costochondritis'
}, {
    name: 'Costovertebral angle tenderness'
}, {
    name: 'Cotton wool spots'
}, {
    name: 'Cough'
}, {
    name: 'Cough decreased'
}, {
    name: 'Cough increased'
}, {
    name: 'Cough suppression'
}, {
    name: 'Coxalgia'
}, {
    name: 'Cramp muscle'
}, {
    name: 'Cramp of limb'
}, {
    name: 'Cramps of lower extremities'
}, {
    name: 'Cranial nerve disorder'
}, {
    name: 'Cranial nerve paralysis'
}, {
    name: 'Craniopharyngioma'
}, {
    name: 'Craniosynostosis'
}, {
    name: 'Creatine increased'
}, {
    name: 'Creatine phosphokinase increased'
}, {
    name: 'Creatine phosphokinase normal'
}, {
    name: 'Creatine phosphokinase serum increased'
}, {
    name: 'Creatinine abnormal NOS'
}, {
    name: 'Creatinine increased'
}, {
    name: 'Creatinine low'
}, {
    name: 'Creatinine normal'
}, {
    name: 'Creatinine renal clearance decreased'
}, {
    name: "Crohn's disease"
}, {
    name: "Crohn's ileocolitis"
}, {
    name: 'Crohns disease aggravated'
}, {
    name: 'Cross reactive drug hypersensitivity'
}, {
    name: 'Cross resistance'
}, {
    name: 'Croup'
}, {
    name: 'Croup infectious'
}, {
    name: 'Crying'
}, {
    name: 'Crying abnormal'
}, {
    name: 'Cryptococcal cutaneous infection'
}, {
    name: 'Cryptococcosis'
}, {
    name: 'Cryptorchism'
}, {
    name: 'Cryptosporidiosis infection'
}, {
    name: 'Crystal urine present'
}, {
    name: 'Crystalluria'
}, {
    name: 'Crystalluria calcium'
}, {
    name: 'Culture negative'
}, {
    name: 'Culture positive'
}, {
    name: "Cushing's syndrome"
}, {
    name: 'Cushingoid'
}, {
    name: 'Cutaneous T-cell lymphoma'
}, {
    name: 'Cutaneous hypersensitivity'
}, {
    name: 'Cutaneous larva migrans'
}, {
    name: 'Cutaneous lupus erythematosus'
}, {
    name: 'Cutaneous sarcoidosis'
}, {
    name: 'Cutaneous vasculitis'
}, {
    name: 'Cutis anserina'
}, {
    name: 'Cutis laxa'
}, {
    name: 'Cyanopsia'
}, {
    name: 'Cyanosis'
}, {
    name: 'Cyanosis peripheral'
}, {
    name: 'Cyanotic heart disease'
}, {
    name: 'Cyclic vomiting syndrome'
}, {
    name: 'Cyclitis'
}, {
    name: 'Cyclophoria'
}, {
    name: 'Cycloplegia'
}, {
    name: 'Cyclosporine toxicity'
}, {
    name: 'Cyclothymic disorder'
}, {
    name: 'Cyst'
}, {
    name: 'Cyst epidermal'
}, {
    name: 'Cystic fibrosis'
}, {
    name: 'Cystine urine'
}, {
    name: 'Cystine urine present'
}, {
    name: 'Cystinosis'
}, {
    name: 'Cystinuria'
}, {
    name: 'Cystitis'
}, {
    name: 'Cystitis haemorrhagic'
}, {
    name: 'Cystitis interstitial'
}, {
    name: 'Cystitis noninfective'
}, {
    name: 'Cystitis viral'
}, {
    name: 'Cystocele'
}, {
    name: 'Cystoid macular oedema'
}, {
    name: 'Cytarabine syndrome'
}, {
    name: 'Cytogenetic abnormality'
}, {
    name: 'Cytokine release syndrome'
}, {
    name: 'Cytolytic hepatitis'
}, {
    name: 'Cytomegalovirus chorioretinitis'
}, {
    name: 'Cytomegalovirus colitis'
}, {
    name: 'Cytomegalovirus gastritis'
}, {
    name: 'Cytomegalovirus hepatitis'
}, {
    name: 'Cytomegalovirus infection'
}, {
    name: 'Cytomegalovirus retinitis'
}, {
    name: 'Cytomegalovirus syndrome'
}, {
    name: 'Cytomegalovirus viraemia'
}, {
    name: 'Cytopenia'
}, {
    name: 'Cytotoxic oedema'
}, {
    name: 'Dacryoadenitis acquired'
}, {
    name: 'Dacryocanaliculitis'
}, {
    name: 'Dacryocystitis'
}, {
    name: 'Dacryostenosis acquired'
}, {
    name: 'Dactylitis'
}, {
    name: 'Dandruff'
}, {
    name: 'Dark circles under eyes'
}, {
    name: 'Daytime sleepiness'
}, {
    name: 'Dead foetus'
}, {
    name: 'Deafness'
}, {
    name: 'Deafness bilateral'
}, {
    name: 'Deafness neurosensory'
}, {
    name: 'Deafness permanent'
}, {
    name: 'Deafness transitory'
}, {
    name: 'Deafness unilateral'
}, {
    name: 'Death'
}, {
    name: 'Death neonatal'
}, {
    name: 'Decompensated cirrhosis'
}, {
    name: 'Decompensation cardiac'
}, {
    name: 'Decreased appetite'
}, {
    name: 'Decreased immune responsiveness'
}, {
    name: 'Decreased interest'
}, {
    name: 'Decreased night vision'
}, {
    name: 'Decreased tolerance'
}, {
    name: 'Decreased vibratory sense'
}, {
    name: 'Decubitus ulcer'
}, {
    name: 'Deep vein thrombosis'
}, {
    name: 'Deep vein thrombosis postoperative'
}, {
    name: 'Defaecation urgency'
}, {
    name: 'Defect conduction intraventricular'
}, {
    name: 'Defective colour vision'
}, {
    name: 'Deficiency anaemia'
}, {
    name: 'Deficiency of bile secretion'
}, {
    name: 'Degeneration of uterine fibroid'
}, {
    name: 'Degenerative myopia'
}, {
    name: 'Dehydration'
}, {
    name: 'Delayed delivery'
}, {
    name: 'Delayed gastric emptying'
}, {
    name: 'Delayed orgasm'
}, {
    name: 'Delayed puberty'
}, {
    name: 'Delayed recovery from anaesthesia'
}, {
    name: 'Delirium'
}, {
    name: 'Delirium toxic'
}, {
    name: 'Delirium tremens'
}, {
    name: 'Delusion'
}, {
    name: 'Delusion of grandeur'
}, {
    name: 'Delusional disorders'
}, {
    name: 'Delusional perception'
}, {
    name: 'Demented'
}, {
    name: 'Dementia'
}, {
    name: "Dementia Alzheimer's type"
}, {
    name: 'Dementia with Lewy bodies'
}, {
    name: 'Demyelinating polyneuropathy'
}, {
    name: 'Demyelination'
}, {
    name: 'Demyelination disorder NOS'
}, {
    name: 'Dendritic keratitis'
}, {
    name: 'Dental caries'
}, {
    name: 'Dental discomfort'
}, {
    name: 'Dentoalveolar abscess'
}, {
    name: 'Dentofacial anomaly'
}, {
    name: 'Dependence'
}, {
    name: 'Dependence on opiates'
}, {
    name: 'Dependence physiological'
}, {
    name: 'Dependence psychological'
}, {
    name: 'Depersonalisation'
}, {
    name: 'Depersonalization syndrome'
}, {
    name: 'Deposit calcium'
}, {
    name: 'Deposit eye'
}, {
    name: 'Depressed level of consciousness'
}, {
    name: 'Depressed mood'
}, {
    name: 'Depression'
}, {
    name: 'Depression aggravated'
}, {
    name: 'Depression suicidal'
}, {
    name: 'Depressive disorder'
}, {
    name: 'Depressive episode'
}, {
    name: 'Depressive symptom'
}, {
    name: 'Derealisation'
}, {
    name: 'Dermal cyst'
}, {
    name: 'Dermatillomania'
}, {
    name: 'Dermatitis'
}, {
    name: 'Dermatitis acneiform'
}, {
    name: 'Dermatitis atopic'
}, {
    name: 'Dermatitis bullous'
}, {
    name: 'Dermatitis contact'
}, {
    name: 'Dermatitis diaper'
}, {
    name: 'Dermatitis exfoliative'
}, {
    name: 'Dermatitis eyelid'
}, {
    name: 'Dermatitis flare-up'
}, {
    name: 'Dermatitis hemorrhagic'
}, {
    name: 'Dermatitis herpetiformis'
}, {
    name: 'Dermatitis infected'
}, {
    name: 'Dermatitis irritant contact'
}, {
    name: 'Dermatitis perioral'
}, {
    name: 'Dermatitis psoriasiform'
}, {
    name: 'Dermatitis radiation NOS'
}, {
    name: 'Dermatochalasis'
}, {
    name: 'Dermatofibrosarcoma protuberans'
}, {
    name: 'Dermatomyositis'
}, {
    name: 'Dermatophytosis'
}, {
    name: 'Dermoid cyst'
}, {
    name: 'Dermoid cyst of ovary'
}, {
    name: 'Descemetitis'
}, {
    name: 'Destructive thyroiditis'
}, {
    name: 'Detachment of retinal pigment epithelium'
}, {
    name: 'Detachment psychological'
}, {
    name: 'Detrusor hyperreflexia'
}, {
    name: 'Detrusor instability'
}, {
    name: 'Developmental coordination disorder'
}, {
    name: 'Developmental delay'
}, {
    name: 'Developmental glaucoma'
}, {
    name: 'Developmental hip dysplasia'
}, {
    name: 'Device breakage'
}, {
    name: 'Device capturing issue'
}, {
    name: 'Device dislocation'
}, {
    name: 'Device expulsion'
}, {
    name: 'Device interaction'
}, {
    name: 'Device malfunction'
}, {
    name: 'Device occlusion'
}, {
    name: 'Device related infection'
}, {
    name: 'Device related sepsis'
}, {
    name: 'Diabetes insipidus'
}, {
    name: 'Diabetes mellitus'
}, {
    name: 'Diabetes mellitus exacerbated'
}, {
    name: 'Diabetes mellitus inadequate control'
}, {
    name: 'Diabetic'
}, {
    name: 'Diabetic autonomic neuropathy'
}, {
    name: 'Diabetic coma'
}, {
    name: 'Diabetic complication'
}, {
    name: 'Diabetic foot infection'
}, {
    name: 'Diabetic gastroparesis'
}, {
    name: 'Diabetic hyperglycaemic coma'
}, {
    name: 'Diabetic hyperosmolar coma'
}, {
    name: 'Diabetic ketoacidosis'
}, {
    name: 'Diabetic macular edema'
}, {
    name: 'Diabetic nephropathy'
}, {
    name: 'Diabetic neuropathy'
}, {
    name: 'Diabetic peripheral neuropathic pain'
}, {
    name: 'Diabetic peripheral neuropathy'
}, {
    name: 'Diabetic retinal oedema'
}, {
    name: 'Diabetic retinopathy'
}, {
    name: 'Diabetic vascular disorder'
}, {
    name: 'Dialysis dementia'
}, {
    name: 'Diamond-Blackfan anemia'
}, {
    name: 'Diaphragmatic hernia'
}, {
    name: 'Diarrhoea'
}, {
    name: 'Diarrhoea haemorrhagic'
}, {
    name: 'Diarrhoea predominant irritable bowel syndrome'
}, {
    name: 'Diarrhoea, Clostridium difficile'
}, {
    name: 'Diastolic dysfunction'
}, {
    name: 'Diastolic hypertension'
}, {
    name: 'Diet refusal'
}, {
    name: 'Difficulty focusing eyes'
}, {
    name: 'Difficulty sleeping'
}, {
    name: 'Difficulty thinking'
}, {
    name: 'Diffuse alopecia'
}, {
    name: 'Diffuse large B-cell lymphoma'
}, {
    name: 'Digestion impaired'
}, {
    name: 'Digital ulcer'
}, {
    name: 'Digitalis intoxication (NOS)'
}, {
    name: 'Digitalis toxicity'
}, {
    name: 'Digoxin effect'
}, {
    name: 'Digoxin level increased'
}, {
    name: 'Digoxin toxicity'
}, {
    name: 'Dihydropyrimidine dehydrogenase deficiency'
}, {
    name: 'Dilatation atrial'
}, {
    name: 'Dilatation ventricular'
}, {
    name: 'Diphtheria'
}, {
    name: 'Diphyllobothriasis'
}, {
    name: 'Diplegia'
}, {
    name: 'Diplopia'
}, {
    name: 'Direct bilirubin increased'
}, {
    name: 'Disability'
}, {
    name: 'Discoid lupus erythematosus'
}, {
    name: 'Discomfort'
}, {
    name: 'Discomfort rectal'
}, {
    name: 'Disease progression'
}, {
    name: 'Disease recurrence'
}, {
    name: 'Disequilibrium syndrome'
}, {
    name: 'Disinhibition'
}, {
    name: 'Disorder birth'
}, {
    name: 'Disorder calcium (NOS)'
}, {
    name: 'Disorder periosteal'
}, {
    name: 'Disorder sight'
}, {
    name: 'Disorders of fluid, electrolyte and acid-base balance'
}, {
    name: 'Disorders of urea cycle metabolism'
}, {
    name: 'Disorientation'
}, {
    name: 'Disseminated adenocarcinoma'
}, {
    name: 'Disseminated intravascular coagulation'
}, {
    name: 'Disseminated mycobacterium avium complex infection'
}, {
    name: 'Disseminated tuberculosis'
}, {
    name: 'Dissociation'
}, {
    name: 'Dissociative disorder'
}, {
    name: 'Distention'
}, {
    name: 'Distractibility'
}, {
    name: 'Distress'
}, {
    name: 'Distress gastrointestinal'
}, {
    name: 'Disturbance in attention'
}, {
    name: 'Disturbance in sexual arousal'
}, {
    name: 'Disturbance in social behaviour'
}, {
    name: 'Disulfiram like reaction'
}, {
    name: 'Disuse muscle atrophy'
}, {
    name: 'Diuresis'
}, {
    name: 'Diuretic effect'
}, {
    name: 'Diverticular perforation'
}, {
    name: 'Diverticulitis'
}, {
    name: 'Diverticulitis aggravated'
}, {
    name: 'Diverticulum'
}, {
    name: 'Diverticulum intestinal'
}, {
    name: 'Dizziness'
}, {
    name: 'Dizziness aggravated'
}, {
    name: 'Dizziness exertional'
}, {
    name: 'Dizziness postural'
}, {
    name: 'Dizzy spells'
}, {
    name: 'Dreaming excessive'
}, {
    name: 'Dreamy state'
}, {
    name: 'Dribbling of urine'
}, {
    name: 'Drooling'
}, {
    name: 'Drop attacks'
}, {
    name: 'Dropped beats'
}, {
    name: 'Drowsiness'
}, {
    name: 'Drug - food interaction'
}, {
    name: 'Drug abuse'
}, {
    name: 'Drug administration error'
}, {
    name: 'Drug craving'
}, {
    name: 'Drug dependence'
}, {
    name: 'Drug effect decreased'
}, {
    name: 'Drug effect increased'
}, {
    name: 'Drug effect prolonged'
}, {
    name: 'Drug eruption'
}, {
    name: 'Drug fever'
}, {
    name: 'Drug hypersensitivity'
}, {
    name: 'Drug ineffective'
}, {
    name: 'Drug interaction'
}, {
    name: 'Drug intolerance'
}, {
    name: 'Drug level changed'
}, {
    name: 'Drug level decreased'
}, {
    name: 'Drug level increased'
}, {
    name: 'Drug level therapeutic'
}, {
    name: 'Drug maladministration'
}, {
    name: 'Drug reaction with eosinophilia and systemic symptoms'
}, {
    name: 'Drug screen positive'
}, {
    name: 'Drug seeking behavior'
}, {
    name: 'Drug tolerance'
}, {
    name: 'Drug tolerance decreased'
}, {
    name: 'Drug toxicity'
}, {
    name: 'Drug withdrawal convulsions'
}, {
    name: 'Drug withdrawal syndrome'
}, {
    name: 'Drug withdrawal syndrome neonatal'
}, {
    name: 'Drug-induced cough'
}, {
    name: 'Drug-induced hepatitis'
}, {
    name: 'Drug-induced hypersensitivity syndrome'
}, {
    name: 'Drug-induced liver injury'
}, {
    name: 'Drug-induced lupus erythematosus'
}, {
    name: 'Drug-induced parkinsonism'
}, {
    name: 'Dry cough'
}, {
    name: 'Dry eye'
}, {
    name: 'Dry eye syndrome'
}, {
    name: 'Dry hair'
}, {
    name: 'Dry mouth'
}, {
    name: 'Dry scalp'
}, {
    name: 'Dry skin'
}, {
    name: 'Dry throat'
}, {
    name: 'Dumping syndrome'
}, {
    name: 'Duodenal perforation'
}, {
    name: 'Duodenal ulcer'
}, {
    name: 'Duodenal ulcer aggravated'
}, {
    name: 'Duodenal ulcer haemorrhage'
}, {
    name: 'Duodenal ulcer perforation'
}, {
    name: 'Duodenitis'
}, {
    name: 'Duodenitis haemorrhagic'
}, {
    name: "Dupuytren's contracture"
}, {
    name: 'Dwarfism'
}, {
    name: 'Dysacusis'
}, {
    name: 'Dysaesthesia'
}, {
    name: 'Dysaesthesia pharynx'
}, {
    name: 'Dysarthria'
}, {
    name: 'Dysautonomia'
}, {
    name: 'Dyschezia'
}, {
    name: 'Dyschromatopsia'
}, {
    name: 'Dysdiadochokinesis'
}, {
    name: 'Dysentery'
}, {
    name: 'Dysequilibrium'
}, {
    name: 'Dysfunction adrenal'
}, {
    name: 'Dysfunction thyroid'
}, {
    name: 'Dysgeusia'
}, {
    name: 'Dysgraphia'
}, {
    name: 'Dyshidrotic eczema'
}, {
    name: 'Dyskinesia'
}, {
    name: 'Dyslexia'
}, {
    name: 'Dyslipidaemia'
}, {
    name: 'Dyslipoproteinaemia'
}, {
    name: 'Dysmenorrhoea'
}, {
    name: 'Dysmetria'
}, {
    name: 'Dysmorphism'
}, {
    name: 'Dysosmia'
}, {
    name: 'Dyspareunia'
}, {
    name: 'Dyspepsia'
}, {
    name: 'Dyspepsia aggravated'
}, {
    name: 'Dyspeptic signs and symptoms'
}, {
    name: 'Dysphagia'
}, {
    name: 'Dysphasia'
}, {
    name: 'Dysphemia'
}, {
    name: 'Dysphonia'
}, {
    name: 'Dysphoria'
}, {
    name: 'Dysplasia'
}, {
    name: 'Dyspnoea'
}, {
    name: 'Dyspnoea at rest'
}, {
    name: 'Dyspnoea exacerbated'
}, {
    name: 'Dyspnoea exertional'
}, {
    name: 'Dyspnoea paroxysmal nocturnal'
}, {
    name: 'Dyssomnia'
}, {
    name: 'Dysstasia'
}, {
    name: 'Dysthymic disorder'
}, {
    name: 'Dystonia'
}, {
    name: 'Dystonic reaction'
}, {
    name: 'Dystrophic calcification'
}, {
    name: 'Dysuria'
}, {
    name: 'Ear and labyrinth disorders'
}, {
    name: 'Ear buzzing'
}, {
    name: 'Ear canal erythema'
}, {
    name: 'Ear congestion'
}, {
    name: 'Ear discomfort'
}, {
    name: 'Ear disorder'
}, {
    name: 'Ear disorders NEC'
}, {
    name: 'Ear feels clogged'
}, {
    name: 'Ear haemorrhage'
}, {
    name: 'Ear infection'
}, {
    name: 'Ear malformation'
}, {
    name: 'Ear pain'
}, {
    name: 'Ear pruritus'
}, {
    name: 'Ear roaring'
}, {
    name: 'Early menarche'
}, {
    name: 'Early satiety'
}, {
    name: 'Eating disorder'
}, {
    name: 'Ecchymosis'
}, {
    name: 'ECG signs of myocardial ischaemia'
}, {
    name: 'Echinococciasis'
}, {
    name: 'Echoacousia'
}, {
    name: 'Echocardiogram abnormal'
}, {
    name: 'Echolalia'
}, {
    name: 'Eclampsia'
}, {
    name: 'Ecthyma'
}, {
    name: 'Ectopic ACTH syndrome'
}, {
    name: 'Ectopic ossification'
}, {
    name: 'Ectopic pregnancy'
}, {
    name: 'Ectromelia'
}, {
    name: 'Ectropion'
}, {
    name: 'Ectropion of cervix'
}, {
    name: 'Eczema'
}, {
    name: 'Eczema allergic atopic'
}, {
    name: 'Eczema exacerbated'
}, {
    name: 'Eczema eyelids'
}, {
    name: 'Eczema herpeticum'
}, {
    name: 'Eczema infantile'
}, {
    name: 'Eczema infected'
}, {
    name: 'Eczema nummular'
}, {
    name: 'Edema cerebral'
}, {
    name: 'Edema hands'
}, {
    name: 'Edema of lower extremities'
}, {
    name: 'Edema transient'
}, {
    name: 'Effusion'
}, {
    name: 'Effusion of knee'
}, {
    name: 'Ejaculation decreased'
}, {
    name: 'Ejaculation delayed'
}, {
    name: 'Ejaculation disorder'
}, {
    name: 'Ejaculation failure'
}, {
    name: 'Ejaculation inhibited'
}, {
    name: 'Ejection fraction decreased'
}, {
    name: 'Elastosis perforans'
}, {
    name: 'Electric shock'
}, {
    name: 'Electrocardiogram PR prolongation'
}, {
    name: 'Electrocardiogram PR shortened'
}, {
    name: 'Electrocardiogram QRS complex'
}, {
    name: 'Electrocardiogram QRS complex abnormal'
}, {
    name: 'Electrocardiogram QRS complex prolonged'
}, {
    name: 'Electrocardiogram QT corrected interval'
}, {
    name: 'Electrocardiogram QT corrected interval prolonged'
}, {
    name: 'Electrocardiogram QT interval'
}, {
    name: 'Electrocardiogram QT interval abnormal'
}, {
    name: 'Electrocardiogram QT prolonged'
}, {
    name: 'Electrocardiogram QT shortened'
}, {
    name: 'Electrocardiogram ST segment'
}, {
    name: 'Electrocardiogram ST segment abnormal'
}, {
    name: 'Electrocardiogram ST segment depression'
}, {
    name: 'Electrocardiogram ST segment elevation'
}, {
    name: 'Electrocardiogram ST-T change'
}, {
    name: 'Electrocardiogram ST-T segment abnormal'
}, {
    name: 'Electrocardiogram T wave abnormal'
}, {
    name: 'Electrocardiogram T wave amplitude decreased'
}, {
    name: 'Electrocardiogram T wave inversion'
}, {
    name: 'Electrocardiogram U wave present'
}, {
    name: 'Electrocardiogram U-wave abnormality'
}, {
    name: 'Electrocardiogram abnormal'
}, {
    name: 'Electrocardiogram abnormal specific'
}, {
    name: 'Electrocardiogram change'
}, {
    name: 'Electrocardiogram normal'
}, {
    name: 'Electrocardiogram poor R-wave progression'
}, {
    name: 'Electrocardiogram repolarisation abnormality'
}, {
    name: 'Electroencephalogram abnormal'
}, {
    name: 'Electrolyte abnormality'
}, {
    name: 'Electrolyte depletion'
}, {
    name: 'Electrolyte disturbance'
}, {
    name: 'Electrolyte imbalance'
}, {
    name: 'Electrolytes NOS decreased'
}, {
    name: 'Electroretinogram abnormal'
}, {
    name: 'Elevated liver enzyme levels'
}, {
    name: 'Elevated mood'
}, {
    name: 'Embolic stroke'
}, {
    name: 'Embolism'
}, {
    name: 'Embolism arterial'
}, {
    name: 'Embolism arterial (limb)'
}, {
    name: 'Embolism limb'
}, {
    name: 'Embolism venous'
}, {
    name: 'Embolus'
}, {
    name: 'Embolus leg'
}, {
    name: 'Emotional disorder'
}, {
    name: 'Emotional distress'
}, {
    name: 'Emotional disturbance NOS'
}, {
    name: 'Emotional poverty'
}, {
    name: 'Emotional problems'
}, {
    name: 'Emphysema'
}, {
    name: 'Emprosthotonus'
}, {
    name: 'Empty sella syndrome'
}, {
    name: 'Empyema'
}, {
    name: 'Enanthema'
}, {
    name: 'Encephalitis'
}, {
    name: 'Encephalitis cytomegalovirus'
}, {
    name: 'Encephalitis viral'
}, {
    name: 'Encephalocele'
}, {
    name: 'Encephalomyelitis'
}, {
    name: 'Encephalopathy'
}, {
    name: 'Encephalopathy acute'
}, {
    name: 'End stage AIDS'
}, {
    name: 'End stage cancer'
}, {
    name: 'End stage liver disease'
}, {
    name: 'Endocardial fibrosis'
}, {
    name: 'Endocarditis'
}, {
    name: 'Endocarditis bacterial'
}, {
    name: 'Endocarditis staphylococcal'
}, {
    name: 'Endocrine disorder'
}, {
    name: 'Endocrine disorders congenital'
}, {
    name: 'Endocrine neoplasm'
}, {
    name: 'Endocrine neoplasms malignant and unspecified'
}, {
    name: 'Endogenous depression'
}, {
    name: 'Endometrial adenocarcinoma'
}, {
    name: 'Endometrial cancer'
}, {
    name: 'Endometrial cancer stage IV'
}, {
    name: 'Endometrial disorder'
}, {
    name: 'Endometrial hyperplasia'
}, {
    name: 'Endometrial hypertrophy'
}, {
    name: 'Endometrial neoplasm'
}, {
    name: 'Endometrial neoplasm malignant'
}, {
    name: 'Endometrial thickening'
}, {
    name: 'Endometriosis'
}, {
    name: 'Endometritis'
}, {
    name: 'Endomyometritis'
}, {
    name: 'Endophthalmitis'
}, {
    name: 'Endotracheal intubation complication'
}, {
    name: 'Endotracheal tube obstruction'
}, {
    name: 'Energy increased'
}, {
    name: 'Enlarged clitoris'
}, {
    name: 'Enlargement abdomen'
}, {
    name: 'Enophthalmos'
}, {
    name: 'Enteritis'
}, {
    name: 'Enteritis ulcerative'
}, {
    name: 'Enterobacter sepsis'
}, {
    name: 'Enterobiasis'
}, {
    name: 'Enterococcal bacteraemia'
}, {
    name: 'Enterococcal infection'
}, {
    name: 'Enterocolitis'
}, {
    name: 'Enterocolitis haemorrhagic'
}, {
    name: 'Enterocolitis infectious'
}, {
    name: 'Enterocutaneous fistula'
}, {
    name: 'Enuresis'
}, {
    name: 'Environmental exposure'
}, {
    name: 'Enzyme abnormality'
}, {
    name: 'Enzyme induction'
}, {
    name: 'Enzyme inhibition'
}, {
    name: 'Eosinopenia'
}, {
    name: 'Eosinophil count abnormal'
}, {
    name: 'Eosinophil count increased'
}, {
    name: 'Eosinophilia'
}, {
    name: 'Eosinophilic cystitis'
}, {
    name: 'Eosinophilic myocarditis'
}, {
    name: 'Eosinophilic pneumonia'
}, {
    name: 'Eosinophilic pustular folliculitis'
}, {
    name: 'Eosinophiluria'
}, {
    name: 'Ependymoma'
}, {
    name: 'Ephelides'
}, {
    name: 'Epicondylitis'
}, {
    name: 'Epidemic typhus'
}, {
    name: 'Epidermal and dermal conditions'
}, {
    name: 'Epidermal growth factor receptor decreased'
}, {
    name: 'Epidermal naevus'
}, {
    name: 'Epidermal necrosis'
}, {
    name: 'Epidermolysis'
}, {
    name: 'Epidermolysis bullosa'
}, {
    name: 'Epididymal tenderness'
}, {
    name: 'Epididymitis'
}, {
    name: 'Epididymo-orchitis'
}, {
    name: 'Epidural haemorrhage'
}, {
    name: 'Epidural lipomatosis'
}, {
    name: 'Epigastric discomfort'
}, {
    name: 'Epigastric distress'
}, {
    name: 'Epigastric fullness'
}, {
    name: 'Epigastric pain'
}, {
    name: 'Epigastric pain not food-related'
}, {
    name: 'Epiglottitis'
}, {
    name: 'Epilepsy'
}, {
    name: 'Epilepsy aggravated'
}, {
    name: 'Epiphyses premature fusion'
}, {
    name: 'Epiphysiolysis'
}, {
    name: 'Episcleritis'
}, {
    name: 'Epistaxis'
}, {
    name: 'Epithelial cells urine'
}, {
    name: 'Epstein-Barr virus infection'
}, {
    name: 'Equilibrium loss'
}, {
    name: 'Erectile dysfunction'
}, {
    name: 'Erection increased'
}, {
    name: 'Erection prolonged'
}, {
    name: 'Ergot poisoning'
}, {
    name: 'Erosive gastroduodenitis'
}, {
    name: 'Erosive oesophagitis'
}, {
    name: 'Eructation'
}, {
    name: 'Eruption'
}, {
    name: 'Eruption lichenoid'
}, {
    name: 'Eruptive xanthoma'
}, {
    name: 'Erysipelas'
}, {
    name: 'Erysipeloid'
}, {
    name: 'Erythema'
}, {
    name: 'Erythema annulare'
}, {
    name: 'Erythema annulare centrifugum'
}, {
    name: 'Erythema facial'
}, {
    name: 'Erythema infectiosum'
}, {
    name: 'Erythema migrans'
}, {
    name: 'Erythema multiforme'
}, {
    name: 'Erythema multiforme minor'
}, {
    name: 'Erythema multiforme severe'
}, {
    name: 'Erythema nodosum'
}, {
    name: 'Erythema nodosum leprosum'
}, {
    name: 'Erythema of eyelid'
}, {
    name: 'Erythema periorbital'
}, {
    name: 'Erythrasma'
}, {
    name: 'Erythroblastopenia'
}, {
    name: 'Erythrocytosis'
}, {
    name: 'Erythrodermic psoriasis'
}, {
    name: 'Erythroleukaemia'
}, {
    name: 'Erythromelalgia'
}, {
    name: 'Erythropenia'
}, {
    name: 'Erythropoiesis abnormal'
}, {
    name: 'Erythropoietic protoporphyria'
}, {
    name: 'Erythropsia'
}, {
    name: 'Erythrosis'
}, {
    name: 'Eschar'
}, {
    name: 'Escherichia bacteraemia'
}, {
    name: 'Escherichia coli infection'
}, {
    name: 'Escherichia infection'
}, {
    name: 'Escherichia sepsis'
}, {
    name: 'Esophageal erosions'
}, {
    name: 'Esotropia'
}, {
    name: 'Essential hypertension'
}, {
    name: 'Essential thrombocythaemia'
}, {
    name: 'Essential tremor'
}, {
    name: 'Estrangement'
}, {
    name: 'Euphoric mood'
}, {
    name: 'Eustachian tube disorder'
}, {
    name: 'Euthyroid goiter'
}, {
    name: 'Evans syndrome'
}, {
    name: "Ewing's sarcoma"
}, {
    name: 'Exacerbation of acne'
}, {
    name: 'Exacerbation of asthma'
}, {
    name: 'Exacerbation of hot flushes'
}, {
    name: 'Exaggerated startle response'
}, {
    name: 'Excessive daytime sleepiness'
}, {
    name: 'Excessive flatulence'
}, {
    name: 'Excessive granulation tissue'
}, {
    name: 'Excessive thirst'
}, {
    name: 'Excitability'
}, {
    name: 'Excitable'
}, {
    name: 'Excitation cerebral'
}, {
    name: 'Excitement'
}, {
    name: 'Excoriation'
}, {
    name: 'Exencephaly'
}, {
    name: 'Exercise induced angina'
}, {
    name: 'Exercise-induced anaphylaxis'
}, {
    name: 'Exercise-induced bronchospasm'
}, {
    name: 'Exfoliative conditions'
}, {
    name: 'Exfoliative rash'
}, {
    name: 'Exhaustion'
}, {
    name: 'Exomphalos'
}, {
    name: 'Exophthalmos'
}, {
    name: 'Exostosis'
}, {
    name: 'Explosive personality disorder'
}, {
    name: 'Exposure to lead'
}, {
    name: 'Exposure to poisonous plant'
}, {
    name: 'Exposure to toxic agent'
}, {
    name: 'Expressive language disorder'
}, {
    name: 'Extensive burns'
}, {
    name: 'Extensor plantar response'
}, {
    name: 'External ear disorder'
}, {
    name: 'External ophthalmoplegia'
}, {
    name: 'Extradural abscess'
}, {
    name: 'Extranodal NK/T-cell lymphoma, nasal type'
}, {
    name: 'Extranodal marginal zone B-cell lymphoma (MALT type)'
}, {
    name: 'Extrapulmonary pneumocystosis'
}, {
    name: 'Extrapulmonary tuberculosis'
}, {
    name: 'Extrapyramidal disorder'
}, {
    name: 'Extrapyramidal symptoms'
}, {
    name: 'Extraskeletal ossification'
}, {
    name: 'Extrasystoles'
}, {
    name: 'Extravasation'
}, {
    name: 'Extremity contracture'
}, {
    name: 'Extremity necrosis'
}, {
    name: 'Eye allergy'
}, {
    name: 'Eye bleeding'
}, {
    name: 'Eye burns'
}, {
    name: 'Eye discharge'
}, {
    name: 'Eye disorder'
}, {
    name: 'Eye haemorrhage'
}, {
    name: 'Eye infection'
}, {
    name: 'Eye infection bacterial'
}, {
    name: 'Eye infection viral'
}, {
    name: 'Eye injury'
}, {
    name: 'Eye irritation'
}, {
    name: 'Eye movement disorder'
}, {
    name: 'Eye naevus'
}, {
    name: 'Eye oedema'
}, {
    name: 'Eye pain'
}, {
    name: 'Eye penetration'
}, {
    name: 'Eye pruritus'
}, {
    name: 'Eye redness'
}, {
    name: 'Eye rolling'
}, {
    name: 'Eye swelling'
}, {
    name: 'Eye ulcer'
}, {
    name: 'Eyebrow loss of'
}, {
    name: 'Eyelash darkening'
}, {
    name: 'Eyelash discolouration'
}, {
    name: 'Eyelash hyperpigmentation'
}, {
    name: 'Eyelash thickening'
}, {
    name: 'Eyelid bleeding'
}, {
    name: 'Eyelid disorder'
}, {
    name: 'Eyelid exfoliation'
}, {
    name: 'Eyelid function disorder'
}, {
    name: 'Eyelid infection'
}, {
    name: 'Eyelid irritation'
}, {
    name: 'Eyelid margin crusting'
}, {
    name: 'Eyelid oedema'
}, {
    name: 'Eyelid pain'
}, {
    name: 'Eyelid ptosis'
}, {
    name: 'Eyelid retraction'
}, {
    name: 'Eyelids pruritus'
}, {
    name: 'Face injury'
}, {
    name: 'Face oedema'
}, {
    name: 'Facial bones fracture'
}, {
    name: 'Facial neuralgia'
}, {
    name: 'Facial pain'
}, {
    name: 'Facial paralysis'
}, {
    name: 'Facial paresis'
}, {
    name: 'Facial paresthesia'
}, {
    name: 'Facial rash'
}, {
    name: 'Facial spasm'
}, {
    name: 'Facial wasting'
}, {
    name: 'Factor I deficiency'
}, {
    name: 'Factor II deficiency'
}, {
    name: 'Factor IX deficiency'
}, {
    name: 'Factor VIII deficiency'
}, {
    name: 'Factor XI deficiency'
}, {
    name: 'Faecal incontinence'
}, {
    name: 'Faecal occult blood positive'
}, {
    name: 'Faecalith'
}, {
    name: 'Faecaloma'
}, {
    name: 'Faeces discoloured'
}, {
    name: 'Faeces hard'
}, {
    name: 'Failed induction of labour'
}, {
    name: 'Failure to thrive'
}, {
    name: 'Falciparum malaria'
}, {
    name: 'Fall'
}, {
    name: 'Fallopian tube cyst'
}, {
    name: 'Fallopian tube obstruction'
}, {
    name: "Fallot's tetralogy"
}, {
    name: 'Familial periodic paralysis'
}, {
    name: 'Familial pulmonary arterial hypertension'
}, {
    name: 'Familial tremor'
}, {
    name: 'Family stress'
}, {
    name: 'Fanconi syndrome'
}, {
    name: 'Fanconi syndrome acquired'
}, {
    name: 'Fasciculation'
}, {
    name: 'Fasciitis'
}, {
    name: 'Fasting'
}, {
    name: 'Fasting blood glucose increased'
}, {
    name: 'Fasting hyperglycaemia'
}, {
    name: 'Fat atrophy'
}, {
    name: 'Fat embolism'
}, {
    name: 'Fat intolerance'
}, {
    name: 'Fat necrosis'
}, {
    name: 'Fat redistribution'
}, {
    name: 'Fat tissue increased'
}, {
    name: 'Fatal outcomes'
}, {
    name: 'Fatigability'
}, {
    name: 'Fatigue'
}, {
    name: 'Fatigue aggravated'
}, {
    name: 'Fear'
}, {
    name: 'Fear of death'
}, {
    name: 'Febrile bone marrow aplasia'
}, {
    name: 'Febrile convulsion'
}, {
    name: 'Febrile disorders'
}, {
    name: 'Febrile neutropenia'
}, {
    name: 'Feces bloodstained'
}, {
    name: 'Feeling abnormal'
}, {
    name: 'Feeling cold'
}, {
    name: 'Feeling drunk'
}, {
    name: 'Feeling guilty'
}, {
    name: 'Feeling hot'
}, {
    name: 'Feeling hot and cold'
}, {
    name: 'Feeling jittery'
}, {
    name: 'Feeling of body temperature change'
}, {
    name: 'Feeling of despair'
}, {
    name: 'Feeling of relaxation'
}, {
    name: 'Feeling of residual urine'
}, {
    name: 'Feeling sad'
}, {
    name: 'Feeling sick'
}, {
    name: 'Feeling strange'
}, {
    name: 'Feeling tense'
}, {
    name: 'Feelings of worthlessness'
}, {
    name: 'Felt faint'
}, {
    name: "Felty's syndrome"
}, {
    name: 'Female orgasmic disorder'
}, {
    name: 'Female reproductive neoplasm'
}, {
    name: 'Female sexual arousal disorder'
}, {
    name: 'Female sexual dysfunction'
}, {
    name: 'Feminisation acquired'
}, {
    name: 'Feminization'
}, {
    name: 'Femoral artery thrombosis'
}, {
    name: 'Femoral neck fracture'
}, {
    name: 'Femur fracture'
}, {
    name: 'Femur fracture subtrochanteric'
}, {
    name: 'Femur shaft fracture'
}, {
    name: 'Fertility female decreased'
}, {
    name: 'Fertility male decreased'
}, {
    name: 'Fertilization'
}, {
    name: 'Festinating gait'
}, {
    name: 'Fever chills'
}, {
    name: 'Fever neonatal'
}, {
    name: 'Fever of unknown origin'
}, {
    name: 'Fibrillation atrial aggravated'
}, {
    name: 'Fibrinogen decreased'
}, {
    name: 'Fibroadenoma of breast'
}, {
    name: 'Fibroadenosis of breast'
}, {
    name: 'Fibrocystic breast disease'
}, {
    name: 'Fibrocystic disease'
}, {
    name: 'Fibroma'
}, {
    name: 'Fibromyalgia'
}, {
    name: 'Fibrosis'
}, {
    name: 'Filariasis'
}, {
    name: 'Filariasis lymphatic'
}, {
    name: 'Finger deformity'
}, {
    name: 'Fistula'
}, {
    name: 'Fixed drug eruption'
}, {
    name: 'Fixed eruption'
}, {
    name: 'Flank pain'
}, {
    name: 'Flashback'
}, {
    name: 'Flat affect'
}, {
    name: 'Flatulence'
}, {
    name: 'Flight of ideas'
}, {
    name: 'Floating feeling'
}, {
    name: 'Floppy infant'
}, {
    name: 'Floppy iris syndrome'
}, {
    name: 'Flu symptoms'
}, {
    name: 'Fluid and electrolyte imbalance'
}, {
    name: 'Fluid imbalance'
}, {
    name: 'Fluid intake increased'
}, {
    name: 'Fluid intake reduced'
}, {
    name: 'Fluid loss'
}, {
    name: 'Fluid overload'
}, {
    name: 'Fluid retention'
}, {
    name: 'Fluoride increased'
}, {
    name: 'Fluorosis'
}, {
    name: 'Flushing'
}, {
    name: 'Focal segmental glomerulosclerosis'
}, {
    name: 'Foetal acidosis'
}, {
    name: 'Foetal alcohol syndrome'
}, {
    name: 'Foetal anticonvulsant syndrome'
}, {
    name: 'Foetal chromosome abnormality'
}, {
    name: 'Foetal damage'
}, {
    name: 'Foetal death'
}, {
    name: 'Foetal disorder'
}, {
    name: 'Foetal distress syndrome'
}, {
    name: 'Foetal heart rate'
}, {
    name: 'Foetor hepaticus'
}, {
    name: 'Folate deficiency'
}, {
    name: 'Follicular conjunctivitis'
}, {
    name: 'Follicular thyroid cancer'
}, {
    name: 'Folliculitis'
}, {
    name: 'Fontanelle bulging'
}, {
    name: 'Food allergy'
}, {
    name: 'Food aversion'
}, {
    name: 'Food craving'
}, {
    name: 'Food interaction'
}, {
    name: 'Food intolerance'
}, {
    name: 'Food poisoning'
}, {
    name: 'Foot and mouth disease'
}, {
    name: 'Foot edema'
}, {
    name: 'Foot fracture'
}, {
    name: 'Foot infection fungal NOS'
}, {
    name: 'Foot pain'
}, {
    name: 'Footdrop'
}, {
    name: 'Foramen ovale patent'
}, {
    name: 'Forced expiratory volume decreased'
}, {
    name: 'Foreign body'
}, {
    name: 'Foreign body in eye'
}, {
    name: 'Foreign body sensation in eyes'
}, {
    name: 'Forgetfulness'
}, {
    name: 'Formication'
}, {
    name: 'Found dead'
}, {
    name: 'Found dead (cause undetermined)'
}, {
    name: 'Fraction of inspired oxygen'
}, {
    name: 'Fracture'
}, {
    name: 'Frank hematuria'
}, {
    name: 'Fredrickson Type III lipidemia'
}, {
    name: 'Free prostate-specific antigen increased'
}, {
    name: 'Freezing phenomenon'
}, {
    name: 'Frequent bowel movements'
}, {
    name: 'Frequent headaches'
}, {
    name: 'Friction rub'
}, {
    name: 'Frigidity'
}, {
    name: 'Frozen shoulder'
}, {
    name: 'Fructose intolerance'
}, {
    name: 'Frustration'
}, {
    name: 'Fullness abdominal'
}, {
    name: 'Function kidney decreased'
}, {
    name: 'Function liver decreased'
}, {
    name: 'Functional dyspepsia'
}, {
    name: 'Functional gastrointestinal disorder'
}, {
    name: 'Fundic gland polyp'
}, {
    name: 'Fungaemia'
}, {
    name: 'Fungal infection'
}, {
    name: 'Fungal peritonitis'
}, {
    name: 'Fungal rash'
}, {
    name: 'Fungal sepsis'
}, {
    name: 'Fungal skin infection'
}, {
    name: 'Fungal test positive'
}, {
    name: 'Fungus sputum test positive'
}, {
    name: 'Furuncle'
}, {
    name: 'Furunculosis'
}, {
    name: 'Fusarium infection'
}, {
    name: 'Fuzzy head'
}, {
    name: 'Gagging'
}, {
    name: 'Gait disturbance'
}, {
    name: 'Gait shuffling'
}, {
    name: 'Galactorrhoea'
}, {
    name: 'Gallbladder cancer'
}, {
    name: 'Gallbladder disorder'
}, {
    name: 'Gallbladder infection'
}, {
    name: 'Gallbladder polyp'
}, {
    name: 'Gallbladder sludge'
}, {
    name: 'Gallop rhythm'
}, {
    name: 'Gamma globulins increased'
}, {
    name: 'Gamma-glutamyltransferase increased'
}, {
    name: 'Gammaglobulins decreased'
}, {
    name: 'Gangrene'
}, {
    name: 'Gangrenous cholecystitis'
}, {
    name: 'Gas'
}, {
    name: 'Gas gangrene'
}, {
    name: 'Gas in stomach'
}, {
    name: 'Gas pain'
}, {
    name: 'Gasping'
}, {
    name: 'Gastric atony'
}, {
    name: 'Gastric cancer'
}, {
    name: 'Gastric dilatation'
}, {
    name: 'Gastric disorder'
}, {
    name: 'Gastric erosions'
}, {
    name: 'Gastric flu'
}, {
    name: 'Gastric haemorrhage'
}, {
    name: 'Gastric irritation'
}, {
    name: 'Gastric pH decreased'
}, {
    name: 'Gastric perforation'
}, {
    name: 'Gastric polyps'
}, {
    name: 'Gastric ulcer'
}, {
    name: 'Gastric ulcer haemorrhage'
}, {
    name: 'Gastric ulcer helicobacter'
}, {
    name: 'Gastric ulcer perforation'
}, {
    name: 'Gastrinoma'
}, {
    name: 'Gastritis'
}, {
    name: 'Gastritis aggravated'
}, {
    name: 'Gastritis atrophic'
}, {
    name: 'Gastritis erosive'
}, {
    name: 'Gastritis haemorrhagic'
}, {
    name: 'Gastritis viral'
}, {
    name: 'Gastroduodenitis'
}, {
    name: 'Gastroenteritis'
}, {
    name: 'Gastroenteritis adenovirus'
}, {
    name: 'Gastroenteritis bacterial'
}, {
    name: 'Gastroenteritis salmonella'
}, {
    name: 'Gastroenteritis staphylococcal'
}, {
    name: 'Gastroenteritis yersinia'
}, {
    name: 'Gastroesophageal varices'
}, {
    name: 'Gastrointestinal candidiasis'
}, {
    name: 'Gastrointestinal carcinoma'
}, {
    name: 'Gastrointestinal cramps'
}, {
    name: 'Gastrointestinal discomfort'
}, {
    name: 'Gastrointestinal disorder'
}, {
    name: 'Gastrointestinal fistula'
}, {
    name: 'Gastrointestinal fullness'
}, {
    name: 'Gastrointestinal fungal infection'
}, {
    name: 'Gastrointestinal haemorrhage'
}, {
    name: 'Gastrointestinal hypermotility'
}, {
    name: 'Gastrointestinal hypomotility'
}, {
    name: 'Gastrointestinal infection'
}, {
    name: 'Gastrointestinal inflammation'
}, {
    name: 'Gastrointestinal inflammatory conditions'
}, {
    name: 'Gastrointestinal malformation'
}, {
    name: 'Gastrointestinal motility disorder'
}, {
    name: 'Gastrointestinal necrosis'
}, {
    name: 'Gastrointestinal neoplasm'
}, {
    name: 'Gastrointestinal neoplasm malignant'
}, {
    name: 'Gastrointestinal obstruction'
}, {
    name: 'Gastrointestinal pain'
}, {
    name: 'Gastrointestinal perforation'
}, {
    name: 'Gastrointestinal signs and symptoms'
}, {
    name: 'Gastrointestinal signs and symptoms NEC'
}, {
    name: 'Gastrointestinal sounds abnormal'
}, {
    name: 'Gastrointestinal stoma complication'
}, {
    name: 'Gastrointestinal stromal tumour'
}, {
    name: 'Gastrointestinal symptom NOS'
}, {
    name: 'Gastrointestinal toxicity'
}, {
    name: 'Gastrointestinal tract irritation'
}, {
    name: 'Gastrointestinal ulcer'
}, {
    name: 'Gastrointestinal ulcer haemorrhage'
}, {
    name: 'Gastrointestinal ulcer perforation'
}, {
    name: 'Gastrooesophageal cancer'
}, {
    name: 'Gastrooesophageal reflux disease'
}, {
    name: 'Gastrooesophageal sphincter insufficiency'
}, {
    name: 'Gastrooesophagitis'
}, {
    name: "Gaucher's disease"
}, {
    name: 'Gaze palsy'
}, {
    name: 'General discomfort'
}, {
    name: 'General disorders and administration site conditions'
}, {
    name: 'General physical health deterioration'
}, {
    name: 'General symptom'
}, {
    name: 'Generalised anxiety disorder'
}, {
    name: 'Generalised erythema'
}, {
    name: 'Generalised oedema'
}, {
    name: 'Generalised spasm'
}, {
    name: 'Generalized aching'
}, {
    name: 'Generalized flushing'
}, {
    name: 'Generalized illness'
}, {
    name: 'Generalized lymphadenopathy'
}, {
    name: 'Generalized macular rash'
}, {
    name: 'Generalized urticaria'
}, {
    name: 'Genetic polymorphism'
}, {
    name: 'Genital burning sensation'
}, {
    name: 'Genital candidiasis'
}, {
    name: 'Genital discharge'
}, {
    name: 'Genital discomfort'
}, {
    name: 'Genital disorder female'
}, {
    name: 'Genital disorder male'
}, {
    name: 'Genital haemorrhage'
}, {
    name: 'Genital herpes'
}, {
    name: 'Genital hypoaesthesia'
}, {
    name: 'Genital infection'
}, {
    name: 'Genital infection female'
}, {
    name: 'Genital infection fungal'
}, {
    name: 'Genital infection male'
}, {
    name: 'Genital injury'
}, {
    name: 'Genital irritation'
}, {
    name: 'Genital itching female'
}, {
    name: 'Genital itching male'
}, {
    name: 'Genital lesion'
}, {
    name: 'Genital pain'
}, {
    name: 'Genital pain male'
}, {
    name: 'Genital rash'
}, {
    name: 'Genital swelling'
}, {
    name: 'Genital ulceration'
}, {
    name: 'Genitourinary chlamydia infection'
}, {
    name: 'Genitourinary tract infection'
}, {
    name: 'Genitourinary tract neoplasm'
}, {
    name: 'Genu valgum'
}, {
    name: 'Germ cell cancer'
}, {
    name: 'Germinoma'
}, {
    name: 'Gestational diabetes'
}, {
    name: 'Gestational hypertension'
}, {
    name: 'Gestational trophoblastic tumour'
}, {
    name: 'Giant cell arteritis'
}, {
    name: 'Giant papillary conjunctivitis'
}, {
    name: 'Giardiasis'
}, {
    name: 'Gigantism'
}, {
    name: "Gilbert's syndrome"
}, {
    name: 'Gingival abscess'
}, {
    name: 'Gingival bleeding'
}, {
    name: 'Gingival blister'
}, {
    name: 'Gingival disorder'
}, {
    name: 'Gingival erythema'
}, {
    name: 'Gingival hyperplasia'
}, {
    name: 'Gingival hypertrophy'
}, {
    name: 'Gingival infection'
}, {
    name: 'Gingival oedema'
}, {
    name: 'Gingival pain'
}, {
    name: 'Gingival recession'
}, {
    name: 'Gingival swelling'
}, {
    name: 'Gingival ulceration'
}, {
    name: 'Gingivitis'
}, {
    name: 'Gingivitis ulcerative'
}, {
    name: 'Gingivostomatitis'
}, {
    name: 'Glabellar reflex abnormal'
}, {
    name: 'Glaucoma'
}, {
    name: 'Glaucoma both eyes'
}, {
    name: 'Glioblastoma'
}, {
    name: 'Glioblastoma multiforme'
}, {
    name: 'Glioma'
}, {
    name: 'Globulins decreased'
}, {
    name: 'Globus hystericus'
}, {
    name: 'Glomerular filtration rate decreased'
}, {
    name: 'Glomerulitis'
}, {
    name: 'Glomerulonephritis'
}, {
    name: 'Glomerulonephritis acute'
}, {
    name: 'Glomerulonephritis chronic'
}, {
    name: 'Glomerulonephritis membranoproliferative'
}, {
    name: 'Glomerulonephritis membranous'
}, {
    name: 'Glomerulonephritis minimal lesion'
}, {
    name: 'Glomerulonephritis rapidly progressive'
}, {
    name: 'Glomerulonephropathy'
}, {
    name: 'Glomerulosclerosis'
}, {
    name: 'Glossitis'
}, {
    name: 'Glossodynia'
}, {
    name: 'Glossopharyngeal neuralgia'
}, {
    name: 'Glottic edema'
}, {
    name: 'Glucagonoma'
}, {
    name: 'Glucocorticoids decreased'
}, {
    name: 'Glucose decreased'
}, {
    name: 'Glucose increased'
}, {
    name: 'Glucose low'
}, {
    name: 'Glucose metabolism abnormal'
}, {
    name: 'Glucose normal'
}, {
    name: 'Glucose tolerance abnormal'
}, {
    name: 'Glucose tolerance decreased'
}, {
    name: 'Glucose tolerance impaired'
}, {
    name: 'Glucose urine increased'
}, {
    name: 'Glucose-6-phosphate dehydrogenase deficiency'
}, {
    name: 'Glucose-galactose malabsorption'
}, {
    name: 'Gluten free diet'
}, {
    name: 'Glycogen storage disorder'
}, {
    name: 'Glycosuria'
}, {
    name: 'Glycosylated haemoglobin decreased'
}, {
    name: 'Glycosylated haemoglobin increased'
}, {
    name: 'Goiter diffuse'
}, {
    name: 'Goiter nodular'
}, {
    name: 'Goitre'
}, {
    name: 'Gonadotropic luteinizing hormone increased'
}, {
    name: 'Gonadotropins NOS low'
}, {
    name: 'Gonorrhoea'
}, {
    name: "Goodpasture's syndrome"
}, {
    name: 'Gout'
}, {
    name: 'Gout acute'
}, {
    name: 'Gout attack'
}, {
    name: 'Gout flare'
}, {
    name: 'Gouty arthritis'
}, {
    name: 'Gouty tophus'
}, {
    name: 'Graft complication'
}, {
    name: 'Graft dysfunction'
}, {
    name: 'Graft loss'
}, {
    name: 'Graft thrombosis'
}, {
    name: 'Graft versus host disease'
}, {
    name: 'Graft versus host reaction'
}, {
    name: 'Gram-negative bacterial infection NOS'
}, {
    name: 'Grand mal convulsion'
}, {
    name: 'Granulocytosis'
}, {
    name: 'Granuloma'
}, {
    name: 'Granuloma annulare'
}, {
    name: 'Granuloma inguinale'
}, {
    name: 'Granuloma skin'
}, {
    name: 'Granulomatosis with polyangiitis'
}, {
    name: 'Granulomatous liver disease'
}, {
    name: 'Gravitational oedema'
}, {
    name: 'Grey syndrome neonatal'
}, {
    name: 'Grimacing'
}, {
    name: 'Gritty feeling in eyes'
}, {
    name: 'Groin pain'
}, {
    name: 'Ground glass appearance'
}, {
    name: 'Growth accelerated'
}, {
    name: 'Growth hormone overproduction'
}, {
    name: 'Growth of eyelashes'
}, {
    name: 'Growth retardation'
}, {
    name: 'Guillain-Barre syndrome'
}, {
    name: 'Gynaecomastia'
}, {
    name: 'Gynecological infection'
}, {
    name: 'Gynecological-related pain'
}, {
    name: 'Gynecomastia aggravated'
}, {
    name: 'Haemangioma'
}, {
    name: 'Haemangioma congenital'
}, {
    name: 'Haemangioma of skin'
}, {
    name: 'Haemarthrosis'
}, {
    name: 'Haematemesis'
}, {
    name: 'Haematochezia'
}, {
    name: 'Haematocrit decreased'
}, {
    name: 'Haematocrit increased'
}, {
    name: 'Haematological malignancy'
}, {
    name: 'Haematology test abnormal'
}, {
    name: 'Haematoma'
}, {
    name: 'Haematospermia'
}, {
    name: 'Haematotoxicity'
}, {
    name: 'Haematuria'
}, {
    name: 'Haemobilia'
}, {
    name: 'Haemochromatosis'
}, {
    name: 'Haemodynamic instability'
}, {
    name: 'Haemoglobin'
}, {
    name: 'Haemoglobin abnormal'
}, {
    name: 'Haemoglobin decreased'
}, {
    name: 'Haemoglobin increased'
}, {
    name: 'Haemoglobin normal'
}, {
    name: 'Haemoglobinaemia'
}, {
    name: 'Haemoglobinuria'
}, {
    name: 'Haemolysis'
}, {
    name: 'Haemolytic anaemia'
}, {
    name: 'Haemolytic uraemic syndrome'
}, {
    name: 'Haemophilia'
}, {
    name: 'Haemoptysis'
}, {
    name: 'Haemorrhage'
}, {
    name: 'Haemorrhage in pregnancy'
}, {
    name: 'Haemorrhage intracranial'
}, {
    name: 'Haemorrhage subcutaneous'
}, {
    name: 'Haemorrhage urinary tract'
}, {
    name: 'Haemorrhagic anaemia'
}, {
    name: 'Haemorrhagic disease of newborn'
}, {
    name: 'Haemorrhagic disorder'
}, {
    name: 'Haemorrhagic erosive gastritis'
}, {
    name: 'Haemorrhagic ovarian cyst'
}, {
    name: 'Haemorrhagic stroke'
}, {
    name: 'Haemorrhagic urticaria'
}, {
    name: 'Haemorrhoidal haemorrhage'
}, {
    name: 'Haemorrhoids'
}, {
    name: 'Haemosiderosis'
}, {
    name: 'Haemothorax'
}, {
    name: 'Hair colour changes'
}, {
    name: 'Hair discoloration'
}, {
    name: 'Hair disorder'
}, {
    name: 'Hair growth abnormal'
}, {
    name: 'Hair growth increased'
}, {
    name: 'Hair texture abnormal'
}, {
    name: 'Hairy cell leukaemia'
}, {
    name: 'Hallucination'
}, {
    name: 'Hallucination, auditory'
}, {
    name: 'Hallucination, tactile'
}, {
    name: 'Hallucination, visual'
}, {
    name: 'Hallucinations, mixed'
}, {
    name: 'Halo vision'
}, {
    name: 'Hamartoma'
}, {
    name: 'Hamman-Rich syndrome'
}, {
    name: 'Hand and foot syndrome secondary to sickle cell anaemia'
}, {
    name: 'Hand dermatitis'
}, {
    name: 'Hand fracture'
}, {
    name: 'Hand osteoarthritis'
}, {
    name: 'Hand pain'
}, {
    name: 'Hand rash'
}, {
    name: 'Hand swelling'
}, {
    name: 'Hands weakness of'
}, {
    name: 'Hangover'
}, {
    name: 'Haptoglobin increased'
}, {
    name: "Hashimoto's disease"
}, {
    name: 'HBV DNA decreased'
}, {
    name: 'HBV coinfection'
}, {
    name: 'HCV coinfection'
}, {
    name: 'HDL cholesterol increased'
}, {
    name: 'Head discomfort'
}, {
    name: 'Head injury'
}, {
    name: 'Head lag abnormal'
}, {
    name: 'Head pressure'
}, {
    name: 'Head titubation'
}, {
    name: 'Headache'
}, {
    name: 'Headache aggravated'
}, {
    name: 'Headache dull'
}, {
    name: 'Headache fullness'
}, {
    name: 'Headache occurring'
}, {
    name: 'Hearing impaired'
}, {
    name: 'Heart alternation'
}, {
    name: 'Heart disease congenital'
}, {
    name: 'Heart failure signs and symptoms'
}, {
    name: 'Heart malformation'
}, {
    name: 'Heart pounding'
}, {
    name: 'Heart racing'
}, {
    name: 'Heart rate abnormal'
}, {
    name: 'Heart rate irregular'
}, {
    name: 'Heart rate normal'
}, {
    name: 'Heart sounds abnormal'
}, {
    name: 'Heartburn'
}, {
    name: 'Heat exhaustion'
}, {
    name: 'Heat intolerance'
}, {
    name: 'Heat stroke'
}, {
    name: 'Heaviness in limbs'
}, {
    name: 'Heaviness of head'
}, {
    name: 'HELLP syndrome'
}, {
    name: 'Helicobacter gastritis'
}, {
    name: 'Helicobacter infection'
}, {
    name: 'Hemangioma acquired'
}, {
    name: 'Hemangioma simplex'
}, {
    name: 'Hematoma muscle'
}, {
    name: 'Hematuria aggravated'
}, {
    name: 'Hemianopia'
}, {
    name: 'Hemiballismus'
}, {
    name: 'Hemiblock NOS'
}, {
    name: 'Hemimelia'
}, {
    name: 'Hemiparesis'
}, {
    name: 'Hemiparesis (left)'
}, {
    name: 'Hemiplegia'
}, {
    name: 'Hemiplegia transient'
}, {
    name: 'Hemiplegic migraine'
}, {
    name: 'Hemolytic reaction'
}, {
    name: 'Hemophagocytic lymphohistiocytosis'
}, {
    name: 'Hemorrhage abnormal'
}, {
    name: 'Hemorrhage of colon'
}, {
    name: 'Hemorrhage symptom'
}, {
    name: 'Hemorrhagic colitis'
}, {
    name: 'Hemorrhoids aggravated'
}, {
    name: 'Henoch-Schonlein purpura'
}, {
    name: 'Heparin-induced thrombocytopenia'
}, {
    name: 'Hepatic adenoma'
}, {
    name: 'Hepatic amoebiasis'
}, {
    name: 'Hepatic angiosarcoma'
}, {
    name: 'Hepatic artery thrombosis'
}, {
    name: 'Hepatic atrophy'
}, {
    name: 'Hepatic cancer'
}, {
    name: 'Hepatic cancer metastatic'
}, {
    name: 'Hepatic cirrhosis'
}, {
    name: 'Hepatic congestion'
}, {
    name: 'Hepatic cyst'
}, {
    name: 'Hepatic encephalopathy'
}, {
    name: 'Hepatic enzyme abnormal'
}, {
    name: 'Hepatic enzyme decreased'
}, {
    name: 'Hepatic enzyme increased'
}, {
    name: 'Hepatic failure'
}, {
    name: 'Hepatic fibrosis'
}, {
    name: 'Hepatic function abnormal'
}, {
    name: 'Hepatic granuloma'
}, {
    name: 'Hepatic haemorrhage'
}, {
    name: 'Hepatic impairment'
}, {
    name: 'Hepatic infiltration eosinophilic'
}, {
    name: 'Hepatic insufficiency'
}, {
    name: 'Hepatic lymphoma'
}, {
    name: 'Hepatic necrosis'
}, {
    name: 'Hepatic neoplasm'
}, {
    name: 'Hepatic pain'
}, {
    name: 'Hepatic steatosis'
}, {
    name: 'Hepatic vein occlusion'
}, {
    name: 'Hepatic vein thrombosis'
}, {
    name: 'Hepatitis'
}, {
    name: 'Hepatitis A'
}, {
    name: 'Hepatitis B'
}, {
    name: 'Hepatitis B DNA decreased'
}, {
    name: 'Hepatitis B e antigen positive'
}, {
    name: 'Hepatitis B reactivation'
}, {
    name: 'Hepatitis B surface antigen positive'
}, {
    name: 'Hepatitis C'
}, {
    name: 'Hepatitis C antibody positive'
}, {
    name: 'Hepatitis C positive'
}, {
    name: 'Hepatitis C virus test positive'
}, {
    name: 'Hepatitis D'
}, {
    name: 'Hepatitis E'
}, {
    name: 'Hepatitis F'
}, {
    name: 'Hepatitis acute'
}, {
    name: 'Hepatitis aggravated'
}, {
    name: 'Hepatitis alcoholic'
}, {
    name: 'Hepatitis cholestatic'
}, {
    name: 'Hepatitis chronic active'
}, {
    name: 'Hepatitis fulminant'
}, {
    name: 'Hepatitis granulomatous'
}, {
    name: 'Hepatitis symptom'
}, {
    name: 'Hepatitis toxic'
}, {
    name: 'Hepatitis viral'
}, {
    name: 'Hepato-lenticular degeneration'
}, {
    name: 'Hepatobiliary disease'
}, {
    name: 'Hepatoblastoma'
}, {
    name: 'Hepatocellular adenoma'
}, {
    name: 'Hepatocellular carcinoma'
}, {
    name: 'Hepatocellular injury'
}, {
    name: 'Hepatomegaly'
}, {
    name: 'Hepatorenal syndrome'
}, {
    name: 'Hepatosplenic T-cell lymphoma'
}, {
    name: 'Hepatosplenic candidiasis'
}, {
    name: 'Hepatosplenomegaly'
}, {
    name: 'Hepatotoxicity'
}, {
    name: 'Hereditary angioedema'
}, {
    name: 'Hereditary coproporphyria'
}, {
    name: 'Hereditary optic atrophy'
}, {
    name: 'Hernia'
}, {
    name: 'Hernia congenital'
}, {
    name: 'Hernia pain'
}, {
    name: 'Heroin addiction'
}, {
    name: 'Herpangina'
}, {
    name: 'Herpes NOS'
}, {
    name: 'Herpes dermatitis'
}, {
    name: 'Herpes labialis'
}, {
    name: 'Herpes simplex'
}, {
    name: 'Herpes simplex dermatitis'
}, {
    name: 'Herpes simplex encephalitis'
}, {
    name: 'Herpes simplex hepatitis'
}, {
    name: 'Herpes virus infection'
}, {
    name: 'Herpes zoster'
}, {
    name: 'Herpes zoster disseminated'
}, {
    name: 'Herpes zoster keratitis'
}, {
    name: 'Heterozygous familial hypercholesterolemia'
}, {
    name: 'Hiatus hernia'
}, {
    name: 'Hiccups'
}, {
    name: 'Hidradenitis'
}, {
    name: 'High cholesterol'
}, {
    name: 'High density lipoprotein decreased'
}, {
    name: 'High density lipoprotein increased'
}, {
    name: 'High frequency deafness'
}, {
    name: 'High turnover osteopathy'
}, {
    name: 'High-pitched crying'
}, {
    name: 'Hip dislocation'
}, {
    name: 'Hip dysplasia'
}, {
    name: 'Hip fracture'
}, {
    name: 'Hirsutism'
}, {
    name: 'Histiocytosis'
}, {
    name: 'Histiocytosis X of lung'
}, {
    name: 'Histiocytosis haematophagic'
}, {
    name: 'Histoplasmosis'
}, {
    name: 'HIV associated nephropathy'
}, {
    name: 'HIV infection'
}, {
    name: 'Hoarseness'
}, {
    name: "Hodgkin's disease"
}, {
    name: "Hodgkin's disease lymphocyte depletion type stage unspecified"
}, {
    name: "Hodgkin's disease lymphocyte predominance type stage unspecified"
}, {
    name: "Hoigne's syndrome"
}, {
    name: 'Homicidal ideation'
}, {
    name: 'Homocystinuria'
}, {
    name: 'Homozygous familial hypercholesterolaemia'
}, {
    name: 'Hookworm infection'
}, {
    name: 'Hordeolum'
}, {
    name: 'Hormone level abnormal'
}, {
    name: 'Hormone-dependent prostate cancer'
}, {
    name: 'Hormone-refractory prostate cancer'
}, {
    name: "Horner's syndrome"
}, {
    name: 'Hostility'
}, {
    name: 'Hot dry skin'
}, {
    name: 'Hot flush'
}, {
    name: 'House dust allergy'
}, {
    name: 'Human herpesvirus 6 infection'
}, {
    name: 'Human immunodeficiency virus type'
}, {
    name: 'Humerus fracture'
}, {
    name: 'Hunger'
}, {
    name: 'Hunger abnormal'
}, {
    name: "Huntington's disease"
}, {
    name: 'Hydatidiform mole'
}, {
    name: 'Hydraemia'
}, {
    name: 'Hydrocele'
}, {
    name: 'Hydrocephalus'
}, {
    name: 'Hydrocephalus acquired'
}, {
    name: 'Hydrocortisone decreased'
}, {
    name: 'Hydrometra'
}, {
    name: 'Hydronephrosis'
}, {
    name: 'Hydrops foetalis'
}, {
    name: 'Hydrothorax'
}, {
    name: 'Hydroureter'
}, {
    name: 'Hyperacusis'
}, {
    name: 'Hyperadrenocorticism'
}, {
    name: 'Hyperaemia'
}, {
    name: 'Hyperaesthesia'
}, {
    name: 'Hyperalbuminaemia'
}, {
    name: 'Hyperaldosteronism'
}, {
    name: 'Hyperammonaemia'
}, {
    name: 'Hyperammonaemic encephalopathy'
}, {
    name: 'Hyperamylasaemia'
}, {
    name: 'Hyperbilirubinaemia'
}, {
    name: 'Hyperbilirubinemia aggravated'
}, {
    name: 'Hypercalcaemia'
}, {
    name: 'Hypercalcaemia of malignancy'
}, {
    name: 'Hypercalciuria'
}, {
    name: 'Hypercapnia'
}, {
    name: 'Hyperchloraemia'
}, {
    name: 'Hyperchlorhydria'
}, {
    name: 'Hypercholesterolaemia'
}, {
    name: 'Hypercholesterolemia aggravated'
}, {
    name: 'Hyperchylomicronaemia'
}, {
    name: 'Hypercoagulation'
}, {
    name: 'Hyperemesis'
}, {
    name: 'Hyperemesis gravidarum'
}, {
    name: 'Hypereosinophilia'
}, {
    name: 'Hypereosinophilic syndrome'
}, {
    name: 'Hyperexcitation'
}, {
    name: 'Hyperfibrinogenaemia'
}, {
    name: 'Hypergammaglobulinaemia'
}, {
    name: 'Hypergastrinaemia'
}, {
    name: 'Hyperglycaemia'
}, {
    name: 'Hyperhemoglobinemia'
}, {
    name: 'Hyperhidrosis'
}, {
    name: 'Hyperinsulinism'
}, {
    name: 'Hyperkalaemia'
}, {
    name: 'Hyperkaliuria'
}, {
    name: 'Hyperkeratosis'
}, {
    name: 'Hyperkinesia'
}, {
    name: 'Hyperkinetic heart syndrome'
}, {
    name: 'Hyperlactacidaemia'
}, {
    name: 'Hyperlipidaemia'
}, {
    name: 'Hyperlipoproteinemia'
}, {
    name: 'Hypermagnesaemia'
}, {
    name: 'Hypermetabolism'
}, {
    name: 'Hypermethioninaemia'
}, {
    name: 'Hypernatraemia'
}, {
    name: 'Hyperostosis'
}, {
    name: 'Hyperoxaluria'
}, {
    name: 'Hyperparathyroidism'
}, {
    name: 'Hyperparathyroidism primary'
}, {
    name: 'Hyperparathyroidism secondary'
}, {
    name: 'Hyperpathia'
}, {
    name: 'Hyperphagia'
}, {
    name: 'Hyperphosphataemia'
}, {
    name: 'Hyperplasia'
}, {
    name: 'Hyperplasia adrenal'
}, {
    name: 'Hyperplasia erythroid'
}, {
    name: 'Hyperpnea'
}, {
    name: 'Hyperprolactinaemia'
}, {
    name: 'Hyperproteinaemia'
}, {
    name: 'Hyperpyrexia'
}, {
    name: 'Hyperreflexia'
}, {
    name: 'Hypersensation skin'
}, {
    name: 'Hypersensitive syndrome'
}, {
    name: 'Hypersensitivity'
}, {
    name: 'Hypersexuality'
}, {
    name: 'Hypersomnia'
}, {
    name: 'Hypersplenism'
}, {
    name: 'Hypertension'
}, {
    name: 'Hypertension paroxysmal'
}, {
    name: 'Hypertension worsened'
}, {
    name: 'Hypertensive'
}, {
    name: 'Hypertensive crisis'
}, {
    name: 'Hypertensive emergency'
}, {
    name: 'Hypertensive encephalopathy'
}, {
    name: 'Hypertensive episode'
}, {
    name: 'Hypertensive nephropathy'
}, {
    name: 'Hyperthyroidism'
}, {
    name: 'Hypertonia'
}, {
    name: 'Hypertonic bladder'
}, {
    name: 'Hypertonicity'
}, {
    name: 'Hypertransaminasaemia'
}, {
    name: 'Hypertrichosis'
}, {
    name: 'Hypertriglyceridaemia'
}, {
    name: 'Hypertrophic cardiomyopathy'
}, {
    name: 'Hypertrophic osteoarthropathy'
}, {
    name: 'Hypertrophic scar'
}, {
    name: 'Hypertrophy'
}, {
    name: 'Hypertrophy of breast'
}, {
    name: 'Hyperuricaemia'
}, {
    name: 'Hyperuricosuria'
}, {
    name: 'Hyperventilation'
}, {
    name: 'Hypervigilance'
}, {
    name: 'Hyperviscosity syndrome'
}, {
    name: 'Hypervitaminosis A'
}, {
    name: 'Hypervitaminosis D'
}, {
    name: 'Hyphaema'
}, {
    name: 'Hypnagogic hallucination'
}, {
    name: 'Hypnopompic hallucination'
}, {
    name: 'Hypoactive sexual desire disorder'
}, {
    name: 'Hypoaesthesia'
}, {
    name: 'Hypoaesthesia eye'
}, {
    name: 'Hypoaesthesia facial'
}, {
    name: 'Hypoaesthesia oral'
}, {
    name: 'Hypoalbuminaemia'
}, {
    name: 'Hypoaldosteronism'
}, {
    name: 'Hypoalgesia'
}, {
    name: 'Hypocalcaemia'
}, {
    name: 'Hypocalcemic tetany'
}, {
    name: 'Hypocalciuria'
}, {
    name: 'Hypocapnia'
}, {
    name: 'Hypochloraemia'
}, {
    name: 'Hypocholesterolaemia'
}, {
    name: 'Hypochondriasis'
}, {
    name: 'Hypochromasia'
}, {
    name: 'Hypochromic anaemia'
}, {
    name: 'Hypochromic microcytic anemia'
}, {
    name: 'Hypoesthesia tongue'
}, {
    name: 'Hypofibrinogenaemia'
}, {
    name: 'Hypogammaglobulinaemia'
}, {
    name: 'Hypogeusia'
}, {
    name: 'Hypoglycaemia'
}, {
    name: 'Hypoglycaemia neonatal'
}, {
    name: 'Hypoglycaemic coma'
}, {
    name: 'Hypoglycaemic episode'
}, {
    name: 'Hypoglycaemic seizure'
}, {
    name: 'Hypoglycaemic unconsciousness'
}, {
    name: 'Hypoglycemic reaction'
}, {
    name: 'Hypogonadism'
}, {
    name: 'Hypogonadism female'
}, {
    name: 'Hypogonadism male'
}, {
    name: 'Hypohidrosis'
}, {
    name: 'Hypokalaemia'
}, {
    name: 'Hypokinesia'
}, {
    name: 'Hypolipidaemia'
}, {
    name: 'Hypomagnesaemia'
}, {
    name: 'Hypomania'
}, {
    name: 'Hypomenorrhoea'
}, {
    name: 'Hyponatraemia'
}, {
    name: 'Hyponatraemic'
}, {
    name: 'Hypoparathyroidism'
}, {
    name: 'Hypoperfusion'
}, {
    name: 'Hypophagia'
}, {
    name: 'Hypophosphataemia'
}, {
    name: 'Hypophosphataemic rickets'
}, {
    name: 'Hypopituitarism'
}, {
    name: 'Hypoplasia enamel'
}, {
    name: 'Hypoplasia erythroid'
}, {
    name: 'Hypoplastic anaemia'
}, {
    name: 'Hypopnea syndrome'
}, {
    name: 'Hypopnoea'
}, {
    name: 'Hypoproteinaemia'
}, {
    name: 'Hypoprothrombinaemia'
}, {
    name: 'Hypopyon'
}, {
    name: 'Hyporeflexia'
}, {
    name: 'Hyposmia'
}, {
    name: 'Hyposthenuria'
}, {
    name: 'Hypotension'
}, {
    name: 'Hypotension asymptomatic'
}, {
    name: 'Hypotension orthostatic symptomatic'
}, {
    name: 'Hypotension symptomatic'
}, {
    name: 'Hypotensive'
}, {
    name: 'Hypothermia'
}, {
    name: 'Hypothrombinaemia'
}, {
    name: 'Hypothyroidism'
}, {
    name: 'Hypotonia'
}, {
    name: 'Hypotonia neonatal'
}, {
    name: 'Hypotonic-hyporesponsive episode'
}, {
    name: 'Hypotony of eye'
}, {
    name: 'Hypotrichosis'
}, {
    name: 'Hypouricaemia'
}, {
    name: 'Hypoventilation'
}, {
    name: 'Hypovitaminosis'
}, {
    name: 'Hypovolaemia'
}, {
    name: 'Hypovolaemic shock'
}, {
    name: 'Hypoxemia'
}, {
    name: 'Hypoxia'
}, {
    name: 'Hypoxic-ischaemic encephalopathy'
}, {
    name: 'Hypsarrhythmia'
}, {
    name: 'Hysteria'
}, {
    name: 'Ichthyosis'
}, {
    name: 'Ichthyosis acquired'
}, {
    name: 'Ichthyosis vulgaris'
}, {
    name: 'Idiopathic edema'
}, {
    name: 'Idiopathic generalised epilepsy'
}, {
    name: 'Idiopathic hirsutism'
}, {
    name: 'Idiopathic hypertrophic subaortic stenosis'
}, {
    name: 'Idiopathic pneumonia syndrome'
}, {
    name: 'Idiopathic pulmonary arterial hypertension'
}, {
    name: 'Idiopathic pulmonary fibrosis'
}, {
    name: 'Idiopathic thrombocytopenia'
}, {
    name: 'Idiopathic thrombocytopenic purpura'
}, {
    name: 'Idiopathic torsion dystonia'
}, {
    name: 'Idiosyncratic drug reaction'
}, {
    name: 'IIIrd nerve paralysis'
}, {
    name: 'Ileal obstruction'
}, {
    name: 'Ileal perforation'
}, {
    name: 'Ileal ulcer'
}, {
    name: 'Ileitis'
}, {
    name: 'Ileitis regional'
}, {
    name: 'Ileus'
}, {
    name: 'Ileus paralytic'
}, {
    name: 'Ill-defined disorder'
}, {
    name: 'Illusion'
}, {
    name: 'Imbalance hormonal'
}, {
    name: 'Immediate post-injection reaction'
}, {
    name: 'Imminent abortion'
}, {
    name: 'Immobile'
}, {
    name: 'Immune complex reaction'
}, {
    name: 'Immune status'
}, {
    name: 'Immune system disorder'
}, {
    name: 'Immune-mediated necrotising myopathy'
}, {
    name: 'Immunocompromised'
}, {
    name: 'Immunodeficiency'
}, {
    name: 'Immunodeficiency common variable'
}, {
    name: 'Immunoglobulin G low'
}, {
    name: 'Immunoglobulins decreased'
}, {
    name: 'Immunoglobulins increased'
}, {
    name: 'Immunology test'
}, {
    name: 'Immunosuppressant drug level increased'
}, {
    name: 'Immunosuppression'
}, {
    name: 'Impaired fasting glucose'
}, {
    name: 'Impaired gastric emptying'
}, {
    name: 'Impaired healing'
}, {
    name: 'Impairment of attention'
}, {
    name: 'Impatience'
}, {
    name: 'Imperforate hymen'
}, {
    name: 'Impetigo'
}, {
    name: 'Implant breakage'
}, {
    name: 'Implant expulsion'
}, {
    name: 'Implant infection'
}, {
    name: 'Implant site pain'
}, {
    name: 'Implant site reaction'
}, {
    name: 'Implantation complication'
}, {
    name: 'Imprisonment'
}, {
    name: 'Impulse-control disorder'
}, {
    name: 'Inappropriate affect'
}, {
    name: 'Inappropriate antidiuretic hormone secretion'
}, {
    name: 'Inborn error of metabolism'
}, {
    name: 'Incessant ventricular tachycardia'
}, {
    name: 'Incision site complication'
}, {
    name: 'Incision site haematoma'
}, {
    name: 'Incision site haemorrhage'
}, {
    name: 'Incision site oedema'
}, {
    name: 'Incision site pain'
}, {
    name: 'Incisional hernia'
}, {
    name: 'Inclusion conjunctivitis'
}, {
    name: 'Incoherent'
}, {
    name: 'Incomplete bladder emptying'
}, {
    name: 'Incomplete precocious puberty'
}, {
    name: 'Incontinence'
}, {
    name: 'Increased activity'
}, {
    name: 'Increased agitation'
}, {
    name: 'Increased anticoagulant effect'
}, {
    name: 'Increased appetite'
}, {
    name: 'Increased bronchial secretion'
}, {
    name: 'Increased effect'
}, {
    name: 'Increased insulin requirement'
}, {
    name: 'Increased prolactin level'
}, {
    name: 'Increased skin sensitivity'
}, {
    name: 'Increased tendency to bruise'
}, {
    name: 'Increased thirst'
}, {
    name: 'Increased upper airway secretion'
}, {
    name: 'Increased viscosity of bronchial secretion'
}, {
    name: 'Induration'
}, {
    name: 'Inevitable abortion'
}, {
    name: 'Infantile colic'
}, {
    name: 'Infantile spasms'
}, {
    name: 'Infarction'
}, {
    name: 'Infarction mesenteric'
}, {
    name: 'Infected bites'
}, {
    name: 'Infected cyst'
}, {
    name: 'Infection'
}, {
    name: 'Infection induced'
}, {
    name: 'Infection mixed'
}, {
    name: 'Infection parasitic'
}, {
    name: 'Infection pseudomonas aeruginosa'
}, {
    name: 'Infection reactivation'
}, {
    name: 'Infection susceptibility increased'
}, {
    name: 'Infectious meningitis'
}, {
    name: 'Infectious mononucleosis'
}, {
    name: 'Infectious peritonitis'
}, {
    name: 'Infectious pneumonitis'
}, {
    name: 'Infectious thyroiditis'
}, {
    name: 'Infective myositis'
}, {
    name: 'Infective otitis externa'
}, {
    name: 'Infective tenosynovitis'
}, {
    name: 'Inferior myocardial infarction'
}, {
    name: 'Inferior vena cava syndrome'
}, {
    name: 'Infertility'
}, {
    name: 'Infertility female'
}, {
    name: 'Infertility male'
}, {
    name: 'Infestation'
}, {
    name: 'Infestation NOS'
}, {
    name: 'Inflammation'
}, {
    name: 'Inflammation localised'
}, {
    name: 'Inflammatory bowel disease'
}, {
    name: 'Inflammatory swelling'
}, {
    name: 'Inflicted injury'
}, {
    name: 'Influenza'
}, {
    name: 'Influenza A virus infection'
}, {
    name: 'Influenza like illness'
}, {
    name: 'Influenza viral infections'
}, {
    name: 'Influenza-like symptoms'
}, {
    name: 'Infrequent bowel movements'
}, {
    name: 'Infusion related pain'
}, {
    name: 'Infusion related reaction'
}, {
    name: 'Infusion site burning'
}, {
    name: 'Infusion site erythema'
}, {
    name: 'Infusion site extravasation'
}, {
    name: 'Infusion site hypersensitivity'
}, {
    name: 'Infusion site induration'
}, {
    name: 'Infusion site infection'
}, {
    name: 'Infusion site inflammation'
}, {
    name: 'Infusion site irritation'
}, {
    name: 'Infusion site oedema'
}, {
    name: 'Infusion site pain'
}, {
    name: 'Infusion site paraesthesia'
}, {
    name: 'Infusion site phlebitis'
}, {
    name: 'Infusion site pruritus'
}, {
    name: 'Infusion site rash'
}, {
    name: 'Infusion site reaction'
}, {
    name: 'Infusion site reactions'
}, {
    name: 'Infusion site swelling'
}, {
    name: 'Infusion site thrombophlebitis'
}, {
    name: 'Infusion site thrombosis'
}, {
    name: 'Infusion site urticaria'
}, {
    name: 'Infusion site warmth'
}, {
    name: 'Ingrowing nail'
}, {
    name: 'Ingrown hair'
}, {
    name: 'Inguinal hernia'
}, {
    name: 'Inhibition of enzyme activity'
}, {
    name: 'Initial insomnia'
}, {
    name: 'Injection site abscess'
}, {
    name: 'Injection site abscess sterile'
}, {
    name: 'Injection site atrophy'
}, {
    name: 'Injection site bruising'
}, {
    name: 'Injection site burning'
}, {
    name: 'Injection site cellulitis'
}, {
    name: 'Injection site coldness'
}, {
    name: 'Injection site cyst'
}, {
    name: 'Injection site dermatitis'
}, {
    name: 'Injection site discolouration'
}, {
    name: 'Injection site discomfort'
}, {
    name: 'Injection site dryness'
}, {
    name: 'Injection site erythema'
}, {
    name: 'Injection site exfoliation'
}, {
    name: 'Injection site extravasation'
}, {
    name: 'Injection site fibrosis'
}, {
    name: 'Injection site granuloma'
}, {
    name: 'Injection site haematoma'
}, {
    name: 'Injection site haemorrhage'
}, {
    name: 'Injection site hypersensitivity'
}, {
    name: 'Injection site hypertrophy'
}, {
    name: 'Injection site induration'
}, {
    name: 'Injection site infection'
}, {
    name: 'Injection site inflammation'
}, {
    name: 'Injection site injury'
}, {
    name: 'Injection site irritation'
}, {
    name: 'Injection site joint pain'
}, {
    name: 'Injection site mass'
}, {
    name: 'Injection site necrosis'
}, {
    name: 'Injection site nodule'
}, {
    name: 'Injection site pain'
}, {
    name: 'Injection site pallor'
}, {
    name: 'Injection site paraesthesia'
}, {
    name: 'Injection site phlebitis'
}, {
    name: 'Injection site pigmentation changes'
}, {
    name: 'Injection site pruritus'
}, {
    name: 'Injection site reaction'
}, {
    name: 'Injection site stinging'
}, {
    name: 'Injection site swelling'
}, {
    name: 'Injection site tenderness'
}, {
    name: 'Injection site thrombosis'
}, {
    name: 'Injection site ulcer'
}, {
    name: 'Injection site urticaria'
}, {
    name: 'Injection site vesicles'
}, {
    name: 'Injection site warmth'
}, {
    name: 'Injury'
}, {
    name: 'Injury asphyxiation'
}, {
    name: 'Injury associated with device'
}, {
    name: 'Injury corneal'
}, {
    name: 'Inner ear disorder'
}, {
    name: 'Inner ear infection'
}, {
    name: 'Insect bite NOS'
}, {
    name: 'Insomnia'
}, {
    name: 'Insomnia NEC'
}, {
    name: 'Insomnia exacerbated'
}, {
    name: 'Instability vasomotor'
}, {
    name: 'Instillation site irritation'
}, {
    name: 'Instillation site pain'
}, {
    name: 'Insulin C-peptide decreased'
}, {
    name: 'Insulin C-peptide increased'
}, {
    name: 'Insulin autoimmune syndrome'
}, {
    name: 'Insulin hypoglycemia'
}, {
    name: 'Insulin resistance'
}, {
    name: 'Insulin resistant diabetes'
}, {
    name: 'Insulinoma'
}, {
    name: 'Intentional drug misuse'
}, {
    name: 'Intentional injury'
}, {
    name: 'Intentional misuse'
}, {
    name: 'Intentional self-injury'
}, {
    name: 'Intercapillary glomerulosclerosis'
}, {
    name: 'Intermittent claudication'
}, {
    name: 'Intermittent explosive disorder'
}, {
    name: 'Intermittent fever'
}, {
    name: 'Intermittent headache'
}, {
    name: 'Internal hordeolum'
}, {
    name: 'International normalised ratio abnormal'
}, {
    name: 'International normalised ratio decreased'
}, {
    name: 'International normalised ratio increased'
}, {
    name: 'Interstitial lung disease'
}, {
    name: 'Interstitial pneumonia'
}, {
    name: 'Intertrigo'
}, {
    name: 'Intertrigo candida'
}, {
    name: 'Intervertebral disc degeneration'
}, {
    name: 'Intervertebral disc disorder'
}, {
    name: 'Intervertebral disc protrusion'
}, {
    name: 'Intervertebral discitis'
}, {
    name: 'Intestinal atony'
}, {
    name: 'Intestinal cramps'
}, {
    name: 'Intestinal diaphragm disease'
}, {
    name: 'Intestinal functional disorder'
}, {
    name: 'Intestinal haemorrhage'
}, {
    name: 'Intestinal hypomotility'
}, {
    name: 'Intestinal infarction'
}, {
    name: 'Intestinal infection due to staphylococcus'
}, {
    name: 'Intestinal infections'
}, {
    name: 'Intestinal ischaemia'
}, {
    name: 'Intestinal mass'
}, {
    name: 'Intestinal necrosis'
}, {
    name: 'Intestinal obstruction'
}, {
    name: 'Intestinal parasitism, unspecified'
}, {
    name: 'Intestinal perforation'
}, {
    name: 'Intestinal polyp'
}, {
    name: 'Intestinal pseudo-obstruction'
}, {
    name: 'Intestinal stenosis'
}, {
    name: 'Intestinal stoma complication'
}, {
    name: 'Intestinal ulcer'
}, {
    name: 'Intoxication'
}, {
    name: 'Intra-abdominal haematoma'
}, {
    name: 'Intra-abdominal haemorrhage'
}, {
    name: 'Intracardiac thrombus'
}, {
    name: 'Intracranial aneurysm'
}, {
    name: 'Intracranial pressure increased'
}, {
    name: 'Intracranial venous sinus thrombosis'
}, {
    name: 'Intractable epilepsy'
}, {
    name: 'Intractable hiccups'
}, {
    name: 'Intractable pain'
}, {
    name: 'Intraductal proliferative breast lesion'
}, {
    name: 'Intranasal hypoaesthesia'
}, {
    name: 'Intraocular pressure increased'
}, {
    name: 'Intraoperative floppy iris syndrome'
}, {
    name: 'Intraoperative hemorrhage'
}, {
    name: 'Intraoperative hypotension'
}, {
    name: 'Intraspinal bleeding'
}, {
    name: 'Intravascular large B-cell lymphoma'
}, {
    name: 'Intraventricular haemorrhage'
}, {
    name: 'Intussusception'
}, {
    name: 'Invasive bronchopulmonary aspergillosis'
}, {
    name: 'Invasive candidiasis'
}, {
    name: 'Involutional depression'
}, {
    name: 'Iodism'
}, {
    name: 'Iridocyclitis'
}, {
    name: 'Iris adhesions'
}, {
    name: 'Iris disorder'
}, {
    name: 'Iris hyperpigmentation'
}, {
    name: 'Iritis'
}, {
    name: 'Iron binding capacity total'
}, {
    name: 'Iron deficiency'
}, {
    name: 'Iron deficiency anaemia'
}, {
    name: 'Iron overload'
}, {
    name: 'Irreversible renal failure'
}, {
    name: 'Irritability'
}, {
    name: 'Irritable bowel syndrome'
}, {
    name: 'Irritation gum'
}, {
    name: 'Ischaemia'
}, {
    name: 'Ischaemic cardiomyopathy'
}, {
    name: 'Ischaemic cerebral infarction'
}, {
    name: 'Ischaemic coronary artery disorders'
}, {
    name: 'Ischaemic hepatitis'
}, {
    name: 'Ischaemic neuropathy'
}, {
    name: 'Ischaemic stroke'
}, {
    name: 'Ischial neuralgia'
}, {
    name: 'Itch burning'
}, {
    name: 'Itchy scalp'
}, {
    name: 'IUD complication'
}, {
    name: 'IUD expelled'
}, {
    name: 'Jacksonian seizures'
}, {
    name: 'Jarisch-Herxheimer reaction'
}, {
    name: 'Jaundice'
}, {
    name: 'Jaundice cholestatic'
}, {
    name: 'Jaundice hepatocellular'
}, {
    name: 'Jaundice neonatal'
}, {
    name: 'Jaw disorder'
}, {
    name: 'Jaw stiffness'
}, {
    name: 'Jerky movement NOS'
}, {
    name: "Jessner's lymphocytic infiltration"
}, {
    name: 'Joint contracture'
}, {
    name: 'Joint crepitation'
}, {
    name: 'Joint destruction'
}, {
    name: 'Joint dislocation'
}, {
    name: 'Joint effusion'
}, {
    name: 'Joint hyperextension'
}, {
    name: 'Joint injury'
}, {
    name: 'Joint instability'
}, {
    name: 'Joint lock'
}, {
    name: 'Joint range of motion decreased'
}, {
    name: 'Joint related signs and symptoms'
}, {
    name: 'Joint sprain'
}, {
    name: 'Joint stiffness'
}, {
    name: 'Joint swelling'
}, {
    name: 'Joint tenderness'
}, {
    name: 'Joint tuberculosis'
}, {
    name: 'Judgement impaired'
}, {
    name: 'Junctional bradycardia'
}, {
    name: 'Junctional tachycardia'
}, {
    name: 'Juvenile idiopathic arthritis'
}, {
    name: 'Juvenile myoclonic epilepsy'
}, {
    name: 'Kaluresis'
}, {
    name: "Kaposi's sarcoma"
}, {
    name: "Kaposi's sarcoma AIDS related"
}, {
    name: "Kaposi's varicelliform eruption"
}, {
    name: 'Kayser-Fleischer ring'
}, {
    name: 'Kearns-Sayre syndrome'
}, {
    name: 'Keloid scar'
}, {
    name: 'Keratic precipitates'
}, {
    name: 'Keratitis'
}, {
    name: 'Keratitis bacterial'
}, {
    name: 'Keratitis fungal'
}, {
    name: 'Keratitis sicca'
}, {
    name: 'Keratoacanthoma'
}, {
    name: 'Keratoconjunctivitis'
}, {
    name: 'Keratoconjunctivitis sicca'
}, {
    name: 'Keratoconus'
}, {
    name: 'Keratopathy'
}, {
    name: 'Keratosis'
}, {
    name: 'Keratosis follicular'
}, {
    name: 'Keratosis palmaris'
}, {
    name: 'Keratosis pilaris'
}, {
    name: 'Ketoacidosis'
}, {
    name: 'Ketogenic diet'
}, {
    name: 'Ketonemia'
}, {
    name: 'Ketonuria'
}, {
    name: 'Ketosis'
}, {
    name: 'Kidney fibrosis'
}, {
    name: 'Kidney function abnormal'
}, {
    name: 'Kidney infection'
}, {
    name: 'Kidney transplant rejection'
}, {
    name: 'Klebsiella sepsis'
}, {
    name: "Klinefelter's syndrome"
}, {
    name: 'Knee deformity'
}, {
    name: 'Knee pain'
}, {
    name: 'Knee sprain'
}, {
    name: 'Koebner phenomenon'
}, {
    name: "Korsakoff's psychosis (non-alcoholic)"
}, {
    name: 'Kounis syndrome'
}, {
    name: 'Kyphosis'
}, {
    name: 'Labile blood pressure'
}, {
    name: 'Labile hypertension'
}, {
    name: 'Laboratory test abnormal'
}, {
    name: 'Labored breathing'
}, {
    name: 'Labour pain'
}, {
    name: 'Labyrinthine disorder'
}, {
    name: 'Labyrinthitis'
}, {
    name: 'Laceration'
}, {
    name: 'Lack of drug effect'
}, {
    name: 'Lack of spontaneous speech'
}, {
    name: 'Lacrimal disorder'
}, {
    name: 'Lacrimal duct obstruction'
}, {
    name: 'Lacrimal gland disorder'
}, {
    name: 'Lacrimal structural disorder'
}, {
    name: 'Lacrimation'
}, {
    name: 'Lacrimation abnormal NOS'
}, {
    name: 'Lacrimation decreased'
}, {
    name: 'Lacrimation increased'
}, {
    name: 'Lactase deficiency'
}, {
    name: 'Lactate increased'
}, {
    name: 'Lactation female'
}, {
    name: 'Lactic acidosis'
}, {
    name: 'Lactic acidosis syndrome'
}, {
    name: 'Lactic dehydrogenase activity increased'
}, {
    name: 'Lactose intolerance'
}, {
    name: 'Lacunar infarction'
}, {
    name: "Laennec's cirrhosis"
}, {
    name: 'Lambert-Eaton myasthenic syndrome'
}, {
    name: "Langerhans' cell histiocytosis"
}, {
    name: 'Large intestinal haemorrhage'
}, {
    name: 'Large intestinal obstruction'
}, {
    name: 'Large intestinal ulcer'
}, {
    name: 'Large intestine perforation'
}, {
    name: 'Large intestine polyp'
}, {
    name: 'Laryngeal cancer'
}, {
    name: 'Laryngeal disorder'
}, {
    name: 'Laryngeal dystonia'
}, {
    name: 'Laryngeal haemorrhage'
}, {
    name: 'Laryngeal neoplasm'
}, {
    name: 'Laryngeal oedema'
}, {
    name: 'Laryngeal pain'
}, {
    name: 'Laryngitis'
}, {
    name: 'Laryngopharyngeal dysesthesia'
}, {
    name: 'Laryngopharyngitis'
}, {
    name: 'Laryngospasm'
}, {
    name: 'Laryngotracheal oedema'
}, {
    name: 'Laryngotracheitis'
}, {
    name: 'Lassitude'
}, {
    name: 'Latent tetany'
}, {
    name: 'Latent tuberculosis'
}, {
    name: 'Latex allergy'
}, {
    name: 'Lead poisoning'
}, {
    name: 'Learning disability'
}, {
    name: 'Learning disorder'
}, {
    name: "Leber's hereditary optic atrophy neuropathy"
}, {
    name: 'Left ventricular dysfunction'
}, {
    name: 'Left ventricular ejection fraction decreased'
}, {
    name: 'Left ventricular failure'
}, {
    name: 'Left ventricular hypertrophy'
}, {
    name: 'Left ventricular systolic dysfunction'
}, {
    name: 'Left-sided ulcerative (chronic) colitis'
}, {
    name: 'Leg edema'
}, {
    name: 'Leg pain'
}, {
    name: 'Leg ulcer'
}, {
    name: 'Legionella infection'
}, {
    name: 'Leiomyoma'
}, {
    name: 'Leiomyosarcoma'
}, {
    name: 'Leishmaniasis'
}, {
    name: 'Lennox-Gastaut syndrome'
}, {
    name: 'Lenticular opacities'
}, {
    name: 'Lenticular pigmentation'
}, {
    name: 'Lentigo'
}, {
    name: 'Lentigo maligna'
}, {
    name: 'Lepromatous leprosy'
}, {
    name: 'Leprosy'
}, {
    name: 'Leptomeningeal metastases'
}, {
    name: 'Leriche syndrome'
}, {
    name: 'Lethargy'
}, {
    name: 'Letterer-Siwe disease'
}, {
    name: 'Leukaemia'
}, {
    name: 'Leukaemia cutis'
}, {
    name: 'Leukaemia monocytic'
}, {
    name: 'Leukaemic infiltration brain'
}, {
    name: 'Leukaemoid reaction'
}, {
    name: 'Leukemia secondary'
}, {
    name: 'Leukocytoclastic vasculitis'
}, {
    name: 'Leukocytosis'
}, {
    name: 'Leukoderma'
}, {
    name: 'Leukoencephalopathy'
}, {
    name: 'Leukonychia'
}, {
    name: 'Leukopenia'
}, {
    name: 'Leukoplakia'
}, {
    name: 'Leukoplakia oral'
}, {
    name: 'Leukorrhea'
}, {
    name: 'Leukostasis'
}, {
    name: "Lhermitte's sign"
}, {
    name: 'Libido decreased'
}, {
    name: 'Libido disorder'
}, {
    name: 'Libido increased'
}, {
    name: 'Lice infestation'
}, {
    name: 'Lichen planus'
}, {
    name: 'Lichen sclerosus'
}, {
    name: 'Lichen simplex chronicus'
}, {
    name: 'Lichenification'
}, {
    name: 'Lichenoid keratosis'
}, {
    name: 'Lid sulcus deepened'
}, {
    name: 'Ligament injury'
}, {
    name: 'Ligament sprain'
}, {
    name: 'Light anaesthesia'
}, {
    name: 'Light sleep'
}, {
    name: 'Lightheadedness'
}, {
    name: 'Limb deformity'
}, {
    name: 'Limb discomfort'
}, {
    name: 'Limb injury'
}, {
    name: 'Limb malformation'
}, {
    name: 'Limb paresis'
}, {
    name: 'Limb reduction defect'
}, {
    name: 'Linear IgA disease'
}, {
    name: 'Lip blister'
}, {
    name: 'Lip burning sensation of'
}, {
    name: 'Lip dry'
}, {
    name: 'Lip haemorrhage'
}, {
    name: 'Lip oedema'
}, {
    name: 'Lip pain'
}, {
    name: 'Lip swelling'
}, {
    name: 'Lip ulceration'
}, {
    name: 'Lipase abnormal'
}, {
    name: 'Lipase increased'
}, {
    name: 'Lipid metabolism disorder'
}, {
    name: 'Lipidosis'
}, {
    name: 'Lipids abnormal'
}, {
    name: 'Lipids increased'
}, {
    name: 'Lipoatrophy'
}, {
    name: 'Lipodystrophy'
}, {
    name: 'Lipodystrophy acquired'
}, {
    name: 'Lipoedema'
}, {
    name: 'Lipohypertrophy'
}, {
    name: 'Lipoid nephrosis'
}, {
    name: 'Lipoma'
}, {
    name: 'Lipomatosis'
}, {
    name: 'Liposarcoma'
}, {
    name: 'Listeriosis'
}, {
    name: 'Lithium poisoning'
}, {
    name: 'Lithium toxicity'
}, {
    name: 'Livedo reticularis'
}, {
    name: 'Liver abscess'
}, {
    name: 'Liver disorder'
}, {
    name: 'Liver fatty'
}, {
    name: 'Liver fatty deposition'
}, {
    name: 'Liver function test abnormal'
}, {
    name: 'Liver function test normal'
}, {
    name: 'Liver injury'
}, {
    name: 'Liver nodule'
}, {
    name: 'Liver tenderness'
}, {
    name: 'Liver transplant rejection'
}, {
    name: 'Lividity'
}, {
    name: 'Lobar pneumonia'
}, {
    name: 'Lobular breast carcinoma in situ'
}, {
    name: 'Local reaction'
}, {
    name: 'Local swelling'
}, {
    name: 'Local throat irritation'
}, {
    name: 'Localised infection'
}, {
    name: 'Localised intraabdominal fluid collection'
}, {
    name: 'Localised numbness'
}, {
    name: 'Localised oedema'
}, {
    name: 'Localised skin reaction'
}, {
    name: 'Localized erythema'
}, {
    name: 'Localized exfoliation'
}, {
    name: 'Localized osteoarthritis'
}, {
    name: 'Localized rash'
}, {
    name: 'Locally advanced breast cancer'
}, {
    name: 'Lockjaw'
}, {
    name: "Loeffler's syndrome"
}, {
    name: 'Logorrhoea'
}, {
    name: 'Loin pain'
}, {
    name: 'Long QT syndrome'
}, {
    name: 'Long QT syndrome congenital'
}, {
    name: 'Long-term memory loss'
}, {
    name: 'Loose stools'
}, {
    name: 'Lordosis'
}, {
    name: 'Loss of confidence'
}, {
    name: 'Loss of consciousness'
}, {
    name: 'Loss of control of legs'
}, {
    name: 'Loss of libido'
}, {
    name: 'Loss of proprioception'
}, {
    name: 'Loss of skin markings'
}, {
    name: 'Low back pain'
}, {
    name: 'Low birth weight baby'
}, {
    name: 'Low density lipoprotein increased'
}, {
    name: 'Low income'
}, {
    name: 'Low pH'
}, {
    name: 'Low set ears'
}, {
    name: 'Lower gastrointestinal haemorrhage'
}, {
    name: 'Lower limb fracture'
}, {
    name: 'Lower motor neurone lesion'
}, {
    name: 'Lower respiratory tract infection'
}, {
    name: 'Lower urinary tract symptoms'
}, {
    name: 'Lumbar disc lesion'
}, {
    name: 'Lumbar puncture headache'
}, {
    name: 'Lumbar radiculopathy'
}, {
    name: 'Lumbo-sacral pain'
}, {
    name: 'Lung abscess'
}, {
    name: 'Lung adenocarcinoma stage I'
}, {
    name: 'Lung cancer metastatic'
}, {
    name: 'Lung disorder'
}, {
    name: 'Lung fibrosis interstitial'
}, {
    name: 'Lung infection'
}, {
    name: 'Lung infiltration'
}, {
    name: 'Lung neoplasm'
}, {
    name: 'Lung neoplasm malignant'
}, {
    name: 'Lung nodule'
}, {
    name: 'Lupus erythematosus'
}, {
    name: 'Lupus nephritis'
}, {
    name: 'Lupus-like syndrome'
}, {
    name: 'Luteal phase deficiency'
}, {
    name: 'Lyme disease'
}, {
    name: 'Lymph node abscess'
}, {
    name: 'Lymph node pain'
}, {
    name: 'Lymph node tenderness'
}, {
    name: 'Lymphadenitis'
}, {
    name: 'Lymphadenopathy'
}, {
    name: 'Lymphadenopathy axillary'
}, {
    name: 'Lymphadenopathy cervical'
}, {
    name: 'Lymphadenopathy inguinal'
}, {
    name: 'Lymphangioleiomyomatosis'
}, {
    name: 'Lymphangitis'
}, {
    name: 'Lymphatic disorder'
}, {
    name: 'Lymphoblastic lymphoma'
}, {
    name: 'Lymphocele'
}, {
    name: 'Lymphocyte abnormal'
}, {
    name: 'Lymphocyte count abnormal'
}, {
    name: 'Lymphocyte count decreased'
}, {
    name: 'Lymphocyte count increased'
}, {
    name: 'Lymphocyte transformation test positive'
}, {
    name: 'Lymphocytic colitis'
}, {
    name: 'Lymphocytic infiltration'
}, {
    name: 'Lymphocytic leukaemia'
}, {
    name: 'Lymphocytoma cutis'
}, {
    name: 'Lymphocytosis'
}, {
    name: 'Lymphoedema'
}, {
    name: 'Lymphogranuloma venereum'
}, {
    name: 'Lymphoma'
}, {
    name: 'Lymphoma cutis'
}, {
    name: 'Lymphopenia'
}, {
    name: 'Lymphoproliferative disorder'
}, {
    name: 'Lymphorrhoea'
}, {
    name: 'Lymphostasis'
}, {
    name: 'Macroangiopathy'
}, {
    name: 'Macrovascular disease'
}, {
    name: 'Macular degeneration'
}, {
    name: 'Macular fibrosis'
}, {
    name: 'Macular hole'
}, {
    name: 'Macular oedema'
}, {
    name: 'Macular pigmentation'
}, {
    name: 'Macule'
}, {
    name: 'Maculopathy'
}, {
    name: 'Madarosis'
}, {
    name: 'Magnesium deficiency'
}, {
    name: 'Major bleed'
}, {
    name: 'Major depression'
}, {
    name: 'Major depressive disorder, single episode'
}, {
    name: 'MALT lymphoma'
}, {
    name: 'Malabsorption'
}, {
    name: 'Malaise'
}, {
    name: 'Malaise and fatigue'
}, {
    name: 'Malaria'
}, {
    name: 'Male contraception'
}, {
    name: 'Male orgasmic disorder'
}, {
    name: 'Male sexual dysfunction'
}, {
    name: 'Malformation venous'
}, {
    name: 'Malignant glioma'
}, {
    name: 'Malignant histiocytosis'
}, {
    name: 'Malignant hydatidiform mole'
}, {
    name: 'Malignant hypertension'
}, {
    name: 'Malignant melanoma'
}, {
    name: 'Malignant mesenchymoma'
}, {
    name: 'Malignant neoplasm of esophagus'
}, {
    name: 'Malignant neoplasm of islets of Langerhans'
}, {
    name: 'Malignant neoplasm of pancreas'
}, {
    name: 'Malignant neoplasm of renal pelvis'
}, {
    name: 'Malignant neoplasm progression'
}, {
    name: 'Malignant ovarian cyst'
}, {
    name: 'Malignant pleural effusion'
}, {
    name: 'Malignant solid tumour'
}, {
    name: 'Malignant syndrome NOS'
}, {
    name: 'Malignant transformation'
}, {
    name: 'Mallory-Weiss syndrome'
}, {
    name: 'Malnutrition'
}, {
    name: 'Mammogram abnormal'
}, {
    name: 'Mania'
}, {
    name: 'Mania acute'
}, {
    name: 'Manic episode'
}, {
    name: 'Manic psychosis'
}, {
    name: 'Mantle cell lymphoma'
}, {
    name: 'Mantle cell lymphoma refractory'
}, {
    name: 'Markedly reduced dietary intake'
}, {
    name: 'Marrow hyperplasia'
}, {
    name: 'Masked facies'
}, {
    name: 'Mass'
}, {
    name: 'Mastication disorder'
}, {
    name: 'Mastitis'
}, {
    name: 'Mastitis acute female'
}, {
    name: 'Mastitis male'
}, {
    name: 'Mastocytosis'
}, {
    name: 'Mastoiditis'
}, {
    name: 'Maxillary sinusitis'
}, {
    name: 'Mean arterial pressure'
}, {
    name: 'Mean arterial pressure decreased'
}, {
    name: 'Mean cell volume increased'
}, {
    name: 'Mean platelet volume decreased'
}, {
    name: 'Measles'
}, {
    name: 'Mechanical complication of implant'
}, {
    name: 'Mechanical urticaria'
}, {
    name: 'Mediastinal disorder'
}, {
    name: 'Mediastinitis'
}, {
    name: 'Mediastinum neoplasm'
}, {
    name: 'Medical device complication'
}, {
    name: 'Medical device discomfort'
}, {
    name: 'Medication overuse headache'
}, {
    name: 'Medication residue'
}, {
    name: 'Medication residue present'
}, {
    name: 'Medullary thyroid cancer'
}, {
    name: 'Medulloblastoma'
}, {
    name: 'Megacolon'
}, {
    name: 'Megacolon toxic'
}, {
    name: 'Meibomianitis'
}, {
    name: 'Melaena'
}, {
    name: 'Melancholia'
}, {
    name: 'Melanocytic naevus'
}, {
    name: 'Melanoderma'
}, {
    name: 'Melanoma skin'
}, {
    name: 'Melanonychia'
}, {
    name: 'Melanosis'
}, {
    name: 'Memory impairment'
}, {
    name: 'Memory loss'
}, {
    name: 'Menarche'
}, {
    name: "Mendelson's syndrome"
}, {
    name: "Meniere's disease"
}, {
    name: "Meniere's disease aggravated"
}, {
    name: 'Meningeal leukemia'
}, {
    name: 'Meningeal neoplasm'
}, {
    name: 'Meningioma'
}, {
    name: 'Meningioma benign'
}, {
    name: 'Meningism'
}, {
    name: 'Meningitis'
}, {
    name: 'Meningitis aseptic'
}, {
    name: 'Meningitis bacterial'
}, {
    name: 'Meningitis chemical'
}, {
    name: 'Meningitis cryptococcal'
}, {
    name: 'Meningitis fungal'
}, {
    name: 'Meningitis meningococcal'
}, {
    name: 'Meningitis tuberculous'
}, {
    name: 'Meningitis viral'
}, {
    name: 'Meningocele'
}, {
    name: 'Meningococcal infection'
}, {
    name: 'Meningoencephalitis'
}, {
    name: 'Meningoencephalitis herpetic'
}, {
    name: 'Meningomyelocele'
}, {
    name: 'Menometrorrhagia'
}, {
    name: 'Menopausal depression'
}, {
    name: 'Menopausal disorder'
}, {
    name: 'Menopausal symptoms'
}, {
    name: 'Menopause'
}, {
    name: 'Menorrhagia'
}, {
    name: 'Menstrual cycle abnormal'
}, {
    name: 'Menstrual cycle prolonged'
}, {
    name: 'Menstrual disorder'
}, {
    name: 'Menstruation delayed'
}, {
    name: 'Menstruation irregular'
}, {
    name: 'Mental aberration'
}, {
    name: 'Mental deficiency'
}, {
    name: 'Mental deterioration'
}, {
    name: 'Mental disability'
}, {
    name: 'Mental disorder'
}, {
    name: 'Mental disorder due to a general medical condition'
}, {
    name: 'Mental impairment disorders'
}, {
    name: 'Mental retardation'
}, {
    name: 'Mental state abnormal'
}, {
    name: 'Mental status changes'
}, {
    name: 'Mercury poisoning'
}, {
    name: 'Mesenteric artery thrombosis'
}, {
    name: 'Mesenteric ischemia'
}, {
    name: 'Mesenteric occlusion'
}, {
    name: 'Mesenteric vascular insufficiency'
}, {
    name: 'Mesothelioma'
}, {
    name: 'Metabolic acidosis'
}, {
    name: 'Metabolic alkalosis'
}, {
    name: 'Metabolic disorder'
}, {
    name: 'Metabolic encephalopathy'
}, {
    name: 'Metabolic syndrome'
}, {
    name: 'Metal poisoning'
}, {
    name: 'Metaphyseal dysplasia'
}, {
    name: 'Metaplasia'
}, {
    name: 'Metastases to central nervous system'
}, {
    name: 'Metastases to liver'
}, {
    name: 'Metastases to meninges'
}, {
    name: 'Metastases to pancreas'
}, {
    name: 'Metastases to peritoneum'
}, {
    name: 'Metastases to spine'
}, {
    name: 'Metastasis'
}, {
    name: 'Metastatic bone pain'
}, {
    name: 'Metastatic carcinoma'
}, {
    name: 'Metastatic disease'
}, {
    name: 'Metastatic gastric adenocarcinoma'
}, {
    name: 'Metastatic malignant melanoma'
}, {
    name: 'Metastatic melanoma'
}, {
    name: 'Metastatic neoplasm'
}, {
    name: 'Metastatic pain'
}, {
    name: 'Metastatic renal cell carcinoma'
}, {
    name: 'Metastatic squamous cell carcinoma'
}, {
    name: 'Methaemoglobinaemia'
}, {
    name: 'Methicillin-resistant Staphylococcus aureus infection'
}, {
    name: 'Metrorrhagia'
}, {
    name: 'Mg reduced'
}, {
    name: 'Mg++ increased'
}, {
    name: 'Microalbuminuria'
}, {
    name: 'Microangiopathic haemolytic anaemia'
}, {
    name: 'Microangiopathy'
}, {
    name: 'Microcephaly'
}, {
    name: 'Microcytic'
}, {
    name: 'Microcytic anaemia'
}, {
    name: 'Microcytosis'
}, {
    name: 'Microembolism'
}, {
    name: 'Microhemorrhage'
}, {
    name: 'Microscopic hematuria'
}, {
    name: 'Microsomia'
}, {
    name: 'Micturition burning'
}, {
    name: 'Micturition disorder'
}, {
    name: 'Micturition urgency'
}, {
    name: 'Middle ear effusion'
}, {
    name: 'Middle insomnia'
}, {
    name: 'Midsystolic click'
}, {
    name: 'Migraine'
}, {
    name: 'Migraine aggravated'
}, {
    name: 'Migraine with aura'
}, {
    name: 'Migraine without aura'
}, {
    name: 'Migration of implant'
}, {
    name: 'Milia'
}, {
    name: 'Miliaria'
}, {
    name: 'Miliaria rubra'
}, {
    name: 'Miliary tuberculosis'
}, {
    name: 'Mineralocorticoid deficiency'
}, {
    name: 'Minimal brain dysfunction'
}, {
    name: 'Minor bleed'
}, {
    name: 'Miosis'
}, {
    name: 'Mitochondrial toxicity'
}, {
    name: 'Mitral valve atresia'
}, {
    name: 'Mitral valve disease'
}, {
    name: 'Mitral valve incompetence'
}, {
    name: 'Mitral valve prolapse'
}, {
    name: 'Mitral valve stenosis'
}, {
    name: 'Mixed connective tissue disease'
}, {
    name: 'Mixed hyperlipidemia'
}, {
    name: 'Mixed liver injury'
}, {
    name: 'Moaning'
}, {
    name: 'Mobility decreased'
}, {
    name: 'Molluscum contagiosum'
}, {
    name: 'Monarthritis'
}, {
    name: 'Moniliasis genital female'
}, {
    name: 'Monoclonal gammopathy'
}, {
    name: 'Monocyte count decreased'
}, {
    name: 'Monocyte count increased'
}, {
    name: 'Monocytosis'
}, {
    name: 'Monomorphic ventricular tachycardia'
}, {
    name: 'Mononeuritis'
}, {
    name: 'Mononeuropathy'
}, {
    name: 'Monoparesis'
}, {
    name: 'Monoplegia'
}, {
    name: 'Mood alteration NOS'
}, {
    name: 'Mood alterations with depressive symptoms'
}, {
    name: 'Mood swings'
}, {
    name: 'Morbid dreams'
}, {
    name: 'Morbid thoughts'
}, {
    name: 'Morphoea'
}, {
    name: 'Mosquito bite'
}, {
    name: 'Motion sickness'
}, {
    name: 'Motor dysfunction'
}, {
    name: 'Motor neurone disease'
}, {
    name: 'Motor restlessness'
}, {
    name: 'Motor tic'
}, {
    name: 'Mountain sickness acute'
}, {
    name: 'Mouth haemorrhage'
}, {
    name: 'Mouth injury'
}, {
    name: 'Mouth irritation'
}, {
    name: 'Mouth ulceration'
}, {
    name: 'Movement disorder'
}, {
    name: 'Movements involuntary'
}, {
    name: 'Mucocutaneous candidiasis'
}, {
    name: 'Mucocutaneous herpes simplex'
}, {
    name: 'Mucocutaneous leishmaniasis'
}, {
    name: 'Mucormycosis'
}, {
    name: 'Mucosal atrophy'
}, {
    name: 'Mucosal bleeding'
}, {
    name: 'Mucosal discolouration'
}, {
    name: 'Mucosal dryness'
}, {
    name: 'Mucosal erosion'
}, {
    name: 'Mucosal excoriation'
}, {
    name: 'Mucosal haemorrhage'
}, {
    name: 'Mucosal inflammation'
}, {
    name: 'Mucosal pigmentation'
}, {
    name: 'Mucosal swelling'
}, {
    name: 'Mucosal ulceration'
}, {
    name: 'Mucous membrane disorder'
}, {
    name: 'Mucous stools'
}, {
    name: 'Multi-infarct dementia'
}, {
    name: 'Multi-organ failure'
}, {
    name: 'Multidrug resistant tuberculosis'
}, {
    name: 'Multifocal atrial tachycardia'
}, {
    name: 'Multifocal motor neuropathy'
}, {
    name: 'Multifocal ventricular tachycardia'
}, {
    name: 'Multiparous'
}, {
    name: 'Multiple allergies'
}, {
    name: 'Multiple congenital abnormalities'
}, {
    name: 'Multiple fractures'
}, {
    name: 'Multiple pregnancy'
}, {
    name: 'Multiple sclerosis'
}, {
    name: 'Multiple sclerosis exacerbation'
}, {
    name: 'Multiple sclerosis relapse'
}, {
    name: 'Multiple system atrophy'
}, {
    name: 'Murine typhus'
}, {
    name: 'Muscarinic effects'
}, {
    name: 'Muscle atrophy'
}, {
    name: 'Muscle contractions involuntary'
}, {
    name: 'Muscle contracture'
}, {
    name: 'Muscle damage'
}, {
    name: 'Muscle enzyme increased'
}, {
    name: 'Muscle fatigue'
}, {
    name: 'Muscle fibrosis'
}, {
    name: 'Muscle haemorrhage'
}, {
    name: 'Muscle injury'
}, {
    name: 'Muscle mass'
}, {
    name: 'Muscle movement involuntary'
}, {
    name: 'Muscle necrosis'
}, {
    name: 'Muscle relaxant therapy'
}, {
    name: 'Muscle relaxation'
}, {
    name: 'Muscle rigidity'
}, {
    name: 'Muscle rupture'
}, {
    name: 'Muscle spasms'
}, {
    name: 'Muscle spasticity'
}, {
    name: 'Muscle stiffness'
}, {
    name: 'Muscle strain'
}, {
    name: 'Muscle swelling'
}, {
    name: 'Muscle tightness'
}, {
    name: 'Muscle tone disorder'
}, {
    name: 'Muscle tone flaccid'
}, {
    name: 'Muscle twitching'
}, {
    name: 'Muscular incoordination'
}, {
    name: 'Muscular ventricular septal defect'
}, {
    name: 'Muscular weakness'
}, {
    name: 'Musculoskeletal chest pain'
}, {
    name: 'Musculoskeletal deformity'
}, {
    name: 'Musculoskeletal discomfort'
}, {
    name: 'Musculoskeletal disorder'
}, {
    name: 'Musculoskeletal pain'
}, {
    name: 'Musculoskeletal stiffness'
}, {
    name: 'Mutism'
}, {
    name: 'Myalgia'
}, {
    name: 'Myasthenia'
}, {
    name: 'Myasthenia gravis'
}, {
    name: 'Myasthenia gravis-like syndrome'
}, {
    name: 'Myasthenic syndrome'
}, {
    name: 'Mycetoma NOS'
}, {
    name: 'Mycetoma mycotic'
}, {
    name: 'Mycobacterial infection'
}, {
    name: 'Mycobacterium avium complex infection'
}, {
    name: 'Mycobacterium test'
}, {
    name: 'Mycosis fungoides'
}, {
    name: 'Mycotic aneurysm'
}, {
    name: 'Mycotic endophthalmitis'
}, {
    name: 'Mydriasis'
}, {
    name: 'Myelitis'
}, {
    name: 'Myelitis transverse'
}, {
    name: 'Myelodysplasia'
}, {
    name: 'Myelodysplastic syndrome'
}, {
    name: 'Myelodysplastic syndrome transformation'
}, {
    name: 'Myelofibrosis'
}, {
    name: 'Myeloid leukaemia'
}, {
    name: 'Myeloid metaplasia'
}, {
    name: 'Myeloproliferative disorder'
}, {
    name: 'Myelosuppression'
}, {
    name: 'Myocardial depression'
}, {
    name: 'Myocardial disorder'
}, {
    name: 'Myocardial haemorrhage'
}, {
    name: 'Myocardial hypertrophy'
}, {
    name: 'Myocardial infarction'
}, {
    name: 'Myocardial ischaemia'
}, {
    name: 'Myocardial necrosis'
}, {
    name: 'Myocardial reinfarction'
}, {
    name: 'Myocardial rupture'
}, {
    name: 'Myocarditis'
}, {
    name: 'Myoclonic epilepsy'
}, {
    name: 'Myoclonus'
}, {
    name: 'Myofascial pain syndrome'
}, {
    name: 'Myoglobin urine present'
}, {
    name: 'Myoglobinaemia'
}, {
    name: 'Myoglobinuria'
}, {
    name: 'Myopathy'
}, {
    name: 'Myopathy toxic'
}, {
    name: 'Myopericarditis'
}, {
    name: 'Myopia'
}, {
    name: 'Myopia transient'
}, {
    name: 'Myositis'
}, {
    name: 'Myotonia'
}, {
    name: 'Myringitis'
}, {
    name: 'Myxoedema'
}, {
    name: 'Myxoedema coma'
}, {
    name: 'N-acetylglutamate synthase deficiency'
}, {
    name: 'Nail abnormality NOS'
}, {
    name: 'Nail bed infection'
}, {
    name: 'Nail bed tenderness'
}, {
    name: 'Nail changes'
}, {
    name: 'Nail discolouration'
}, {
    name: 'Nail discomfort'
}, {
    name: 'Nail disorder'
}, {
    name: 'Nail dystrophy'
}, {
    name: 'Nail hypertrophy'
}, {
    name: 'Nail infection'
}, {
    name: 'Nail longitudinal striations'
}, {
    name: 'Nail pigmentation'
}, {
    name: 'Nail ridging'
}, {
    name: 'Nail thinning'
}, {
    name: 'Nail toxicity'
}, {
    name: 'Narcolepsy'
}, {
    name: 'Narcosis'
}, {
    name: 'Nasal burning'
}, {
    name: 'Nasal congestion'
}, {
    name: 'Nasal discomfort'
}, {
    name: 'Nasal disorder'
}, {
    name: 'Nasal dryness'
}, {
    name: 'Nasal inflammation'
}, {
    name: 'Nasal irritation'
}, {
    name: 'Nasal itching'
}, {
    name: 'Nasal mucosa atrophy'
}, {
    name: 'Nasal mucosal disorder'
}, {
    name: 'Nasal mucosal erythema'
}, {
    name: 'Nasal mucus blood tinged'
}, {
    name: 'Nasal obstruction'
}, {
    name: 'Nasal odour'
}, {
    name: 'Nasal oedema'
}, {
    name: 'Nasal pain'
}, {
    name: 'Nasal passage irritation'
}, {
    name: 'Nasal polyps'
}, {
    name: 'Nasal septum deviation'
}, {
    name: 'Nasal septum disorder'
}, {
    name: 'Nasal septum perforation'
}, {
    name: 'Nasal septum ulceration'
}, {
    name: 'Nasal sinus drainage'
}, {
    name: 'Nasal soreness'
}, {
    name: 'Nasal ulcer'
}, {
    name: 'Nasopharyngeal cancer'
}, {
    name: 'Nasopharyngeal carcinoma'
}, {
    name: 'Nasopharyngeal disorder'
}, {
    name: 'Nasopharyngitis'
}, {
    name: 'Natural menopause'
}, {
    name: 'Nausea'
}, {
    name: 'Nausea aggravated'
}, {
    name: 'Nausea alone'
}, {
    name: 'Nausea postoperative'
}, {
    name: 'Neck injury'
}, {
    name: 'Neck oedema of'
}, {
    name: 'Neck pain'
}, {
    name: 'Neck stiffness'
}, {
    name: 'Neck swelling'
}, {
    name: 'Neck tightness'
}, {
    name: 'Necrobiosis lipoidica diabeticorum'
}, {
    name: 'Necrolysis epidermal'
}, {
    name: 'Necrosis'
}, {
    name: 'Necrosis ischaemic'
}, {
    name: 'Necrotising colitis'
}, {
    name: 'Necrotising enterocolitis neonatal'
}, {
    name: 'Necrotising fasciitis'
}, {
    name: 'Necrotising ulcerative gingivostomatitis'
}, {
    name: 'Necrotizing enterocolitis'
}, {
    name: 'Needle injury'
}, {
    name: 'Negativism'
}, {
    name: 'Neisseria infection'
}, {
    name: 'Neonatal and infancy disorder'
}, {
    name: 'Neonatal disorder'
}, {
    name: 'Neonatal hyponatraemia'
}, {
    name: 'Neonatal infection'
}, {
    name: 'Neonatal respiratory distress syndrome'
}, {
    name: 'Neonatal tachypnoea'
}, {
    name: 'Neonatal tetany'
}, {
    name: 'Neoplasm'
}, {
    name: 'Neoplasm malignant'
}, {
    name: 'Neoplasm malignant aggravated'
}, {
    name: 'Neoplasm progression'
}, {
    name: 'Neoplasm prostate'
}, {
    name: 'Neoplasm recurrence'
}, {
    name: 'Neoplasm skin'
}, {
    name: 'Nephritic syndrome'
}, {
    name: 'Nephritis'
}, {
    name: 'Nephritis interstitial'
}, {
    name: 'Nephroblastoma'
}, {
    name: 'Nephrocalcinosis'
}, {
    name: 'Nephrogenic diabetes insipidus'
}, {
    name: 'Nephrogenic systemic fibrosis'
}, {
    name: 'Nephrolithiasis'
}, {
    name: 'Nephropathy'
}, {
    name: 'Nephropathy toxic'
}, {
    name: 'Nephrosclerosis'
}, {
    name: 'Nephrosis'
}, {
    name: 'Nephrosis lower nephron'
}, {
    name: 'Nephrotic syndrome'
}, {
    name: 'Nephrotic syndrome with lesion of minimal change glomerulonephritis'
}, {
    name: 'Nephrotoxicity'
}, {
    name: 'Nerve compression'
}, {
    name: 'Nerve conduction studies abnormal'
}, {
    name: 'Nerve injury'
}, {
    name: 'Nerve paralysis'
}, {
    name: 'Nerve root lesion'
}, {
    name: 'Nervous system disorder'
}, {
    name: 'Nervous tremulousness'
}, {
    name: 'Nervousness'
}, {
    name: "Netherton's syndrome"
}, {
    name: 'Nettle rash'
}, {
    name: 'Neural hearing loss'
}, {
    name: 'Neural tube defect'
}, {
    name: 'Neuralgia'
}, {
    name: 'Neuritis'
}, {
    name: 'Neuritis retrobulbar'
}, {
    name: 'Neuroblastoma'
}, {
    name: 'Neurocirculatory asthenia'
}, {
    name: 'Neurocysticercosis'
}, {
    name: 'Neurodegenerative disorder'
}, {
    name: 'Neurodermatitis'
}, {
    name: 'Neuroectodermal neoplasm'
}, {
    name: 'Neuroendocrine tumour'
}, {
    name: 'Neurofibroma'
}, {
    name: 'Neurofibromatosis'
}, {
    name: 'Neurogenic bladder'
}, {
    name: 'Neurogenic bowel'
}, {
    name: 'Neuroglycopenia'
}, {
    name: 'Neuroleptic malignant syndrome'
}, {
    name: 'Neurologic reaction'
}, {
    name: 'Neurological disorders NEC'
}, {
    name: 'Neurological examination abnormal'
}, {
    name: 'Neurological impairment'
}, {
    name: 'Neurological symptom'
}, {
    name: 'Neuroma'
}, {
    name: 'Neuromuscular block prolonged'
}, {
    name: 'Neuromuscular toxicity'
}, {
    name: 'Neuromyopathy'
}, {
    name: 'Neuropathic arthropathy'
}, {
    name: 'Neuropathy'
}, {
    name: 'Neuropathy peripheral'
}, {
    name: 'Neuropsychiatric syndrome'
}, {
    name: 'Neurosis'
}, {
    name: 'Neurosyphilis'
}, {
    name: 'Neurotic depression'
}, {
    name: 'Neurotoxicity'
}, {
    name: 'Neurotransmitter level altered'
}, {
    name: 'Neutropenia'
}, {
    name: 'Neutropenia aggravated'
}, {
    name: 'Neutropenic colitis'
}, {
    name: 'Neutropenic enterocolitis'
}, {
    name: 'Neutropenic infection'
}, {
    name: 'Neutropenic sepsis'
}, {
    name: 'Neutrophil count decreased'
}, {
    name: 'Neutrophil count increased'
}, {
    name: 'Neutrophil percentage increased'
}, {
    name: 'Neutrophilia'
}, {
    name: 'Neutrophilic dermatosis'
}, {
    name: 'Nevus'
}, {
    name: 'Nicotine dependence'
}, {
    name: 'Nicotine poisoning'
}, {
    name: 'Nicotinic acid deficiency'
}, {
    name: 'Nicotinic effects'
}, {
    name: 'Night blindness'
}, {
    name: 'Night cramps'
}, {
    name: 'Night sweats'
}, {
    name: 'Nightmare'
}, {
    name: 'Nipple disorder'
}, {
    name: 'Nipple pain'
}, {
    name: 'Nipple swelling'
}, {
    name: 'Nipple tenderness'
}, {
    name: 'Nitrogen balance negative'
}, {
    name: 'Nocardiosis'
}, {
    name: 'Nocturia'
}, {
    name: 'Nocturia aggravated'
}, {
    name: 'Nocturnal awakening'
}, {
    name: 'Nocturnal confusion'
}, {
    name: 'Nocturnal dyspnoea'
}, {
    name: 'Nocturnal emission'
}, {
    name: 'Nocturnal enuresis'
}, {
    name: 'Nocturnal polyuria'
}, {
    name: 'Nodal arrhythmia'
}, {
    name: 'Nodal block'
}, {
    name: 'Nodal rhythm'
}, {
    name: 'Nodal tachycardia'
}, {
    name: 'Node-negative breast cancer'
}, {
    name: 'Node-positive breast cancer'
}, {
    name: 'Nodular basal cell carcinoma'
}, {
    name: 'Nodular glomerulosclerosis'
}, {
    name: 'Nodular lymphoma'
}, {
    name: 'Nodular regenerative hyperplasia'
}, {
    name: 'Nodule'
}, {
    name: "Non-Hodgkin's lymphoma"
}, {
    name: 'Non-Q wave MI'
}, {
    name: 'Non-accidental injury'
}, {
    name: 'Non-cardiac chest pain'
}, {
    name: 'Non-cardiogenic pulmonary oedema'
}, {
    name: 'Non-erosive reflux disease'
}, {
    name: 'Non-ischemic cardiomyopathy'
}, {
    name: 'Non-scalp psoriasis'
}, {
    name: 'Non-small cell lung cancer'
}, {
    name: 'Non-small cell lung cancer metastatic'
}, {
    name: 'Non-small cell lung cancer stage III'
}, {
    name: 'Non-smoker'
}, {
    name: 'Non-sustained ventricular tachycardia'
}, {
    name: 'Non-tobacco user'
}, {
    name: 'Nonconvulsive status epilepticus'
}, {
    name: 'Noninfectious peritonitis'
}, {
    name: 'Nonketotic hyperglycinaemia'
}, {
    name: 'Nontoxic goiter'
}, {
    name: 'Normal pregnancy'
}, {
    name: 'Normochromic normocytic anaemia'
}, {
    name: 'Normocytic anemia'
}, {
    name: 'Norwegian scabies'
}, {
    name: 'Nose infection NOS'
}, {
    name: 'Nosocomial infection'
}, {
    name: 'Nosocomial pneumonia'
}, {
    name: 'NPN increased'
}, {
    name: 'Nuchal rigidity'
}, {
    name: 'Nulliparous'
}, {
    name: 'Numbness'
}, {
    name: 'Numbness facial'
}, {
    name: 'Numbness generalized'
}, {
    name: 'Numbness in fingers'
}, {
    name: 'Numbness in leg'
}, {
    name: 'Numbness lips'
}, {
    name: 'Numbness of limbs'
}, {
    name: 'Numbness of tongue'
}, {
    name: 'Nystagmus'
}, {
    name: 'Obesity'
}, {
    name: 'Obliterative bronchiolitis'
}, {
    name: 'Obnubilation'
}, {
    name: 'Obsessional neurosis'
}, {
    name: 'Obsessive rumination'
}, {
    name: 'Obsessive thoughts'
}, {
    name: 'Obsessive-compulsive disorder'
}, {
    name: 'Obsessive-compulsive personality disorder'
}, {
    name: 'Obstetric procedure complication'
}, {
    name: 'Obstipation'
}, {
    name: 'Obstruction'
}, {
    name: 'Obstruction pyloric'
}, {
    name: 'Obstructive airways disorder'
}, {
    name: 'Obstructive chronic bronchitis'
}, {
    name: 'Obstructive sleep apnea syndrome'
}, {
    name: 'Occipital headache'
}, {
    name: 'Occipital neuralgia'
}, {
    name: 'Occult blood positive'
}, {
    name: 'Occupational asthma'
}, {
    name: 'Occupational exposures'
}, {
    name: 'Ochronosis'
}, {
    name: 'Ocular discomfort'
}, {
    name: 'Ocular hyperaemia'
}, {
    name: 'Ocular hypertension'
}, {
    name: 'Ocular icterus'
}, {
    name: 'Ocular sensation disorders'
}, {
    name: 'Ocular stinging'
}, {
    name: 'Ocular surface disease'
}, {
    name: 'Ocular toxicity'
}, {
    name: 'Ocular vascular disorder'
}, {
    name: 'Oculo-respiratory syndrome'
}, {
    name: 'Oculogyration'
}, {
    name: 'Oculogyric crisis'
}, {
    name: 'Oculomucocutaneous syndrome'
}, {
    name: 'Oculorespiratory syndrome'
}, {
    name: 'Odynophagia'
}, {
    name: 'Oedema'
}, {
    name: 'Oedema aggravated'
}, {
    name: 'Oedema auricular'
}, {
    name: 'Oedema due to cardiac disease'
}, {
    name: 'Oedema genital'
}, {
    name: 'Oedema labial genital'
}, {
    name: 'Oedema mouth'
}, {
    name: 'Oedema mucosal'
}, {
    name: 'Oedema peripheral'
}, {
    name: 'Oesophageal achalasia'
}, {
    name: 'Oesophageal adenocarcinoma'
}, {
    name: 'Oesophageal atresia'
}, {
    name: 'Oesophageal candidiasis'
}, {
    name: 'Oesophageal carcinoma'
}, {
    name: 'Oesophageal discomfort'
}, {
    name: 'Oesophageal disorder'
}, {
    name: 'Oesophageal haemorrhage'
}, {
    name: 'Oesophageal irritation'
}, {
    name: 'Oesophageal motility disorder'
}, {
    name: 'Oesophageal neoplasm'
}, {
    name: 'Oesophageal obstruction'
}, {
    name: 'Oesophageal oedema'
}, {
    name: 'Oesophageal pain'
}, {
    name: 'Oesophageal perforation'
}, {
    name: 'Oesophageal reflux aggravated'
}, {
    name: 'Oesophageal rupture'
}, {
    name: 'Oesophageal spasm'
}, {
    name: 'Oesophageal stenosis'
}, {
    name: 'Oesophageal stenosis acquired'
}, {
    name: 'Oesophageal ulcer'
}, {
    name: 'Oesophageal varices haemorrhage'
}, {
    name: 'Oesophagitis'
}, {
    name: 'Oesophagitis ulcerative'
}, {
    name: 'Oestradiol increased'
}, {
    name: 'Oestrogen deficiency'
}, {
    name: 'Oestrogen low'
}, {
    name: 'Oestrogenic effect'
}, {
    name: 'Oily hair'
}, {
    name: 'Oily skin'
}, {
    name: 'Old myocardial infarction'
}, {
    name: 'Olecranon bursitis'
}, {
    name: 'Oligohydramnios'
}, {
    name: 'Oligomenorrhoea'
}, {
    name: 'Oligospermia'
}, {
    name: 'Oliguria'
}, {
    name: 'Omphalocele'
}, {
    name: 'Onchocerciasis'
}, {
    name: 'Onychia'
}, {
    name: 'Onychoclasis'
}, {
    name: 'Onycholysis'
}, {
    name: 'Onychomadesis'
}, {
    name: 'Onychomycosis'
}, {
    name: 'Open angle glaucoma'
}, {
    name: 'Open wound'
}, {
    name: 'Operative bleeding'
}, {
    name: 'Ophthalmia neonatorum'
}, {
    name: 'Ophthalmic herpes simplex'
}, {
    name: 'Ophthalmic herpes zoster'
}, {
    name: 'Ophthalmoplegia'
}, {
    name: 'Opioid abuse'
}, {
    name: 'Opioid induced constipation'
}, {
    name: 'Opioid naive'
}, {
    name: 'Opisthotonus'
}, {
    name: 'Opportunistic infection'
}, {
    name: 'Opportunistic mycosis'
}, {
    name: 'Oppositional'
}, {
    name: 'Optic atrophy'
}, {
    name: 'Optic disc vascular disorder'
}, {
    name: 'Optic ischaemic neuropathy'
}, {
    name: 'Optic nerve cupping'
}, {
    name: 'Optic nerve disorder'
}, {
    name: 'Optic neuritis'
}, {
    name: 'Oral candidiasis'
}, {
    name: 'Oral discomfort'
}, {
    name: 'Oral disorder'
}, {
    name: 'Oral fungal infection'
}, {
    name: 'Oral herpes'
}, {
    name: 'Oral infection'
}, {
    name: 'Oral lesion'
}, {
    name: 'Oral mucosa erosion'
}, {
    name: 'Oral mucosa sore'
}, {
    name: 'Oral mucosal blistering'
}, {
    name: 'Oral mucosal discolouration'
}, {
    name: 'Oral mucosal disorder'
}, {
    name: 'Oral mucosal exfoliation'
}, {
    name: 'Oral mucosal irritation'
}, {
    name: 'Oral mucosal petechiae'
}, {
    name: 'Oral neoplasm'
}, {
    name: 'Oral neoplasm benign'
}, {
    name: 'Oral pain'
}, {
    name: 'Oral papilloma'
}, {
    name: 'Oral pruritus'
}, {
    name: 'Oral pustule'
}, {
    name: 'Oral soft tissue disorder NOS'
}, {
    name: 'Oral toxicity'
}, {
    name: 'Orbital oedema'
}, {
    name: 'Orchitis'
}, {
    name: 'Orchitis noninfective'
}, {
    name: 'Organ failure'
}, {
    name: 'Organic brain syndrome'
}, {
    name: 'Organising pneumonia'
}, {
    name: 'Orgasm abnormal'
}, {
    name: 'Orgasmic sensation decreased'
}, {
    name: 'Ornithine transcarbamoylase deficiency'
}, {
    name: 'Orofacial dyskinesia'
}, {
    name: 'Orofacial oedema'
}, {
    name: 'Oromandibular dystonia'
}, {
    name: 'Oropharyngeal blistering'
}, {
    name: 'Oropharyngeal candidiasis'
}, {
    name: 'Oropharyngeal discomfort'
}, {
    name: 'Oropharyngeal pain'
}, {
    name: 'Oropharyngeal spasm'
}, {
    name: 'Oropharyngeal squamous cell carcinoma'
}, {
    name: 'Oropharyngeal swelling'
}, {
    name: 'Orthopnoea'
}, {
    name: 'Orthostatic collapse'
}, {
    name: 'Orthostatic dysregulation'
}, {
    name: 'Orthostatic hypertension'
}, {
    name: 'Orthostatic hypotension'
}, {
    name: 'Orthostatic intolerance'
}, {
    name: 'Oscillopsia'
}, {
    name: 'Osmolality increased'
}, {
    name: 'Osmotic demyelination syndrome'
}, {
    name: 'Osteitis'
}, {
    name: 'Osteitis deformans'
}, {
    name: 'Osteoarthritis'
}, {
    name: 'Osteoarthritis aggravated'
}, {
    name: 'Osteoarthritis of cervical spine'
}, {
    name: 'Osteoarticular pain'
}, {
    name: 'Osteocalcin increased'
}, {
    name: 'Osteochondrosis'
}, {
    name: 'Osteodystrophy'
}, {
    name: 'Osteogenesis imperfecta'
}, {
    name: 'Osteolysis'
}, {
    name: 'Osteolytic lesion'
}, {
    name: 'Osteomalacia'
}, {
    name: 'Osteomyelitis'
}, {
    name: 'Osteonecrosis'
}, {
    name: 'Osteonecrosis of jaw'
}, {
    name: 'Osteopenia'
}, {
    name: 'Osteoporosis'
}, {
    name: 'Osteoporosis postmenopausal'
}, {
    name: 'Osteoporotic fracture'
}, {
    name: 'Osteosarcoma'
}, {
    name: 'Osteosarcoma metastatic'
}, {
    name: 'Osteosclerosis'
}, {
    name: 'Other acne'
}, {
    name: 'Other bacterial diseases'
}, {
    name: 'Other conjunctivitis'
}, {
    name: 'Other dermatoses'
}, {
    name: 'Other disorders of eye'
}, {
    name: 'Other forms of epilepsy'
}, {
    name: 'Other scleritis'
}, {
    name: 'Other sleep disturbances'
}, {
    name: 'Otitis'
}, {
    name: 'Otitis externa'
}, {
    name: 'Otitis externa fungal'
}, {
    name: 'Otitis media'
}, {
    name: 'Otitis media acute'
}, {
    name: 'Otitis media bacterial'
}, {
    name: 'Otitis media chronic'
}, {
    name: 'Otitis media serous'
}, {
    name: 'Otorrhoea'
}, {
    name: 'Otosalpingitis'
}, {
    name: 'Ototoxicity'
}, {
    name: 'Ovarian adenocarcinoma'
}, {
    name: 'Ovarian atrophy'
}, {
    name: 'Ovarian cancer'
}, {
    name: 'Ovarian carcinoma'
}, {
    name: 'Ovarian cyst'
}, {
    name: 'Ovarian disorder'
}, {
    name: 'Ovarian enlargement'
}, {
    name: 'Ovarian epithelial cancer'
}, {
    name: 'Ovarian epithelial cancer recurrent'
}, {
    name: 'Ovarian epithelial cancer stage IV'
}, {
    name: 'Ovarian failure'
}, {
    name: 'Ovarian germ cell teratoma benign'
}, {
    name: 'Ovarian haemorrhage'
}, {
    name: 'Ovarian hyperstimulation'
}, {
    name: 'Ovarian hyperstimulation syndrome'
}, {
    name: 'Ovarian neoplasm'
}, {
    name: 'Ovarian pain'
}, {
    name: 'Overactivity'
}, {
    name: 'Overdose'
}, {
    name: 'Overdose effect'
}, {
    name: 'Overgrowth bacterial'
}, {
    name: 'Oversedation'
}, {
    name: 'Overweight'
}, {
    name: 'Overwork'
}, {
    name: 'Ovulation disorder'
}, {
    name: 'Ovulation inhibited'
}, {
    name: 'Ovulation pain'
}, {
    name: 'Oxygen saturation decreased'
}, {
    name: 'Pain'
}, {
    name: 'Pain at rest'
}, {
    name: 'Pain burning'
}, {
    name: 'Pain during injection'
}, {
    name: 'Pain hunger'
}, {
    name: 'Pain in arm'
}, {
    name: 'Pain in elbow'
}, {
    name: 'Pain in extremity'
}, {
    name: 'Pain in fingers'
}, {
    name: 'Pain in jaw'
}, {
    name: 'Pain localised'
}, {
    name: 'Pain neck/shoulder'
}, {
    name: 'Pain nerve'
}, {
    name: 'Pain of lower extremities'
}, {
    name: 'Pain of skin'
}, {
    name: 'Pain worsened'
}, {
    name: 'Painful ankle'
}, {
    name: 'Painful ejaculation'
}, {
    name: 'Painful erection'
}, {
    name: 'Painful red eyes'
}, {
    name: 'Painful respiration'
}, {
    name: 'Painful response to normal stimuli'
}, {
    name: 'Pallanesthesia'
}, {
    name: 'Pallor'
}, {
    name: 'Pallor facial'
}, {
    name: 'Pallor of skin'
}, {
    name: 'Palmar erythema'
}, {
    name: 'Palmar-plantar erythema'
}, {
    name: 'Palmar-plantar erythrodysaesthesia syndrome'
}, {
    name: 'Palmoplantar keratoderma'
}, {
    name: 'Palpable purpura'
}, {
    name: 'Palpitations'
}, {
    name: 'Panaritium'
}, {
    name: 'Pancolitis'
}, {
    name: 'Pancreatic abscess'
}, {
    name: 'Pancreatic carcinoma'
}, {
    name: 'Pancreatic carcinoma metastatic'
}, {
    name: 'Pancreatic disorder'
}, {
    name: 'Pancreatic enzymes abnormal'
}, {
    name: 'Pancreatic enzymes increased'
}, {
    name: 'Pancreatic fistula'
}, {
    name: 'Pancreatic insufficiency'
}, {
    name: 'Pancreatic necrosis'
}, {
    name: 'Pancreatic neoplasm'
}, {
    name: 'Pancreatic pseudocyst'
}, {
    name: 'Pancreatitis'
}, {
    name: 'Pancreatitis acute'
}, {
    name: 'Pancreatitis acute on chronic'
}, {
    name: 'Pancreatitis aggravated'
}, {
    name: 'Pancreatitis chronic'
}, {
    name: 'Pancreatitis due to biliary obstruction'
}, {
    name: 'Pancreatitis haemorrhagic'
}, {
    name: 'Pancreatitis necrotising'
}, {
    name: 'Pancytopenia'
}, {
    name: 'Panhypopituitarism'
}, {
    name: 'Panic attack'
}, {
    name: 'Panic disorder'
}, {
    name: 'Panic reaction'
}, {
    name: 'Panniculitis'
}, {
    name: 'Panophthalmitis'
}, {
    name: 'Panuveitis'
}, {
    name: 'Papanicolaou smear suspicious'
}, {
    name: 'Papillary muscle rupture'
}, {
    name: 'Papillary thyroid cancer'
}, {
    name: 'Papilloedema'
}, {
    name: 'Papilloma'
}, {
    name: 'Papillomatosis'
}, {
    name: 'Papule'
}, {
    name: 'Papulopustular rash'
}, {
    name: 'Paracoccidioides infection'
}, {
    name: 'Paradoxical pressor response'
}, {
    name: 'Paraesthesia'
}, {
    name: 'Paraesthesia NEC'
}, {
    name: 'Paraesthesia foot'
}, {
    name: 'Paraesthesia hand'
}, {
    name: 'Paraesthesia oral'
}, {
    name: 'Paraesthesia skin'
}, {
    name: 'Paraesthesias and dysaesthesias'
}, {
    name: 'Paraganglion neoplasm'
}, {
    name: 'Parainfluenzae virus infection'
}, {
    name: 'Paralysis'
}, {
    name: 'Paralysis flaccid'
}, {
    name: 'Paralysis of bladder'
}, {
    name: 'Parametritis'
}, {
    name: 'Paranasal sinus hypersecretion'
}, {
    name: 'Paranoia'
}, {
    name: 'Paranoid delusions'
}, {
    name: 'Paranoid reaction'
}, {
    name: 'Paranoid state'
}, {
    name: 'Paraparesis'
}, {
    name: 'Paraplegia'
}, {
    name: 'Paraproteinaemia'
}, {
    name: 'Parasitic gastroenteritis'
}, {
    name: 'Parasomnia'
}, {
    name: 'Parasuicide'
}, {
    name: 'Parathyroid disorder'
}, {
    name: 'Parathyroid tumour'
}, {
    name: 'Parathyroid tumour benign'
}, {
    name: 'Paratyphoid fever'
}, {
    name: 'Paresis'
}, {
    name: 'Paresthesia generalized'
}, {
    name: 'Paresthesia lips'
}, {
    name: 'Paresthesia lower limb'
}, {
    name: 'Paresthesia of fingers'
}, {
    name: 'Paresthesia of limbs'
}, {
    name: 'Paresthesia of scalp'
}, {
    name: "Parkinson's disease"
}, {
    name: "Parkinson's disease aggravated"
}, {
    name: 'Parkinsonian gait'
}, {
    name: 'Parkinsonian rest tremor'
}, {
    name: 'Parkinsonism'
}, {
    name: 'Parkinsonism aggravated'
}, {
    name: 'Parkinsonism post encephalitic'
}, {
    name: 'Paronychia'
}, {
    name: 'Parosmia'
}, {
    name: 'Parotid duct obstruction'
}, {
    name: 'Parotid gland enlargement'
}, {
    name: 'Parotid gland inflammation'
}, {
    name: 'Parotid swelling'
}, {
    name: 'Parotitis'
}, {
    name: 'Paroxysmal atrial fibrillation'
}, {
    name: 'Paroxysmal atrial flutter'
}, {
    name: 'Paroxysmal atrial tachycardia'
}, {
    name: 'Paroxysmal nocturnal haemoglobinuria'
}, {
    name: 'Paroxysmal supraventricular tachycardia'
}, {
    name: 'Paroxysmal ventricular tachycardia'
}, {
    name: 'Pars planitis'
}, {
    name: 'Partial epilepsy'
}, {
    name: 'Partial hearing loss'
}, {
    name: 'Partial permanent deafness'
}, {
    name: 'Partial seizures'
}, {
    name: 'Partial transitory deafness'
}, {
    name: 'Partner stress'
}, {
    name: 'Pasteurella infection'
}, {
    name: 'Patent ductus arteriosus'
}, {
    name: 'Pathogen resistance'
}, {
    name: 'Pathologic myopia'
}, {
    name: 'Pathological gambling'
}, {
    name: 'PCO2'
}, {
    name: 'Peak expiratory flow rate'
}, {
    name: 'Peak flow'
}, {
    name: 'Peanut allergy'
}, {
    name: 'Pectus excavatum'
}, {
    name: 'Pedal pulse decreased'
}, {
    name: 'Pediculosis capitis'
}, {
    name: 'Pediculosis corporis'
}, {
    name: 'Peliosis hepatis'
}, {
    name: 'Pelvi-ureteric obstruction'
}, {
    name: 'Pelvic abscess'
}, {
    name: 'Pelvic discomfort'
}, {
    name: 'Pelvic fibrosis'
}, {
    name: 'Pelvic fracture'
}, {
    name: 'Pelvic haematoma'
}, {
    name: 'Pelvic haemorrhage'
}, {
    name: 'Pelvic infection'
}, {
    name: 'Pelvic inflammatory disease'
}, {
    name: 'Pelvic neoplasm'
}, {
    name: 'Pelvic pain'
}, {
    name: 'Pelvic pain female'
}, {
    name: 'Pelvic peritoneal adhesions'
}, {
    name: 'Pelvic peritonitis'
}, {
    name: 'Pelvic venous thrombosis'
}, {
    name: 'Pemphigoid'
}, {
    name: 'Pemphigoid reaction'
}, {
    name: 'Pemphigus'
}, {
    name: 'Pemphigus vulgaris'
}, {
    name: 'Penicillin allergy'
}, {
    name: 'Penile cancer'
}, {
    name: 'Penile curvature'
}, {
    name: 'Penile discharge'
}, {
    name: 'Penile haematoma'
}, {
    name: 'Penile haemorrhage'
}, {
    name: 'Penile infection'
}, {
    name: 'Penile oedema'
}, {
    name: 'Penile pain'
}, {
    name: 'Penile swelling'
}, {
    name: 'Penis disorder'
}, {
    name: 'Peptic ulcer'
}, {
    name: 'Peptic ulcer haemorrhage'
}, {
    name: 'Peptic ulcer perforation'
}, {
    name: 'Peptic ulcer reactivated'
}, {
    name: 'Perceptual distortions'
}, {
    name: 'Perceptual disturbance'
}, {
    name: 'Perennial allergic rhinitis'
}, {
    name: 'Performance fear'
}, {
    name: 'Performance status decreased'
}, {
    name: 'Perianal warts'
}, {
    name: 'Periarthritis'
}, {
    name: 'Pericardial disease'
}, {
    name: 'Pericardial effusion'
}, {
    name: 'Pericardial haemorrhage'
}, {
    name: 'Pericardial rub'
}, {
    name: 'Pericarditis'
}, {
    name: 'Pericarditis constrictive'
}, {
    name: 'Pericoronitis'
}, {
    name: 'Peridiverticular abscess'
}, {
    name: 'Perineal abscess'
}, {
    name: 'Perineal injury'
}, {
    name: 'Perineal laceration'
}, {
    name: 'Perineal pain'
}, {
    name: 'Perineal pain female'
}, {
    name: 'Perinephric abscess'
}, {
    name: 'Perinephric collection'
}, {
    name: 'Periodontal destruction'
}, {
    name: 'Periodontal disease'
}, {
    name: 'Periodontitis'
}, {
    name: 'Perioral paraesthesia'
}, {
    name: 'Perioral tingling'
}, {
    name: 'Periorbital haematoma'
}, {
    name: 'Periorbital oedema'
}, {
    name: 'Periorbital pain'
}, {
    name: 'Periorbital swelling'
}, {
    name: 'Periostitis'
}, {
    name: 'Peripheral T-cell lymphoma unspecified'
}, {
    name: 'Peripheral arterial disease'
}, {
    name: 'Peripheral arterial occlusive disease'
}, {
    name: 'Peripheral artery aneurysm'
}, {
    name: 'Peripheral artery stenosis'
}, {
    name: 'Peripheral artery thrombosis'
}, {
    name: 'Peripheral coldness'
}, {
    name: 'Peripheral embolism'
}, {
    name: 'Peripheral gangrene'
}, {
    name: 'Peripheral ischaemia'
}, {
    name: 'Peripheral motor neuropathy'
}, {
    name: 'Peripheral nerve injury'
}, {
    name: 'Peripheral nerve palsy'
}, {
    name: 'Peripheral neuropathy aggravated'
}, {
    name: 'Peripheral sensorimotor neuropathy'
}, {
    name: 'Peripheral sensory neuropathy'
}, {
    name: 'Peripheral swelling'
}, {
    name: 'Peripheral vascular disorder'
}, {
    name: 'Peripheral vasodilatation'
}, {
    name: 'Perirectal abscess'
}, {
    name: 'Perirenal haematoma'
}, {
    name: 'Peritoneal adhesions'
}, {
    name: 'Peritoneal cloudy effluent'
}, {
    name: 'Peritoneal haemorrhage'
}, {
    name: 'Peritoneal infection'
}, {
    name: 'Peritonitis'
}, {
    name: 'Peritonitis bacterial'
}, {
    name: 'Peritonsillar abscess'
}, {
    name: 'Peritonsillitis'
}, {
    name: 'Periungual erythema'
}, {
    name: 'Periventricular leukomalacia'
}, {
    name: 'Permanent atrial fibrillation'
}, {
    name: 'Pernicious anaemia'
}, {
    name: 'Peroneal muscular atrophy'
}, {
    name: 'Peroneal nerve palsy'
}, {
    name: 'Perseveration'
}, {
    name: 'Persistent atrial fibrillation'
}, {
    name: 'Persistent cough'
}, {
    name: 'Persistent dry cough'
}, {
    name: 'Persistent foetal circulation'
}, {
    name: 'Persistent vomiting'
}, {
    name: 'Personality change'
}, {
    name: 'Personality disorder'
}, {
    name: 'Pertussis'
}, {
    name: 'Petechiae'
}, {
    name: 'Petit mal epilepsy'
}, {
    name: 'Petit mal status, epileptic'
}, {
    name: "Peyronie's disease"
}, {
    name: 'pH normal'
}, {
    name: 'pH urine decreased'
}, {
    name: 'pH urine increased'
}, {
    name: 'Phaeochromocytoma'
}, {
    name: 'Phaeochromocytoma malignant'
}, {
    name: 'Phagocytosis'
}, {
    name: 'Phantom limb pain'
}, {
    name: 'Phantom pain'
}, {
    name: 'Pharmacokinetic interaction'
}, {
    name: 'Pharyngeal disorder'
}, {
    name: 'Pharyngeal erythema'
}, {
    name: 'Pharyngeal haemorrhage'
}, {
    name: 'Pharyngeal lesion'
}, {
    name: 'Pharyngeal mucositis'
}, {
    name: 'Pharyngeal oedema'
}, {
    name: 'Pharyngitis'
}, {
    name: 'Pharyngitis streptococcal'
}, {
    name: 'Pharyngitis ulcerative'
}, {
    name: 'Pharyngo-oral irritation'
}, {
    name: 'Pharyngolaryngeal pain'
}, {
    name: 'Pharyngotonsillitis'
}, {
    name: 'Phenylketonuria'
}, {
    name: 'Philadelphia chromosome positive'
}, {
    name: 'Phimosis'
}, {
    name: 'Phlebitis'
}, {
    name: 'Phlebitis superficial'
}, {
    name: 'Phlebosclerosis'
}, {
    name: 'Phobia'
}, {
    name: 'Phobic avoidance'
}, {
    name: 'Phocomelia'
}, {
    name: 'Phonological disorder'
}, {
    name: 'Phonophobia'
}, {
    name: 'Phosphatase alkaline increased'
}, {
    name: 'Phosphate increased'
}, {
    name: 'Phosphate low'
}, {
    name: 'Phosphorus low'
}, {
    name: 'Photocontact dermatitis'
}, {
    name: 'Photodamaged skin'
}, {
    name: 'Photodermatosis'
}, {
    name: 'Photoonycholysis'
}, {
    name: 'Photophobia'
}, {
    name: 'Photopsia'
}, {
    name: 'Photosensitivity'
}, {
    name: 'Photosensitivity allergic reaction'
}, {
    name: 'Photosensitivity reaction'
}, {
    name: 'Phototoxicity'
}, {
    name: 'Physical assault'
}, {
    name: 'Physical disability'
}, {
    name: 'Physical wandering'
}, {
    name: 'Phytosterolaemia'
}, {
    name: 'Pica'
}, {
    name: 'Pigment dispersion syndrome'
}, {
    name: 'Pigmentation disorder'
}, {
    name: 'Pigmentation skin'
}, {
    name: 'Pill rolling'
}, {
    name: 'Piloerection'
}, {
    name: 'Pilonidal cyst'
}, {
    name: 'Pimples'
}, {
    name: 'Pinealoma'
}, {
    name: 'Pinta'
}, {
    name: 'Pitting edema'
}, {
    name: 'Pituitary adenoma'
}, {
    name: 'Pituitary apoplexy'
}, {
    name: 'Pituitary dwarfism'
}, {
    name: 'Pituitary haemorrhage'
}, {
    name: 'Pituitary hormone deficiency'
}, {
    name: 'Pituitary infarction'
}, {
    name: 'Pituitary microadenoma'
}, {
    name: 'Pituitary tumour'
}, {
    name: 'Pituitary tumour benign'
}, {
    name: "Pituitary-dependent Cushing's syndrome"
}, {
    name: 'Pityriasis'
}, {
    name: 'Pityriasis lichenoides et varioliformis acuta'
}, {
    name: 'Pityriasis rubra pilaris'
}, {
    name: 'Placental disorder'
}, {
    name: 'Plague'
}, {
    name: 'Plague sepsis'
}, {
    name: 'Plantar erythema'
}, {
    name: 'Plantar fasciitis'
}, {
    name: 'Plantar warts'
}, {
    name: 'Plaque psoriasis'
}, {
    name: 'Plasma calcium decreased'
}, {
    name: 'Plasma cell leukaemia'
}, {
    name: 'Plasma cell myeloma'
}, {
    name: 'Plasma cholesterol increased'
}, {
    name: 'Plasma creatinine increased'
}, {
    name: 'Plasma osmolality decreased'
}, {
    name: 'Plasma osmolality increased'
}, {
    name: 'Plasma triglycerides increased'
}, {
    name: 'Plasmacytoma'
}, {
    name: 'Plasmodium falciparum infection'
}, {
    name: 'Plasmodium malariae infection'
}, {
    name: 'Plasmodium ovale infection'
}, {
    name: 'Plasmodium vivax infection'
}, {
    name: 'Platelet adhesiveness'
}, {
    name: 'Platelet aggregation abnormal'
}, {
    name: 'Platelet aggregation increased'
}, {
    name: 'Platelet aggregation inhibition'
}, {
    name: 'Platelet count abnormal'
}, {
    name: 'Platelet count decreased'
}, {
    name: 'Platelet count normal'
}, {
    name: 'Platelet disorder'
}, {
    name: 'Platelet dysfunction'
}, {
    name: 'Platelet production decreased'
}, {
    name: 'Plateletcrit decreased'
}, {
    name: 'Pleural disorder'
}, {
    name: 'Pleural effusion'
}, {
    name: 'Pleural fibrosis'
}, {
    name: 'Pleural infection'
}, {
    name: 'Pleural mesothelioma malignant'
}, {
    name: 'Pleural rub'
}, {
    name: 'Pleural thickening'
}, {
    name: 'Pleurisy'
}, {
    name: 'Pleuritic pain'
}, {
    name: 'Pleuropericarditis'
}, {
    name: 'Pleurothotonus'
}, {
    name: 'Pneumatosis'
}, {
    name: 'Pneumatosis cystoides intestinalis'
}, {
    name: 'Pneumatosis intestinalis'
}, {
    name: 'Pneumococcal infection'
}, {
    name: 'Pneumocystis carinii infection'
}, {
    name: 'Pneumocystis jirovecii infection'
}, {
    name: 'Pneumocystis jirovecii pneumonia'
}, {
    name: 'Pneumomediastinum'
}, {
    name: 'Pneumonia'
}, {
    name: 'Pneumonia anthrax'
}, {
    name: 'Pneumonia aspiration'
}, {
    name: 'Pneumonia bacterial'
}, {
    name: 'Pneumonia chlamydial'
}, {
    name: 'Pneumonia cytomegaloviral'
}, {
    name: 'Pneumonia due to Streptococcus, group b'
}, {
    name: 'Pneumonia fungal'
}, {
    name: 'Pneumonia hypostatic'
}, {
    name: 'Pneumonia klebsiella'
}, {
    name: 'Pneumonia legionella'
}, {
    name: 'Pneumonia mycoplasmal'
}, {
    name: 'Pneumonia necrotising'
}, {
    name: 'Pneumonia recurrent'
}, {
    name: 'Pneumonia staphylococcal'
}, {
    name: 'Pneumonia streptococcal'
}, {
    name: 'Pneumopericardium'
}, {
    name: 'Pneumoperitoneum'
}, {
    name: 'Pneumothorax'
}, {
    name: 'Poikilocytosis'
}, {
    name: 'Poisoning'
}, {
    name: 'Poisoning by salicylates'
}, {
    name: 'Poliomyelitis'
}, {
    name: 'Pollakiuria'
}, {
    name: 'Polyangiitis'
}, {
    name: 'Polyarteritis nodosa'
}, {
    name: 'Polyarthralgia'
}, {
    name: 'Polyarthritis'
}, {
    name: 'Polyarthropathy'
}, {
    name: 'Polychondritis'
}, {
    name: 'Polycystic kidney'
}, {
    name: 'Polycystic ovaries'
}, {
    name: 'Polycythaemia'
}, {
    name: 'Polycythaemia vera'
}, {
    name: 'Polydactyly'
}, {
    name: 'Polydipsia'
}, {
    name: 'Polydipsia psychogenic'
}, {
    name: 'Polyhydramnios'
}, {
    name: 'Polymenorrhoea'
}, {
    name: 'Polymorphic light eruption'
}, {
    name: 'Polymorphonuclear leukocytosis'
}, {
    name: 'Polymyalgia'
}, {
    name: 'Polymyalgia rheumatica'
}, {
    name: 'Polymyositis'
}, {
    name: 'Polyneuritis'
}, {
    name: 'Polyneuropathy'
}, {
    name: 'Polyomavirus infections'
}, {
    name: 'Polyomavirus-associated nephropathy'
}, {
    name: 'Polyp'
}, {
    name: 'Polyradiculoneuritis'
}, {
    name: 'Polyserositis'
}, {
    name: 'Polyuria'
}, {
    name: 'Poor concentration'
}, {
    name: 'Poor peripheral circulation'
}, {
    name: 'Poor quality sleep'
}, {
    name: 'Poor urinary stream'
}, {
    name: 'Poor venous access'
}, {
    name: 'Porphyria acute'
}, {
    name: 'Porphyria aggravated'
}, {
    name: 'Porphyria cutanea tarda'
}, {
    name: 'Porphyria hepatic'
}, {
    name: 'Porphyria non-acute'
}, {
    name: 'Porphyrin metabolism disorder'
}, {
    name: 'Portal hypertension'
}, {
    name: 'Portal vein thrombosis'
}, {
    name: 'Portopulmonary hypertension'
}, {
    name: 'Post MI'
}, {
    name: 'Post abortion haemorrhage'
}, {
    name: 'Post gastric surgery syndrome'
}, {
    name: 'Post herpetic neuralgia'
}, {
    name: 'Post lumbar puncture syndrome'
}, {
    name: 'Post procedural complication'
}, {
    name: 'Post procedural constipation'
}, {
    name: 'Post procedural diarrhoea'
}, {
    name: 'Post procedural discharge'
}, {
    name: 'Post procedural haematoma'
}, {
    name: 'Post procedural haemorrhage'
}, {
    name: 'Post procedural infection'
}, {
    name: 'Post procedural nausea'
}, {
    name: 'Post procedural oedema'
}, {
    name: 'Post procedural pain'
}, {
    name: 'Post procedural swelling'
}, {
    name: 'Post thrombotic syndrome'
}, {
    name: 'Post transplant diabetes mellitus'
}, {
    name: 'Post transplant lymphoproliferative disorder'
}, {
    name: 'Post vagotomy diarrhea'
}, {
    name: 'Post-traumatic neck syndrome'
}, {
    name: 'Post-traumatic pain'
}, {
    name: 'Post-traumatic stress disorder'
}, {
    name: 'Post-tussive vomiting'
}, {
    name: 'Posterior capsule opacification'
}, {
    name: 'Posterior reversible encephalopathy syndrome'
}, {
    name: 'Posterior subcapsular cataract'
}, {
    name: 'Posterior synechiae of iris'
}, {
    name: 'Posterior uveitis'
}, {
    name: 'Posterior vitreous detachment'
}, {
    name: 'Postictal state'
}, {
    name: 'Postinfarction'
}, {
    name: 'Postinfarction angina'
}, {
    name: 'Postmature baby'
}, {
    name: 'Postmaturity'
}, {
    name: 'Postmenopausal haemorrhage'
}, {
    name: 'Postmenopausal spotting'
}, {
    name: 'Postmenopausal syndrome'
}, {
    name: 'Postmenopause'
}, {
    name: 'Postnasal drip'
}, {
    name: 'Postoperative complications NOS'
}, {
    name: 'Postoperative constipation'
}, {
    name: 'Postoperative fever'
}, {
    name: 'Postoperative hemorrhage'
}, {
    name: 'Postoperative hypertension'
}, {
    name: 'Postoperative ileus'
}, {
    name: 'Postoperative infection'
}, {
    name: 'Postoperative pain'
}, {
    name: 'Postoperative shivering'
}, {
    name: 'Postoperative vomiting'
}, {
    name: 'Postoperative wound complication'
}, {
    name: 'Postoperative wound infection'
}, {
    name: 'Postpartum disorder'
}, {
    name: 'Postpartum haemorrhage'
}, {
    name: 'Postpartum hypopituitarism'
}, {
    name: 'Postpartum sepsis'
}, {
    name: 'Postphlebitic syndrome'
}, {
    name: 'Postural orthostatic tachycardia syndrome'
}, {
    name: 'Posture abnormal'
}, {
    name: 'Potassium abnormal NOS'
}, {
    name: 'Potassium deficiency'
}, {
    name: 'Potassium imbalance'
}, {
    name: 'Potassium increased'
}, {
    name: 'Potassium low'
}, {
    name: 'Poverty of speech'
}, {
    name: 'Pre-eclampsia'
}, {
    name: 'Pre-excitation syndrome'
}, {
    name: 'Pre-existing disease'
}, {
    name: 'Pre-menstrual tension syndrome'
}, {
    name: 'Precocious puberty'
}, {
    name: 'Precoma'
}, {
    name: 'Precordial pain'
}, {
    name: 'Pregnancy'
}, {
    name: 'Pregnancy disorder'
}, {
    name: 'Pregnancy loss'
}, {
    name: 'Pregnancy test false positive'
}, {
    name: 'Pregnancy test positive'
}, {
    name: 'Prehypertension'
}, {
    name: 'Premature baby'
}, {
    name: 'Premature delivery'
}, {
    name: 'Premature ejaculation'
}, {
    name: 'Premature labour'
}, {
    name: 'Premature menopause'
}, {
    name: 'Premature rupture of membranes'
}, {
    name: 'Premature separation of placenta'
}, {
    name: 'Premenopausal breast cancer'
}, {
    name: 'Premenopause'
}, {
    name: 'Premenstrual dysphoric disorder'
}, {
    name: 'Premenstrual syndrome'
}, {
    name: 'Premenstrual tension'
}, {
    name: 'Presbyopia'
}, {
    name: 'Pressure of speech'
}, {
    name: 'Presyncope'
}, {
    name: 'Priapism'
}, {
    name: 'Primary amyloidosis'
}, {
    name: 'Primary apnea of premature newborns'
}, {
    name: 'Primary dysmenorrhea'
}, {
    name: 'Primary graft dysfunction'
}, {
    name: 'Primary hyperaldosteronism'
}, {
    name: 'Primary hypogonadism'
}, {
    name: 'Primary hypothyroidism'
}, {
    name: 'Primary insomnia'
}, {
    name: 'Primary malignant neoplasm of liver'
}, {
    name: 'Primary nocturnal enuresis'
}, {
    name: 'Primary open angle glaucoma'
}, {
    name: 'Primary ovarian failure'
}, {
    name: 'Primary pulmonary hypertension'
}, {
    name: 'Primary syphilis'
}, {
    name: 'Primary tuberculous infection'
}, {
    name: 'Prinzmetal angina'
}, {
    name: 'PRL increased'
}, {
    name: 'Proarrhythmia'
}, {
    name: 'Proarrhythmic effect'
}, {
    name: 'Procedural complication'
}, {
    name: 'Procedural haemorrhage'
}, {
    name: 'Procedural hypertension'
}, {
    name: 'Procedural hypotension'
}, {
    name: 'Procedural nausea'
}, {
    name: 'Procedural pain'
}, {
    name: 'Procedural site reaction'
}, {
    name: 'Procedural vomiting'
}, {
    name: 'Proctalgia'
}, {
    name: 'Proctitis'
}, {
    name: 'Proctitis herpes'
}, {
    name: 'Proctitis ulcerative'
}, {
    name: 'Proctocolitis'
}, {
    name: 'Proctosigmoiditis'
}, {
    name: 'Product taste abnormal'
}, {
    name: 'Productive cough'
}, {
    name: 'Progesterone'
}, {
    name: 'Progesterone levels'
}, {
    name: 'Progressive multifocal leukoencephalopathy'
}, {
    name: 'Progressive renal failure'
}, {
    name: 'Progressive supranuclear palsy'
}, {
    name: 'Prolactinoma'
}, {
    name: 'Prolonged labour'
}, {
    name: 'Prolonged menses'
}, {
    name: 'Prostate cancer'
}, {
    name: 'Prostate cancer metastatic'
}, {
    name: 'Prostate carcinoma'
}, {
    name: 'Prostate examination abnormal'
}, {
    name: 'Prostate induration'
}, {
    name: 'Prostate infection'
}, {
    name: 'Prostatic acid phosphatase increased'
}, {
    name: 'Prostatic adenoma'
}, {
    name: 'Prostatic disorder'
}, {
    name: 'Prostatic dysplasia'
}, {
    name: 'Prostatic hypertrophy'
}, {
    name: 'Prostatic intraepithelial neoplasia'
}, {
    name: 'Prostatic pain'
}, {
    name: 'Prostatic specific antigen increased'
}, {
    name: 'Prostatism'
}, {
    name: 'Prostatitis'
}, {
    name: 'Prostatomegaly'
}, {
    name: 'Prosthetic cardiac valve thrombosis'
}, {
    name: 'Prosthetic valve endocarditis'
}, {
    name: 'Prostration'
}, {
    name: 'Protein C deficiency'
}, {
    name: 'Protein allergy'
}, {
    name: 'Protein total decreased'
}, {
    name: 'Protein urine present'
}, {
    name: 'Protein-losing gastroenteropathy'
}, {
    name: 'Proteinuria'
}, {
    name: 'Prothrombin level abnormal'
}, {
    name: 'Prothrombin level decreased'
}, {
    name: 'Prothrombin level increased'
}, {
    name: 'Prothrombin time abnormal'
}, {
    name: 'Prothrombin time ratio'
}, {
    name: 'Prothrombin time shortened'
}, {
    name: 'Protrusion tongue'
}, {
    name: 'Proximal myopathy'
}, {
    name: 'Proximal renal tubular acidosis'
}, {
    name: 'Prurigo'
}, {
    name: 'Prurigo nodularis'
}, {
    name: 'Pruritus'
}, {
    name: 'Pruritus NEC'
}, {
    name: 'Pruritus generalised'
}, {
    name: 'Pruritus genital'
}, {
    name: 'Pruritus vulvae'
}, {
    name: 'Pseudo-Bartter syndrome'
}, {
    name: 'Pseudocholinesterase deficiency'
}, {
    name: 'Pseudocroup'
}, {
    name: 'Pseudodementia'
}, {
    name: 'Pseudofolliculitis barbae'
}, {
    name: 'Pseudohyperkalaemia'
}, {
    name: 'Pseudohypoparathyroidism'
}, {
    name: 'Pseudolymphoma'
}, {
    name: 'Pseudomembranous colitis'
}, {
    name: 'Pseudomembranous enterocolitis'
}, {
    name: 'Pseudomonal sepsis'
}, {
    name: 'Pseudomonas infection'
}, {
    name: 'Pseudomononucleosis'
}, {
    name: 'Pseudoparkinsonism'
}, {
    name: 'Pseudoporphyria'
}, {
    name: 'Pseudotumor'
}, {
    name: 'Psittacosis'
}, {
    name: 'Psoriasis'
}, {
    name: 'Psoriasis flare-up'
}, {
    name: 'Psoriasis of scalp'
}, {
    name: 'Psoriasis vulgaris'
}, {
    name: 'Psoriatic arthropathy'
}, {
    name: 'Psoriatic plaque'
}, {
    name: 'Psychiatric decompensation'
}, {
    name: 'Psychiatric evaluation abnormal'
}, {
    name: 'Psychiatric symptom'
}, {
    name: 'Psychic disturbance'
}, {
    name: 'Psychomotor retardation'
}, {
    name: 'Psychomotor skills impaired'
}, {
    name: 'Psychosexual disorder'
}, {
    name: 'Psychosis depressive'
}, {
    name: 'Psychosomatic disease'
}, {
    name: 'Psychotic behaviour'
}, {
    name: 'Psychotic depression'
}, {
    name: 'Psychotic disorder'
}, {
    name: 'Psychotic episode'
}, {
    name: 'Psychotic state'
}, {
    name: 'Pterygium'
}, {
    name: 'PTH high'
}, {
    name: 'Ptosis'
}, {
    name: 'Puberty'
}, {
    name: 'Puerperal pyrexia'
}, {
    name: 'Pulmonary alveolar haemorrhage'
}, {
    name: 'Pulmonary alveolitis'
}, {
    name: 'Pulmonary arterial hypertension'
}, {
    name: 'Pulmonary arterial wedge pressure increased'
}, {
    name: 'Pulmonary congestion'
}, {
    name: 'Pulmonary embolism'
}, {
    name: 'Pulmonary eosinophilia'
}, {
    name: 'Pulmonary fibrosis'
}, {
    name: 'Pulmonary function test abnormal'
}, {
    name: 'Pulmonary function test decreased'
}, {
    name: 'Pulmonary granuloma'
}, {
    name: 'Pulmonary haemorrhage'
}, {
    name: 'Pulmonary hypertension'
}, {
    name: 'Pulmonary hypertension secondary'
}, {
    name: 'Pulmonary hypoplasia'
}, {
    name: 'Pulmonary infarction'
}, {
    name: 'Pulmonary lymphoma'
}, {
    name: 'Pulmonary mass'
}, {
    name: 'Pulmonary microemboli'
}, {
    name: 'Pulmonary oedema'
}, {
    name: 'Pulmonary oil microembolism'
}, {
    name: 'Pulmonary ossification'
}, {
    name: 'Pulmonary stenosis'
}, {
    name: 'Pulmonary thromboembolism'
}, {
    name: 'Pulmonary thrombosis'
}, {
    name: 'Pulmonary toxicity'
}, {
    name: 'Pulmonary tuberculosis'
}, {
    name: 'Pulmonary valve incompetence'
}, {
    name: 'Pulmonary valve stenosis'
}, {
    name: 'Pulmonary vasculitis'
}, {
    name: 'Pulmonary veno-occlusive disease'
}, {
    name: 'Pulpitis dental'
}, {
    name: 'Pulse abnormal'
}, {
    name: 'Pulse absent'
}, {
    name: 'Pulse irregular'
}, {
    name: 'Pulse pressure decreased'
}, {
    name: 'Pulse rate decrease marked'
}, {
    name: 'Pulseless electrical activity'
}, {
    name: 'Punctate epithelial erosion'
}, {
    name: 'Punctate keratitis'
}, {
    name: 'Puncture site haemorrhage'
}, {
    name: 'Puncture site pain'
}, {
    name: 'Puncture site reaction'
}, {
    name: 'Punding'
}, {
    name: 'Pupillary deformity'
}, {
    name: 'Pupillary disorder'
}, {
    name: 'Pupillary reflex impaired'
}, {
    name: 'Pupils pinpoint'
}, {
    name: 'Pupils unequal'
}, {
    name: 'Purging'
}, {
    name: 'Purine metabolism disorder'
}, {
    name: 'Purple glove syndrome'
}, {
    name: 'Purple toes syndrome'
}, {
    name: 'Purpura'
}, {
    name: 'Purpura fulminans'
}, {
    name: 'Purpura non-thrombocytopenic'
}, {
    name: 'Purpura senile'
}, {
    name: 'Purpuric rash'
}, {
    name: 'Pustular psoriasis'
}, {
    name: 'Pustule'
}, {
    name: 'Pyelitis'
}, {
    name: 'Pyelocystitis'
}, {
    name: 'Pyelonephritis'
}, {
    name: 'Pyelonephritis acute'
}, {
    name: 'Pyelonephritis chronic'
}, {
    name: 'Pyloric stenosis'
}, {
    name: 'Pylorospasm'
}, {
    name: 'Pyoderma'
}, {
    name: 'Pyoderma gangrenosum'
}, {
    name: 'Pyogenic granuloma'
}, {
    name: 'Pyometra'
}, {
    name: 'Pyramidal tract syndrome'
}, {
    name: 'Pyridoxine deficiency'
}, {
    name: 'Pyuria'
}, {
    name: 'Q fever'
}, {
    name: 'QRS axis abnormal'
}, {
    name: 'QRS complex'
}, {
    name: 'QRS voltage decreased'
}, {
    name: 'Quadriparesis'
}, {
    name: 'Quadriplegia'
}, {
    name: 'Quartan malaria'
}, {
    name: 'Queensland tick typhus'
}, {
    name: 'Racing thoughts'
}, {
    name: 'Radial nerve palsy'
}, {
    name: 'Radiation injury'
}, {
    name: 'Radiation myelopathy'
}, {
    name: 'Radiation oesophagitis'
}, {
    name: 'Radiation pneumonitis'
}, {
    name: 'Radiation recall reaction (dermatologic)'
}, {
    name: 'Radiation recall syndrome'
}, {
    name: 'Radiation skin injury'
}, {
    name: 'Radicular pain'
}, {
    name: 'Radiculitis'
}, {
    name: 'Radiculopathy'
}, {
    name: 'Radius fracture'
}, {
    name: 'Rage'
}, {
    name: 'Raised liver function tests'
}, {
    name: 'Raised serum lipid levels'
}, {
    name: 'Raised serum uric acid'
}, {
    name: 'Rales'
}, {
    name: 'Rash'
}, {
    name: 'Rash both legs'
}, {
    name: 'Rash bullous'
}, {
    name: 'Rash erythematous'
}, {
    name: 'Rash follicular'
}, {
    name: 'Rash generalised'
}, {
    name: 'Rash macular'
}, {
    name: 'Rash maculo-papular'
}, {
    name: 'Rash morbilliform'
}, {
    name: 'Rash mouth'
}, {
    name: 'Rash papular'
}, {
    name: 'Rash pemphigoid'
}, {
    name: 'Rash psoriaform'
}, {
    name: 'Rash pustular'
}, {
    name: 'Rash recurrent'
}, {
    name: 'Rash scaly'
}, {
    name: 'Rash scarlatiniform'
}, {
    name: 'Rash vesicular'
}, {
    name: 'Rat-bite fever'
}, {
    name: "Raynaud's disease"
}, {
    name: "Raynaud's phenomenon"
}, {
    name: 'Raynaud-like disorder'
}, {
    name: 'Reaction aggravation'
}, {
    name: 'Reaction febrile'
}, {
    name: 'Reaction gastrointestinal'
}, {
    name: 'Reaction to drug excipients'
}, {
    name: 'Reactive depression'
}, {
    name: 'Rebound effect'
}, {
    name: 'Rebound hypertension'
}, {
    name: 'Recall phenomenon'
}, {
    name: 'Reciprocating tachycardia'
}, {
    name: 'Rectal abscess'
}, {
    name: 'Rectal cancer'
}, {
    name: 'Rectal cramps'
}, {
    name: 'Rectal discharge'
}, {
    name: 'Rectal disorder'
}, {
    name: 'Rectal fistula'
}, {
    name: 'Rectal haemorrhage'
}, {
    name: 'Rectal mass'
}, {
    name: 'Rectal polyp'
}, {
    name: 'Rectal prolapse'
}, {
    name: 'Rectal spasm'
}, {
    name: 'Rectal tenesmus'
}, {
    name: 'Rectal ulcer'
}, {
    name: 'Rectocele'
}, {
    name: 'Recurrence of neuromuscular blockade'
}, {
    name: 'Recurrent depressive disorder'
}, {
    name: 'Recurrent erosion of cornea'
}, {
    name: 'Recurrent infection'
}, {
    name: 'Recurrent pulmonary embolism'
}, {
    name: 'Recurrent urinary tract infection'
}, {
    name: 'Recurrent ventricular fibrillation'
}, {
    name: 'Red blood cell abnormality'
}, {
    name: 'Red blood cell count decreased'
}, {
    name: 'Red blood cell count increased'
}, {
    name: 'Red blood cell disorders'
}, {
    name: 'Red blood cell sedimentation rate increased'
}, {
    name: 'Red blood cells semen positive'
}, {
    name: 'Red blotches'
}, {
    name: 'Red cell aplasia'
}, {
    name: 'Red cell distribution width increased'
}, {
    name: 'Red man syndrome'
}, {
    name: 'Red neck'
}, {
    name: 'Redness'
}, {
    name: 'Redness gum'
}, {
    name: 'Redness of face'
}, {
    name: 'Reduced interest in usual activities'
}, {
    name: 'Reflex bradycardia'
}, {
    name: 'Reflex sympathetic dystrophy'
}, {
    name: 'Reflex tachycardia'
}, {
    name: 'Reflexes abnormal'
}, {
    name: 'Reflux esophagitis'
}, {
    name: 'Reflux gastritis'
}, {
    name: 'Refraction disorder'
}, {
    name: 'Refractory anaemia with an excess of blasts'
}, {
    name: 'Refractory anemia'
}, {
    name: 'Refractory anemia with excess blasts in transformation'
}, {
    name: 'Refractory cytopenia with unilineage dysplasia'
}, {
    name: 'Refractory hypertension'
}, {
    name: 'Regurgitation'
}, {
    name: 'Regurgitation of food'
}, {
    name: 'Rejection acute renal'
}, {
    name: 'Relapsing fever'
}, {
    name: 'Relapsing polychondritis'
}, {
    name: 'Relapsing-remitting multiple sclerosis'
}, {
    name: 'Renal abscess'
}, {
    name: 'Renal agenesis'
}, {
    name: 'Renal aplasia'
}, {
    name: 'Renal artery stenosis'
}, {
    name: 'Renal artery thrombosis'
}, {
    name: 'Renal cancer'
}, {
    name: 'Renal carcinoma'
}, {
    name: 'Renal cell carcinoma'
}, {
    name: 'Renal clearances low'
}, {
    name: 'Renal colic'
}, {
    name: 'Renal cortical necrosis'
}, {
    name: 'Renal cyst'
}, {
    name: 'Renal dysgenesis'
}, {
    name: 'Renal failure'
}, {
    name: 'Renal failure acute'
}, {
    name: 'Renal failure aggravated'
}, {
    name: 'Renal failure chronic'
}, {
    name: 'Renal function test abnormal'
}, {
    name: 'Renal graft loss'
}, {
    name: 'Renal haemorrhage'
}, {
    name: 'Renal hypertension'
}, {
    name: 'Renal impairment'
}, {
    name: 'Renal infarct'
}, {
    name: 'Renal insufficiency aggravated'
}, {
    name: 'Renal mass'
}, {
    name: 'Renal neoplasm'
}, {
    name: 'Renal osteodystrophy'
}, {
    name: 'Renal pain'
}, {
    name: 'Renal papillary necrosis'
}, {
    name: 'Renal rickets'
}, {
    name: 'Renal tubular acidosis'
}, {
    name: 'Renal tubular disorder'
}, {
    name: 'Renal tubular necrosis'
}, {
    name: 'Renal vasculitis'
}, {
    name: 'Renal vein thrombosis'
}, {
    name: 'Renal vessel disorder'
}, {
    name: 'Renin decreased'
}, {
    name: 'Renovascular hypertension'
}, {
    name: 'Reperfusion injury'
}, {
    name: 'Repetitive speech'
}, {
    name: 'Repetitive strain injury'
}, {
    name: 'Reproductive system haemorrhages'
}, {
    name: 'Reproductive toxicity'
}, {
    name: 'Reproductive tract disorder'
}, {
    name: 'Residual urine volume'
}, {
    name: 'Respiration abnormal'
}, {
    name: 'Respiration irregularity'
}, {
    name: 'Respiratory acidosis'
}, {
    name: 'Respiratory alkalosis'
}, {
    name: 'Respiratory arrest'
}, {
    name: 'Respiratory depression'
}, {
    name: 'Respiratory depth increased'
}, {
    name: 'Respiratory disorder'
}, {
    name: 'Respiratory disorder neonatal'
}, {
    name: 'Respiratory disorders NEC'
}, {
    name: 'Respiratory distress'
}, {
    name: 'Respiratory distress syndrome'
}, {
    name: 'Respiratory failure'
}, {
    name: 'Respiratory failure aggravated'
}, {
    name: 'Respiratory fume inhalation disorder'
}, {
    name: 'Respiratory insufficiency'
}, {
    name: 'Respiratory moniliasis'
}, {
    name: 'Respiratory paralysis'
}, {
    name: 'Respiratory rate decreased'
}, {
    name: 'Respiratory sighs'
}, {
    name: 'Respiratory sounds decreased'
}, {
    name: 'Respiratory syncytial virus infection'
}, {
    name: 'Respiratory tract congestion'
}, {
    name: 'Respiratory tract haemorrhage'
}, {
    name: 'Respiratory tract infection'
}, {
    name: 'Respiratory tract infection viral'
}, {
    name: 'Respiratory tract oedema'
}, {
    name: 'Restless legs syndrome'
}, {
    name: 'Restlessness aggravated'
}, {
    name: 'Restrictive cardiomyopathy'
}, {
    name: 'Retained placenta'
}, {
    name: 'Retained placenta or membranes'
}, {
    name: 'Retching'
}, {
    name: 'Retching reflex decreased'
}, {
    name: 'Retention gastric'
}, {
    name: 'Reticulocytopenia'
}, {
    name: 'Reticulocytosis'
}, {
    name: 'Reticuloendothelial system stimulated'
}, {
    name: 'Reticuloendotheliosis'
}, {
    name: 'Retinal aneurysm'
}, {
    name: 'Retinal artery occlusion'
}, {
    name: 'Retinal atrophy'
}, {
    name: 'Retinal damage'
}, {
    name: 'Retinal degeneration'
}, {
    name: 'Retinal depigmentation'
}, {
    name: 'Retinal deposits'
}, {
    name: 'Retinal detachment'
}, {
    name: 'Retinal disorder'
}, {
    name: 'Retinal exudates'
}, {
    name: 'Retinal haemorrhage'
}, {
    name: 'Retinal injury'
}, {
    name: 'Retinal ischaemia'
}, {
    name: 'Retinal oedema'
}, {
    name: 'Retinal pigment epithelial tear'
}, {
    name: 'Retinal pigmentation'
}, {
    name: 'Retinal scar'
}, {
    name: 'Retinal tear'
}, {
    name: 'Retinal toxicity'
}, {
    name: 'Retinal vascular disorder'
}, {
    name: 'Retinal vascular occlusion'
}, {
    name: 'Retinal vascular thrombosis'
}, {
    name: 'Retinal vein branch occlusion'
}, {
    name: 'Retinal vein occlusion'
}, {
    name: 'Retinal vein thrombosis'
}, {
    name: 'Retinitis'
}, {
    name: 'Retinoblastoma'
}, {
    name: 'Retinogram abnormal'
}, {
    name: 'Retinoic acid syndrome'
}, {
    name: 'Retinopathy of prematurity'
}, {
    name: 'Retinopathy proliferative'
}, {
    name: 'Retrograde amnesia'
}, {
    name: 'Retrograde ejaculation'
}, {
    name: 'Retroperitoneal fibrosis'
}, {
    name: 'Retroperitoneal haematoma'
}, {
    name: 'Retroperitoneal haemorrhage'
}, {
    name: 'Retrosternal discomfort'
}, {
    name: 'Retrosternal pain'
}, {
    name: 'Reversible airways obstruction'
}, {
    name: 'Reversible cerebral vasoconstriction syndrome'
}, {
    name: 'Reversible ischaemic neurological deficit'
}, {
    name: "Reye's syndrome"
}, {
    name: 'Rhabdomyolysis'
}, {
    name: 'Rhabdomyosarcoma'
}, {
    name: 'Rhesus incompatibility'
}, {
    name: 'Rheumatic disorder'
}, {
    name: 'Rheumatic fever'
}, {
    name: 'Rheumatic heart disease'
}, {
    name: 'Rheumatism'
}, {
    name: 'Rheumatoid arthritis'
}, {
    name: 'Rheumatoid arthritis aggravated'
}, {
    name: 'Rhinalgia'
}, {
    name: 'Rhinitis'
}, {
    name: 'Rhinitis allergic'
}, {
    name: 'Rhinitis atrophic'
}, {
    name: 'Rhinitis perennial'
}, {
    name: 'Rhinitis seasonal'
}, {
    name: 'Rhinitis ulcerative'
}, {
    name: 'Rhinorrhoea'
}, {
    name: 'Rhinosinusitis'
}, {
    name: 'Rhonchi'
}, {
    name: 'Rhythm idioventricular'
}, {
    name: 'Rib fracture'
}, {
    name: 'Rib pain'
}, {
    name: 'Rickets'
}, {
    name: 'Rickets (vitamin D resistant)'
}, {
    name: 'Rickets familial hypophosphataemic'
}, {
    name: 'Rickettsialpox'
}, {
    name: 'Right upper quadrant pain'
}, {
    name: 'Right ventricular failure'
}, {
    name: 'Rigors'
}, {
    name: 'Risus sardonicus'
}, {
    name: 'Road traffic accident'
}, {
    name: 'Rocky mountain spotted fever'
}, {
    name: 'Rosacea'
}, {
    name: 'Rotator cuff syndrome'
}, {
    name: 'Rubber sensitivity'
}, {
    name: 'Rubella'
}, {
    name: 'Sacroiliitis'
}, {
    name: "Salaam's tic"
}, {
    name: 'Saliva altered'
}, {
    name: 'Salivary duct obstruction'
}, {
    name: 'Salivary gland conditions'
}, {
    name: 'Salivary gland disorder'
}, {
    name: 'Salivary gland enlargement'
}, {
    name: 'Salivary gland pain'
}, {
    name: 'Salivary gland swelling'
}, {
    name: 'Salivary hypersecretion'
}, {
    name: 'Salivation'
}, {
    name: 'Salmonella sepsis'
}, {
    name: 'Salmonellosis'
}, {
    name: 'Salpingitis'
}, {
    name: 'Salpingo-oophoritis'
}, {
    name: 'Sarcoidosis'
}, {
    name: 'Sarcoma'
}, {
    name: 'Sarcoma uterus'
}, {
    name: 'Scab'
}, {
    name: 'Scabies'
}, {
    name: 'Scald'
}, {
    name: 'Scar'
}, {
    name: 'Scar pain'
}, {
    name: 'Scarlet fever'
}, {
    name: 'Schizoaffective disorder'
}, {
    name: 'Schizophrenia'
}, {
    name: 'Schizophrenia and other psychotic disorders'
}, {
    name: 'Schizophrenia, paranoid type'
}, {
    name: 'Schizophrenic reaction'
}, {
    name: 'Schizophreniform disorder'
}, {
    name: 'Schwannoma'
}, {
    name: 'Sciatica'
}, {
    name: 'Scintillating scotoma'
}, {
    name: 'Scleral discolouration'
}, {
    name: 'Scleral disorder'
}, {
    name: 'Scleral haemorrhage'
}, {
    name: 'Scleral hyperaemia'
}, {
    name: 'Scleral icterus'
}, {
    name: 'Scleral pigmentation'
}, {
    name: 'Scleral thinning'
}, {
    name: 'Scleritis'
}, {
    name: 'Scleroderma'
}, {
    name: 'Scleromalacia'
}, {
    name: 'Sclerosing encapsulating peritonitis'
}, {
    name: 'Scoliosis'
}, {
    name: 'Scotoma'
}, {
    name: 'Scotoma annular'
}, {
    name: 'Scotoma of blind spot area'
}, {
    name: 'Scratch'
}, {
    name: 'Screaming'
}, {
    name: 'Scrotal disorder'
}, {
    name: 'Scrotal erythema'
}, {
    name: 'Scrotal oedema'
}, {
    name: 'Scrotal pain'
}, {
    name: 'Scrotal swelling'
}, {
    name: 'Scrotal ulcer'
}, {
    name: 'Scrub typhus'
}, {
    name: 'Scurvy'
}, {
    name: 'Seasonal affective disorder'
}, {
    name: 'Seasonal allergy'
}, {
    name: 'Sebaceous gland disorder'
}, {
    name: 'Sebaceous hyperplasia'
}, {
    name: 'Seborrhoeic dermatitis'
}, {
    name: 'Seborrhoeic keratosis'
}, {
    name: 'Secondary adrenal insufficiency'
}, {
    name: 'Secondary adrenocortical insufficiency'
}, {
    name: 'Secondary aldosteronism'
}, {
    name: 'Secondary anemia'
}, {
    name: 'Secondary glaucoma'
}, {
    name: 'Secondary gout'
}, {
    name: 'Secondary hypertension'
}, {
    name: 'Secondary hypogonadism'
}, {
    name: 'Secondary infection'
}, {
    name: 'Secondary parkinsonism'
}, {
    name: 'Secondary progressive multiple sclerosis'
}, {
    name: 'Secondary syphilis'
}, {
    name: 'Secondary thrombocytopenia'
}, {
    name: 'Sedation'
}, {
    name: 'Seizure cerebral'
}, {
    name: 'Self injurious behaviour'
}, {
    name: 'Self mutilation'
}, {
    name: 'Self-injurious ideation'
}, {
    name: 'Semen abnormal'
}, {
    name: 'Semen analysis abnormal'
}, {
    name: 'Semen volume decreased'
}, {
    name: 'Senile ankylosing vertebral hyperostosis'
}, {
    name: 'Senile dementia'
}, {
    name: 'Senile pruritus'
}, {
    name: 'Senile psychosis'
}, {
    name: 'Senility'
}, {
    name: 'Sensation of blood flow'
}, {
    name: 'Sensation of foreign body'
}, {
    name: 'Sensation of heat'
}, {
    name: 'Sensation of heaviness'
}, {
    name: 'Sensation of pressure'
}, {
    name: 'Sensation of warmth'
}, {
    name: 'Sense of oppression'
}, {
    name: 'Sensitisation'
}, {
    name: 'Sensitivity of teeth'
}, {
    name: 'Sensorimotor disorder'
}, {
    name: 'Sensory ataxia'
}, {
    name: 'Sensory disturbance'
}, {
    name: 'Sensory loss'
}, {
    name: 'Separation'
}, {
    name: 'Sepsis'
}, {
    name: 'Sepsis neonatal'
}, {
    name: 'Sepsis secondary'
}, {
    name: 'Septic arthritis streptobacillus'
}, {
    name: 'Septic joint'
}, {
    name: 'Septic shock'
}, {
    name: 'Septicaemia due to gram-negative organism, unspecified'
}, {
    name: 'Septicemia'
}, {
    name: 'Seroma'
}, {
    name: 'Serositis'
}, {
    name: 'Serotonin syndrome'
}, {
    name: 'Serous retinal detachment'
}, {
    name: 'Serum albumin decreased'
}, {
    name: 'Serum amylase increased'
}, {
    name: 'Serum bicarbonate increased'
}, {
    name: 'Serum bilirubin increased'
}, {
    name: 'Serum calcium decreased'
}, {
    name: 'Serum calcium increased'
}, {
    name: 'Serum cholesterol normal'
}, {
    name: 'Serum creatinine abnormal'
}, {
    name: 'Serum creatinine decreased'
}, {
    name: 'Serum creatinine increased'
}, {
    name: 'Serum ferritin decreased'
}, {
    name: 'Serum ferritin increased'
}, {
    name: 'Serum gastrin increased'
}, {
    name: 'Serum iron decreased'
}, {
    name: 'Serum iron increased'
}, {
    name: 'Serum osmolality increased'
}, {
    name: 'Serum phosphate increased'
}, {
    name: 'Serum potassium abnormal'
}, {
    name: 'Serum potassium decreased'
}, {
    name: 'Serum potassium increased'
}, {
    name: 'Serum prolactin decreased'
}, {
    name: 'Serum prolactin increased'
}, {
    name: 'Serum sickness'
}, {
    name: 'Serum sickness-like reaction'
}, {
    name: 'Serum sodium abnormal'
}, {
    name: 'Serum testosterone decreased'
}, {
    name: 'Serum testosterone increased'
}, {
    name: 'Serum total protein decreased'
}, {
    name: 'Serum transaminase increased'
}, {
    name: 'Serum triglycerides increased'
}, {
    name: 'Serum urea increased'
}, {
    name: 'Severe acute respiratory syndrome'
}, {
    name: 'Sexual abuse'
}, {
    name: 'Sexual assault'
}, {
    name: 'Sexual assault victim'
}, {
    name: 'Sexual desire disorders'
}, {
    name: 'Sexual dysfunction'
}, {
    name: 'Sexually active'
}, {
    name: 'Sexually transmitted disease'
}, {
    name: 'Shakiness'
}, {
    name: 'Shaky feelings'
}, {
    name: 'Shallow breathing'
}, {
    name: 'Shift to the left'
}, {
    name: 'Shigella infection'
}, {
    name: 'Shivering'
}, {
    name: 'Shock'
}, {
    name: 'Shock haemorrhagic'
}, {
    name: 'Shock hypoglycaemic'
}, {
    name: 'Shock insulin'
}, {
    name: 'Short period'
}, {
    name: 'Short-bowel syndrome'
}, {
    name: 'Short-term memory loss'
}, {
    name: 'Shortened cervix'
}, {
    name: 'Shoulder pain'
}, {
    name: 'Shunt infection'
}, {
    name: 'Shunt thrombosis'
}, {
    name: 'Shutdown renal'
}, {
    name: 'Shy-Drager syndrome'
}, {
    name: 'Sialoadenitis'
}, {
    name: 'Sick sinus syndrome'
}, {
    name: 'Sickle cell anaemia'
}, {
    name: 'Sickle cell anaemia with crisis'
}, {
    name: 'Sickness'
}, {
    name: 'Sideroblastic anaemia'
}, {
    name: 'Silicosis'
}, {
    name: 'Simple partial seizures'
}, {
    name: 'Single functional kidney'
}, {
    name: 'Single umbilical artery'
}, {
    name: 'Sinoatrial block'
}, {
    name: 'Sinoatrial node dysfunction'
}, {
    name: 'Sinobronchitis'
}, {
    name: 'Sinus arrest'
}, {
    name: 'Sinus arrhythmia'
}, {
    name: 'Sinus bradycardia'
}, {
    name: 'Sinus congestion'
}, {
    name: 'Sinus disorder'
}, {
    name: 'Sinus headache'
}, {
    name: 'Sinus operation'
}, {
    name: 'Sinus pain'
}, {
    name: 'Sinus rhythm'
}, {
    name: 'Sinus tachycardia'
}, {
    name: 'Sinusitis'
}, {
    name: 'Sinusitis bacterial'
}, {
    name: "Sjogren's syndrome"
}, {
    name: 'Skeletal injury'
}, {
    name: 'Skeletal muscle paralysis'
}, {
    name: 'Skin atrophy'
}, {
    name: 'Skin bacterial infection'
}, {
    name: 'Skin bleeding'
}, {
    name: 'Skin breakdown'
}, {
    name: 'Skin burning sensation'
}, {
    name: 'Skin callus'
}, {
    name: 'Skin cancer'
}, {
    name: 'Skin candida'
}, {
    name: 'Skin carcinoma'
}, {
    name: 'Skin cold clammy'
}, {
    name: 'Skin depigmentation'
}, {
    name: 'Skin discolouration'
}, {
    name: 'Skin discomfort'
}, {
    name: 'Skin disorder'
}, {
    name: 'Skin erosion'
}, {
    name: 'Skin exfoliation'
}, {
    name: 'Skin fibrosis'
}, {
    name: 'Skin fissures'
}, {
    name: 'Skin fragility'
}, {
    name: 'Skin haemorrhage'
}, {
    name: 'Skin hyperpigmentation'
}, {
    name: 'Skin hypertrophy'
}, {
    name: 'Skin induration'
}, {
    name: 'Skin infection'
}, {
    name: 'Skin irritation'
}, {
    name: 'Skin laceration'
}, {
    name: 'Skin lesion'
}, {
    name: 'Skin maceration'
}, {
    name: 'Skin mass'
}, {
    name: 'Skin necrosis'
}, {
    name: 'Skin nodule'
}, {
    name: 'Skin odour abnormal'
}, {
    name: 'Skin oedema'
}, {
    name: 'Skin papilloma'
}, {
    name: 'Skin reaction'
}, {
    name: 'Skin roughness'
}, {
    name: 'Skin scaly'
}, {
    name: 'Skin scarring'
}, {
    name: 'Skin sensitisation'
}, {
    name: 'Skin striae'
}, {
    name: 'Skin swelling'
}, {
    name: 'Skin tear'
}, {
    name: 'Skin tenderness'
}, {
    name: 'Skin test positive'
}, {
    name: 'Skin test reaction'
}, {
    name: 'Skin thickening'
}, {
    name: 'Skin thinness'
}, {
    name: 'Skin tightness'
}, {
    name: 'Skin toxicity'
}, {
    name: 'Skin ulcer'
}, {
    name: 'Skin warm'
}, {
    name: 'Skin wound'
}, {
    name: 'Skin wrinkling'
}, {
    name: 'Skin xerosis'
}, {
    name: 'Skipped beats'
}, {
    name: 'Skull hypoplasia'
}, {
    name: 'Skull malformation'
}, {
    name: 'Sleep apnoea syndrome'
}, {
    name: 'Sleep attacks'
}, {
    name: 'Sleep disorder'
}, {
    name: 'Sleep disturbance'
}, {
    name: 'Sleep paralysis'
}, {
    name: 'Sleep phase rhythm disturbance'
}, {
    name: 'Sleep talking'
}, {
    name: 'Sleep terror'
}, {
    name: 'Slipped femoral capital epiphysis'
}, {
    name: 'Slough injection site'
}, {
    name: 'Slow speech'
}, {
    name: 'Sluggishness'
}, {
    name: 'Slurred speech'
}, {
    name: 'Small bowel angioedema'
}, {
    name: 'Small cell carcinoma'
}, {
    name: 'Small cell lung cancer'
}, {
    name: 'Small cell lung cancer recurrent'
}, {
    name: 'Small intestinal obstruction'
}, {
    name: 'Small intestinal perforation'
}, {
    name: 'Small intestine ulcer'
}, {
    name: 'Smarting'
}, {
    name: 'Smear cervix abnormal'
}, {
    name: 'Smear cervix normal'
}, {
    name: 'Smoke inhalation'
}, {
    name: 'Sneezing'
}, {
    name: 'Sneezing excessive'
}, {
    name: 'Snoring'
}, {
    name: 'Social avoidant behaviour'
}, {
    name: 'Social fear'
}, {
    name: 'Social phobia'
}, {
    name: 'Social withdrawal'
}, {
    name: 'Sodium decreased'
}, {
    name: 'Sodium high'
}, {
    name: 'Soft stools'
}, {
    name: 'Soft tissue disorder'
}, {
    name: 'Soft tissue infection'
}, {
    name: 'Soft tissue inflammation'
}, {
    name: 'Soft tissue injury'
}, {
    name: 'Soft tissue necrosis'
}, {
    name: 'Solar dermatitis'
}, {
    name: 'Solar lentigo'
}, {
    name: 'Solid tumour'
}, {
    name: 'Somatic hallucination'
}, {
    name: 'Somatoform disorder'
}, {
    name: 'Somatoform disorder cardiovascular'
}, {
    name: 'Somnambulism'
}, {
    name: 'Somnolence'
}, {
    name: 'Somnolence neonatal'
}, {
    name: 'Sore eye'
}, {
    name: 'Sore mouth'
}, {
    name: 'Sore nose'
}, {
    name: 'Sour stomach'
}, {
    name: 'Spasm biliary'
}, {
    name: 'Spasm of accommodation'
}, {
    name: 'Spasm of sphincter of Oddi'
}, {
    name: 'Spasmodic dysphonia'
}, {
    name: 'Spastic paralysis'
}, {
    name: 'Spastic paraparesis'
}, {
    name: 'Speech and language abnormalities'
}, {
    name: 'Speech disorder'
}, {
    name: 'Speech impairment NOS'
}, {
    name: 'Speech loss'
}, {
    name: 'Sperm concentration'
}, {
    name: 'Sperm concentration decreased'
}, {
    name: 'Sperm count decreased'
}, {
    name: 'Spermatocele'
}, {
    name: 'Spermatogenesis abnormal'
}, {
    name: 'Spermatogenesis arrest'
}, {
    name: 'Spermatozoa abnormal'
}, {
    name: 'Sphincter of Oddi dysfunction'
}, {
    name: 'Spider bite'
}, {
    name: 'Spina bifida'
}, {
    name: 'Spina bifida occulta'
}, {
    name: 'Spinal anaesthesia'
}, {
    name: 'Spinal compression fracture'
}, {
    name: 'Spinal cord compression'
}, {
    name: 'Spinal cord disorder'
}, {
    name: 'Spinal cord haemorrhage'
}, {
    name: 'Spinal cord infarction'
}, {
    name: 'Spinal cord injury'
}, {
    name: 'Spinal cord paralysis'
}, {
    name: 'Spinal disorder'
}, {
    name: 'Spinal epidural haematoma'
}, {
    name: 'Spinal fracture'
}, {
    name: 'Spinal haematoma'
}, {
    name: 'Spinal osteoarthritis'
}, {
    name: 'Spine malformation'
}, {
    name: 'Spleen disorder'
}, {
    name: 'Spleen palpable'
}, {
    name: 'Splenic flexure syndrome'
}, {
    name: 'Splenic infarction'
}, {
    name: 'Splenic peliosis'
}, {
    name: 'Splenic rupture'
}, {
    name: 'Splenic sequestration'
}, {
    name: 'Splenomegaly'
}, {
    name: 'Splinter haemorrhages'
}, {
    name: 'Splitting nails'
}, {
    name: 'Spondylitis'
}, {
    name: 'Spondyloarthropathy'
}, {
    name: 'Spondylosis'
}, {
    name: 'Spontaneous bruising'
}, {
    name: 'Spontaneous haematoma'
}, {
    name: 'Spontaneous penile erection'
}, {
    name: 'Sporotrichosis'
}, {
    name: 'Sports injury'
}, {
    name: 'Spots before eyes'
}, {
    name: 'Spotting menstrual'
}, {
    name: 'Spotting vaginal'
}, {
    name: 'Sprain'
}, {
    name: 'Sprue'
}, {
    name: 'Sputum discoloured'
}, {
    name: 'Sputum increased'
}, {
    name: 'Sputum purulent'
}, {
    name: 'Squamous cell carcinoma'
}, {
    name: 'Squamous cell carcinoma of head and neck'
}, {
    name: 'Squamous cell carcinoma of lung'
}, {
    name: 'Squamous cell carcinoma of skin'
}, {
    name: 'ST segment elevation myocardial infarction'
}, {
    name: 'Stable angina pectoris'
}, {
    name: 'Staggering gait'
}, {
    name: 'Staphylococcal bacteraemia'
}, {
    name: 'Staphylococcal infection'
}, {
    name: 'Staphylococcal scalded skin syndrome'
}, {
    name: 'Staphylococcal skin infection'
}, {
    name: 'Staphylococcus aureus bacteremia'
}, {
    name: "Stargardt's disease"
}, {
    name: 'Staring'
}, {
    name: 'Stasis dermatitis'
}, {
    name: 'Stasis syndrome'
}, {
    name: 'Status asthmaticus'
}, {
    name: 'Status epilepticus'
}, {
    name: 'Status epilepticus grand mal'
}, {
    name: 'Steatorrhoea'
}, {
    name: 'Stent occlusion'
}, {
    name: 'Stereotypy'
}, {
    name: 'Steroid acne'
}, {
    name: 'Steroid myopathy'
}, {
    name: 'Steroid psychosis'
}, {
    name: 'Steroid withdrawal syndrome'
}, {
    name: 'Steroid-resistant nephrotic syndrome'
}, {
    name: 'Stevens-Johnson syndrome'
}, {
    name: 'Sticky skin'
}, {
    name: 'Stiff back'
}, {
    name: 'Stiff person syndrome'
}, {
    name: 'Stiffness'
}, {
    name: "Still's disease"
}, {
    name: 'Stillbirth'
}, {
    name: 'Sting'
}, {
    name: 'Stinging'
}, {
    name: 'Stinging of nose'
}, {
    name: 'Stinging skin'
}, {
    name: 'Stomach ache'
}, {
    name: 'Stomach cramps'
}, {
    name: 'Stomach dilation procedure'
}, {
    name: 'Stomal ulcer'
}, {
    name: 'Stomatitis'
}, {
    name: 'Stomatitis necrotising'
}, {
    name: 'Strabismus'
}, {
    name: 'Strangulation'
}, {
    name: 'Strangury'
}, {
    name: 'Streptobacillary fever'
}, {
    name: 'Streptococcal endocarditis'
}, {
    name: 'Streptococcal infection'
}, {
    name: 'Streptococcal sepsis'
}, {
    name: 'Streptococcus pyogenes pharyngitis'
}, {
    name: 'Stress'
}, {
    name: 'Stress at work'
}, {
    name: 'Stress fracture'
}, {
    name: 'Stress symptoms'
}, {
    name: 'Stress ulcer'
}, {
    name: 'Stress urinary incontinence'
}, {
    name: 'Stridor'
}, {
    name: 'Stridor inspiratory'
}, {
    name: 'Stroke volume increased'
}, {
    name: 'Strongyloidiasis'
}, {
    name: 'Stupor'
}, {
    name: 'Stuttering'
}, {
    name: 'Subacromial bursitis'
}, {
    name: 'Subacute bacterial endocarditis'
}, {
    name: 'Subacute endocarditis'
}, {
    name: 'Subarachnoid haemorrhage'
}, {
    name: 'Subclinical hypothyroidism'
}, {
    name: 'Subclinical infection'
}, {
    name: 'Subconjunctival cyst'
}, {
    name: 'Subconjunctival hemorrhage'
}, {
    name: 'Subcutaneous abscess'
}, {
    name: 'Subcutaneous bleeding'
}, {
    name: 'Subcutaneous haematoma'
}, {
    name: 'Subcutaneous nodule'
}, {
    name: 'Subdural effusion'
}, {
    name: 'Subdural haematoma'
}, {
    name: 'Subependymal giant cell astrocytoma'
}, {
    name: 'Subepithelial opacities'
}, {
    name: 'Subglottic edema'
}, {
    name: 'Subileus'
}, {
    name: 'Subjective visual disturbances'
}, {
    name: 'Subluxation hip'
}, {
    name: 'Submandibular mass'
}, {
    name: 'Substance abuse'
}, {
    name: 'Substance-induced psychotic disorder'
}, {
    name: 'Sucrase-isomaltase deficiency'
}, {
    name: 'Sudden cardiac death'
}, {
    name: 'Sudden deafness'
}, {
    name: 'Sudden death'
}, {
    name: 'Sudden death, cause unknown'
}, {
    name: 'Sudden hearing loss'
}, {
    name: 'Sudden infant death syndrome'
}, {
    name: 'Sudden onset of sleep'
}, {
    name: 'Sudden unexplained death in epilepsy'
}, {
    name: 'Sudden visual loss'
}, {
    name: 'Suicidal behaviour'
}, {
    name: 'Suicidal ideation'
}, {
    name: 'Suicidal tendency'
}, {
    name: 'Suicide'
}, {
    name: 'Suicide attempt'
}, {
    name: 'Sulphaemoglobinaemia'
}, {
    name: 'Sunburn'
}, {
    name: 'Sunken eyes'
}, {
    name: 'Superficial basal cell carcinoma'
}, {
    name: 'Superficial phlebothrombosis'
}, {
    name: 'Superficial punctate keratopathy'
}, {
    name: 'Superficial thrombophlebitis of leg'
}, {
    name: 'Superinfection'
}, {
    name: 'Superior sagittal sinus thrombosis'
}, {
    name: 'Superior vena cava syndrome'
}, {
    name: 'Supernumerary nipple'
}, {
    name: 'Superovulation'
}, {
    name: 'Supine hypotension'
}, {
    name: 'Suppressed lactation'
}, {
    name: 'Suprapubic pain'
}, {
    name: 'Supraspinatus tendonitis'
}, {
    name: 'Supraventricular extrasystoles'
}, {
    name: 'Supraventricular tachyarrhythmia'
}, {
    name: 'Supraventricular tachycardia'
}, {
    name: 'Surgery'
}, {
    name: 'Surgical intervention'
}, {
    name: 'Surgical menopause'
}, {
    name: 'Surgical site reaction'
}, {
    name: 'Suspiciousness'
}, {
    name: 'Sustained ventricular tachycardia'
}, {
    name: 'Suture related complication'
}, {
    name: 'Sweat gland disorder'
}, {
    name: 'Sweat gland tumour'
}, {
    name: 'Sweating'
}, {
    name: 'Sweating decreased'
}, {
    name: 'Sweating increased'
}, {
    name: 'Swelling'
}, {
    name: 'Swelling face'
}, {
    name: 'Swelling of eyelid'
}, {
    name: 'Swelling of knees'
}, {
    name: 'Swelling of legs'
}, {
    name: 'Swelling of limb'
}, {
    name: 'Swollen arm'
}, {
    name: 'Swollen tongue'
}, {
    name: 'Sycosis barbae'
}, {
    name: 'Sympathetic ophthalmia'
}, {
    name: 'Sympathomimetic effect'
}, {
    name: 'Symptomatic hyperlactatemia'
}, {
    name: 'Syncope'
}, {
    name: 'Syncope vasovagal'
}, {
    name: 'Syndactyly'
}, {
    name: 'Syndrome Fanconi-like'
}, {
    name: 'Syndrome screaming'
}, {
    name: 'Syndrome sicca'
}, {
    name: 'Synovial cyst'
}, {
    name: 'Synovitis'
}, {
    name: 'Syphilis'
}, {
    name: 'Syringomyelia'
}, {
    name: 'Syrinx'
}, {
    name: 'Systemic allergic reaction'
}, {
    name: 'Systemic candida'
}, {
    name: 'Systemic inflammatory response syndrome'
}, {
    name: 'Systemic lupus erythematosus'
}, {
    name: 'Systemic lupus erythematosus rash'
}, {
    name: 'Systemic mastocytosis'
}, {
    name: 'Systemic mycosis'
}, {
    name: 'Systemic sclerosis'
}, {
    name: 'Systolic dysfunction'
}, {
    name: 'Systolic ejection murmur'
}, {
    name: 'Systolic hypertension'
}, {
    name: 'Systolic murmur'
}, {
    name: 'T-cell lymphoma'
}, {
    name: 'T-cell type acute leukaemia'
}, {
    name: 'Tachyarrhythmia'
}, {
    name: 'Tachycardia'
}, {
    name: 'Tachycardia foetal'
}, {
    name: 'Tachycardia nervous'
}, {
    name: 'Tachycardia paroxysmal'
}, {
    name: 'Tachyphrenia'
}, {
    name: 'Tachyphylaxis'
}, {
    name: 'Tachypnoea'
}, {
    name: 'Talipes'
}, {
    name: 'Talkativeness'
}, {
    name: 'Tandem gait test abnormal'
}, {
    name: 'Tardive dyskinesia'
}, {
    name: 'Taste altered'
}, {
    name: 'Taste bitter'
}, {
    name: 'Taste disorders'
}, {
    name: 'Taste metallic'
}, {
    name: 'Taste peculiar'
}, {
    name: 'Taste salty'
}, {
    name: 'Taste sour'
}, {
    name: 'Taste sweet'
}, {
    name: 'Tearfulness'
}, {
    name: 'Tearing eyes'
}, {
    name: 'Teeth clenching'
}, {
    name: 'Teething'
}, {
    name: 'Teething pain'
}, {
    name: 'Telangiectasia'
}, {
    name: 'Telangiectasis facial'
}, {
    name: 'Telogen effluvium'
}, {
    name: 'Temper tantrum'
}, {
    name: 'Temperature intolerance'
}, {
    name: 'Temperature regulation disorder'
}, {
    name: 'Temporal arteritis'
}, {
    name: 'Temporal disorientation'
}, {
    name: 'Temporal lobe epilepsy'
}, {
    name: 'Temporomandibular joint syndrome'
}, {
    name: 'Tenderness'
}, {
    name: 'Tendinous contracture'
}, {
    name: 'Tendon disorder'
}, {
    name: 'Tendon injury'
}, {
    name: 'Tendon pain'
}, {
    name: 'Tendon reflex decreased'
}, {
    name: 'Tendon rupture'
}, {
    name: 'Tendonitis'
}, {
    name: 'Tenosynovitis'
}, {
    name: 'Tension'
}, {
    name: 'Tension headache'
}, {
    name: 'Teratogenicity'
}, {
    name: 'Terminal insomnia'
}, {
    name: 'Testicular atrophy'
}, {
    name: 'Testicular disorder'
}, {
    name: 'Testicular failure primary'
}, {
    name: 'Testicular neoplasm'
}, {
    name: 'Testicular pain'
}, {
    name: 'Testicular swelling'
}, {
    name: 'Testis cancer'
}, {
    name: 'Testosterone deficiency'
}, {
    name: 'Testosterone low'
}, {
    name: 'Tetanus'
}, {
    name: 'Tetanus-like'
}, {
    name: 'Tetany'
}, {
    name: 'Tetrahydrobiopterin deficiency'
}, {
    name: 'Thalassaemia'
}, {
    name: 'Thalassaemia beta'
}, {
    name: 'Therapeutic response decreased'
}, {
    name: 'Therapeutic response increased'
}, {
    name: 'Therapeutic response unexpected'
}, {
    name: 'Therapy naive'
}, {
    name: 'Thermal burn'
}, {
    name: 'Thinking abnormal'
}, {
    name: 'Thirst'
}, {
    name: 'Thoracic vertebral fracture'
}, {
    name: 'Thought blocking'
}, {
    name: 'Thready pulse'
}, {
    name: 'Throat irritation'
}, {
    name: 'Throat sore'
}, {
    name: 'Throat tightness'
}, {
    name: 'Throbbing headache'
}, {
    name: 'Thromboangiitis obliterans'
}, {
    name: 'Thrombocytopenia'
}, {
    name: 'Thrombocytopenia aggravated'
}, {
    name: 'Thrombocytopenia toxic'
}, {
    name: 'Thrombocytopenic purpura'
}, {
    name: 'Thrombocytosis'
}, {
    name: 'Thromboembolic event'
}, {
    name: 'Thromboembolic stroke'
}, {
    name: 'Thromboembolism'
}, {
    name: 'Thrombophilia'
}, {
    name: 'Thrombophlebitis'
}, {
    name: 'Thrombophlebitis injection site'
}, {
    name: 'Thrombophlebitis leg deep'
}, {
    name: 'Thrombophlebitis of the leg'
}, {
    name: 'Thrombophlebitis superficial'
}, {
    name: 'Thromboplastin decreased'
}, {
    name: 'Thrombosis'
}, {
    name: 'Thrombosis in device'
}, {
    name: 'Thrombosis leg'
}, {
    name: 'Thrombosis mesenteric vessel'
}, {
    name: 'Thrombotic microangiopathy'
}, {
    name: 'Thrombotic thrombocytopenic purpura'
}, {
    name: 'Thymoma'
}, {
    name: 'Thyroglobulin increased'
}, {
    name: 'Thyroid adenoma'
}, {
    name: 'Thyroid cancer'
}, {
    name: 'Thyroid carcinoma'
}, {
    name: 'Thyroid disorder'
}, {
    name: 'Thyroid function abnormal'
}, {
    name: 'Thyroid function test abnormal'
}, {
    name: 'Thyroid neoplasm'
}, {
    name: 'Thyroid nodule'
}, {
    name: 'Thyroiditis'
}, {
    name: 'Thyroiditis subacute'
}, {
    name: 'Thyrotoxic crisis'
}, {
    name: 'Thyrotoxicosis'
}, {
    name: 'Thyrotropin high'
}, {
    name: 'Thyrotropin low'
}, {
    name: 'Thyroxine decreased'
}, {
    name: 'Thyroxine free decreased'
}, {
    name: 'TIBC'
}, {
    name: 'Tibial torsion'
}, {
    name: 'Tic'
}, {
    name: 'Tight foreskin'
}, {
    name: 'Tightness in jaw'
}, {
    name: 'Tinea barbae'
}, {
    name: 'Tinea capitis'
}, {
    name: 'Tinea cruris'
}, {
    name: 'Tinea infection'
}, {
    name: 'Tinea pedis'
}, {
    name: 'Tinea versicolour'
}, {
    name: 'Tingling feet/hands'
}, {
    name: 'Tingling of extremity'
}, {
    name: 'Tingling sensation'
}, {
    name: 'Tingling skin'
}, {
    name: 'Tinnitus'
}, {
    name: 'Tinnitus aggravated'
}, {
    name: 'Tired and heavy'
}, {
    name: 'Tobacco abuse'
}, {
    name: 'Tobacco poisoning'
}, {
    name: 'Tobacco withdrawal symptoms'
}, {
    name: 'Toe walking'
}, {
    name: 'Tolerance development'
}, {
    name: 'Tongue blistering'
}, {
    name: 'Tongue coated'
}, {
    name: 'Tongue discolouration'
}, {
    name: 'Tongue disorder'
}, {
    name: 'Tongue dry'
}, {
    name: 'Tongue geographic'
}, {
    name: 'Tongue hairy'
}, {
    name: 'Tongue irritation'
}, {
    name: 'Tongue neoplasm'
}, {
    name: 'Tongue neoplasm malignant stage unspecified'
}, {
    name: 'Tongue oedema'
}, {
    name: 'Tongue paralysis'
}, {
    name: 'Tongue pigmentation'
}, {
    name: 'Tongue spasm'
}, {
    name: 'Tongue ulceration'
}, {
    name: 'Tonic clonic movements'
}, {
    name: 'Tonic convulsion'
}, {
    name: 'Tonic-clonic seizures'
}, {
    name: 'Tonsillar disorder'
}, {
    name: 'Tonsillar hypertrophy'
}, {
    name: 'Tonsillitis'
}, {
    name: 'Tooth abscess'
}, {
    name: 'Tooth caries aggravated NOS'
}, {
    name: 'Tooth discolouration'
}, {
    name: 'Tooth disorder'
}, {
    name: 'Tooth erosion'
}, {
    name: 'Tooth fracture'
}, {
    name: 'Tooth hypoplasia'
}, {
    name: 'Tooth infection'
}, {
    name: 'Tooth injury'
}, {
    name: 'Tooth loss'
}, {
    name: 'Tooth malformation'
}, {
    name: 'Toothache'
}, {
    name: 'Torsade de pointes'
}, {
    name: 'Torsion of ovary'
}, {
    name: 'Torticollis'
}, {
    name: 'Total hypoxanthine-guanine phosphoribosyl transferase deficiency'
}, {
    name: 'Total spinal block'
}, {
    name: "Tourette's disorder"
}, {
    name: 'Toxemia'
}, {
    name: 'Toxic confusional state'
}, {
    name: 'Toxic dilatation of intestine'
}, {
    name: 'Toxic encephalopathy'
}, {
    name: 'Toxic epidermal necrolysis'
}, {
    name: 'Toxic multinodular goiter'
}, {
    name: 'Toxic neuropathy'
}, {
    name: 'Toxic nodular goitre'
}, {
    name: 'Toxic pustuloderma'
}, {
    name: 'Toxic reaction (NOS)'
}, {
    name: 'Toxic shock syndrome'
}, {
    name: 'Toxic skin eruption'
}, {
    name: 'Toxic symptom'
}, {
    name: 'Toxicity to various agents'
}, {
    name: 'Toxoplasmosis'
}, {
    name: 'Tracheal disorder'
}, {
    name: 'Tracheal fistula'
}, {
    name: 'Tracheitis'
}, {
    name: 'Tracheo-oesophageal fistula'
}, {
    name: 'Tracheobronchitis'
}, {
    name: 'Tracheostomy infection'
}, {
    name: 'Trachoma'
}, {
    name: 'Traffic accident'
}, {
    name: 'Tranquillisation excessive'
}, {
    name: 'Transaminases decreased'
}, {
    name: 'Transaminases increased'
}, {
    name: 'Transaminitis'
}, {
    name: 'Transfusion dependent anaemia'
}, {
    name: 'Transfusion reaction'
}, {
    name: 'Transient cerebral ischemia'
}, {
    name: 'Transient cerebrovascular events'
}, {
    name: 'Transient global amnesia'
}, {
    name: 'Transient insomnia'
}, {
    name: 'Transient ischaemic attack'
}, {
    name: 'Transitional cell carcinoma'
}, {
    name: 'Transmural myocardial infarction'
}, {
    name: 'Transplant failure'
}, {
    name: 'Transplant rejection'
}, {
    name: 'Transposition of the great vessels'
}, {
    name: 'Transverse sinus thrombosis'
}, {
    name: 'Trauma'
}, {
    name: 'Traumatic arthropathy'
}, {
    name: 'Traumatic brain injury'
}, {
    name: 'Traumatic fracture'
}, {
    name: 'Traumatic haematoma'
}, {
    name: 'Traumatic haemorrhage'
}, {
    name: 'Traumatic liver injury'
}, {
    name: 'Traumatic lung injury'
}, {
    name: "Traveller's diarrhea"
}, {
    name: 'Trembling'
}, {
    name: 'Tremor'
}, {
    name: 'Tremor coarse'
}, {
    name: 'Tremor fine'
}, {
    name: 'Tremor limb'
}, {
    name: 'Tremor muscle'
}, {
    name: 'Tremor of hands'
}, {
    name: 'Tremulousness'
}, {
    name: 'Trench mouth'
}, {
    name: 'Treponema infections'
}, {
    name: 'Tri-iodothyronine normal'
}, {
    name: 'Trichiniasis'
}, {
    name: 'Trichomonal vaginitis'
}, {
    name: 'Trichomoniasis'
}, {
    name: 'Trichorrhexis'
}, {
    name: 'Trichotillomania'
}, {
    name: 'Trichuriasis'
}, {
    name: 'Tricuspid valve incompetence'
}, {
    name: 'Trigeminal neuralgia'
}, {
    name: 'Trigger finger'
}, {
    name: 'Triglycerides normal'
}, {
    name: 'Trismus'
}, {
    name: 'Trisomy 18'
}, {
    name: 'Trisomy 21'
}, {
    name: 'Trophic disorders'
}, {
    name: 'Tropical sprue'
}, {
    name: 'Troponin I increased'
}, {
    name: 'Troponin increased'
}, {
    name: 'Tubal pregnancy'
}, {
    name: 'Tuberculin test positive'
}, {
    name: 'Tuberculoid leprosy'
}, {
    name: 'Tuberculosis'
}, {
    name: 'Tuberculosis of bones and joints, unspecified'
}, {
    name: 'Tuberculosis of genitourinary system'
}, {
    name: 'Tuberous sclerosis'
}, {
    name: 'Tubo-ovarian abscess'
}, {
    name: 'Tubulointerstitial nephritis'
}, {
    name: 'Tularaemia'
}, {
    name: 'Tumour cell mobilisation'
}, {
    name: 'Tumour compression'
}, {
    name: 'Tumour flare'
}, {
    name: 'Tumour haemorrhage'
}, {
    name: 'Tumour invasion'
}, {
    name: 'Tumour lysis syndrome'
}, {
    name: 'Tumour necrosis'
}, {
    name: 'Tumour pain'
}, {
    name: 'Tunnel vision'
}, {
    name: "Turner's syndrome"
}, {
    name: 'Tympanic membrane disorder'
}, {
    name: 'Tympanic membrane hyperaemia'
}, {
    name: 'Tympanic membrane perforation'
}, {
    name: 'Type 1 diabetes mellitus'
}, {
    name: 'Type 2 diabetes mellitus'
}, {
    name: 'Type 2 lepra reaction'
}, {
    name: 'Type I hyperlipidaemia'
}, {
    name: 'Type I hypersensitivity'
}, {
    name: 'Type II hyperlipidaemia'
}, {
    name: 'Type III hyperlipidaemia'
}, {
    name: 'Type III immune complex mediated reaction'
}, {
    name: 'Type IIa hyperlipidaemia'
}, {
    name: 'Type IIb hyperlipidaemia'
}, {
    name: 'Type IIb hyperlipoproteinemia'
}, {
    name: 'Type IV hyperlipidaemia'
}, {
    name: 'Type IV hypersensitivity reaction'
}, {
    name: 'Type V hyperlipidaemia'
}, {
    name: 'Typhoid fever'
}, {
    name: 'Typhus'
}, {
    name: 'Tyrosinaemia'
}, {
    name: 'Ulcer'
}, {
    name: 'Ulcer foot'
}, {
    name: 'Ulcer haemorrhage'
}, {
    name: 'Ulcerative (chronic) proctosigmoiditis'
}, {
    name: 'Ulcerative enterocolitis'
}, {
    name: 'Ulcerative keratitis'
}, {
    name: 'Ulcerative stomatitis'
}, {
    name: 'Ulna fracture'
}, {
    name: 'Ultrasound breast abnormal'
}, {
    name: 'Ultrasound ovary abnormal'
}, {
    name: 'Umbilical hernia'
}, {
    name: 'Unable to walk'
}, {
    name: 'Uncircumcised'
}, {
    name: 'Uncontrolled hypertension'
}, {
    name: 'Underweight'
}, {
    name: 'Unexpected therapeutic effect'
}, {
    name: 'Unilateral renal agenesis'
}, {
    name: 'Unilateral vision loss'
}, {
    name: 'Unintended pregnancy'
}, {
    name: 'Unresponsive to stimuli'
}, {
    name: 'Unresponsive to verbal stimuli'
}, {
    name: 'Unrest'
}, {
    name: 'Unspecified circulatory system disorder'
}, {
    name: 'Unspecified condition originating in the perinatal period'
}, {
    name: 'Unspecified congenital anomaly of brain, spinal cord, and nervous system'
}, {
    name: 'Unspecified disorder of autonomic nervous system'
}, {
    name: 'Unspecified disorder of intestine'
}, {
    name: 'Unspecified disorder of skin and subcutaneous tissue'
}, {
    name: 'Unspecified non-gonococcal urethritis (NGU)'
}, {
    name: 'Unspecified visual loss'
}, {
    name: 'Unsteadiness'
}, {
    name: 'Unsteady gait'
}, {
    name: 'Unwanted awareness during anaesthesia'
}, {
    name: 'Unwell'
}, {
    name: 'Upper abdominal discomfort'
}, {
    name: 'Upper airway obstruction'
}, {
    name: 'Upper gastrointestinal haemorrhage'
}, {
    name: 'Upper gastrointestinal symptoms'
}, {
    name: 'Upper limb fracture'
}, {
    name: 'Upper limb oedema'
}, {
    name: 'Upper motor neurone lesion'
}, {
    name: 'Upper respiratory tract congestion'
}, {
    name: 'Upper respiratory tract infection'
}, {
    name: 'Upper respiratory tract inflammation'
}, {
    name: 'Upper respiratory tract signs and symptoms'
}, {
    name: 'Upper-airway cough syndrome'
}, {
    name: 'Upset stomach'
}, {
    name: 'Uraemic syndrome'
}, {
    name: 'Urate crystalluria'
}, {
    name: 'Urate nephropathy'
}, {
    name: 'Urea increased'
}, {
    name: 'Uremia'
}, {
    name: 'Ureteral spasm'
}, {
    name: 'Ureteric cancer'
}, {
    name: 'Ureteric obstruction'
}, {
    name: 'Ureteritis'
}, {
    name: 'Ureterostomy site discomfort'
}, {
    name: 'Urethral discharge'
}, {
    name: 'Urethral disorder'
}, {
    name: 'Urethral haemorrhage'
}, {
    name: 'Urethral obstruction'
}, {
    name: 'Urethral pain'
}, {
    name: 'Urethral stenosis'
}, {
    name: 'Urethral syndrome'
}, {
    name: 'Urethritis'
}, {
    name: 'Urethritis gonococcal'
}, {
    name: 'Urethritis noninfective'
}, {
    name: 'Urethritis nonspecific'
}, {
    name: 'Urge incontinence'
}, {
    name: 'Uric acid abnormal'
}, {
    name: 'Uric acid high'
}, {
    name: 'Uric acid increased'
}, {
    name: 'Uric acid level increased'
}, {
    name: 'Uricaciduria'
}, {
    name: 'Urinary abnormalities'
}, {
    name: 'Urinary bladder polyp'
}, {
    name: 'Urinary frequency aggravated'
}, {
    name: 'Urinary hesitation'
}, {
    name: 'Urinary incontinence'
}, {
    name: 'Urinary protein increased'
}, {
    name: 'Urinary retention'
}, {
    name: 'Urinary sediment abnormal'
}, {
    name: 'Urinary sediment present'
}, {
    name: 'Urinary tract disorder'
}, {
    name: 'Urinary tract infection'
}, {
    name: 'Urinary tract infection fungal'
}, {
    name: 'Urinary tract obstruction'
}, {
    name: 'Urinary tract pain'
}, {
    name: 'Urinary tract signs and symptoms'
}, {
    name: 'Urination impaired'
}, {
    name: 'Urine abnormality'
}, {
    name: 'Urine analysis abnormal'
}, {
    name: 'Urine calcium increased'
}, {
    name: 'Urine color abnormal'
}, {
    name: 'Urine drug screen positive'
}, {
    name: 'Urine electrolytes abnormal'
}, {
    name: 'Urine flow decreased'
}, {
    name: 'Urine ketone body present'
}, {
    name: 'Urine odour abnormal'
}, {
    name: 'Urine odour foul'
}, {
    name: 'Urine output'
}, {
    name: 'Urine output increased'
}, {
    name: 'Urine phosphate increased'
}, {
    name: 'Urine phosphorus increased'
}, {
    name: 'Urine sodium increased'
}, {
    name: 'Urogenital disorder'
}, {
    name: 'Urogenital haemorrhage'
}, {
    name: 'Urogenital trichomoniasis'
}, {
    name: 'Urolithiasis'
}, {
    name: 'Urosepsis'
}, {
    name: 'Urticaria'
}, {
    name: 'Urticaria chronic'
}, {
    name: 'Urticaria localised'
}, {
    name: 'Urticaria physical'
}, {
    name: 'Urticaria recurrent'
}, {
    name: 'Urticaria vesiculosa'
}, {
    name: 'Uterine atony'
}, {
    name: 'Uterine cancer'
}, {
    name: 'Uterine cervical erosion'
}, {
    name: 'Uterine cervical lesion'
}, {
    name: 'Uterine cervical squamous metaplasia'
}, {
    name: 'Uterine contractions'
}, {
    name: 'Uterine contractions during pregnancy'
}, {
    name: 'Uterine cramps'
}, {
    name: 'Uterine cyst'
}, {
    name: 'Uterine disorder'
}, {
    name: 'Uterine enlargement'
}, {
    name: 'Uterine fibroids aggravated'
}, {
    name: 'Uterine fibroids enlarged'
}, {
    name: 'Uterine haemorrhage'
}, {
    name: 'Uterine hypertonus'
}, {
    name: 'Uterine hypotonus'
}, {
    name: 'Uterine inflammation'
}, {
    name: 'Uterine leiomyoma'
}, {
    name: 'Uterine mass'
}, {
    name: 'Uterine neoplasm'
}, {
    name: 'Uterine pain'
}, {
    name: 'Uterine perforation'
}, {
    name: 'Uterine polyp'
}, {
    name: 'Uterine prolapse'
}, {
    name: 'Uterine relaxation'
}, {
    name: 'Uterine rupture'
}, {
    name: 'Uterine spasm'
}, {
    name: 'Uterovaginal prolapse'
}, {
    name: 'Uveitis'
}, {
    name: 'Vaccinia'
}, {
    name: 'Vaccinia virus infection'
}, {
    name: 'Vaginal burning sensation'
}, {
    name: 'Vaginal contraceptive device expelled'
}, {
    name: 'Vaginal cyst'
}, {
    name: 'Vaginal discharge'
}, {
    name: 'Vaginal discomfort'
}, {
    name: 'Vaginal disorder'
}, {
    name: 'Vaginal dryness'
}, {
    name: 'Vaginal dysplasia'
}, {
    name: 'Vaginal erosion'
}, {
    name: 'Vaginal erythema'
}, {
    name: 'Vaginal haemorrhage'
}, {
    name: 'Vaginal infection'
}, {
    name: 'Vaginal inflammation'
}, {
    name: 'Vaginal irritation'
}, {
    name: 'Vaginal itching'
}, {
    name: 'Vaginal moniliasis'
}, {
    name: 'Vaginal mucosal blistering'
}, {
    name: 'Vaginal mycosis'
}, {
    name: 'Vaginal neoplasm'
}, {
    name: 'Vaginal odour'
}, {
    name: 'Vaginal pain'
}, {
    name: 'Vaginal prolapse'
}, {
    name: 'Vaginal swelling'
}, {
    name: 'Vaginal ulceration'
}, {
    name: 'Vaginal wall congestion'
}, {
    name: 'Vaginal yeast'
}, {
    name: 'Vaginismus'
}, {
    name: 'Vaginitis atrophic'
}, {
    name: 'Vaginitis bacterial'
}, {
    name: 'Vaginitis gardnerella'
}, {
    name: 'Vaginitis ulcerative'
}, {
    name: 'Vagotonia'
}, {
    name: 'Vanishing bile duct syndrome'
}, {
    name: 'Variants of migraine'
}, {
    name: 'Varicella'
}, {
    name: 'Varicella zoster'
}, {
    name: 'Varices oesophageal'
}, {
    name: 'Varicocele'
}, {
    name: 'Varicose vein'
}, {
    name: 'Varicose veins vulval'
}, {
    name: 'Variegate porphyria'
}, {
    name: 'Vascular anomaly'
}, {
    name: 'Vascular calcification'
}, {
    name: 'Vascular dementia'
}, {
    name: 'Vascular graft occlusion'
}, {
    name: 'Vascular headache'
}, {
    name: 'Vascular hypertensive disorders'
}, {
    name: 'Vascular hypotensive disorders'
}, {
    name: 'Vascular insufficiency'
}, {
    name: 'Vascular occlusion'
}, {
    name: 'Vascular pain'
}, {
    name: 'Vascular pseudoaneurysm'
}, {
    name: 'Vascular purpura'
}, {
    name: 'Vascular resistance'
}, {
    name: 'Vascular resistance pulmonary increased'
}, {
    name: 'Vascular resistance systemic'
}, {
    name: 'Vascular resistance systemic decreased'
}, {
    name: 'Vascular rupture'
}, {
    name: 'Vascular stenosis'
}, {
    name: 'Vasculitic rash'
}, {
    name: 'Vasculitis'
}, {
    name: 'Vasculitis cerebral'
}, {
    name: 'Vasculitis gastrointestinal'
}, {
    name: 'Vasculitis necrotising'
}, {
    name: 'Vaso-occlusive crisis'
}, {
    name: 'Vasoconstriction'
}, {
    name: 'Vasoconstriction peripheral'
}, {
    name: 'Vasodilatation'
}, {
    name: 'Vasodilation'
}, {
    name: 'Vasodilation procedure'
}, {
    name: 'Vasomotor collapse'
}, {
    name: 'Vasomotor rhinitis'
}, {
    name: 'Vasospasm'
}, {
    name: 'Vasospasm cerebral'
}, {
    name: 'Vasovagal symptoms'
}, {
    name: 'Vegetarian'
}, {
    name: 'Vegetative dystonia'
}, {
    name: 'Vein discolouration'
}, {
    name: 'Vein disorder'
}, {
    name: 'Vein distended'
}, {
    name: 'Vein pain'
}, {
    name: 'Vena cava thrombosis'
}, {
    name: 'Venipuncture site bruise'
}, {
    name: 'Venipuncture site hemorrhage'
}, {
    name: 'Venomous bite'
}, {
    name: 'Venoocclusive disease'
}, {
    name: 'Venoocclusive liver disease'
}, {
    name: 'Venospasm'
}, {
    name: 'Venous insufficiency'
}, {
    name: 'Venous occlusion'
}, {
    name: 'Venous pressure increased'
}, {
    name: 'Venous pressure jugular increased'
}, {
    name: 'Venous thromboembolism'
}, {
    name: 'Venous thrombosis'
}, {
    name: 'Venous thrombosis deep limb'
}, {
    name: 'Venous thrombosis limb'
}, {
    name: 'Ventilator associated pneumonia'
}, {
    name: 'Ventricular aneurysm'
}, {
    name: 'Ventricular arrhythmia'
}, {
    name: 'Ventricular bigeminy'
}, {
    name: 'Ventricular dysfunction'
}, {
    name: 'Ventricular extrasystoles'
}, {
    name: 'Ventricular failure'
}, {
    name: 'Ventricular fibrillation'
}, {
    name: 'Ventricular flutter'
}, {
    name: 'Ventricular hypertrophy'
}, {
    name: 'Ventricular hypokinesia'
}, {
    name: 'Ventricular septal defect'
}, {
    name: 'Ventricular tachycardia'
}, {
    name: 'Ventriculitis'
}, {
    name: 'Vermiculation'
}, {
    name: 'Vernal conjunctivitis'
}, {
    name: 'Vertebrobasilar insufficiency'
}, {
    name: 'Vertical infection transmission'
}, {
    name: 'Vertigo'
}, {
    name: 'Vertigo CNS origin'
}, {
    name: 'Vertigo positional'
}, {
    name: 'Vesicoureteric reflux'
}, {
    name: 'Vesiculobullous rash'
}, {
    name: 'Vessel perforation'
}, {
    name: 'Vessel puncture site bruise'
}, {
    name: 'Vessel puncture site haematoma'
}, {
    name: 'Vessel puncture site haemorrhage'
}, {
    name: 'Vessel puncture site inflammation'
}, {
    name: 'Vestibular ataxia'
}, {
    name: 'Vestibular disorder'
}, {
    name: 'Vestibular neuronitis'
}, {
    name: 'Vestibular toxicity'
}, {
    name: 'Victim of sexual abuse'
}, {
    name: 'VIIth nerve paralysis'
}, {
    name: 'Violence'
}, {
    name: 'Violent'
}, {
    name: 'Violent behavior'
}, {
    name: 'Vipoma'
}, {
    name: 'Viraemia'
}, {
    name: 'Viral diarrhoea'
}, {
    name: 'Viral infection'
}, {
    name: 'Viral infections NEC'
}, {
    name: 'Viral pharyngitis'
}, {
    name: 'Viral skin infection'
}, {
    name: 'Viral syndrome'
}, {
    name: 'Viral upper respiratory tract infection'
}, {
    name: 'Virilism'
}, {
    name: 'Visceral larva migrans'
}, {
    name: 'Visceral leishmaniasis'
}, {
    name: 'Visceral pain'
}, {
    name: 'Vision blurred'
}, {
    name: 'Vision decreased'
}, {
    name: 'Visual acuity reduced'
}, {
    name: 'Visual brightness'
}, {
    name: 'Visual colour distortions'
}, {
    name: 'Visual disturbance'
}, {
    name: 'Visual evoked potentials abnormal'
}, {
    name: 'Visual field constriction'
}, {
    name: 'Visual impairment'
}, {
    name: 'VIth nerve paralysis'
}, {
    name: 'Vital dye staining cornea present'
}, {
    name: 'Vitamin A deficiency'
}, {
    name: 'Vitamin B complex deficiency'
}, {
    name: 'Vitamin B1 deficiency'
}, {
    name: 'Vitamin B12 absorption decreased'
}, {
    name: 'Vitamin B12 deficiency'
}, {
    name: 'Vitamin B6 deficiency'
}, {
    name: 'Vitamin C deficiency'
}, {
    name: 'Vitamin D deficiency'
}, {
    name: 'Vitamin E decreased'
}, {
    name: 'Vitamin E deficiency'
}, {
    name: 'Vitamin K decreased'
}, {
    name: 'Vitamin K deficiency'
}, {
    name: 'Vitiligo'
}, {
    name: 'Vitreous detachment'
}, {
    name: 'Vitreous disorder'
}, {
    name: 'Vitreous floaters'
}, {
    name: 'Vitreous haemorrhage'
}, {
    name: 'Vitreous opacities'
}, {
    name: 'Vitreous prolapse'
}, {
    name: 'Vivax malaria'
}, {
    name: 'Vivid dreams'
}, {
    name: 'Vocal cord disorder'
}, {
    name: 'Vocal cord paralysis'
}, {
    name: 'Vocal cord paresis'
}, {
    name: 'Vocal tic'
}, {
    name: 'Vogt-Koyanagi-Harada syndrome'
}, {
    name: 'Voice disturbance'
}, {
    name: 'Volume blood increased'
}, {
    name: 'Volume plasma increased'
}, {
    name: 'Volvulus'
}, {
    name: 'Vomiting'
}, {
    name: 'Vomiting aggravated'
}, {
    name: 'Vomiting in pregnancy'
}, {
    name: 'Vomiting neonatal'
}, {
    name: "Von Willebrand's disease"
}, {
    name: 'VT'
}, {
    name: 'Vulva discomfort'
}, {
    name: 'Vulval abscess'
}, {
    name: 'Vulval disorder'
}, {
    name: 'Vulval erythema'
}, {
    name: 'Vulval leukoplakia'
}, {
    name: 'Vulval ulceration'
}, {
    name: 'Vulvitis'
}, {
    name: 'Vulvovaginal atrophy'
}, {
    name: 'Vulvovaginal burning sensation'
}, {
    name: 'Vulvovaginal candidiasis'
}, {
    name: 'Vulvovaginal discomfort'
}, {
    name: 'Vulvovaginal disorder'
}, {
    name: 'Vulvovaginal dryness'
}, {
    name: 'Vulvovaginal erythema'
}, {
    name: 'Vulvovaginal mycotic infection'
}, {
    name: 'Vulvovaginal pain'
}, {
    name: 'Vulvovaginal pruritus'
}, {
    name: 'Vulvovaginal swelling'
}, {
    name: 'Vulvovaginitis'
}, {
    name: 'Vulvovaginitis trichomonal'
}, {
    name: 'Waist circumference increased'
}, {
    name: 'Wakefulness'
}, {
    name: "Waldenstrom's macroglobulinaemia"
}, {
    name: 'Walking disability'
}, {
    name: 'Wandering pacemaker'
}, {
    name: 'Warm type haemolytic anaemia'
}, {
    name: 'Warmth'
}, {
    name: 'Warts'
}, {
    name: 'Wasting generalized'
}, {
    name: 'Water intoxication'
}, {
    name: 'Water retention'
}, {
    name: 'Watery diarrhoea'
}, {
    name: 'Wave slowing'
}, {
    name: 'Waxy flexibility'
}, {
    name: 'WBC abnormal NOS'
}, {
    name: "Wegener's granulomatosis"
}, {
    name: 'Weight decreased'
}, {
    name: 'Weight fluctuation'
}, {
    name: 'Weight gain poor'
}, {
    name: 'Weight increased'
}, {
    name: 'Welts'
}, {
    name: 'Wenckebach phenomenon'
}, {
    name: "Wernicke's encephalopathy"
}, {
    name: 'Wernicke-Korsakoff syndrome'
}, {
    name: 'Wheezing'
}, {
    name: 'Wheezing expiratory'
}, {
    name: 'Wheezing inspiratory'
}, {
    name: 'Whiplash injury'
}, {
    name: 'White blood cell count abnormal'
}, {
    name: 'White blood cell count decreased'
}, {
    name: 'White blood cell count increased'
}, {
    name: 'White blood cell count low'
}, {
    name: 'White blood cell disorder'
}, {
    name: 'White blood cells urine positive'
}, {
    name: 'White matter lesion'
}, {
    name: 'Whooping cough'
}, {
    name: 'Wide complex tachycardia'
}, {
    name: 'Withdrawal bleed'
}, {
    name: 'Withdrawal emotional'
}, {
    name: 'Withdrawal hypertension'
}, {
    name: 'Withdrawal seizures'
}, {
    name: 'Withdrawal symptom'
}, {
    name: 'Withdrawal syndrome'
}, {
    name: 'Wolff-Parkinson-White syndrome'
}, {
    name: 'Word finding difficulty'
}, {
    name: 'Worry'
}, {
    name: 'Worsening of diabetes'
}, {
    name: 'Wound'
}, {
    name: 'Wound complication'
}, {
    name: 'Wound dehiscence'
}, {
    name: 'Wound discharge increased'
}, {
    name: 'Wound haematoma'
}, {
    name: 'Wound haemorrhage'
}, {
    name: 'Wound healing normal'
}, {
    name: 'Wound infection'
}, {
    name: 'Wound secretion'
}, {
    name: 'Wound sepsis'
}, {
    name: 'Wrist drop'
}, {
    name: 'Wrist fracture'
}, {
    name: 'Writing impaired'
}]