## Requirements

* python 3 
* nodejs

## Installation 

### Download repository

```bash
git clone https://github.com/DSC-ENSB/DRUGOC-project.git && cd DRUGOC-project
```

### Install packages

```bash
npm run requirements
```

### Start project

```bash
npm start
```

> note: you should read this file [SEE](/README.md)